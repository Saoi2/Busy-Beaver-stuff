"""Global exclusion of a boundary in any alleged halting history."""
def add_skelet10_boundary_exclusion(m,api,h,assembly,bd,progress,maximum,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,Q,L=m.A,m.Q,m.L;Z,O=m.Z,m.O
 H,N,o,k=[h[x] for x in ('H','n','offset','start')];AT=h['AT'];cf=api['current'];halt=assembly['halt']
 apply,unpack,pack_rows,elim_rows,bounds=[assembly[x] for x in ('apply','unpack','pack_rows','elim_rows','bounds')]
 P=maximum['P'];mv=maximum['greatest'];scan=maximum['scan'];iv=maximum['index'];inp=maximum['input'];prow=maximum['row']
 gi,ni,ei=[m.declare('excludeBoundary'+s) for s in ('GreatestIndex','Input','LaterIndex')]
 old=[m.declare('excludeBoundaryOld'+s) for s in ('Q','L','Bit','R')]
 new=[m.declare('excludeBoundaryNew'+s) for s in ('Q','L','Bit','R')]
 common=[h['total'](o,N),h['steps'](o,N),*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5))]
 prem=nd.AND([*common,maximum['nonempty'](N)]);bad=L(Z,Z)
 def prove():
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,[*common,maximum['nonempty'](N)])
  m.invoke(c,'skelet17-ladder-skelet10-boundary-index-maximum')
  def have_maximum(dc):
   nd.unpack(dc,[P(gi),maximum['body'](N,gi)[2]])
   def have_input(ec):
    oldbody=b.And(AT(o,gi,prow),bd['boundary'](ni,prow))
    def have_old(fc):
     unpack(fc,b.And(AT(o,gi,old),bd['boundary'](ni,old)))
     mapping={progress['input'][1]:ni,k[1]:gi,**{x[1]:y for x,y in zip(cf,old)}}
     apply(fc,'skelet17-ladder-skelet10-boundary-progress',mapping)
     pi,pr=progress['output_index'],progress['output_row']
     def nextbody(i,row):return nd.AND([L(gi,i),AT(o,i,row),bd['boundary'](old[3],row)])
     def have_index(gc):
      def have_new(hc):
       unpack(hc,nextbody(ei,new))
       hc.both(AT(o,ei,new),bd['boundary'](old[3],new))
       pack_rows(hc,prow,b.And(AT(o,ei,prow),bd['boundary'](old[3],prow)),new)
       m.bex_intro(hc,inp,H,nd.bexs(prow,H,b.And(AT(o,ei,prow),bd['boundary'](inp,prow))),old[3])
       universal=maximum['body'](N,gi)[2]
       hc.all_elim(scan,universal[2],ei);hc.mp(L(ei,A(N,O)),b.Imp(P(ei),L(ei,A(gi,O))));hc.mp(P(ei),L(ei,A(gi,O)))
       apply(hc,'skelet17-binary-below-successor',{'t':ei,'u':gi})
       def contradiction(jc,j):
        if not j:m.translt(jc,gi,ei,gi)
        else:m.rewrite(jc,L(gi,ar.E),ei,gi)
        jc.put(b.Not(L(gi,gi)),b.ax('O1',jc.g,t=gi));return jc.explode(L(gi,gi),bad)
       return nd.cases(hc,[L(ei,gi),Q(ei,gi)],bad,contradiction)
      return elim_rows(gc,pr,nextbody(ei,pr),new,bad,have_new)
     return m.bex_elim(fc,pi,A(N,O),nd.bexs(pr,H,nextbody(pi,pr)),ei,bad,have_index)
    return elim_rows(ec,prow,oldbody,old,bad,have_old)
   return m.bex_elim(dc,inp,H,nd.bexs(prow,H,b.And(AT(o,gi,prow),bd['boundary'](inp,prow))),ni,bad,have_input)
  m.bex_elim(c,mv,A(N,O),maximum['body'](N,mv),gi,bad,have_maximum)
  c.put(b.Not(bad),b.ax('O1',c.g,t=Z));root.put(b.Not(prem),ar.not_intro(root.g,prem,bad,c.get(bad),c.get(b.Not(bad))))
  m.save('skelet17-ladder-skelet10-no-halting-history-with-boundary',root,b.Not(prem),'A supplied total ordinary history ending in halt cannot contain any canonical boundary below its original length. Greatest-index induction plus general progress; invariant predicates are proof tools, not history annotations.')
 if proofs:prove()
 return {'common':common,'prem':prem,'conclusion':b.Not(prem)}
