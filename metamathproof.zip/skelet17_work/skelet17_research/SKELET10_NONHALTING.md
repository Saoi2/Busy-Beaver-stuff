# Skelet #10: the complete nonhalting argument

The final public target is
**skelet17-ladder-skelet10-no-blank-halting-history**.
The precise kernel status and canonical source hash are recorded in
ladder_verification.log, simplification_report.json, and
streaming_audit_report.json. Generation and statement reconstruction alone
are not proof verification.

## Machine, configurations, and the statement

The machine is **1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB**.
States A,B,C,D,E are numbered 0,1,2,3,4; halt Z is 5. The E0
halting transition is completed by 1RZ, including its write and move.

A configuration is (q,L,s,R). L and R encode the two half tapes as
binary integers, with the bit nearest the head least significant. The
currently scanned bit s is separate. Thus the all-zero initial tape
and initial state are exactly (0,0,0,0). A right move writing e satisfies
L'=2L+e and R=2R'+s'; a left move satisfies R'=2R+e and L=2L'+s'.
Each ordinary Step clause explicitly requires s'=0 or s'=1. No phase,
counter, transform, or invariant is part of Step.

Four quotient-and-remainder codes supply the coordinates at each index:

    beta_j(k,x) := exists u<H:
        B_j=u*(1+(k+1)*C_j)+x and x<1+(k+1)*C_j.

At_o(i,c) is the conjunction of these four assertions at absolute index
o+i. TOTAL says that every i<N+1 has a decoded quadruple with all four
coordinates below H. STEPS says that every pair of bounded decoded rows
at consecutive indices i,i+1, for i<N, satisfies ordinary Step.

The blank-initial condition universally states that every bounded
decoded row at local index 0 equals (0,0,0,0). The final-halt condition
gives a bounded decoded row at N whose state is 5. The final theorem
negates the conjunction of TOTAL, STEPS, blank initial condition, and
final-halt condition. The parameter o permits a shifted window; o=0 is
the ordinary blank-start statement. Universal closure over the supplied
numerical parameters rules out every such halting history. The theorem
does not assert totality of history coding, or existence of arbitrarily
long coded runs.

## The boundary invariant is only a proof tool

Write W=2L+s. Sparse(x) is the bounded formula saying that x has no
adjacent 1 bits. T(x,t) is the previously defined bounded transform
graph, with standard interpretation t=10*Spread(x), where Spread moves
the bit at binary place 2^i to place 4^i. J(x,y) is the bounded carry
graph:

    exists p<3x+2 exists a<x+1 exists z<x+1:
        Pow2(p), p=3a+1, x=p*(2z)+a, y=p*(4z+1).

These standard interpretations explain the graphs; the proof uses their
first-order definitions and proved constructors/inverses. It assumes
neither transform uniqueness nor transform totality.

Boundary(n,c) says q=D, s<2, Sparse(n), Sparse(R), and one of:

- An even clause: exists a<n+1 with n=2a, T(a,W), J(a,R).
- An odd clause: exists a<n+1, t<W+1, v<R+1 with
  n=4a+1, W=4t+2, T(a,t), R=2v, J(a,v).

All these quantifiers are bounded. Boundary is derived from ordinary
decoded rows; it is not an extra hypothesis of the final nonhalting
statement or an annotation supplied with the history.

## General progress

The theorem **skelet17-ladder-skelet10-boundary-progress** says: inside
an alleged total history ending in halt, a bounded decoded boundary at
k<N+1 produces a bounded decoded boundary at some e<N+1 with k<e.
The new numerical input is the old coordinate R, so it is below H.

It combines the three previously proved numerical cases. In the odd
clause, apply the odd boundary theorem directly. In the even clause,
Sparse(n) and n=2a give Sparse(a). Divide a=2b+d with d<2. If d=0,
n=4b. If d=1, Sparse(2b+1) forces b to be even; writing b=2c gives
n=8c+2. The corresponding even-case theorem applies. All division and
parity witnesses are eliminated, leaving no numerical case assumption.

Each case constructs actual successor rows and actual counter outputs
inside the original supplied history. No case assumes a sufficiently
long window. History advancement and the embedded counter barriers
prove the required existence, including for short alleged halting runs.
The three case documents give the detailed machine calculations.

## The one additional induction

Fix the original codes, H, offset o, and length N. Define

    P(i) := exists n<H exists c_0<H ... exists c_3<H:
        At_o(i,c) and Boundary(n,c).

The new bounded-induction instance has induction variable t and formula

    (exists i<t+1 P(i)) ->
      exists m<t+1 (P(m) and
        forall j<t+1 (P(j) -> j<m+1)).

This is a Delta-0 formula: P and every newly displayed quantifier are
bounded. At t=0, the sole possible index is 0. At the successor, either
P(t+1) holds, making the new top point greatest, or it fails and the old
maximum remains greatest. The proof handles the empty-set case through
the antecedent, rather than assuming a maximum exists. Fresh variables
and a separately proved binder-renaming deduction meet the kernel's
universal-introduction conditions.

The resulting theorem is
**skelet17-ladder-skelet10-boundary-index-maximum**. No maximum principle
is added as an axiom.

## Global contradiction and blank start

Suppose an alleged halting history has at least one boundary index.
The maximum theorem gives a greatest such index m. General progress
constructs another boundary at e with m<e and e<N+1. The defining maximum
property gives e<m+1, contradicting m<e in a discrete ordered semiring.
The derived theorem is
**skelet17-ladder-skelet10-no-halting-history-with-boundary**.

Finally, TOTAL supplies an actual initial row. The blank condition
identifies its four coordinates with 0. An actual A0 step enters the
right routine with input 0 and left target 0. Its embedded barrier
constructs an actual D output with W=0, J(0,R), Sparse(R), and s<2.
T(0,0), Sparse(0), and the even-boundary constructor give Boundary(0,row).
The initial row's bounds imply 0<H, so this is an instance of P at a
bounded index. Global exclusion gives a contradiction. Every temporary
row, boundary input, counter output and index witness is discharged.

## Strength, organization, and limits

The final dependency closure uses five bounded-induction constructions:
bounded division, left-routine history induction, right-routine history
induction, Sparse carry uniqueness, and the new bounded maximum argument.
This describes this proof's dependencies; it is not a lower bound on
the strength needed to prove nonhalting.

All active mathematical proofs are in **idelta0_machines.mm**, over the
same 93 trusted declarations. The new generator bootstrap and scoping
tools are untrusted conveniences; the official Metamath kernel checks
the resulting deductions. Independent checkers reconstruct all four new
public formulas, including the final ordinary blank-start statement.
An exact-interface audit checks previous interfaces and the trusted core;
the dependency audit checks the five-induction bound and the single new
induction construction.

This is one machine's nonhalting theorem. It proves neither a complete
Busy Beaver value nor Skelet #17 nonhalting, and gives no independence
or minimal-strength result. See STATUS.md for the current verified state.
