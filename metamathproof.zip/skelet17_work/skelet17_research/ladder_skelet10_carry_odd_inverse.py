"""Recursive odd-input carry inversion, with all witness bounds explicit."""
def add_skelet10_carry_odd_inverse(m,right,api):
 nd,b=m.nd,m.b;A,M,Q,L=m.A,m.M,m.Q,m.L;O,Z=m.O,m.Z;use=m.invoke
 two,three,four=map(m.a.num,(2,3,4));x,y=b.t,b.u;xx=A(M(four,x),O);carry=right['carry']
 jp,js,ja=right['jp'],right['js'],right['ja']
 ep,es,ea,h1,h,q,d,v=[m.declare('syncOdd'+n) for n in ('P','S','A','Half','Quarter','Quotient','Digit','Output')]
 def cp(w,z,p,s,a):return [m.power2(p),Q(p,A(M(three,s),O)),Q(w,A(M(p,M(two,a)),s)),Q(z,M(p,A(M(four,a),O)))]
 goal=nd.BEX(v,A(y,O),b.And(Q(y,M(four,v)),carry(x,v)))
 if 'z10-right-prefix-bounds' not in m.theorems:right['prefix_bounds']()
 def finite(c,val,n,fn):
  top,below=m.a.num(n),m.a.num(n-1)
  if n==1:
   m.eq(c,O,A(Z,O));m.rewrite(c,L(val,m.a.E),O,A(Z,O))
  use(c,'skelet17-binary-below-successor',{'t':val,'u':below})
  def branch(dc,k):
   if k:return fn(dc,n-1)
   if n>1:return finite(dc,val,n-1,fn)
   dc.put(b.Not(L(val,Z)),b.ax('O4',dc.g,t=val));return dc.explode(L(val,Z),goal)
  return nd.cases(c,[L(val,below),Q(val,below)],goal,branch)
 root=nd.Ctx();prem=carry(xx,y);c=root.push(prem)
 def pfound(pc):
  def sfound(sc):
   def afound(ac):
    fs=cp(xx,y,ep,es,ea);nd.unpack(ac,fs)
    def exception(dc,n):
     m.eq(dc,A(M(three,es),O),A(M(three,Z),m.a.num(n)),[m.flip(dc,fs[1]),Q(ep,m.a.num(n))])
     m.bound(dc,O,three,O);m.bound(dc,m.a.num(n),three,m.a.num(2-n));m.quotient_unique(dc,three,es,O,Z,m.a.num(n))
     if n==2:
      dc.put(Q(O,O),b.refl(dc.g,O));return api['neq'](dc,O,1,2,goal)
     ee=Q(xx,A(M(two,ea),Z));m.eq(dc,*ee[1:],[fs[2],Q(es,Z),Q(ep,O)])
     m.eq(dc,A(M(two,M(two,x)),O),A(M(two,ea),Z),[m.flip(dc,ee)])
     m.bound(dc,O,two,Z);m.bound(dc,Z,two,O);m.quotient_unique(dc,two,M(two,x),O,ea,Z)
     m.flip(dc,Q(O,Z));return m.false_zero_one(dc,goal)
    def quarter(kc):
     # p=2h1 and h1=2h; h is an existing Pow2 witness.
     pe=Q(ep,M(four,h));m.eq(kc,*pe[1:],[Q(ep,M(two,h1)),Q(h1,M(two,h))])
     m.bound(kc,Z,four,three);use(kc,'skelet17-bounded-division-exists',{'t':es,'u':four})
     def quotient(qc):
      def digit(rc):
       se=Q(es,A(M(four,q),d))
       def case(dc,k):
        de=Q(d,m.a.num(k));a0,r0=divmod(3*k+1,4);tail=A(M(three,q),m.a.num(a0))
        m.eq(dc,A(M(four,h),Z),A(M(four,tail),m.a.num(r0)),[m.flip(dc,pe),fs[1],se,de])
        m.bound(dc,Z,four,three);m.bound(dc,m.a.num(r0),four,m.a.num(3-r0));m.quotient_unique(dc,four,h,Z,tail,m.a.num(r0))
        if k!=1:
         dc.put(Q(Z,Z),b.refl(dc.g,Z));return api['neq'](dc,Z,0,r0,goal)
        he=Q(h,A(M(three,q),O));m.eq(dc,es,A(M(four,q),O),[se,de])
        xe=Q(x,A(M(h,M(two,ea)),q))
        m.eq(dc,A(M(four,x),O),A(M(four,xe[2]),O),[fs[2],pe,Q(es,A(M(four,q),O))])
        m.bound(dc,O,four,two);m.quotient_unique(dc,four,x,O,xe[2],O)
        z=M(h,A(M(four,ea),O));ye=Q(y,M(four,z));m.eq(dc,*ye[1:],[fs[3],pe])
        dc.both(he,xe);use(dc,'z10-right-prefix-bounds',{'t':h,'u':q,'v':x,'w':M(two,ea)})
        nd.unpack(dc,[L(h,A(M(three,x),two)),L(q,A(x,O)),L(M(two,ea),A(x,O))])
        m.bound(dc,ea,A(M(two,ea),O),ea);dc.both(L(ea,A(M(two,ea),O)),L(M(two,ea),A(x,O)));use(dc,'skelet17-binary-le-lt-trans',{'t':ea,'u':M(two,ea),'v':A(x,O)})
        dc.put(Q(z,z),b.refl(dc.g,z));nd.conj(dc,cp(x,z,h,q,ea))
        m.bex_intro(dc,ja,A(x,O),nd.AND(cp(x,z,h,q,ja)),ea)
        m.bex_intro(dc,js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(x,z,h,js,ja))),q)
        m.bex_intro(dc,jp,A(M(three,x),two),nd.BEX(js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(x,z,jp,js,ja)))),h)
        m.bound(dc,z,A(y,O),M(three,z),[ye]);dc.both(ye,carry(x,z));return m.bex_intro(dc,v,A(y,O),b.And(Q(y,M(four,v)),carry(x,v)),z)
       return finite(rc,d,4,case)
      return m.bex_elim(qc,m.r,four,Q(es,A(M(four,q),m.r)),d,goal,digit)
     return m.bex_elim(kc,m.q,A(es,O),nd.BEX(m.r,four,Q(es,A(M(four,m.q),m.r))),q,goal,quotient)
    use(ac,'skelet17-binary-power-halving',{'t':ep});half=nd.BEX(m.pz,A(ep,O),b.And(Q(ep,M(two,m.pz)),m.power2(m.pz)))
    def scale(dc,k):
     if k==0:return exception(dc,1)
     def half_found(hc):
      nd.unpack(hc,[Q(ep,M(two,h1)),m.power2(h1)]);use(hc,'skelet17-binary-power-halving',{'t':h1})
      half2=nd.BEX(m.pz,A(h1,O),b.And(Q(h1,M(two,m.pz)),m.power2(m.pz)))
      def second(ec,j):
       if j==0:
        m.eq(ec,ep,two,[Q(ep,M(two,h1)),Q(h1,O)]);return exception(ec,2)
       def found(qc):nd.unpack(qc,[Q(h1,M(two,h)),m.power2(h)]);return quarter(qc)
       return m.bex_elim(ec,m.pz,A(h1,O),b.And(Q(h1,M(two,m.pz)),m.power2(m.pz)),h,goal,found)
      return nd.cases(hc,[Q(h1,O),half2],goal,second)
     return m.bex_elim(dc,m.pz,A(ep,O),b.And(Q(ep,M(two,m.pz)),m.power2(m.pz)),h1,goal,half_found)
    return nd.cases(ac,[Q(ep,O),half],goal,scale)
   return m.bex_elim(sc,ja,A(xx,O),nd.AND(cp(xx,y,ep,es,ja)),ea,goal,afound)
  return m.bex_elim(pc,js,A(xx,O),nd.BEX(ja,A(xx,O),nd.AND(cp(xx,y,ep,js,ja))),es,goal,sfound)
 m.bex_elim(c,jp,A(M(three,xx),two),nd.BEX(js,A(xx,O),nd.BEX(ja,A(xx,O),nd.AND(cp(xx,y,jp,js,ja)))),ep,goal,pfound)
 m.finish('skelet17-ladder-skelet10-carry-prefix-inverse',root,prem,goal,c,'Recursive carry inversion with a bounded smaller output witness. Reuses division and Pow2 halving; no new induction construction.')
