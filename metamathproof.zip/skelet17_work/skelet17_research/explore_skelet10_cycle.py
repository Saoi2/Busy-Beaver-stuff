"""Untrusted checks of three cases joining the proved counter contracts.

This is a development experiment, not a formal global invariant or a
Metamath proof. It never changes the machine relation or history format.
"""
from pathlib import Path
import json
from check_skelet10_left import raw_step
from check_skelet10_spread import spread
from check_skelet10_right import sparse_num,jval
P=Path(__file__).resolve().parent
def T(x):return 10*spread(x)
def J(x):return jval(x)[0]
def I(n):return J(n//2) if n%2==0 else 2*J(n//4)
def canonical(n):
 assert sparse_num(n)
 wl=T(n//2) if n%2==0 else 4*T(n//4)+2
 return (3,wl//2,wl%2,I(n))
def advance(c,k):
 for _ in range(k):c=raw_step(c)
 return c

def main():
 counts={'even_even':0,'even_odd':0,'odd':0};moves=0;examples=[]
 for n in range(1024):
  if not sparse_num(n):continue
  initial=canonical(n);c=initial;target=canonical(I(n));events=[];elapsed=0
  def walk(k,name):
   nonlocal c,elapsed,moves
   c=advance(c,k);elapsed+=k;moves+=k;events.append({'part':name,'step':elapsed,'row':c})
  def left(w,r):
   nonlocal c,elapsed,moves
   assert c[0]==3 and 2*c[1]+c[2]==T(w) and c[3]==4*r+3
   end=(0,T(J(w)),r%2,r//2);k=0
   while c!=end:
    assert c[0]!=5;c=raw_step(c);k+=1;assert k<32*w+24
   elapsed+=k;moves+=k;events.append({'part':'complete_left','step':elapsed,'row':c})
  def right(w,ell):
   nonlocal c,elapsed,moves
   assert c[0]==1 and c[1]==2*ell+1 and 2*c[3]+c[2]==w
   endword=ell;v=J(w);k=0
   while not (c[0]==3 and 2*c[1]+c[2]==endword and c[3]==v):
    assert c[0]!=5;c=raw_step(c);k+=1;assert k<20*w+18
   elapsed+=k;moves+=k;events.append({'part':'complete_right','step':elapsed,'row':c})
  if n%2:
   counts['odd']+=1;a=n//4;v=J(a);r=2*v
   walk(2,'D0_C1_alignment');left(a,r)
   assert c==(0,T(v),0,v)
   walk(1,'A0_to_B');right(v,T(v))
  elif (n//2)%2==0:
   counts['even_even']+=1;b=n//4;r=4*b+1;assert I(n)==r
   walk(4,'zero_boundary_exit')
   assert c==(0,8*T(b)+5,0,b)
   walk(1,'A0_to_B');right(b,8*T(b)+5);walk(1,'D1_alignment')
  else:
   counts['even_odd']+=1;b=n//8;v=J(b);r=4*v;assert I(n)==r
   walk(4,'four_step_carry');left(b,4*r+3)
   assert c==(0,T(v),1,2*r+1)
   walk(2,'two_A1_clear');assert c==(0,T(2*v),0,r//2)
   walk(1,'A0_to_B');right(2*v,T(2*v))
  assert c==target,(n,c,target)
  if n in (0,1,2,4,5,8):examples.append({'input':n,'next_input':I(n),'initial':initial,'final':c,'moves':elapsed,'events':events})
 out={'experimental_only':True,'formal_global_nonhalting_claim':False,'cases':sum(counts.values()),'branch_cases':counts,'ordinary_steps':moves,'all_three_branch_compositions_match':True,'examples':examples}
 (P/'skelet10_cycle_experiment.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='examples'})
if __name__=='__main__':main()
