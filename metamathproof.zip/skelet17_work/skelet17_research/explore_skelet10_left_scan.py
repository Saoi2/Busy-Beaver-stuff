"""Untrusted numerical check of the proposed full left-counter phase rank."""
from pathlib import Path
import json
from check_skelet10_left import raw_step
from check_skelet10_spread import spread
from check_skelet10_right import jval,sparse_num
PTH=Path(__file__).resolve().parent
def T(x):return 10*spread(x)
def main():
 cases=steps=0;examples=[]
 for w in range(256):
  if not sparse_num(w):continue
  v,_,_,_=jval(w)
  for rtail in range(4):
   l0=T(w);c=(3,l0//2,l0%2,4*rtail+3);p=1;s=0;u=w;a=t=None;j=0;h=word=None;half=0;elapsed=0;last_rank=None;trace=[];K=8*(3*w+2)
   while True:
    q,l,b,r=c;wl=2*l+b;wr=2*r+b
    if j==0:
     assert q==3 and T(u)==wl and sparse_num(u) and r+1==4*p*p*(rtail+1)
     rho=K+8*u+8
    elif j in (1,2,3,4):
     assert u==2*a and T(a)==t and sparse_num(a)
     assert (q,b)==[(2,0),(4,1),(1,1),(0,1)][j-1]
     assert l==[t,2*t+1,4*t+2,8*t+5][j-1]
     assert r+1==[8,4,2,1][j-1]*p*p*(rtail+1)
     rho=K+8*u+(8-j)
    elif j in (5,6,7):
     assert u==4*a+1 and T(a)==t and sparse_num(a)
     assert (q,b)==[(2,1),(3,0),(2,1)][j-5]
     assert l==[4*t+2,2*t+1,t][j-5]
     assert r+1==[8,16,32][j-5]*p*p*(rtail+1)
     rho=K+8*u+[7,6,5][j-5]
    else:
     assert q==0 and h<=3*w+1 and word<=v and sparse_num(word)
     if not half:assert T(word)==l and h*word==v and wr+1==h*h*(rtail+1)
     else:assert T(encword)==et and l==2*et and 2*h*encword==v and wr+1==2*h*h*(rtail+1)
     rho=2*h+half
    if j<8:
     assert p==3*s+1 and w==p*u+s and p<3*w+2 and s<=w and u<=w
    assert rho>0 and elapsed+rho<=32*w+24
    if last_rank is not None:assert rho<last_rank
    if w in (0,1,5) and rtail==0:trace.append({'step':elapsed,'phase':j,'configuration':c,'rank':rho})
    if q==0 and wr==rtail and l==T(v):break
    nxt=raw_step(c);last_rank=rho
    if j==0:
     if u%2==0:a=u//2;t=T(a);j=1
     else:assert u%4==1;a=u//4;t=T(a);j=5
    elif j in (1,2,3):j+=1
    elif j==4:j=8;h=p;word=4*a+1;assert p*word==v
    elif j in (5,6):j+=1
    elif j==7:p*=4;s=4*s+1;u=a;j=0
    elif not half:encword=word;et=l;h//=2;half=1
    else:word=2*encword;half=0
    c=nxt;elapsed+=1;steps+=1
   cases+=1
   if trace:examples.append({'input':w,'output':v,'right_tail':rtail,'steps':elapsed,'trace':trace})
 result={'experimental_only':True,'simulation_is_formal_proof':False,'cases':cases,'ordinary_steps':steps,'proposed_rank_passes':True,'examples':examples}
 (PTH/'skelet10_left_scan_experiment.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='examples'})
if __name__=='__main__':main()
