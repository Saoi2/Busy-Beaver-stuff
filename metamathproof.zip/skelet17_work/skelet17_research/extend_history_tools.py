from pathlib import Path
import json
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_history_tools import add_history_tools
m=r.m;P=Path(__file__).resolve().parent;old=set(m.theorems)
m.nd.OUTPUT_PREFIX='ladder-history-tools-';m.a.OUTPUT_PREFIX='ladder-history-tools-'
api=add_skelet10(m,proofs=False);add_history_tools(m,api)
with (P/'history_tools_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'history_tools_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Shared history tools generated.',flush=True)
