"""Finite routine alignments, proved only from the ordinary Step relation.

Private one-step contracts are shared by the two-step compositions. Nothing
here assumes existence of an entire run or adds a phase to its encoding.
"""
def add_skelet10_alignments(m,api,right,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 two,three,four=map(ar.num,(2,3,4));cf,nf=api['current'],api['next'];step=api['step'];use=m.invoke
 t=b.t
 mid=[m.declare('z10AlignMiddle'+s,'term') for s in ('Q','L','Bit','R')]
 def wl(c):return A(M(two,c[1]),c[2])
 def wr(c):return A(M(two,c[3]),c[2])
 def collect(ctx,f):
  if f[0]=='/\\':collect(ctx,f[1]);collect(ctx,f[2]);return ctx.both(f[1],f[2])
  return ctx.get(f)
 def apply(ctx,label,mapping):
  f=m.sub(m.theorems[label],mapping);collect(ctx,f[1]);use(ctx,label,mapping)
  def unpack(g):
   if g[0]=='/\\':nd.unpack(ctx,[g[1],g[2]]);unpack(g[1]);unpack(g[2])
  unpack(f[2]);return f[2]
 def single(kind):
  # The whole word determines the scanned bit because the instruction
  # itself supplies a binary read bit. No extra tape premise is needed.
  if kind=='d0':
   state,read,known,whole=3,0,A(M(two,t),O),wl
   source=A(M(four,t),two)
   out=[Q(nf[0],two),Q(wl(nf),A(M(two,t),O)),Q(nf[3],A(M(two,cf[3]),O)),L(nf[2],two)]
  elif kind=='c1':
   state,read,known,whole=2,1,t,wl;source=A(M(two,t),O)
   out=[Q(nf[0],three),Q(wl(nf),t),Q(nf[3],A(M(two,cf[3]),O)),L(nf[2],two)]
  else:
   state,read,known,whole=0,1,t,wr;source=A(M(two,t),O)
   out=[Q(nf[0],Z),Q(nf[1],M(two,cf[1])),Q(wr(nf),t),L(nf[2],two)]
  fs=[Q(cf[0],ar.num(state)),Q(whole(cf),source),step(cf,nf)]
  prem=nd.AND(fs);goal=nd.AND(out);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  def branch(dc,j):
   pf=api['parts'](cf,nf,j);nd.unpack(dc,pf)
   if j//2!=state:return api['neq'](dc,cf[0],state,j//2,goal)
   m.bound(dc,ar.num(j%2),two,ar.num(1-j%2))
   m.rewrite(dc,L(ar.E,two),ar.num(j%2),cf[2],ar.sym(cf[2],ar.num(j%2),dc.get(pf[1]),dc.g))
   m.bound(dc,ar.num(read),two,ar.num(1-read))
   side=cf[3] if kind=='a1' else cf[1]
   m.eq(dc,whole(cf),A(M(two,known),ar.num(read)),[fs[1]])
   m.quotient_unique(dc,two,side,cf[2],known,ar.num(read))
   if j%2!=read:return api['neq'](dc,cf[2],read,j%2,goal)
   api['bitbound'](dc,pf)
   if kind=='a1':
    m.eq(dc,nf[1],M(two,cf[1]),[pf[3]])
    m.eq(dc,wr(nf),t,[m.flip(dc,pf[4]),Q(cf[3],t)])
   else:
    m.eq(dc,wl(nf),known,[m.flip(dc,pf[4]),Q(cf[1],known)])
    m.eq(dc,nf[3],A(M(two,cf[3]),O),[pf[3]])
   return nd.conj(dc,out)
  nd.cases(c,[nd.AND(api['parts'](cf,nf,j)) for j in range(10)],goal,branch)
  m.finish('z10-align-'+kind,root,prem,goal,c,'Ordinary one-step alignment from a whole-word equation. Binary read is derived from Step; no induction.')
 def compose_left():
  fs=[Q(cf[0],three),Q(wl(cf),A(M(four,t),two)),step(cf,mid),step(mid,nf)]
  prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  apply(c,'z10-align-d0',{x[1]:y for x,y in zip(nf,mid)})
  apply(c,'z10-align-c1',{x[1]:y for x,y in zip(cf,mid)})
  m.eq(c,nf[3],A(M(four,cf[3]),three),[Q(nf[3],A(M(two,mid[3]),O)),Q(mid[3],A(M(two,cf[3]),O))])
  out=[Q(nf[0],three),Q(wl(nf),t),Q(nf[3],A(M(four,cf[3]),three)),L(nf[2],two)]
  nd.conj(c,out);m.finish('skelet17-ladder-skelet10-left-entry-two-step',root,prem,nd.AND(out),c,'Two ordinary D0,C1 moves give the left-routine alignment. No induction, no supplied binary digit premise.')
 def compose_return():
  fs=[Q(cf[0],Z),Q(wr(cf),A(M(four,t),three)),step(cf,mid),step(mid,nf)]
  prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  m.eq(c,wr(cf),A(M(two,A(M(two,t),O)),O),[fs[1]])
  apply(c,'z10-align-a1',{'t':A(M(two,t),O),**{x[1]:y for x,y in zip(nf,mid)}})
  apply(c,'z10-align-a1',{x[1]:y for x,y in zip(cf,mid)})
  m.eq(c,nf[1],M(four,cf[1]),[Q(nf[1],M(two,mid[1])),Q(mid[1],M(two,cf[1]))])
  out=[Q(nf[0],Z),Q(nf[1],M(four,cf[1])),Q(wr(nf),t),L(nf[2],two)]
  nd.conj(c,out);m.finish('skelet17-ladder-skelet10-return-clear-two-step',root,prem,nd.AND(out),c,'Two ordinary A1 moves clear the two low 1 bits of a whole-right word 4t+3. No induction.')
 def even_entry():
  fs=[Q(cf[0],Z),Q(wr(cf),M(two,t)),api['sparse'](t),step(cf,nf)]
  prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  mp={right['ell'][1]:cf[1],right['word'][1]:t};goal=m.sub(right['entry'](nf),mp)
  def branch(dc,j):
   pf=api['parts'](cf,nf,j);nd.unpack(dc,pf)
   if j//2!=0:return api['neq'](dc,cf[0],0,j//2,goal)
   m.bound(dc,ar.num(j%2),two,ar.num(1-j%2))
   m.rewrite(dc,L(ar.E,two),ar.num(j%2),cf[2],ar.sym(cf[2],ar.num(j%2),dc.get(pf[1]),dc.g))
   m.bound(dc,Z,two,O);m.eq(dc,wr(cf),A(M(two,t),Z),[fs[1]])
   m.quotient_unique(dc,two,cf[3],cf[2],t,Z)
   if j==1:return api['neq'](dc,cf[2],0,1,goal)
   m.rewrite(dc,api['sparse'](ar.E),t,cf[3],ar.sym(cf[3],t,dc.get(Q(cf[3],t)),dc.g))
   apply(dc,'skelet17-ladder-skelet10-a0-enters-right-counter',{})
   m.rewrite(dc,m.sub(right['entry'](nf),{right['ell'][1]:cf[1],right['word'][1]:ar.E}),cf[3],t)
   return dc.get(goal)
  nd.cases(c,[nd.AND(api['parts'](cf,nf,j)) for j in range(10)],goal,branch)
  m.finish('skelet17-ladder-skelet10-even-right-enters-counter',root,prem,goal,c,'An A row with even whole-right word derives its actual zero bit and enters the right counter by one ordinary move. No induction.')
 if proofs:
  for kind in ('d0','c1','a1'):single(kind)
  compose_left();compose_return();even_entry()
 return {'middle':mid,'left_input':t,'left_entry_steps':2,'return_steps':2}
