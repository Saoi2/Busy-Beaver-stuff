"""Resume untrusted proof generation from the checked packet database.

No assertions are turned into axioms: the complete old database, with all old
proofs, is the prefix of the output. Every combined output must be verified.
Only the Python generator's symbol table is reconstructed here.
"""
from pathlib import Path
import ast,sys,types
import build_binary as m
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse
b,nd=m.b,m.nd
source=(P/'packet_projection_checked.mm').read_text()
records,rules,variables=parse(source)
b.lines[:]=[source]
b.rules.clear()
for rec in records:
    if rec['kind']=='f':
        typ,name=rec['expr'];b.metas[name]=typ;b.floats[name]=rec['label']
for rec in records:
    if rec['kind'] not in ('a','p'):continue
    hs=[h for h in rec['hyps'] if rules[h]['kind']=='e']
    mand=[rules[h]['expr'][1] for h in rec['hyps'] if rules[h]['kind']=='f']
    b.rules[rec['label']]=(' '.join(rec['expr']),[' '.join(rules[h]['expr']) for h in hs],mand,hs)
nd.cache.clear();nd.scache.clear();nd.OUTPUT_PREFIX='ladder-'
m.a.OUTPUT_PREFIX='ladder-'
for function in [m.a.associate,m.a.swap_at,m.a.sort_assoc,m.a.normalize]:function.cache_clear()
m.a.proof_ast.clear()
def expression(tokens):
    it=iter(tokens)
    def take(first=None):
        t=next(it) if first is None else first
        if t=='(':
            left=take();op=next(it);right=take();assert next(it)==')'
            return (op,left,right)
        if t in ('A.','E.'):
            v=take();return (t,v,take())
        if t=='-.':return ('not',take())
        if t=='0':return b.Z
        if t=='1':return b.O
        if t=='[]':return b.NIL
        return (b.metas[t],t)
    out=take();assert next(it,None) is None
    return out
for rec in records:
    if rec['kind']=='p' and rec['label'].startswith('skelet17-') and rec['expr'][:3]==['|-','[]','=>']:
        m.theorems[rec['label']]=expression(rec['expr'][3:])
# Restore the generator's standard freshness convention outside closed scopes.
vs=[v for v,t in b.metas.items() if t=='var']
b.lines.append('$d '+' '.join(vs)+' $.')
b.lines.extend('$d '+v+' '+w+' $.' for v in vs for w,t in b.metas.items() if t!='var')
original_declare=m.declare
def reuse_declare(name,typ='var'):
    if name in b.metas:
        assert b.metas[name]==typ
        return (typ,name)
    return original_declare(name,typ)
m.declare=reuse_declare
# Execute definitions and setup assignments, never theorem-construction calls.
tree=ast.parse((P/'build_packets_generated.py').read_text())
tree.body=[node for node in tree.body if isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))
           and not (isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='syntax' for t in node.targets))]
module=types.ModuleType('build_packets_generated');module.__file__=str(P/'build_packets_generated.py')
exec(compile(tree,module.__file__,'exec'),module.__dict__)
sys.modules['build_packets_generated']=module
# Discard parsed proof-token arrays after rebuilding the generator table.
del records,rules,variables,rec,tree
print('Resumed checked packet database; prior proofs retained verbatim.',flush=True)
