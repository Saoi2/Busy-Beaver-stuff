"""A complete bounded-history contract for Skelet #10's D1 return phase."""
def add_skelet10_return(m,api,stage='all',proofs=True):
 nd,b,a=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 two,three=map(a.num,(2,3));use=m.invoke
 ell,value=[m.declare('return'+s,'term') for s in ('Left','Value')]
 cf,nf=api['current'],api['next'];step,parts=api['step'],api['parts']
 def whole(c):return A(M(two,c[1]),c[2])
 def marker(c,s):return nd.AND([Q(c[0],three),L(c[2],two),m.power2(s),Q(A(whole(c),O),M(s,A(ell,O))),Q(M(s,c[3]),value)])
 def endpoint(c):return nd.AND([Q(c[0],three),Q(whole(c),ell),Q(c[3],value)])
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+name,root,prem,goal,c,comment)
 def unpack_marker(c,row,s):return nd.unpack(c,[Q(row[0],three),L(row[2],two),m.power2(s),Q(A(whole(row),O),M(s,A(ell,O))),Q(M(s,row[3]),value)])
 def cancel_add(c,x,y,z):
  ant=Q(A(x,z),A(y,z));out=Q(x,y);c.theorem(b.Imp(ant,out),b.apply('add-cancel',{'t':x,'u':y,'v':z}));return c.mp(ant,out)
 def no_irrefl(c,x,goal):c.put(b.Not(L(x,x)),b.ax('O1',c.g,t=x));return c.explode(L(x,x),goal)
 def predecessor():
  x,y,z,d=b.t,b.u,b.v,b.w;fs=[Q(A(x,O),M(two,y)),Q(x,A(M(two,z),d)),L(d,two)]
  prem=nd.AND(fs);goal=b.And(Q(d,O),Q(A(z,O),y));root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  m.bound(c,Z,two,O);m.bound(c,O,two,Z);use(c,'skelet17-binary-digit-cases',{'t':d})
  def digit(cc,k):
   if k==0:
    m.eq(cc,A(M(two,y),Z),A(M(two,z),O),[m.flip(cc,fs[0]),fs[1],Q(d,Z)])
    m.quotient_unique(cc,two,y,Z,z,O);return m.false_zero_one(cc,goal)
   m.eq(cc,A(M(two,y),Z),A(M(two,A(z,O)),Z),[m.flip(cc,fs[0]),fs[1],Q(d,O)])
   m.quotient_unique(cc,two,y,Z,A(z,O),Z);m.flip(cc,Q(y,A(z,O)));return cc.both(Q(d,O),Q(A(z,O),y))
  nd.cases(c,[Q(d,Z),Q(d,O)],goal,digit)
  m.finish('z10-return-even-predecessor',root,prem,goal,c,'The predecessor of 2y has low bit 1 and half y-1, stated without subtraction. No induction.')
 if proofs: predecessor()
 hs=m.declare('returnHalfScale');outscale=m.declare('returnOutputScale')
 def local():
  s=b.t;fs=[marker(cf,s),b.Not(endpoint(cf)),step(cf,nf)];prem=nd.AND(fs)
  goal=nd.BEX(outscale,s,marker(nf,outscale));root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);unpack_marker(c,cf,s)
  use(c,'skelet17-binary-power-halving',{'t':s})
  hb=b.And(Q(s,M(two,m.pz)),m.power2(m.pz));opts=[Q(s,O),nd.BEX(m.pz,A(s,O),hb)]
  def scale_branch(cc,k):
   if k==0:
    eq=Q(A(whole(cf),O),M(s,A(ell,O)))
    m.eq(cc,A(whole(cf),O),A(ell,O),[eq,Q(s,O)]);cancel_add(cc,whole(cf),ell,O)
    m.rewrite(cc,Q(M(a.E,cf[3]),value),s,O)
    m.eq(cc,M(O,cf[3]),cf[3]);m.rewrite(cc,Q(a.E,value),M(O,cf[3]),cf[3])
    nd.conj(cc,[Q(cf[0],three),Q(whole(cf),ell),Q(cf[3],value)]);return cc.explode(endpoint(cf),goal)
   def half_found(dc):
    heq=Q(s,M(two,hs));nd.unpack(dc,[heq,m.power2(hs)]);nd.unpack(dc,list(m.power2(hs)[1:]))
    use(dc,'skelet17-binary-double-larger',{'t':hs});m.rewrite(dc,L(hs,a.E),M(two,hs),s,a.sym(s,M(two,hs),dc.get(heq),dc.g))
    peq=Q(A(whole(cf),O),M(two,M(hs,A(ell,O))))
    m.eq(dc,*peq[1:],[Q(A(whole(cf),O),M(s,A(ell,O))),heq])
    m.eq(dc,whole(cf),A(M(two,cf[1]),cf[2]))
    nd.conj(dc,[peq,Q(whole(cf),A(M(two,cf[1]),cf[2])),L(cf[2],two)])
    use(dc,'z10-return-even-predecessor',{'t':whole(cf),'u':M(hs,A(ell,O)),'v':cf[1],'w':cf[2]})
    nd.unpack(dc,[Q(cf[2],O),Q(A(cf[1],O),M(hs,A(ell,O)))])
    def instruction(ec,j):
     fields=parts(cf,nf,j);nd.unpack(ec,fields)
     if j//2!=3:return api['neq'](ec,cf[0],3,j//2,goal)
     if j==6:return api['neq'](ec,cf[2],1,0,goal)
     assert j==7
     api['bitbound'](ec,fields)
     m.eq(ec,A(whole(nf),O),M(hs,A(ell,O)),[m.flip(ec,fields[4]),Q(A(cf[1],O),M(hs,A(ell,O)))])
     m.eq(ec,M(s,cf[3]),M(hs,nf[3]),[heq,fields[3]])
     m.rewrite(ec,Q(a.E,value),M(s,cf[3]),M(hs,nf[3]))
     nd.conj(ec,[Q(nf[0],three),L(nf[2],two),m.power2(hs),Q(A(whole(nf),O),M(hs,A(ell,O))),Q(M(hs,nf[3]),value)])
     return m.bex_intro(ec,outscale,s,marker(nf,outscale),hs)
    return nd.cases(dc,[nd.AND(parts(cf,nf,j)) for j in range(10)],goal,instruction)
   return m.bex_elim(cc,m.pz,A(s,O),hb,hs,goal,half_found)
  nd.cases(c,opts,goal,scale_branch)
  finish('return-marker-step',root,prem,goal,c,'Every ordinary step from an unfinished D marker produces a smaller positive Pow2 marker, preserving its left/right target. All ten instruction cases are checked. No induction.')
 if proofs: local()
 if stage=='local':return {'marker':marker,'endpoint':endpoint,'ell':ell,'value':value,'outscale':outscale}
 gap=m.declare('returnClockGap')
 def clock_step():
  i,s,h,P=b.t,b.u,b.v,b.w;fs=[L(h,s),L(A(i,s),A(P,O))];prem=b.And(*fs);goal=L(A(A(i,O),h),A(P,O))
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  def found(cc,eq):
   m.bound(cc,A(A(i,O),h),A(A(i,s),O),gap,[eq])
   cc.both(L(A(A(i,O),h),A(A(i,s),O)),L(A(i,s),A(P,O)))
   return use(cc,'skelet17-binary-le-lt-trans',{'t':A(A(i,O),h),'u':A(i,s),'v':A(P,O)})
  m.gap_elim(c,h,s,gap,goal,found);m.finish('z10-return-clock-step',root,prem,goal,c,'A strict decrease of a positive marker advances the bounded clock. No induction.')
 def clock_end():
  i,s,P=b.t,b.u,b.v;fs=[L(Z,s),L(A(i,s),A(P,O))];prem=b.And(*fs);goal=L(i,P)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  m.gap_elim(c,Z,s,gap,L(i,A(i,s)),lambda cc,eq:m.bound(cc,i,A(i,s),gap,[eq]))
  use(c,'skelet17-binary-below-successor',{'t':A(i,s),'u':P})
  def branch(cc,k):
   if k==0:return m.translt(cc,i,A(i,s),P)
   return m.rewrite(cc,L(i,a.E),A(i,s),P)
  nd.cases(c,[L(A(i,s),P),Q(A(i,s),P)],goal,branch)
  m.finish('z10-return-clock-positive',root,prem,goal,c,'A positive remaining marker gives a strict bound on the elapsed time. No induction.')
 if proofs: clock_step();clock_end()
 # Original beta-history format, with explicitly renamed window parameters.
 H,n,offset,P=[m.declare('return'+s,'term') for s in ('H','N','Offset','InitialScale')]
 Bj=[m.declare('returnB'+str(j),'term') for j in range(4)];Cj=[m.declare('returnC'+str(j),'term') for j in range(4)]
 i,ti,si,avoid_i=[m.declare('return'+s) for s in ('Index','TotalIndex','StepIndex','AvoidIndex')]
 quo=m.declare('returnBetaQuotient')
 IP=[m.declare('returnIndRow'+s) for s in ('Q','L','Bit','R')]
 IV=[m.declare('returnInitialRow'+s) for s in ('Q','L','Bit','R')]
 TV=[m.declare('returnTotalRow'+s) for s in ('Q','L','Bit','R')]
 SV=[m.declare('returnStepRow'+str(j)+s) for j in (0,1) for s in ('Q','L','Bit','R')]
 EV=[m.declare('returnAvoidRow'+s) for s in ('Q','L','Bit','R')]
 CR=[m.declare('returnCurrentRow'+s) for s in ('Q','L','Bit','R')]
 NR=[m.declare('returnNextRow'+s) for s in ('Q','L','Bit','R')]
 last=[m.declare('returnLastRow'+s) for s in ('Q','L','Bit','R')]
 scale=m.declare('returnHistoryScale');freshscale=m.declare('returnFreshScale');nextscale=m.declare('returnFreshNextScale')
 def beta(index,v,j):
  mod=A(O,M(A(index,O),Cj[j]));return nd.BEX(quo,H,b.And(Q(Bj[j],A(M(quo,mod),v)),L(v,mod)))
 def AT(index,row):return nd.AND([beta(A(offset,index),v,j) for j,v in enumerate(row)])
 total=nd.BALL(ti,A(n,O),nd.bexs(TV,H,AT(ti,TV)))
 initial=nd.balls(IV,H,b.Imp(AT(Z,IV),marker(IV,P)))
 steps=nd.BALL(si,n,nd.balls(SV,H,b.Imp(b.And(AT(si,SV[:4]),AT(A(si,O),SV[4:])),step(SV[:4],SV[4:]))))
 avoid=nd.BALL(avoid_i,A(n,O),nd.balls(EV,H,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV)))))
 def inv(index,row):return nd.BEX(scale,A(P,O),b.And(marker(row,scale),L(A(index,scale),A(P,O))))
 def phi(index):return b.Imp(L(index,A(n,O)),nd.balls(IP,H,b.Imp(AT(index,IP),inv(index,IP))))
 def bforall(ctx,vs,body,prove):
  if not vs:return ctx.put(body,prove(ctx))
  v=vs[0];ch=ctx.push(L(v,H));inner=nd.balls(vs[1:],H,body)
  bforall(ch,vs[1:],body,prove);ctx.intro(L(v,H),inner,ch);return ctx.all_intro(v,b.Imp(L(v,H),inner))
 def eliminate(ctx,vs,body,freshs,goal,prove):
  if not vs:return ctx.put(goal,prove(ctx))
  v,fresh=vs[0],freshs[0];rest=nd.bexs(vs[1:],H,body);full=b.And(L(v,H),rest)
  actual,_=b.subst(full,v,fresh,True);ch=ctx.push(actual);nd.unpack(ch,list(actual[1:]));newbody,_=b.subst(body,v,fresh,True)
  eliminate(ch,vs[1:],newbody,freshs[1:],goal,prove);return ctx.ex_elim(v,full,fresh,goal,ch)
 def rename(ctx,old,new,body):
  before=nd.balls(old,H,body(old));after=nd.balls(new,H,body(new));root=nd.Ctx();c=root.push(before)
  bforall(c,new,body(new),lambda cc:nd.inst_balls(cc,old,H,body(old),new)[1]);root.intro(before,after,c)
  ctx.theorem(b.Imp(before,after),root.get(b.Imp(before,after)));return ctx.mp(before,after)
 def inst_avoid(ctx,index,row):
  body=avoid[2];ctx.all_elim(avoid_i,body,index);inner=nd.balls(EV,H,b.Imp(AT(index,EV),b.Not(endpoint(EV))))
  ctx.mp(L(index,A(n,O)),inner);nd.inst_balls(ctx,EV,H,b.Imp(AT(index,EV),b.Not(endpoint(EV))),row)
  return ctx.mp(AT(index,row),b.Not(endpoint(row)))
 def history():
  fields=[total,initial,steps,avoid];prem=nd.AND(fields);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fields)
  baseguard=L(Z,A(n,O));bc=c.push(baseguard)
  def base(cc):
   ac=cc.push(AT(Z,NR));nd.inst_balls(ac,IV,H,b.Imp(AT(Z,IV),marker(IV,P)),NR);ac.mp(AT(Z,NR),marker(NR,P))
   m.successor(ac,P);m.eq(ac,A(Z,P),P);m.rewrite(ac,L(a.E,A(P,O)),P,A(Z,P),a.sym(A(Z,P),P,ac.get(Q(A(Z,P),P)),ac.g))
   ac.both(marker(NR,P),L(A(Z,P),A(P,O)));m.bex_intro(ac,scale,A(P,O),b.And(marker(NR,scale),L(A(Z,scale),A(P,O))),P)
   cc.intro(AT(Z,NR),inv(Z,NR),ac);return cc.get(b.Imp(AT(Z,NR),inv(Z,NR)))
  bforall(bc,NR,b.Imp(AT(Z,NR),inv(Z,NR)),base);rename(bc,NR,IP,lambda row:b.Imp(AT(Z,row),inv(Z,row)))
  c.intro(baseguard,nd.balls(IP,H,b.Imp(AT(Z,IP),inv(Z,IP))),bc)
  sc=c.push(phi(i));guard=L(A(i,O),A(n,O));gc=sc.push(guard)
  use(gc,'skelet17-ladder-lt-add-cancel',{'t':i,'u':n,'v':O});m.successor(gc,n);m.translt(gc,i,n,A(n,O))
  def successor(cc):
   atnext=AT(A(i,O),NR);goal=inv(A(i,O),NR);ac=cc.push(atnext)
   ac.all_elim(ti,total[2],i);ac.mp(L(i,A(n,O)),nd.bexs(TV,H,AT(i,TV)))
   def current(pc):
    pc.mp(L(i,A(n,O)),nd.balls(IP,H,b.Imp(AT(i,IP),inv(i,IP))));nd.inst_balls(pc,IP,H,b.Imp(AT(i,IP),inv(i,IP)),CR);pc.mp(AT(i,CR),inv(i,CR))
    inst_avoid(pc,i,CR)
    pc.all_elim(si,steps[2],i);inner=nd.balls(SV,H,b.Imp(b.And(AT(i,SV[:4]),AT(A(i,O),SV[4:])),step(SV[:4],SV[4:])))
    pc.mp(L(i,n),inner);nd.inst_balls(pc,SV,H,b.Imp(b.And(AT(i,SV[:4]),AT(A(i,O),SV[4:])),step(SV[:4],SV[4:])),CR+NR)
    pc.both(AT(i,CR),atnext);pc.mp(b.And(AT(i,CR),atnext),step(CR,NR))
    def current_scale(dc):
     nd.unpack(dc,[marker(CR,freshscale),L(A(i,freshscale),A(P,O))])
     nd.conj(dc,[marker(CR,freshscale),b.Not(endpoint(CR)),step(CR,NR)])
     mapping={'t':freshscale,**{v[1]:x for v,x in zip(cf,CR)},**{v[1]:x for v,x in zip(nf,NR)}}
     use(dc,'skelet17-ladder-skelet10-return-marker-step',mapping)
     def next_scale(ec):
      ec.both(L(nextscale,freshscale),L(freshscale,A(P,O)));m.translt(ec,nextscale,freshscale,A(P,O))
      ec.both(L(nextscale,freshscale),L(A(i,freshscale),A(P,O)))
      use(ec,'z10-return-clock-step',{'t':i,'u':freshscale,'v':nextscale,'w':P})
      ec.both(marker(NR,nextscale),L(A(A(i,O),nextscale),A(P,O)))
      return m.bex_intro(ec,scale,A(P,O),b.And(marker(NR,scale),L(A(A(i,O),scale),A(P,O))),nextscale)
     return m.bex_elim(dc,outscale,freshscale,marker(NR,outscale),nextscale,goal,next_scale)
    return m.bex_elim(pc,scale,A(P,O),b.And(marker(CR,scale),L(A(i,scale),A(P,O))),freshscale,goal,current_scale)
   eliminate(ac,TV,AT(i,TV),CR,goal,current);cc.intro(atnext,goal,ac);return cc.get(b.Imp(atnext,goal))
  bforall(gc,NR,b.Imp(AT(A(i,O),NR),inv(A(i,O),NR)),successor)
  rename(gc,NR,IP,lambda row:b.Imp(AT(A(i,O),row),inv(A(i,O),row)))
  sc.intro(guard,nd.balls(IP,H,b.Imp(AT(A(i,O),IP),inv(A(i,O),IP))),gc)
  c.intro(phi(i),phi(A(i,O)),sc);c.all_intro(i,b.Imp(phi(i),phi(A(i,O))))
  m.induction(c,i,phi(i),phi(Z),b.All(i,b.Imp(phi(i),phi(A(i,O)))))
  finish('return-window-invariant',root,prem,b.All(i,phi(i)),c,
   'Construct bounded marker witnesses and the remaining-time inequality at every row of a target-avoiding ordinary history. Exactly one bounded history induction.')
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fields)
  use(c,'skelet17-ladder-skelet10-return-window-invariant')
  c.all_elim(i,phi(i),n);m.successor(c,n);c.mp(L(n,A(n,O)),nd.balls(IP,H,b.Imp(AT(n,IP),inv(n,IP))))
  c.all_elim(ti,total[2],n);c.mp(L(n,A(n,O)),nd.bexs(TV,H,AT(n,TV)))
  def finalrow(cc):
   nd.inst_balls(cc,IP,H,b.Imp(AT(n,IP),inv(n,IP)),last);cc.mp(AT(n,last),inv(n,last))
   def finalscale(dc):
    nd.unpack(dc,[marker(last,freshscale),L(A(n,freshscale),A(P,O))]);unpack_marker(dc,last,freshscale);nd.unpack(dc,list(m.power2(freshscale)[1:]))
    dc.both(L(Z,freshscale),L(A(n,freshscale),A(P,O)));return use(dc,'z10-return-clock-positive',{'t':n,'u':freshscale,'v':P})
   return m.bex_elim(cc,scale,A(P,O),b.And(marker(last,scale),L(A(n,scale),A(P,O))),freshscale,L(n,P),finalscale)
  eliminate(c,TV,AT(n,TV),last,L(n,P),finalrow)
  finish('return-window-bound',root,prem,L(n,P),c,'Any supplied ordinary beta-history window starting with marker P and avoiding the target has length n<P. One bounded history induction, no totality of history coding.')
 if proofs: history()
 exit_index=m.declare('returnExitIndex');exit_rows=[m.declare('returnExitRow'+s) for s in ('Q','L','Bit','R')]
 def has_exit():return nd.BEX(exit_index,A(n,O),nd.bexs(exit_rows,H,b.And(AT(exit_index,exit_rows),endpoint(exit_rows))))
 def pack_rows(c,vs,body,values):
  if not vs:return c.get(body)
  freshbody,_=b.subst(body,vs[0],values[0],True)
  pack_rows(c,vs[1:],freshbody,values[1:]);return m.bex_intro(c,vs[0],H,nd.bexs(vs[1:],H,body),values[0])
 def no_exit_avoid():
  goal=has_exit()
  root=nd.Ctx();nc=root.push(b.Not(goal));ic=nc.push(L(avoid_i,A(n,O)))
  def avoid_row(cc):
   at=AT(avoid_i,EV);ac=cc.push(at);ec=ac.push(endpoint(EV));ec.both(at,endpoint(EV))
   body=b.And(AT(avoid_i,exit_rows),endpoint(exit_rows));pack_rows(ec,exit_rows,body,EV)
   m.bex_intro(ec,exit_index,A(n,O),nd.bexs(exit_rows,H,b.And(AT(exit_index,exit_rows),endpoint(exit_rows))),avoid_i)
   ec.put(L(Z,Z),ec.explode(goal,L(Z,Z)));ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z))
   ac.put(b.Not(endpoint(EV)),a.not_intro(ac.g,endpoint(EV),L(Z,Z),ec.get(L(Z,Z)),ec.get(b.Not(L(Z,Z)))))
   cc.intro(at,b.Not(endpoint(EV)),ac);return cc.get(b.Imp(at,b.Not(endpoint(EV))))
  bforall(ic,EV,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV))),avoid_row)
  nc.intro(L(avoid_i,A(n,O)),nd.balls(EV,H,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV)))),ic)
  nc.all_intro(avoid_i,b.Imp(L(avoid_i,A(n,O)),nd.balls(EV,H,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV))))))
  m.finish('z10-return-no-exit-avoid',root,b.Not(goal),avoid,nc,'Negating the bounded existential exit yields the unannotated target-avoidance premise. Pure first-order logic.')
 if proofs: no_exit_avoid()
 def exit_proof():
  fs=[total,initial,steps,L(P,A(n,O))];prem=nd.AND(fs);goal=has_exit();root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  nc=c.push(b.Not(goal));use(nc,'z10-return-no-exit-avoid')
  nd.conj(nc,[total,initial,steps,avoid]);use(nc,'skelet17-ladder-skelet10-return-window-bound')
  use(nc,'skelet17-binary-below-successor',{'t':P,'u':n})
  def impossible(cc,k):
   if k==0:m.translt(cc,n,P,n)
   else:m.rewrite(cc,L(n,a.E),P,n)
   return cc.get(L(n,n))
  nd.cases(nc,[L(P,n),Q(P,n)],L(n,n),impossible);nc.put(b.Not(L(n,n)),b.ax('O1',nc.g,t=n))
  c.put(b.Not(b.Not(goal)),a.not_intro(c.g,b.Not(goal),L(n,n),nc.get(L(n,n)),nc.get(b.Not(L(n,n)))))
  c.put(goal,b.apply('nd-dne',{'ga':c.g,'ph':goal},[c.get(b.Not(b.Not(goal)))]))
  finish('return-window-exit',root,prem,goal,c,'A supplied ordinary window of length at least P must visit the specified D endpoint. Derived from the bounded return clock; no extra induction construction.')
 if proofs: exit_proof()

 haltrow=[m.declare('returnHalt'+s,'term') for s in ('Q','L','Bit','R')]
 def barrier_proof():
  fs=[total,initial,steps,*[L(x,H) for x in haltrow],AT(n,haltrow),Q(haltrow[0],a.num(5))]
  prem=nd.AND(fs);goal=has_exit();root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  nc=c.push(b.Not(goal));use(nc,'z10-return-no-exit-avoid');nd.conj(nc,[total,initial,steps,avoid])
  use(nc,'skelet17-ladder-skelet10-return-window-invariant')
  nc.all_elim(i,phi(i),n);m.successor(nc,n);nc.mp(L(n,A(n,O)),nd.balls(IP,H,b.Imp(AT(n,IP),inv(n,IP))))
  nd.inst_balls(nc,IP,H,b.Imp(AT(n,IP),inv(n,IP)),haltrow);nc.mp(AT(n,haltrow),inv(n,haltrow))
  def impossible(cc):
   nd.unpack(cc,[marker(haltrow,freshscale),L(A(n,freshscale),A(P,O))]);unpack_marker(cc,haltrow,freshscale)
   return api['neq'](cc,haltrow[0],3,5,L(Z,Z))
  m.bex_elim(nc,scale,A(P,O),b.And(marker(haltrow,scale),L(A(n,scale),A(P,O))),freshscale,L(Z,Z),impossible)
  nc.put(b.Not(L(Z,Z)),b.ax('O1',nc.g,t=Z))
  c.put(b.Not(b.Not(goal)),a.not_intro(c.g,b.Not(goal),L(Z,Z),nc.get(L(Z,Z)),nc.get(b.Not(L(Z,Z)))))
  c.put(goal,b.apply('nd-dne',{'ga':c.g,'ph':goal},[c.get(b.Not(b.Not(goal)))]))
  finish('return-window-halting-barrier',root,prem,goal,c,'Every supplied ordinary history from a return marker to halt has already visited the specified D endpoint. No premature halt in the return phase. Reuses the same single history induction.')
 if proofs: barrier_proof()

 return {'marker':marker,'endpoint':endpoint,'ell':ell,'value':value,'outscale':outscale,
  'H':H,'n':n,'offset':offset,'P':P,'Bj':Bj,'Cj':Cj,'AT':AT,'total':total,'initial':initial,'steps':steps,'avoid':avoid,'TV':TV,'IV':IV,'EV':EV,'IP':IP,'i':i,'avoid_i':avoid_i,'bforall':bforall,'eliminate':eliminate,'rename':rename,'has_exit':has_exit,'phi':phi,'inv':inv,'scale':scale,'haltrow':haltrow,'predecessor':predecessor,'clock_step':clock_step,'clock_end':clock_end}
