# Four boundary connections for Skelet #10

These theorems connect parts of the counter contracts to a canonical
boundary predicate. They do not yet compose a complete counter cycle or
prove blank-start nonhalting. Every Step and history definition is unchanged.

## Bounded canonical predicate

Put W=2L+b. Boundary(n,c) requires q=D, b<2, Sparse(n), Sparse(R),
and one of the following bounded alternatives:

- exists a<n+1: n=2a, T(a,W), J(a,R).
- exists a<n+1 exists t<W+1 exists v<R+1:
  n=4a+1, W=4t+2, T(a,t), R=2v, J(a,v).

All J, T and Sparse predicates are their existing Delta-0 formulas. This
is a proof invariant: it is not a different definition of configuration,
machine, halting or history. Its witnesses must eventually be constructed
from the blank history by the global proof, which is still unfinished.

## 1. A0 enters the right counter

`skelet17-ladder-skelet10-a0-enters-right-counter` proves that
q=A, b=0, Sparse(R), and an ordinary Step(c,d) imply the right-counter
entry for d with input old R and left target old L.

The only matching instruction is A0: write 1 and move right to B. Thus
L'=2L+1 and 2R'+b'=R. The new scanned bit is below 2 by its explicit
zero-or-one disjunction. These facts are exactly the previously defined
right-entry predicate. The proof splits all ten ordinary instructions;
wrong source states or bits give contradictions. No induction is used.

## 2. The right output closes an even boundary

`skelet17-ladder-skelet10-boundary-even-output` assumes
q=D, b<2, Sparse(a), T(a,W), J(a,R) and Sparse(R), and proves
Boundary(2a,c).

Sparse(2a) follows from the earlier zero-prefix theorem. The existing
input a is the witness in Boundary's even alternative; a<2a+1 has
explicit additive gap a. No new induction construction is introduced.
The theorem does require the displayed bit bound; a complete global
history proof must establish it from an ordinary adjacent Step (or
handle an alleged final halt directly by its incompatible state).

## 3. The odd right output requires a D1 alignment

`skelet17-ladder-skelet10-right-output-align-odd` assumes
q=D, Sparse(a), T(a,t), J(a,R), Sparse(R), W=8t+5 and Step(c,d).
It proves Boundary(4a+1,d).

This output row is NOT already canonical. Since the source whole-left
word is 8t+5=2(4t+2)+1, the actual D step must scan 1 and have
L=4t+2. The D0 branch contradicts remainder uniqueness modulo 2.
The matching D1 instruction writes 0 and moves left, so

    d.state=D, WholeLeft(d)=old L=4t+2, d.R=2*old R.

Its target bit is below 2. An existing private bounded constructor then
packages the odd boundary with witnesses a,t,v=old R. Sparse(4a+1)
and Sparse(2v) follow from earlier prefix lemmas. The witness bounds are
proved explicitly: a<4a+2, t<WholeLeft(d)+1, v<d.R+1.
This uses no new induction construction.

## 4. Identify the left output with a tracked counter value

`skelet17-ladder-skelet10-left-output-identify` assumes Sparse(a),
J(a,v), and the existing full-left endpoint shape:

    q=A, WholeRight=r,
    exists z<3a+2: J(a,z), T(z,L), Sparse(z).

It proves q=A, WholeRight=r, T(v,L) and Sparse(v). Eliminate the
routine's bounded output witness z. Sparse carry uniqueness gives z=v.
Substitute that equality into T and Sparse, then discharge the witness.

The bound-variable name in the endpoint premise is the original
leftOutput, so this premise matches the earlier routine endpoint after
parameter substitution; no hidden alpha-renaming or new endpoint
encoding is assumed. The proof reuses the two induction dependencies of
carry uniqueness and adds no new induction construction.

## Verification and exact scope

All four public formulas are independently reconstructed in
check_skelet10_boundaries.py, including the canonical bounded alternatives
and the original ten-instruction Step. Supplementary numerical tests
check 1,088 A0 entries and 89 D1 alignments. These are not formal proofs.
Kernel verification checks the actual universal deductions.

The expected induction dependency counts are 0 for the A0 entry, 1 for
even canonical construction, 1 for odd alignment, and 2 for left-output
identification. The counts are audited from the proof graph; the nonzero
counts reuse earlier arithmetic induction, with no new induction here.

Subsequent work has now proved the D0,C1 and A1,A1 alignments and the
shared beta-history uniqueness/suffix lemmas; see SKELET10_FINITE_ALIGNMENTS.md
and HISTORY_TOOLS.md. The remaining global work includes using these
results in the complete three boundary compositions, routine-specific
entry/exit transports, finite-prefix safety, and the remaining-length
induction. SKELET10_GLOBAL_PLAN.md gives the current proposal. These four
connections do not yet assert that every canonical boundary reaches the
next one, nor that an arbitrary blank computation is safe forever.
