# Low-memory append-only proof checks

The official Metamath kernel verifies every proof in idelta0_machines.mm.
No Python generator or audit is a trusted inference rule. The unchanged
core contains 93 trusted declarations.

refresh_streaming_report.py checks the entire old byte prefix against
its prior verified SHA256, then reads the whole current source to compute
exact protected-interface signatures: conclusion, ordered mandatory
floating/essential hypotheses, and mandatory DV pairs. It compares every
old signature and the exact axiom-core signatures, and computes the new
interface from the actual canonical file. The new conclusion is also
compared with the generated export used by its independent checker.
This implementation was first checked against all 264 signatures from the
previous full-parser report. That comparison passed, with about 19 MiB
peak resident memory. It is an append-only refresh and rejects changed
old bytes.

audit_streaming.py independently decodes actually used compressed proof
indices, accounting for mandatory hypothesis offsets and saved subproof
indices. It checks all recorded induction dependency counts, that any newly appended direct induction construction is explicitly
registered and belongs to the maximum theorem, new formulas against independent
reconstructions, the exact old prefix and the strict whole-file kernel log.
Its reports record measured peak memory. The legacy large dependency audit
did not complete during recovery; this lower-memory audit passed instead.

extract_streaming.py is an untrusted extraction convenience. An extracted
file must pass the kernel before use. Final dependency pruning also scopes
required DV conditions; retaining every global dummy-variable constraint
can make even a small extracted file unnecessarily expensive to read.

The earlier exact-interface audit also passed for the recovered odd file.
The current checkpoint uses the streaming exact-interface and dependency
audits after fresh whole-file kernel verification. A whole-file rewrite
or cleanup requires the corresponding exact-interface checks, not an
unchecked append-prefix assumption. No new arithmetic axioms are accepted.

Current exact results and hashes are in simplification_report.json,
streaming_audit_report.json and ladder_manifest.json. All three numerical cases, the general combination, greatest-index argument
and ordinary blank-start endpoint are now proved. The assembly adds exactly
one direct induction construction, checked to belong to the maximum lemma.

The newest generator bootstrap, resume_streaming.py, loads existing rule
interfaces without retaining old proof bodies as Python records. The
scoper scope_new_extension.py prunes only new reachable nodes, preserves
existing DV pairs and compresses their proof labels. The resulting proof
extension is checked against the actual project declarations, then the
whole standalone canonical file is verified. No generator is trusted.
