"""Advance ordinary histories and embed counter contracts in their suffixes."""
def add_history_assembly(m,api,h,right,left,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 H,N,o,k,n,idx=[h[x] for x in ('H','n','offset','start','length','index')]
 AT,absolute,total,steps=h['AT'],h['absolute'],h['total'],h['steps']
 cf,nf=api['current'],api['next'];step=api['step'];two=ar.num(2);use=m.invoke
 halt=[m.declare('assemblyHalt'+s,'term') for s in ('Q','L','Bit','R')]
 freshnext=[m.declare('assemblyFreshNext'+s) for s in ('Q','L','Bit','R')]
 freshpast=[m.declare('assemblyFreshPast'+s) for s in ('Q','L','Bit','R')]
 def bounds(row):return [L(x,H) for x in row]
 def unpack(c,f):
  if f[0]=='/\\':nd.unpack(c,[f[1],f[2]]);unpack(c,f[1]);unpack(c,f[2])
 def collect(c,f):
  try:return c.get(f)
  except KeyError:pass
  if f[0]=='/\\':collect(c,f[1]);collect(c,f[2]);return c.both(f[1],f[2])
  return c.get(f)
 def apply(c,label,mp={}):
  f=m.sub(m.theorems[label],mp);collect(c,f[1]);use(c,label,mp);unpack(c,f[2]);return f[2]
 def elim_rows(c,vs,body,values,goal,fn):
  if not vs:return c.put(goal,fn(c))
  v=vs[0];rest=nd.bexs(vs[1:],H,body)
  def found(dc):
   newbody,_=b.subst(body,v,values[0],True)
   return elim_rows(dc,vs[1:],newbody,values[1:],goal,fn)
  return m.bex_elim(c,v,H,rest,values[0],goal,found)
 def pack_rows(c,vs,body,values):
  if not vs:return c.get(body)
  newbody,_=b.subst(body,vs[0],values[0],True)
  pack_rows(c,vs[1:],newbody,values[1:]);return m.bex_intro(c,vs[0],H,nd.bexs(vs[1:],H,body),values[0])
 def bforall(c,vs,body,fn):
  if not vs:return c.put(body,fn(c))
  v=vs[0];guard=L(v,H);dc=c.push(guard);inner=nd.balls(vs[1:],H,body)
  bforall(dc,vs[1:],body,fn);c.intro(guard,inner,dc);return c.all_intro(v,b.Imp(guard,inner))
 def row_unique(c,i,c0,c1):
  mp={h['index'][1]:i,**{v[1]:x for v,x in zip(cf,c0)},**{v[1]:x for v,x in zip(nf,c1)}}
  apply(c,'skelet17-ladder-history-row-unique',mp)
 def inst_total(c,i):
  c.all_elim(h['ti'],total(o,N)[2],i);return c.mp(L(i,A(N,O)),nd.bexs(h['TV'],H,AT(o,i,h['TV'])))
 def inst_step(c,i,c0,c1):
  body=b.Imp(b.And(AT(o,i,h['SV'][:4]),AT(o,A(i,O),h['SV'][4:])),step(h['SV'][:4],h['SV'][4:]))
  c.all_elim(h['si'],steps(o,N)[2],i);c.mp(L(i,N),nd.balls(h['SV'],H,body))
  nd.inst_balls(c,h['SV'],H,body,c0+c1);c.both(AT(o,i,c0),AT(o,A(i,O),c1));return c.mp(b.And(AT(o,i,c0),AT(o,A(i,O),c1)),step(c0,c1))
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-'+name,root,prem,goal,c,comment)
 def step_bit():
  prem=step(cf,nf);goal=L(nf[2],two);root=nd.Ctx();c=root.push(prem)
  def branch(dc,j):pf=api['parts'](cf,nf,j);nd.unpack(dc,pf);return api['bitbound'](dc,pf)
  nd.cases(c,[nd.AND(api['parts'](cf,nf,j)) for j in range(10)],goal,branch)
  m.finish('z10-assembly-step-bit',root,prem,goal,c,'Every ordinary Step explicitly supplies a binary target bit. No induction.')
 def advance():
  fs=[total(o,N),steps(o,N),*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5)),*bounds(cf),L(idx,A(N,O)),AT(o,idx,cf),b.Not(Q(cf[0],ar.num(5)))]
  prem=nd.AND(fs);TV=h['TV'];exists=nd.bexs(TV,H,b.And(AT(o,A(idx,O),TV),step(cf,TV)));goal=b.And(L(idx,N),exists)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  use(c,'skelet17-binary-below-successor',{'t':idx,'u':N})
  def index_case(dc,j):
   if j==0:return dc.get(L(idx,N))
   m.rewrite(dc,AT(o,ar.E,cf),idx,N);row_unique(dc,N,cf,halt)
   m.eq(dc,cf[0],ar.num(5),[Q(cf[0],halt[0]),Q(halt[0],ar.num(5))])
   return dc.explode(Q(cf[0],ar.num(5)),L(idx,N))
  nd.cases(c,[L(idx,N),Q(idx,N)],L(idx,N),index_case)
  m.ltadd(c,idx,N,O);inst_total(c,A(idx,O))
  def next_row(dc):
   inst_step(dc,idx,cf,freshnext);dc.both(AT(o,A(idx,O),freshnext),step(cf,freshnext))
   return pack_rows(dc,TV,b.And(AT(o,A(idx,O),TV),step(cf,TV)),freshnext)
  elim_rows(c,TV,AT(o,A(idx,O),TV),freshnext,exists,next_row)
  c.both(L(idx,N),exists);finish('history-advance-before-halt',root,prem,goal,c,'A decoded nonhalting row in a raw history ending at halt lies before its end and has an ordinary next step. No induction or history annotations.')
 def positive_bit():
  fs=[total(o,N),steps(o,N),L(idx,N),*bounds(nf),AT(o,A(idx,O),nf)]
  prem=nd.AND(fs);goal=L(nf[2],two);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  m.successor(c,N);m.translt(c,idx,N,A(N,O));inst_total(c,idx)
  def past_row(dc):
   inst_step(dc,idx,freshpast,nf)
   apply(dc,'z10-assembly-step-bit',{v[1]:x for v,x in zip(cf,freshpast)});return dc.get(goal)
  elim_rows(c,h['TV'],AT(o,idx,h['TV']),freshpast,goal,past_row)
  finish('history-positive-row-bit',root,prem,goal,c,'Every supplied row at index i+1, with i<N, has a binary scanned bit. Derived from a preceding ordinary step; no induction or initial-bit assumption.')
 def transport(c,predicate,old,new):
  row=list(old)
  for j,(x,y) in enumerate(zip(old,new)):
   template=list(row);template[j]=ar.E;m.rewrite(c,predicate(template),x,y,c.get(Q(x,y)));row[j]=y
  return c.get(predicate(new))
 def embed(kind,routine):
  prefix=kind+'Run';entry,endpoint=routine['entry'],routine['endpoint']
  IV=[m.declare('embedded'+kind.title()+'Initial'+s) for s in ('Q','L','Bit','R')]
  RI=m.declare('embedded'+kind.title()+'RelativeIndex')
  RR=[m.declare('embedded'+kind.title()+'RelativeRow'+s) for s in ('Q','L','Bit','R')]
  EI=m.declare('embedded'+kind.title()+'AbsoluteIndex')
  ER=[m.declare('embedded'+kind.title()+'OutputRow'+s) for s in ('Q','L','Bit','R')]
  wi=m.declare('embedded'+kind.title()+'WitnessIndex')
  rows=[m.declare('embedded'+kind.title()+'WitnessRow'+s) for s in ('Q','L','Bit','R')]
  pred=m.declare('embedded'+kind.title()+'PreviousIndex')
  mp={prefix+'H':H,prefix+'N':n,prefix+'Offset':A(o,k),prefix+'BetaQuotient':h['quo'],prefix+'TotalIndex':h['sti'],prefix+'StepIndex':h['ssi'],prefix+'ExitIndex':RI}
  for j in range(4):mp[prefix+'B'+str(j)]=h['Bj'][j];mp[prefix+'C'+str(j)]=h['Cj'][j]
  for suffix,values in [('TotalRow',h['TV']),('StepRow0',h['SSV'][:4]),('StepRow1',h['SSV'][4:]),('InitialRow',IV),('Halt',halt),('ExitRow',RR)]:
   for s,v in zip(('Q','L','Bit','R'),values):mp[prefix+suffix+s]=v
  label='skelet17-ladder-skelet10-'+kind+'-window-halting-barrier'
  f=m.sub(m.theorems[label],mp)
  fs=[total(o,N),steps(o,N),Q(A(k,n),N),*bounds(cf),AT(o,k,cf),entry(cf),*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5))]
  prem=nd.AND(fs)
  def result(i,row):return nd.AND([L(k,i),AT(o,i,row),endpoint(row),L(row[2],two)])
  goal=nd.BEX(EI,A(N,O),nd.bexs(ER,H,result(EI,ER)))
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);unpack(c,entry(cf))
  apply(c,'skelet17-ladder-history-total-suffix');apply(c,'skelet17-ladder-history-steps-suffix')
  initial=b.Imp(AT(A(o,k),Z,IV),entry(IV))
  def initial_row(dc):
   ac=dc.push(AT(A(o,k),Z,IV));old=A(A(o,k),Z);new=A(o,k);m.eq(ac,old,new)
   m.rewrite(ac,absolute(ar.E,IV),old,new);row_unique(ac,k,cf,IV);transport(ac,entry,cf,IV)
   dc.intro(AT(A(o,k),Z,IV),entry(IV),ac);return dc.get(initial)
  bforall(c,IV,initial,initial_row)
  old=A(o,N);new=A(A(o,k),n);m.eq(c,old,new,[m.flip(c,Q(A(k,n),N))]);m.rewrite(c,absolute(ar.E,halt),old,new)
  collect(c,f[1]);use(c,label,mp)
  assert f[2]==nd.BEX(RI,A(n,O),nd.bexs(RR,H,b.And(AT(A(o,k),RI,RR),endpoint(RR))))
  def have_index(ic):
   def have_row(rc):
    unpack(rc,b.And(AT(A(o,k),wi,rows),endpoint(rows)))
    cases=[L(wi,Z),Q(wi,Z),L(Z,wi)]
    rc.put(nd.OR(cases),b.ax('O3',rc.g,t=wi,u=Z))
    def positive(dc,j):
     if j==0:
      dc.put(b.Not(L(wi,Z)),b.ax('O4',dc.g,t=wi));return dc.explode(L(wi,Z),L(Z,wi))
     if j==2:return dc.get(L(Z,wi))
     m.rewrite(dc,AT(A(o,k),ar.E,rows),wi,Z)
     old=A(A(o,k),Z);new=A(o,k);m.eq(dc,old,new);m.rewrite(dc,absolute(ar.E,rows),old,new)
     row_unique(dc,k,cf,rows)
     source,target=(1,3) if kind=='right' else (3,0)
     m.eq(dc,cf[0],ar.num(target),[Q(cf[0],rows[0]),Q(rows[0],ar.num(target))])
     return api['neq'](dc,cf[0],source,target,L(Z,wi))
    nd.cases(rc,cases,L(Z,wi),positive)
    # The endpoint bit is recovered from the preceding supplied Step.
    def preceding(dc,eq):
     m.eq(dc,wi,A(pred,O),[eq]);m.rewrite(dc,L(ar.E,A(n,O)),wi,A(pred,O))
     apply(dc,'skelet17-ladder-lt-add-cancel',{'t':pred,'u':n,'v':O})
     m.rewrite(dc,AT(A(o,k),ar.E,rows),wi,A(pred,O))
     bpm={N[1]:n,o[1]:A(o,k),idx[1]:pred,h['ti'][1]:h['sti'],h['si'][1]:h['ssi'],**{v[1]:x for v,x in zip(h['SV'],h['SSV'])},**{v[1]:x for v,x in zip(nf,rows)}}
     apply(dc,'skelet17-ladder-history-positive-row-bit',bpm);return dc.get(L(rows[2],two))
    m.gap_elim(rc,Z,wi,pred,L(rows[2],two),preceding)
    e=A(k,wi);m.ltadd(rc,wi,A(n,O),k)
    m.eq(rc,A(wi,k),e);m.rewrite(rc,L(ar.E,A(A(n,O),k)),A(wi,k),e)
    m.eq(rc,A(A(n,O),k),A(N,O),[m.flip(rc,Q(A(k,n),N))]);m.rewrite(rc,L(e,ar.E),A(A(n,O),k),A(N,O))
    m.ltadd(rc,Z,wi,k);m.eq(rc,A(Z,k),k);m.rewrite(rc,L(ar.E,A(wi,k)),A(Z,k),k)
    m.rewrite(rc,L(k,ar.E),A(wi,k),e)
    old=A(A(o,k),wi);new=A(o,e);m.eq(rc,old,new);m.rewrite(rc,absolute(ar.E,rows),old,new)
    nd.conj(rc,[L(k,e),AT(o,e,rows),endpoint(rows),L(rows[2],two)])
    pack_rows(rc,ER,result(e,ER),rows)
    return m.bex_intro(rc,EI,A(N,O),nd.bexs(ER,H,result(EI,ER)),e)
   return elim_rows(ic,RR,b.And(AT(A(o,k),wi,RR),endpoint(RR)),rows,goal,have_row)
  m.bex_elim(c,RI,A(n,O),nd.bexs(RR,H,b.And(AT(A(o,k),RI,RR),endpoint(RR))),wi,goal,have_index)
  finish('skelet10-'+kind+'-embedded-halting-barrier',root,prem,goal,c,'From a known counter entry in a supplied halting history, construct its correctly decoded strictly later output in that SAME history. Derives endpoint bit bound; reuses existing routine induction only.')
 if proofs:step_bit();advance();positive_bit();embed('right',right);embed('left',left)
 return {'halt':halt,'H':H,'n':N,'offset':o,'index':idx,'bounds':bounds,'unpack':unpack,'collect':collect,'apply':apply,'elim_rows':elim_rows,'pack_rows':pack_rows,'transport':transport}
