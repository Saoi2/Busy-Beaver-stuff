"""Decode the bounded spread relation; every theorem is derived, not an axiom."""
def add_skelet10_inverse(m, api, stage='all'):
 nd,b,a=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 two,four,ten=map(a.num,(2,4,10));use=m.invoke
 dil,transform,sq,push=[api[k] for k in ('dil','transform','sq','push')]
 pf,pb=api['pf'],api['pb'];forward,back,low_use=[api[k] for k in ('forward','back','low_use')]
 half=m.declare('inverseRootHalf');witness=m.declare('inverseRootWitness')
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+name,root,prem,goal,c,comment)
 def constants(c):
  m.bound(c,Z,two,O);m.bound(c,O,two,Z);m.bound(c,Z,four,a.num(3));m.bound(c,two,four,O)
 def contra(c,lo,hi,goal):
  m.bound(c,lo,hi,Z);m.rewrite(c,L(lo,a.E),hi,lo,a.sym(lo,hi,c.get(Q(lo,hi)),c.g))
  bad=L(lo,lo);c.put(b.Not(bad),b.ax('O1',c.g,t=lo));return c.explode(bad,goal)
 def powhalf(c,p,goal,one,even):return api['pow_half'](c,p,goal,one,even,half)
 def root_one():
  p=b.t;fs=[m.power2(p),Q(sq(p),O)];prem=b.And(*fs);goal=Q(p,O)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);constants(c)
  def even(cc,h,heq):
   left=A(M(two,M(two,sq(h))),Z)
   m.eq(cc,sq(p),left,[heq]);se=m.flip(cc,Q(sq(p),left))
   m.eq(cc,left,A(M(two,Z),O),[se,fs[1]])
   m.quotient_unique(cc,two,M(two,sq(h)),Z,Z,O);return m.false_zero_one(cc,goal)
  powhalf(c,p,goal,lambda cc:cc.get(goal),even)
  m.finish('z10-inverse-square-one',root,prem,goal,c,'A Pow2 square equals 1 only at 1. No new induction.')
 def root_not_two():
  p=b.t;prem=m.power2(p);root=nd.Ctx();c=root.push(prem);eq=Q(sq(p),two);ec=c.push(eq);constants(ec);bad=L(O,O)
  def one(cc):
   m.eq(cc,sq(p),O,[Q(p,O)]);m.rewrite(cc,Q(a.E,two),sq(p),O);return contra(cc,O,two,bad)
  def even(cc,h,heq):
   left=A(M(four,sq(h)),Z)
   m.eq(cc,sq(p),left,[heq]);se=m.flip(cc,Q(sq(p),left))
   m.eq(cc,left,A(M(four,Z),two),[se,eq]);m.quotient_unique(cc,four,sq(h),Z,Z,two)
   m.rewrite(cc,L(Z,a.E),two,Z,a.sym(Z,two,cc.get(Q(Z,two)),cc.g));cc.put(b.Not(L(Z,Z)),b.ax('O1',cc.g,t=Z))
   return cc.explode(L(Z,Z),bad)
  powhalf(ec,p,bad,one,even);ec.put(b.Not(bad),b.ax('O1',ec.g,t=O))
  c.put(b.Not(eq),a.not_intro(c.g,eq,bad,ec.get(bad),ec.get(b.Not(bad))))
  m.finish('z10-inverse-square-not-two',root,prem,b.Not(eq),c,'No Pow2 square equals 2. Quotient uniqueness, no new induction.')
 def square_quarter():
  p,q=b.t,b.u;fs=[m.power2(p),Q(sq(p),M(four,q))];prem=b.And(*fs)
  wb=nd.AND([Q(p,M(two,witness)),m.power2(witness),Q(q,sq(witness))]);goal=nd.BEX(witness,A(p,O),wb)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);constants(c)
  def one(cc):
   m.eq(cc,sq(p),O,[Q(p,O)]);m.rewrite(cc,Q(a.E,M(four,q)),sq(p),O)
   left=A(M(two,Z),O);right=A(M(two,M(two,q)),Z)
   m.eq(cc,O,left);m.rewrite(cc,Q(a.E,M(four,q)),O,left)
   m.eq(cc,M(four,q),right);m.rewrite(cc,Q(left,a.E),M(four,q),right)
   m.quotient_unique(cc,two,Z,O,M(two,q),Z);m.flip(cc,Q(O,Z));return m.false_zero_one(cc,goal)
  def even(cc,h,heq):
   left=A(M(four,sq(h)),Z)
   m.eq(cc,sq(p),left,[heq]);se=m.flip(cc,Q(sq(p),left))
   m.eq(cc,left,A(M(four,q),Z),[se,fs[1]])
   m.quotient_unique(cc,four,sq(h),Z,q,Z);m.flip(cc,Q(sq(h),q))
   nd.conj(cc,[heq,m.power2(h),Q(q,sq(h))]);return m.bex_intro(cc,witness,A(p,O),wb,h)
  powhalf(c,p,goal,one,even)
  m.finish('z10-inverse-square-quarter',root,prem,goal,c,'A Pow2 square divisible by 4 has the corresponding bounded half-root. No new induction.')
 root_one();root_not_two();square_quarter()
 if stage=='roots':return
 def low_digit():
  x,z,d,e=b.t,b.u,b.v,b.w;nx=push(x,d);nz=push(z,e)
  fs=[dil(nx,nz),L(d,two),L(e,two)];prem=nd.AND(fs);goal=Q(d,e)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);nd.unpack(c,list(dil(nx,nz)[1:]));constants(c)
  low_use(c,x,d);low_use(c,z,e)
  # The forward clause identifies input bit 1 with output bit 1.
  ic=c.push(Q(d,O));ic.mp(Q(d,O),m.bit1(nx,O));use(ic,'skelet17-binary-power-one',{},False)
  use(ic,'skelet17-ladder-skelet10-bit-support-bound',{'t':nx,'u':O});api['use_fwd'](ic,nx,nz,O)
  m.eq(ic,sq(O),O);m.rewrite(ic,m.bit1(nz,a.E),sq(O),O);ic.mp(m.bit1(nz,O),Q(e,O))
  c.intro(Q(d,O),Q(e,O),ic)
  # The reverse clause forbids an extra low output bit.
  ec=c.push(Q(e,O));ec.mp(Q(e,O),m.bit1(nz,O));use(ec,'skelet17-binary-power-one',{},False)
  use(ec,'skelet17-ladder-skelet10-bit-support-bound',{'t':nz,'u':O});api['use_rev'](ec,nx,nz,O)
  def found(cc,p):
   m.flip(cc,Q(O,sq(p)));cc.both(m.power2(p),Q(sq(p),O));use(cc,'z10-inverse-square-one',{'t':p})
   m.rewrite(cc,m.bit1(nx,a.E),p,O);return cc.mp(m.bit1(nx,O),Q(d,O))
  api['eliminate_witness'](ec,nx,O,Q(d,O),found);c.intro(Q(e,O),Q(d,O),ec)
  use(c,'skelet17-binary-digit-cases',{'t':d})
  def digit(cc,k):
   if k==1:
    cc.mp(Q(d,O),Q(e,O));return m.eq(cc,d,e,[Q(d,O),Q(e,O)])
   use(cc,'skelet17-binary-digit-cases',{'t':e})
   def outdigit(dc,j):
    if j==0:return m.eq(dc,d,e,[Q(d,Z),Q(e,Z)])
    dc.mp(Q(e,O),Q(d,O));m.rewrite(dc,Q(a.E,O),d,Z,dc.get(Q(d,Z)));return m.false_zero_one(dc,goal)
   return nd.cases(cc,[Q(e,Z),Q(e,O)],goal,outdigit)
  nd.cases(c,[Q(d,Z),Q(d,O)],goal,digit)
  finish('spread-low-digit',root,prem,goal,c,'A bounded spread pair has the same low input/output bit. No new induction.')
 def second_zero():
  x,z=b.t,b.u;prem=dil(x,z);root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]))
  bit=m.bit1(z,two);ec=c.push(bit);use(ec,'skelet17-binary-power-one',{},False)
  use(ec,'skelet17-binary-power-double',{'t':O});m.eq(ec,M(two,O),two)
  m.rewrite(ec,m.power2(a.E),M(two,O),two)
  use(ec,'skelet17-ladder-skelet10-bit-support-bound',{'t':z,'u':two});api['use_rev'](ec,x,z,two)
  def found(cc,p):
   use(cc,'z10-inverse-square-not-two',{'t':p});m.flip(cc,Q(two,sq(p)))
   return cc.explode(Q(sq(p),two),L(Z,Z))
  api['eliminate_witness'](ec,x,two,L(Z,Z),found);ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z))
  c.put(b.Not(bit),a.not_intro(c.g,bit,L(Z,Z),ec.get(L(Z,Z)),ec.get(b.Not(L(Z,Z)))))
  finish('spread-second-bit-zero',root,prem,b.Not(bit),c,'Every bounded spread output has zero in binary place 2. No new induction.')
 def pop():
  x,z,d=b.t,b.u,b.v;nx=push(x,d);nz=push(M(two,z),d)
  prem=b.And(dil(nx,nz),L(d,two));root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));nd.unpack(c,list(dil(nx,nz)[1:]));constants(c)
  def fproof(pc):
   p=pf;ante=b.And(m.power2(p),m.bit1(x,p));cc=pc.push(ante);nd.unpack(cc,list(ante[1:]));goal=m.bit1(z,sq(p))
   forward(cc,x,p,d);use(cc,'skelet17-binary-power-double',{'t':p})
   use(cc,'skelet17-ladder-skelet10-bit-support-bound',{'t':nx,'u':M(two,p)})
   api['use_fwd'](cc,nx,nz,M(two,p))
   m.eq(cc,sq(M(two,p)),M(two,M(two,sq(p))));m.rewrite(cc,m.bit1(nz,a.E),sq(M(two,p)),M(two,M(two,sq(p))))
   nd.unpack(cc,list(m.power2(p)[1:]));cc.both(L(Z,p),L(Z,p))
   cc.put(b.Imp(b.And(L(Z,p),L(Z,p)),L(M(Z,p),sq(p))),b.ax('O6',cc.g,t=Z,u=p,v=p))
   cc.mp(b.And(L(Z,p),L(Z,p)),L(M(Z,p),sq(p)));m.eq(cc,M(Z,p),Z);m.rewrite(cc,L(a.E,sq(p)),M(Z,p),Z)
   cc.both(L(Z,two),L(Z,sq(p)))
   cc.put(b.Imp(b.And(L(Z,two),L(Z,sq(p))),L(M(Z,sq(p)),M(two,sq(p)))),b.ax('O6',cc.g,t=Z,u=two,v=sq(p)))
   cc.mp(b.And(L(Z,two),L(Z,sq(p))),L(M(Z,sq(p)),M(two,sq(p))));m.eq(cc,M(Z,sq(p)),Z);m.rewrite(cc,L(a.E,M(two,sq(p))),M(Z,sq(p)),Z)
   back(cc,M(two,z),M(two,sq(p)),d)
   m.eq(cc,M(two,z),push(z,Z));m.rewrite(cc,m.bit1(a.E,M(two,sq(p))),M(two,z),push(z,Z))
   back(cc,z,sq(p),Z);pc.intro(ante,goal,cc);return pc.get(api['fbody'](x,z,p))
  api['fresh_fwd'](c,x,z,fproof)
  def rproof(pc):
   q=pb;ante=b.And(m.power2(q),m.bit1(z,q));cc=pc.push(ante);nd.unpack(cc,list(ante[1:]));goal=api['witness'](x,q)
   forward(cc,z,q,Z);m.eq(cc,push(z,Z),M(two,z));m.rewrite(cc,m.bit1(a.E,M(two,q)),push(z,Z),M(two,z))
   forward(cc,M(two,z),M(two,q),d)
   use(cc,'skelet17-binary-power-double',{'t':q});use(cc,'skelet17-binary-power-double',{'t':M(two,q)})
   scale=M(two,M(two,q));use(cc,'skelet17-ladder-skelet10-bit-support-bound',{'t':nz,'u':scale})
   api['use_rev'](cc,nx,nz,scale)
   def found(dc,p):
    m.eq(dc,sq(p),M(four,q),[m.flip(dc,Q(scale,sq(p)))]);dc.both(m.power2(p),Q(sq(p),M(four,q)))
    use(dc,'z10-inverse-square-quarter',{'t':p,'u':q})
    wb=nd.AND([Q(p,M(two,witness)),m.power2(witness),Q(q,sq(witness))])
    def rootfound(ec):
     heq=Q(p,M(two,half));nd.unpack(ec,[heq,m.power2(half),Q(q,sq(half))]);nd.unpack(ec,list(m.power2(half)[1:]))
     m.rewrite(ec,m.bit1(nx,a.E),p,M(two,half));back(ec,x,half,d)
     use(ec,'skelet17-ladder-skelet10-bit-support-bound',{'t':x,'u':half});return api['pack_witness'](ec,x,q,half)
    return m.bex_elim(dc,witness,A(p,O),wb,half,goal,rootfound)
   api['eliminate_witness'](cc,nx,scale,goal,found);pc.intro(ante,goal,cc);return pc.get(api['rbody'](x,z,q))
  api['fresh_rev'](c,x,z,rproof);c.both(api['fwd'](x,z),api['rev'](x,z))
  finish('spread-pop',root,prem,dil(x,z),c,'Removing a matched low binary/base-four digit preserves the exact bounded spread graph. No new induction.')
 low_digit();second_zero();pop()
 if stage=='pop':return
 outvar=m.declare('inverseOutputTail');dq,dr,eq,er=[m.declare('inverse'+s) for s in ('FirstHalf','FirstBit','SecondHalf','SecondBit')]
 def decoded(x,z,d):return nd.BEX(outvar,A(z,O),b.And(Q(z,A(M(four,outvar),d)),dil(x,outvar)))
 def decompose():
  x,z,d=b.t,b.u,b.v;nx=push(x,d);prem=b.And(dil(nx,z),L(d,two));goal=decoded(x,z,d)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));constants(c)
  use(c,'skelet17-ladder-skelet10-spread-second-bit-zero',{'t':nx,'u':z})
  use(c,'skelet17-bounded-division-exists',{'t':z,'u':two})
  def firstq(qc):
   def firstbit(rc):
    zeq=Q(z,push(dq,dr));m.rewrite(rc,dil(nx,a.E),z,push(dq,dr))
    nd.conj(rc,[dil(nx,push(dq,dr)),L(d,two),L(dr,two)])
    use(rc,'skelet17-ladder-skelet10-spread-low-digit',{'t':x,'u':dq,'v':d,'w':dr})
    use(rc,'skelet17-bounded-division-exists',{'t':dq,'u':two})
    def secondq(sc):
     def secondbit(tc):
      qeq=Q(dq,push(eq,er));use(tc,'skelet17-binary-digit-cases',{'t':er})
      def digit(dc,k):
       if k==1:
        low_use(dc,eq,er);dc.mp(Q(er,O),m.bit1(push(eq,er),O))
        m.rewrite(dc,m.bit1(a.E,O),push(eq,er),dq,a.sym(dq,push(eq,er),dc.get(qeq),dc.g))
        forward(dc,dq,O,dr);m.eq(dc,M(two,O),two);m.rewrite(dc,m.bit1(push(dq,dr),a.E),M(two,O),two)
        m.rewrite(dc,m.bit1(a.E,two),push(dq,dr),z,a.sym(z,push(dq,dr),dc.get(zeq),dc.g))
        return dc.explode(m.bit1(z,two),goal)
       # Quotient uniqueness has matched the two low digits; the second
       # output bit is zero, so divide off one entire base-four digit.
       m.flip(dc,Q(d,dr));value=A(M(four,eq),d)
       m.eq(dc,z,value,[zeq,qeq,Q(er,Z),Q(dr,d)]);m.rewrite(dc,dil(nx,a.E),z,value)
       canonical=push(M(two,eq),d);m.eq(dc,value,canonical)
       m.rewrite(dc,dil(nx,a.E),value,canonical);dc.both(dil(nx,canonical),L(d,two))
       use(dc,'skelet17-ladder-skelet10-spread-pop',{'t':x,'u':eq,'v':d})
       dc.both(L(eq,A(dq,O)),L(dq,A(z,O)));use(dc,'skelet17-binary-le-lt-trans',{'t':eq,'u':dq,'v':A(z,O)})
       dc.both(Q(z,value),dil(x,eq));return m.bex_intro(dc,outvar,A(z,O),b.And(Q(z,A(M(four,outvar),d)),dil(x,outvar)),eq)
      return nd.cases(tc,[Q(er,Z),Q(er,O)],goal,digit)
     return m.bex_elim(sc,m.r,two,Q(dq,push(eq,m.r)),er,goal,secondbit)
    return m.bex_elim(rc,m.q,A(dq,O),nd.BEX(m.r,two,Q(dq,push(m.q,m.r))),eq,goal,secondq)
   return m.bex_elim(qc,m.r,two,Q(z,push(dq,m.r)),dr,goal,firstbit)
  m.bex_elim(c,m.q,A(z,O),nd.BEX(m.r,two,Q(z,push(m.q,m.r))),dq,goal,firstq)
  finish('spread-decompose',root,prem,goal,c,'Every encoded binary digit can be decoded: Dil(2x+d,z) entails a bounded u with z=4u+d and Dil(x,u). No new induction.')
 decompose()
 if stage=='decode':return
 if 'z10-spread-product-reorder' not in m.theorems:api['coefficient_identities']()
 # Inverse forms of the left-word grammar constructors. These are needed
 # when a machine carry removes a previously encoded 00 or 1010 block.
 tf,first,second=[m.declare('inverseTransform'+s) for s in ('Spread','First','Second')]
 zw=api['zw']
 def use_decode(c,x,z,d):
  c.both(dil(push(x,d),z),L(d,two));use(c,'skelet17-ladder-skelet10-spread-decompose',{'t':x,'u':z,'v':d})
 def decode_elim(c,x,z,d,fresh,goal,fn):
  body=b.And(Q(z,A(M(four,outvar),d)),dil(x,outvar))
  def found(cc):nd.unpack(cc,[Q(z,A(M(four,fresh),d)),dil(x,fresh)]);return fn(cc)
  return m.bex_elim(c,outvar,A(z,O),body,fresh,goal,found)
 def transform_inverse(digits,label):
  x,t=b.t,b.u;nx=M(two,x) if digits==1 else A(M(four,x),O)
  scale=four if digits==1 else a.num(16);nt=M(four,t) if digits==1 else A(M(scale,t),ten)
  root=nd.Ctx();prem=transform(nx,nt);c=root.push(prem);goal=transform(x,t);constants(c)
  def found(cc):
   original=Q(nt,M(ten,tf));nd.unpack(cc,[original,dil(nx,tf)])
   ix=x if digits==1 else M(two,x);digit=Z if digits==1 else O
   m.eq(cc,nx,push(ix,digit));m.rewrite(cc,dil(a.E,tf),nx,push(ix,digit));use_decode(cc,ix,tf,digit)
   def firstfound(dc):
    firsteq=Q(tf,A(M(four,first),digit))
    def conclude(ec,z,zeq):
     # First move the coefficient identity as one unit; expanding a
     # literal 16*10 in unary would add unnecessary semiring proof nodes.
     inner=M(scale,z) if digits==1 else A(M(scale,z),O)
     m.rewrite(ec,Q(nt,M(ten,a.E)),tf,inner,ec.get(zeq))
     if digits==1:
      use(ec,'z10-spread-product-reorder',{'t':ten,'u':scale,'v':z},False)
      rhs=M(scale,M(ten,z));m.rewrite(ec,Q(nt,a.E),M(ten,inner),rhs)
     else:
      use(ec,'z10-spread-affine-scale',{'t':scale,'u':ten,'v':z},False)
      rhs=A(M(scale,M(ten,z)),ten)
      m.rewrite(ec,Q(nt,a.E),M(ten,inner),rhs,a.sym(rhs,M(ten,inner),ec.get(Q(rhs,M(ten,inner))),ec.g))
      ant=Q(nt,rhs);ce=Q(M(scale,t),M(scale,M(ten,z)))
      ec.theorem(b.Imp(ant,ce),b.apply('add-cancel',{'t':M(scale,t),'u':M(scale,M(ten,z)),'v':ten}));ec.mp(ant,ce)
     lhs0=A(M(scale,t),Z);rhs0=A(M(scale,M(ten,z)),Z)
     ce=Q(M(scale,t),M(scale,M(ten,z)))
     m.eq(ec,lhs0,rhs0,[ce]);m.bound(ec,Z,scale,a.num(3 if digits==1 else 15))
     m.quotient_unique(ec,scale,t,Z,M(ten,z),Z)
     m.bound(ec,Z,ten,a.num(9));use(ec,'skelet17-binary-factor-bound',{'t':z,'u':ten})
     m.rewrite(ec,L(z,A(a.E,O)),M(ten,z),t,a.sym(t,M(ten,z),ec.get(Q(t,M(ten,z))),ec.g))
     return api['pack_transform'](ec,x,t,z)
    if digits==1:
     m.eq(dc,tf,M(four,first),[firsteq]);return conclude(dc,first,Q(tf,M(four,first)))
    m.eq(dc,M(two,x),push(x,Z));m.rewrite(dc,dil(a.E,first),M(two,x),push(x,Z));use_decode(dc,x,first,Z)
    def secondfound(ec):
     secondeq=Q(first,A(M(four,second),Z));inner=A(M(scale,second),O)
     m.eq(ec,tf,inner,[firsteq,secondeq]);return conclude(ec,second,Q(tf,inner))
    return decode_elim(dc,x,first,Z,second,goal,secondfound)
   return decode_elim(cc,ix,tf,digit,first,goal,firstfound)
  m.bex_elim(c,zw,A(nt,O),b.And(Q(nt,M(ten,zw)),dil(nx,zw)),tf,goal,found)
  finish(label,root,prem,goal,c,'Inverse of the bounded left-word grammar constructor, derived from exact spread decoding. No new induction.')
 transform_inverse(1,'transform-pop-0');transform_inverse(2,'transform-pop-10')
 return {'decoded':decoded}
