"""The complete right-counter relation and ranked ordinary-step invariant."""
def add_skelet10_right(m,api,ret,proofs=True):
 nd,b,a=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 two,three,four,five,twelve,sixteen=map(a.num,(2,3,4,5,12,16));use=m.invoke
 word,ell=[m.declare('right'+s,'term') for s in ('Input','Left')]
 cf,nf=api['current'],api['next'];step,parts,sparse=api['step'],api['parts'],api['sparse']
 def wr(c):return A(M(two,c[3]),c[2])
 def wl(c):return A(M(two,c[1]),c[2])
 S=A(M(three,word),two);W=A(word,O);K=M(sixteen,W)
 jp,js,ja=[m.declare('rightCarry'+s) for s in ('Scale','Suffix','Tail')]
 pp,ps=[m.declare('rightPhase'+s) for s in ('Scale','Suffix')]
 fp,fs,fh,fe=[m.declare('rightFresh'+s) for s in ('Scale','Suffix','Half','Even')]
 nrank=m.declare('rightOutputRank');gap=m.declare('rightGap')
 def carry_parts(w,v,p,s,t):return [m.power2(p),Q(p,A(M(three,s),O)),Q(w,A(M(p,M(two,t)),s)),Q(v,M(p,A(M(four,t),O)))]
 def carry(w,v):return nd.BEX(jp,A(M(three,w),two),nd.BEX(js,A(w,O),nd.BEX(ja,A(w,O),nd.AND(carry_parts(w,v,jp,js,ja)))))
 def endpoint(c):return nd.AND([Q(c[0],three),Q(wl(c),ell),carry(word,c[3]),sparse(c[3])])
 def ranks(c,p):return [A(A(K,M(four,wr(c))),two),A(A(K,M(sixteen,c[3])),five),A(A(K,M(four,c[3])),O),M(four,p)]
 def phase(c,r,j,p,s):
  q,l,bit,rr=c;common=[m.power2(p),Q(p,A(M(three,s),O))]
  if j==0:return [Q(q,O),L(bit,two),*common,Q(A(l,O),M(M(two,p),A(ell,O))),Q(word,A(M(p,wr(c)),s)),sparse(wr(c)),Q(r,ranks(c,p)[j])]
  if j==1:return [Q(q,Z),Q(bit,Z),*common,Q(A(l,O),M(M(four,p),A(ell,O))),Q(word,A(M(M(four,p),rr),A(M(four,s),O))),sparse(rr),Q(r,ranks(c,p)[j])]
  if j==2:return [Q(q,two),Q(bit,O),*common,Q(A(l,O),M(p,A(ell,O))),Q(word,A(M(p,rr),s)),m.even(rr),sparse(rr),Q(r,ranks(c,p)[j])]
  return [Q(q,three),L(bit,two),m.power2(p),Q(A(wl(c),O),M(p,A(ell,O))),carry(word,M(p,rr)),sparse(rr),Q(r,ranks(c,p)[j])]
 def clause(c,r,j):
  body=nd.AND(phase(c,r,j,pp,ps))
  if j<3:body=nd.BEX(ps,W,body)
  return nd.BEX(pp,S,body)
 def rank(c,r):return nd.OR([clause(c,r,j) for j in range(4)])
 initial_rank=A(A(K,M(four,word)),two)
 def entry(c):return nd.AND([Q(c[0],O),Q(c[1],A(M(two,ell),O)),Q(wr(c),word),L(c[2],two),sparse(word)])
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+name,root,prem,goal,c,comment)
 def prefix_bounds():
  p,s,w,r=b.t,b.u,b.v,b.w;eqs=[Q(p,A(M(three,s),O)),Q(w,A(M(p,r),s))];prem=b.And(*eqs)
  goals=[L(p,A(M(three,w),two)),L(s,A(w,O)),L(r,A(w,O))];root=nd.Ctx();c=root.push(prem);nd.unpack(c,eqs)
  m.bound(c,p,A(M(three,w),two),M(three,M(p,r)),eqs[::-1])
  m.bound(c,s,A(w,O),M(p,r),eqs[1:]);m.bound(c,r,A(w,O),A(M(M(three,s),r),s),eqs[::-1])
  nd.conj(c,goals);m.finish('z10-right-prefix-bounds',root,prem,nd.AND(goals),c,'Bounds for every consumed carry prefix. No induction.')
 def elementary_rank_helpers():
  # Keep coefficients and the common rank offset opaque on instantiation.
  x,y=b.t,b.u;root=nd.Ctx();prem=L(Z,y);c=root.push(prem);goal=L(Z,A(x,y))
  m.gap_elim(c,Z,y,gap,goal,lambda dc,eq:m.bound(dc,Z,A(x,y),A(x,gap),[eq]))
  m.finish('z10-right-positive-add',root,prem,goal,c,'Adding a positive summand gives a positive sum. No induction.')
  root=nd.Ctx();goal=L(x,A(A(x,y),O));m.bound(root,x,A(A(x,y),O),y)
  m.save('z10-right-margin',root,goal,'An explicitly positive additive margin. No induction.')
  root=nd.Ctx();coef=Q(M(four,four),sixteen);m.eq(root,*coef[1:])
  # Associativity and coefficient equality, without expanding the input x.
  left=M(M(four,x),four);middle=M(M(four,four),x)
  root.put(Q(left,M(four,M(four,x))),b.ax('A5',root.g,t=M(four,x),u=four))
  root.put(Q(middle,M(four,M(four,x))),b.ax('A4',root.g,t=four,u=four,v=x))
  root.put(Q(left,middle),a.trans(left,M(four,M(four,x)),middle,root.get(Q(left,M(four,M(four,x)))),a.sym(middle,M(four,M(four,x)),root.get(Q(middle,M(four,M(four,x)))),root.g),root.g))
  m.rewrite(root,Q(left,M(a.E,x)),M(four,four),sixteen)
  m.save('z10-right-four-square-scale',root,Q(left,M(sixteen,x)),'Factored coefficient 4*4=16, at an arbitrary input. No induction.')
  k,x,y,r=b.t,b.u,b.v,b.w
  for case in ('B1','B0','A0'):
   old=A(A(k,M(four,A(M(two,x),O))),two) if case=='B1' else A(A(k,M(four,M(two,x))),two) if case=='B0' else A(A(k,M(sixteen,x)),five)
   new=A(A(k,M(sixteen,y)),five) if case=='B1' else A(A(k,M(four,y)),O) if case=='B0' else A(A(k,M(four,y)),two)
   relation=Q(x,M(two,y)) if case=='B1' else Q(y,M(two,x)) if case=='B0' else Q(y,x)
   fs0=[Q(r,old),relation];prem=b.And(*fs0);goal=L(new,r);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs0)
   slack=A(M(twelve,x),two) if case=='A0' else Z
   m.bound(c,new,r,slack,fs0)
   m.finish('z10-right-rank-drop-'+case,root,prem,goal,c,'Rank comparison with the common offset treated as an arbitrary parameter. No induction.')
 def c_rank_bound():
  p,s,w,r=b.t,b.u,b.v,b.w;fs0=[Q(p,A(M(three,s),O)),L(s,A(w,O))];prem=b.And(*fs0)
  upper=M(four,A(w,O));target=A(A(M(sixteen,A(w,O)),M(four,r)),O);goal=L(M(four,p),target)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs0)
  def found(cc,geq):
   ant=Q(A(w,O),A(A(s,gap),O));m.eq(cc,*ant[1:],[geq]);out=Q(w,A(s,gap))
   cc.theorem(b.Imp(ant,out),b.apply('add-cancel',{'t':w,'u':A(s,gap),'v':O}));cc.mp(ant,out)
   return m.bound(cc,p,upper,A(A(s,M(four,gap)),two),[fs0[0],out])
  m.gap_elim(c,s,A(w,O),gap,L(p,upper),found);m.bound(c,Z,four,three)
  c.both(L(p,upper),L(Z,four));out=L(M(p,four),M(upper,four));c.put(out,b.mp(c.g,b.And(L(p,upper),L(Z,four)),out,b.ax('O6',c.g,t=p,u=upper,v=four),c.get(b.And(L(p,upper),L(Z,four)))))
  c.put(Q(M(p,four),M(four,p)),b.ax('A5',c.g,t=p,u=four));m.rewrite(c,L(a.E,M(upper,four)),M(p,four),M(four,p))
  use(c,'z10-right-four-square-scale',{'t':A(w,O)},False);m.rewrite(c,L(M(four,p),a.E),M(upper,four),M(sixteen,A(w,O)))
  use(c,'z10-right-margin',{'t':M(sixteen,A(w,O)),'u':M(four,r)},False);m.translt(c,M(four,p),M(sixteen,A(w,O)),target)
  m.finish('z10-right-C-rank-bound',root,prem,goal,c,'The carry exit to D strictly decreases the global rank. Factored coefficients; no induction.')
 if proofs:prefix_bounds();elementary_rank_helpers();c_rank_bound()
 def bounds(c,p,s,r):
  c.both(Q(p,A(M(three,s),O)),Q(word,A(M(p,r),s)));use(c,'z10-right-prefix-bounds',{'t':p,'u':s,'v':word,'w':r})
  return nd.unpack(c,[L(p,S),L(s,W),L(r,W)])
 def pack(c,row,r,j,p,s=Z):
  body=nd.AND(phase(row,r,j,p,s));nd.conj(c,phase(row,r,j,p,s))
  if j<3:
   m.bex_intro(c,ps,W,nd.AND(phase(row,r,j,p,ps)),s)
   body=nd.BEX(ps,W,nd.AND(phase(row,r,j,p,ps)))
  m.bex_intro(c,pp,S,nd.BEX(ps,W,nd.AND(phase(row,r,j,pp,ps))) if j<3 else nd.AND(phase(row,r,j,pp,ps)),p)
  return nd.disj(c,[clause(row,r,k) for k in range(4)],j)
 def eliminate(c,row,r,j,goal,fn):
  def havep(pc):
   if j==3:nd.unpack(pc,phase(row,r,j,fp,ps));return fn(pc,fp,Z)
   def haves(sc):nd.unpack(sc,phase(row,r,j,fp,fs));return fn(sc,fp,fs)
   return m.bex_elim(pc,ps,W,nd.AND(phase(row,r,j,fp,ps)),fs,goal,haves)
  body=nd.BEX(ps,W,nd.AND(phase(row,r,j,pp,ps))) if j<3 else nd.AND(phase(row,r,j,pp,ps))
  return m.bex_elim(c,pp,S,body,fp,goal,havep)
 def pack_carry(c,v,p,s,t):
  nd.conj(c,carry_parts(word,v,p,s,t));m.bex_intro(c,ja,W,nd.AND(carry_parts(word,v,p,s,ja)),t)
  m.bex_intro(c,js,W,nd.BEX(ja,W,nd.AND(carry_parts(word,v,p,js,ja))),s)
  return m.bex_intro(c,jp,S,nd.BEX(js,W,nd.BEX(ja,W,nd.AND(carry_parts(word,v,jp,js,ja)))),p)
 def positivity():
  r=b.t;prem=rank(cf,r);goal=L(Z,r);root=nd.Ctx();c=root.push(prem)
  def branch(cc,j):
   def found(dc,p,s):
    re=Q(r,ranks(cf,p)[j])
    if j<3:
     scaled=[M(four,wr(cf)),M(sixteen,cf[3]),M(four,cf[3])][j];const=[two,five,O][j]
     m.bound(dc,Z,const,a.num([1,4,0][j]));use(dc,'z10-right-positive-add',{'t':A(K,scaled),'u':const})
     return m.rewrite(dc,L(Z,a.E),ranks(cf,p)[j],r,a.sym(r,ranks(cf,p)[j],dc.get(re),dc.g))
    nd.unpack(dc,list(m.power2(p)[1:]));return m.gap_elim(dc,Z,p,gap,goal,lambda ec,eq:m.bound(ec,Z,r,A(M(four,gap),three),[re,eq]))
   return eliminate(cc,cf,r,j,goal,found)
  nd.cases(c,[clause(cf,r,j) for j in range(4)],goal,branch)
  m.finish('z10-right-rank-positive',root,prem,goal,c,'All four phase ranks are positive. No induction.')
  root=nd.Ctx();c=root.push(prem);bad=Q(cf[0],a.num(5));bc=c.push(bad)
  def wrong(cc,j):
   return eliminate(cc,cf,r,j,L(Z,Z),lambda dc,p,s:api['neq'](dc,cf[0],[1,0,2,3][j],5,L(Z,Z)))
  nd.cases(bc,[clause(cf,r,j) for j in range(4)],L(Z,Z),wrong);bc.put(b.Not(L(Z,Z)),b.ax('O1',bc.g,t=Z))
  c.put(b.Not(bad),a.not_intro(c.g,bad,L(Z,Z),bc.get(L(Z,Z)),bc.get(b.Not(L(Z,Z)))))
  m.finish('z10-right-rank-safe',root,prem,b.Not(bad),c,'All ranked phases exclude halt. No induction.')
 if proofs:positivity()
 def entry_proof():
  root=nd.Ctx();prem=entry(cf);c=root.push(prem);nd.unpack(c,list_entry(cf));use(c,'skelet17-binary-power-one',{},False)
  m.bound(c,O,S,M(three,word));m.bound(c,Z,W,word)
  m.eq(c,O,A(M(three,Z),O));m.eq(c,A(cf[1],O),M(M(two,O),A(ell,O)),[Q(cf[1],A(M(two,ell),O))])
  m.eq(c,word,A(M(O,wr(cf)),Z),[m.flip(c,Q(wr(cf),word))]);m.rewrite(c,sparse(a.E),word,wr(cf),c.get(Q(word,wr(cf))))
  c.put(Q(initial_rank,initial_rank),b.refl(c.g,initial_rank));m.rewrite(c,Q(initial_rank,A(A(K,M(four,a.E)),two)),word,wr(cf),c.get(Q(word,wr(cf))))
  pack(c,cf,initial_rank,0,O,Z)
  finish('right-counter-entry',root,prem,rank(cf,initial_rank),c,'Every proper B entry has the bounded ranked invariant. Initial rank is 20w+18. No induction.')
 def list_entry(c):return [Q(c[0],O),Q(c[1],A(M(two,ell),O)),Q(wr(c),word),L(c[2],two),sparse(word)]
 if proofs:entry_proof()
 def pop_sparse(c,x,y,d,eq):
  nd.conj(c,[sparse(x),eq,L(d,two)]);return use(c,'skelet17-ladder-skelet10-sparse-pop',{'t':x,'u':y,'v':d})
 def doubled_successor(c,old,new,eq):
  out=Q(A(new,O),M(two,A(old,O)));m.eq(c,*out[1:],[eq]);return out
 def d_sparse_step():
  fs0=[Q(cf[0],three),Q(nf[0],three),sparse(cf[3]),step(cf,nf)];prem=nd.AND(fs0);goal=sparse(nf[3])
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs0)
  def instruction(cc,j):
   fields=parts(cf,nf,j);nd.unpack(cc,fields)
   if j//2!=3:return api['neq'](cc,cf[0],3,j//2,goal)
   if j==6:return api['neq'](cc,nf[0],3,2,goal)
   use(cc,'skelet17-ladder-skelet10-sparse-prefix-0',{'t':cf[3]})
   m.eq(cc,nf[3],M(two,cf[3]),[fields[3]])
   return m.rewrite(cc,sparse(a.E),M(two,cf[3]),nf[3],a.sym(nf[3],M(two,cf[3]),cc.get(Q(nf[3],M(two,cf[3]))),cc.g))
  nd.cases(c,[nd.AND(parts(cf,nf,j)) for j in range(10)],goal,instruction)
  m.finish('z10-right-D-sparse-step',root,prem,goal,c,'A D-to-D return step preserves Sparse of the right half. Ordinary instruction table, no new induction.')
 if proofs:d_sparse_step()
 def local():
  r=b.t;prem=nd.AND([rank(cf,r),b.Not(endpoint(cf)),step(cf,nf)]);goal=nd.BEX(nrank,r,rank(nf,nrank))
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,[rank(cf,r),b.Not(endpoint(cf)),step(cf,nf)])
  def output(cc,j,p,s,rho):
   assert rho==ranks(nf,p)[j];cc.put(Q(rho,rho),b.refl(cc.g,rho));pack(cc,nf,rho,j,p,s);return m.bex_intro(cc,nrank,r,rank(nf,nrank),rho)
  def region(cc,j):
   def found(dc,p,s):
    oldrank=Q(r,ranks(cf,p)[j])
    if j==3:
     # Instantiate the already verified D1 return-step theorem.
     prod=M(p,cf[3]);mapping={ret['ell'][1]:ell,ret['value'][1]:prod}
     rm=m.sub(ret['marker'](cf,p),mapping);re=m.sub(ret['endpoint'](cf),mapping)
     m.eq(dc,prod,prod);nd.conj(dc,[Q(cf[0],three),L(cf[2],two),m.power2(p),Q(A(wl(cf),O),M(p,A(ell,O))),Q(prod,prod)])
     ec=dc.push(re);nd.unpack(ec,[Q(cf[0],three),Q(wl(cf),ell),Q(cf[3],prod)])
     m.rewrite(ec,carry(word,a.E),prod,cf[3],a.sym(cf[3],prod,ec.get(Q(cf[3],prod)),ec.g));nd.conj(ec,[Q(cf[0],three),Q(wl(cf),ell),carry(word,cf[3]),sparse(cf[3])])
     ec.explode(endpoint(cf),L(Z,Z));ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z))
     dc.put(b.Not(re),a.not_intro(dc.g,re,L(Z,Z),ec.get(L(Z,Z)),ec.get(b.Not(L(Z,Z)))))
     nd.conj(dc,[rm,b.Not(re),step(cf,nf)])
     use(dc,'skelet17-ladder-skelet10-return-marker-step',{'t':p,**mapping})
     body=m.sub(ret['marker'](nf,ret['outscale']),mapping)
     def halve(ec):
      actual=m.sub(ret['marker'](nf,fh),mapping);nd.unpack(ec,list_marker(nf,fh,prod))
      m.translt(ec,fh,p,S)
      nd.conj(ec,[Q(cf[0],three),Q(nf[0],three),sparse(cf[3]),step(cf,nf)]);use(ec,'z10-right-D-sparse-step')
      m.rewrite(ec,carry(word,a.E),prod,M(fh,nf[3]),a.sym(M(fh,nf[3]),prod,ec.get(Q(M(fh,nf[3]),prod)),ec.g))
      m.bound(ec,Z,four,three);ec.both(L(fh,p),L(Z,four));out=L(M(fh,four),M(p,four));ec.put(out,b.mp(ec.g,b.And(L(fh,p),L(Z,four)),out,b.ax('O6',ec.g,t=fh,u=p,v=four),ec.get(b.And(L(fh,p),L(Z,four)))))
      m.eq(ec,M(fh,four),M(four,fh));m.rewrite(ec,L(a.E,M(p,four)),M(fh,four),M(four,fh));m.eq(ec,M(p,four),M(four,p));m.rewrite(ec,L(M(four,fh),a.E),M(p,four),M(four,p));m.rewrite(ec,L(M(four,fh),a.E),M(four,p),r,a.sym(r,M(four,p),ec.get(oldrank),ec.g))
      return output(ec,3,fh,Z,M(four,fh))
     return m.bex_elim(dc,ret['outscale'],p,body,fh,goal,halve)
    def instruction(ec,k):
     pf=parts(cf,nf,k);nd.unpack(ec,pf)
     state=[1,0,2][j]
     if k//2!=state:return api['neq'](ec,cf[0],state,k//2,goal)
     if j in (1,2) and k%2!=[0,0,1][j]:return api['neq'](ec,cf[2],[0,0,1][j],k%2,goal)
     api['bitbound'](ec,pf)
     if j==0 and k==3:
      # B1 -> A0; two Sparse deletions identify the next scanned zero.
      m.rewrite(ec,sparse(A(M(two,cf[3]),a.E)),cf[2],O)
      use(ec,'skelet17-ladder-skelet10-sparse-odd-tail',{'t':cf[3]})
      def even_found(hc):
       req=Q(cf[3],M(two,fe));m.eq(hc,A(M(two,nf[3]),nf[2]),A(M(two,fe),Z),[m.flip(hc,pf[4]),req])
       m.bound(hc,Z,two,O);m.quotient_unique(hc,two,nf[3],nf[2],fe,Z)
       m.bound(hc,O,two,Z);eq1=Q(A(M(two,cf[3]),O),A(M(two,cf[3]),O));m.eq(hc,*eq1[1:]);pop_sparse(hc,A(M(two,cf[3]),O),cf[3],O,eq1)
       eq2=Q(cf[3],A(M(two,nf[3]),Z));m.eq(hc,*eq2[1:],[pf[4],Q(nf[2],Z)]);pop_sparse(hc,cf[3],nf[3],Z,eq2)
       ds=doubled_successor(hc,cf[1],nf[1],pf[3]);m.eq(hc,A(nf[1],O),M(M(four,p),A(ell,O)),[ds,Q(A(cf[1],O),M(M(two,p),A(ell,O)))])
       m.eq(hc,word,A(M(M(four,p),nf[3]),A(M(four,s),O)),[Q(word,A(M(p,wr(cf)),s)),Q(cf[2],O),pf[4],Q(nf[2],Z),Q(p,A(M(three,s),O))])
       rho=ranks(nf,p)[1]
       adjusted=A(A(K,M(four,A(M(two,cf[3]),O))),two)
       m.rewrite(hc,Q(r,A(A(K,M(four,A(M(two,cf[3]),a.E))),two)),cf[2],O)
       m.eq(hc,cf[3],M(two,nf[3]),[pf[4],Q(nf[2],Z)])
       hc.both(Q(r,adjusted),Q(cf[3],M(two,nf[3])));use(hc,'z10-right-rank-drop-B1',{'t':K,'u':cf[3],'v':nf[3],'w':r})
       return output(hc,1,p,s,rho)
      return m.bex_elim(ec,m.pz,A(cf[3],O),Q(cf[3],M(two,m.pz)),fe,goal,even_found)
     if j==0 and k==2:
      peq=Q(A(cf[1],O),M(two,M(p,A(ell,O))));m.eq(ec,*peq[1:],[Q(A(cf[1],O),M(M(two,p),A(ell,O)))])
      nd.conj(ec,[peq,pf[4],L(nf[2],two)]);use(ec,'z10-return-even-predecessor',{'t':cf[1],'u':M(p,A(ell,O)),'v':nf[1],'w':nf[2]})
      nd.unpack(ec,[Q(nf[2],O),Q(A(nf[1],O),M(p,A(ell,O)))])
      m.eq(ec,word,A(M(p,nf[3]),s),[Q(word,A(M(p,wr(cf)),s)),Q(cf[2],Z),m.flip(ec,pf[3])])
      m.eq(ec,nf[3],M(two,cf[3]),[pf[3]]);m.bound(ec,cf[3],A(nf[3],O),cf[3],[pf[3]])
      m.bex_intro(ec,m.pz,A(nf[3],O),Q(nf[3],M(two,m.pz)),cf[3])
      m.rewrite(ec,sparse(A(M(two,cf[3]),a.E)),cf[2],Z);m.rewrite(ec,sparse(a.E),A(M(two,cf[3]),Z),nf[3],a.sym(nf[3],A(M(two,cf[3]),Z),ec.get(pf[3]),ec.g))
      rho=ranks(nf,p)[2];adjusted=A(A(K,M(four,M(two,cf[3]))),two)
      m.rewrite(ec,Q(r,A(A(K,M(four,A(M(two,cf[3]),a.E))),two)),cf[2],Z)
      pluszero=A(M(two,cf[3]),Z);ec.put(Q(pluszero,M(two,cf[3])),b.ax('A3',ec.g,t=M(two,cf[3])))
      m.rewrite(ec,Q(r,A(A(K,M(four,a.E)),two)),pluszero,M(two,cf[3]))
      ec.both(Q(r,adjusted),Q(nf[3],M(two,cf[3])));use(ec,'z10-right-rank-drop-B0',{'t':K,'u':cf[3],'v':nf[3],'w':r})
      return output(ec,2,p,s,rho)
     if j==1:
      assert k==0
      np,ns=M(four,p),A(M(four,s),O)
      use(ec,'skelet17-binary-power-double',{'t':p});use(ec,'skelet17-binary-power-double',{'t':M(two,p)})
      m.eq(ec,M(two,M(two,p)),np);m.rewrite(ec,m.power2(a.E),M(two,M(two,p)),np)
      m.eq(ec,np,A(M(three,ns),O),[Q(p,A(M(three,s),O))])
      m.eq(ec,word,A(M(np,wr(nf)),ns),[Q(word,A(M(M(four,p),cf[3]),A(M(four,s),O))),pf[4]])
      bounds(ec,np,ns,wr(nf));m.rewrite(ec,sparse(a.E),cf[3],wr(nf),ec.get(pf[4]))
      ds=doubled_successor(ec,cf[1],nf[1],pf[3]);m.eq(ec,A(nf[1],O),M(M(two,np),A(ell,O)),[ds,Q(A(cf[1],O),M(M(four,p),A(ell,O)))])
      rho=ranks(nf,np)[0];ec.both(oldrank,m.flip(ec,pf[4]));use(ec,'z10-right-rank-drop-A0',{'t':K,'u':cf[3],'v':wr(nf),'w':r})
      return output(ec,0,np,ns,rho)
     assert j==2 and k==5
     def even_found(hc):
      req=Q(cf[3],M(two,fe));bounds(hc,p,s,cf[3])
      hc.both(L(fe,A(cf[3],O)),L(cf[3],W));use(hc,'skelet17-binary-le-lt-trans',{'t':fe,'u':cf[3],'v':W})
      m.eq(hc,word,A(M(p,M(two,fe)),s),[Q(word,A(M(p,cf[3]),s)),req])
      m.eq(hc,M(p,nf[3]),M(p,A(M(four,fe),O)),[pf[3],req]);pack_carry(hc,M(p,nf[3]),p,s,fe)
      m.bound(hc,O,two,Z);nd.disj(hc,[Q(O,Z),m.even(cf[3])],1);nd.conj(hc,[sparse(cf[3]),L(O,two),b.Or(Q(O,Z),m.even(cf[3]))]);use(hc,'skelet17-ladder-skelet10-sparse-push',{'t':cf[3],'u':O})
      m.rewrite(hc,sparse(a.E),A(M(two,cf[3]),O),nf[3],a.sym(nf[3],A(M(two,cf[3]),O),hc.get(pf[3]),hc.g))
      m.eq(hc,A(wl(nf),O),M(p,A(ell,O)),[m.flip(hc,pf[4]),Q(A(cf[1],O),M(p,A(ell,O)))])
      hc.both(Q(p,A(M(three,s),O)),L(s,W));use(hc,'z10-right-C-rank-bound',{'t':p,'u':s,'v':word,'w':cf[3]})
      m.rewrite(hc,L(M(four,p),a.E),ranks(cf,p)[2],r,a.sym(r,ranks(cf,p)[2],hc.get(oldrank),hc.g))
      return output(hc,3,p,Z,M(four,p))
     return m.bex_elim(ec,m.pz,A(cf[3],O),Q(cf[3],M(two,m.pz)),fe,goal,even_found)
    return nd.cases(dc,[nd.AND(parts(cf,nf,k)) for k in range(10)],goal,instruction)
   return eliminate(cc,cf,r,j,goal,found)
  nd.cases(c,[clause(cf,r,j) for j in range(4)],goal,region)
  finish('right-counter-step',root,prem,goal,c,'An unfinished right-counter ordinary step preserves a bounded carry phase with strictly smaller rank. All four phases and ten instructions are checked; reuses the D1 return proof.')
 def list_marker(c,p,v):return [Q(c[0],three),L(c[2],two),m.power2(p),Q(A(wl(c),O),M(p,A(ell,O))),Q(M(p,c[3]),v)]
 if proofs:
  if 'z10-return-even-predecessor' not in m.theorems:ret['predecessor']()
  local()
 return {'rank':rank,'endpoint':endpoint,'entry':entry,'initial_rank':initial_rank,'word':word,'ell':ell,'carry':carry,'phase':phase,'clause':clause,'eliminate':eliminate,'pp':pp,'ps':ps,'jp':jp,'js':js,'ja':ja,'cf':cf,'nf':nf,'outscale':nrank,'prefix_bounds':prefix_bounds}
