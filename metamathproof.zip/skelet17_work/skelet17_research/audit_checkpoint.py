"""Audit trusted declarations and exact induction dependencies after verification."""
from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse,rewrite

old=(P/'scan_checked.mm').read_text();new=(P/'transitions_checked.mm').read_text()
orr,orules,_=parse(old);nrr,nrules,_=parse(new)
def trusted(records,rules):
    return {r['label']:{'expression':r['expr'],'hypotheses':[rules[h]['expr'] for h in r['hyps']],
            'disjoint':sorted(r['dv'])} for r in records if r['kind']=='a'}
assert trusted(orr,orules)==trusted(nrr,nrules)
assert len(trusted(nrr,nrules))==93
log=(P/'history_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
deps={r['label']:rewrite(r,{})[1] for r in nrr if r['kind']=='p'}
def closure(root):
    seen=set();todo=[root]
    while todo:
        name=todo.pop()
        if name in seen:continue
        seen.add(name);todo.extend(deps.get(name,()))
    return seen
roots=[r['label'] for r in nrr if r['kind']=='p' and r['label'].startswith('skelet17-')]
metrics={}
for root in roots:
    reach=closure(root)
    instances=[k for k in reach if 'ax-ind-bounded' in deps.get(k,set())]
    metrics[root]={'bounded_induction_application_nodes':sorted(instances),'induction_application_count':len(instances)}
assert metrics['skelet17-right-scan-history']['induction_application_count']==1
assert all(v['induction_application_count']==0 for k,v in metrics.items() if k!='skelet17-right-scan-history')
files=['transitions_checked.mm','build_scan.py','build_transitions.py','build_history.py','build_terminal.py','build_global.py','gray_transducer.py','gray_transducer_checks.json','prune.py','check_scan.py','check_transitions.py','history_verification.log','theorems.json']
out={'whole_machine_nonhalting_proved':False,'whole_machine_independence_proved':False,
     'trusted_declarations_unchanged':True,'trusted_count':93,
     'proved_statement_count':sum(r['kind']=='p' for r in nrr),
     'public_interfaces':metrics,'verifier_log_clean':True,
     'files':{s:{'bytes':(P/s).stat().st_size,'sha256':hashlib.sha256((P/s).read_bytes()).hexdigest()} for s in files}}
(P/'extension_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('files','public_interfaces')},indent=2))
