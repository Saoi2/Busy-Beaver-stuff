"""Finite interpretation and abstraction checks, supplementary to Metamath."""
import json
from pathlib import Path
from collections import deque
TABLE=[(1,1,1),(0,0,0),(2,1,1),(5,1,1),
       (3,1,0),(2,1,0),(3,0,1),(0,0,0)]
def invariant(c):
 q,l,bit,r=c
 return (q==0 and r%2==0) or (q==1 and bit==0) or q in (2,3)
def step(c):
 q,l,bit,r=c;nq,right,w=TABLE[2*q+bit]
 return (nq,2*l+w,r%2,r//2) if right else (nq,l//2,l%2,2*r+w)
count=0
for q in range(4):
 for l in range(128):
  for bit in (0,1):
   for r in range(128):
    c=(q,l,bit,r)
    if invariant(c):
     assert invariant(step(c)),(c,step(c))
     count+=1
c=(0,0,0,0)
for _ in range(100000):
 assert invariant(c),c
 c=step(c)
# A one-bit abstraction overapproximates both possible forgotten pop bits.
seen={(0,0,0,0)};queue=deque(seen)
while queue:
 q,l,bit,r=queue.popleft();nq,right,w=TABLE[2*q+bit]
 assert nq!=5
 for forgotten in (0,1):
  c=(nq,w,r,forgotten) if right else (nq,forgotten,l,w)
  if c not in seen:seen.add(c);queue.append(c)
out={'finite_invariant_configurations_checked':count,
     'raw_run_steps_checked':100000,
     'one_bit_abstract_configurations':len(seen),
     'scope':'standard-integer interpretation checks only; formal proof is in idelta0_machines.mm'}
Path(__file__).with_name('fractal_invariant_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(out)
