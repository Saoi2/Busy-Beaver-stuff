"""Independent formulas and numerical tests for block tails and A clearing."""
from pathlib import Path
import json
from check_skelet10_scope import parse,plus,times,eq,lt,implies,both,AND,OR,num,ALL,EX,power,sparse,step
from check_skelet10_left import norm,raw_step
from check_skelet10_spread import transform,spread,bounded
PTH=Path(__file__).resolve().parent;TWO,FOUR,TEN,SIXTEEN=map(num,(2,4,10,16))
P,V,tail=['clear'+s for s in ('InitialScale','OutputWord','RightTail')];p,u,t=['clear'+s for s in ('Scale','Word','EncodedTail')]
def wr(c):return plus(times(TWO,c[3]),c[2])
def fields(c,j,p,u,t):
 common=[eq(c[0],'0'),lt(c[2],TWO),power(p),sparse(u)]
 if j==0:return [*common,transform(u,c[1]),eq(times(p,u),V),eq(plus(wr(c),'1'),times(times(p,p),plus(tail,'1')))]
 return [*common,transform(u,t),eq(c[1],times(TWO,t)),eq(times(times(TWO,p),u),V),eq(plus(wr(c),'1'),times(TWO,times(times(p,p),plus(tail,'1'))))]
def rv(j,p):return times(TWO,p) if j==0 else plus(times(TWO,p),'1')
def clause(c,r,j):
 f=AND([*fields(c,j,p,u,t),eq(r,rv(j,p))])
 if j:f=EX(t,plus(c[1],'1'),f)
 return EX(p,plus(P,'1'),EX(u,plus(V,'1'),f))
def rank(c,r):return OR([clause(c,r,j) for j in (0,1)])
def entry(c):return EX(u,plus(V,'1'),AND(fields(c,0,P,u,t)))
def endpoint(c):return AND([eq(c[0],'0'),eq(wr(c),tail),transform(V,c[1]),sparse(V)])
R0=times(TWO,P)
def alls(vs,bound,body):
 for v in reversed(vs):body=ALL(v,bound,body)
 return body
def exs(vs,bound,body):
 for v in reversed(vs):body=EX(v,bound,body)
 return body
H,n,offset=['clearRun'+s for s in ('H','N','Offset')]
def at(index,row):
 q='clearRunBetaQuotient';out=[]
 for j,v in enumerate(row):
  mod=plus('1',times(plus(plus(offset,index),'1'),'clearRunC'+str(j)))
  out.append(EX(q,H,both(eq('clearRunB'+str(j),plus(times(q,mod),v)),lt(v,mod))))
 return AND(out)
TV=['clearRunTotalRow'+s for s in ('Q','L','Bit','R')];IV=['clearRunInitialRow'+s for s in ('Q','L','Bit','R')]
SV=['clearRunStepRow'+str(j)+s for j in (0,1) for s in ('Q','L','Bit','R')]
EV=['clearRunAvoidRow'+s for s in ('Q','L','Bit','R')];IP=['clearRunIndRow'+s for s in ('Q','L','Bit','R')]
HR=['clearRunHalt'+s for s in ('Q','L','Bit','R')];ER=['clearRunExitRow'+s for s in ('Q','L','Bit','R')]
ti,si,ai,i=['clearRun'+s for s in ('TotalIndex','StepIndex','AvoidIndex','Index')];rho='clearRunHistoryScale'
total=ALL(ti,plus(n,'1'),exs(TV,H,at(ti,TV)));initial=alls(IV,H,implies(at('0',IV),entry(IV)))
steps=ALL(si,n,alls(SV,H,implies(both(at(si,SV[:4]),at(plus(si,'1'),SV[4:])),step(SV[:4],SV[4:]))))
avoid=ALL(ai,plus(n,'1'),alls(EV,H,implies(at(ai,EV),('-.',endpoint(EV)))))
def inv(index,row):return EX(rho,plus(R0,'1'),both(rank(row,rho),lt(plus(index,rho),plus(R0,'1'))))
invariant=ALL(i,plus(n,'1'),alls(IP,H,implies(at(i,IP),inv(i,IP))))
xi='clearRunExitIndex';exit_goal=EX(xi,plus(n,'1'),exs(ER,H,both(at(xi,ER),endpoint(ER))))
cf=['z10Current'+s for s in ('Q','L','Bit','R')];nf=['z10Next'+s for s in ('Q','L','Bit','R')];h='clearOutputRank';bt='blockTail'
expected={
 'transform-decompose-0':implies(transform(times(TWO,'t'),'u'),EX(bt,plus('u','1'),both(eq('u',times(FOUR,bt)),transform('t',bt)))),
 'transform-decompose-10':implies(transform(plus(times(FOUR,'t'),'1'),'u'),EX(bt,plus('u','1'),both(eq('u',plus(times(SIXTEEN,bt),TEN)),transform('t',bt)))),
 'left-return-entry':implies(entry(cf),rank(cf,R0)),
 'left-return-step':implies(AND([rank(cf,'t'),('-.',endpoint(cf)),step(cf,nf)]),EX(h,'t',rank(nf,h))),
 'left-return-window-invariant':implies(AND([total,initial,steps,avoid]),invariant),
 'left-return-window-bound':implies(AND([total,initial,steps,avoid]),lt(n,R0)),
 'left-return-window-exit':implies(AND([total,initial,steps,lt(R0,plus(n,'1'))]),exit_goal),
 'left-return-window-halting-barrier':implies(AND([total,initial,steps,*[lt(x,H) for x in HR],at(n,HR),eq(HR[0],num(5))]),exit_goal),
}
def sparse_num(x):return not x&(x>>1)
def tval(x):return 10*spread(x)
def main():
 actual=json.loads((PTH/'skelet10_clear_theorems.json').read_text());assert len(actual)==len(expected),(len(actual),len(expected))
 for name,f in expected.items():
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(f),label
  assert bounded(f),label
 for name in ('left-return-window-exit','left-return-window-halting-barrier'):
  text=actual['skelet17-ladder-skelet10-'+name]
  for forbidden in ('clearScale','clearEncodedTail','clearRunHistoryScale','clearFreshScale'):
   assert forbidden not in text,(name,forbidden)
 for x in range(128):
  value=tval(x);assert tval(2*x)==4*value and value<=4*value
  assert tval(4*x+1)==16*value+10 and value<=16*value+10
 cases=steps_count=0;examples=[]
 for u0 in range(64):
  if not sparse_num(u0):continue
  for k in range(8):
   initial_p=2**k;v=initial_p*u0
   for right_tail in range(8):
    p0=initial_p;u1=u0;l0=tval(u0);whole=initial_p**2*(right_tail+1)-1;c=(0,l0,whole%2,whole//2)
    j=0;t1=None;elapsed=0;trace=[]
    while True:
     q,l,b,r=c;word=2*r+b;rho=2*p0+j
     assert q==0 and sparse_num(u1) and u1<=v and p0<=initial_p and elapsed+rho<=2*initial_p
     if j==0:
      assert l==tval(u1) and p0*u1==v and word+1==p0*p0*(right_tail+1)
     else:
      assert l==2*t1 and t1==tval(u1) and t1<=l and (2*p0)*u1==v and word+1==2*p0*p0*(right_tail+1)
     trace.append({'step':elapsed,'configuration':c,'half_step':j,'remaining_scale':p0,'word':u1,'rank':rho})
     if word==right_tail and l==tval(v) and sparse_num(v):break
     assert b==1;nxt=raw_step(c)
     if j==0:t1=l;p0//=2;j=1
     else:u1*=2;j=0
     assert 2*p0+j<rho;c=nxt;elapsed+=1;steps_count+=1
    assert elapsed==2*k and elapsed<=2*initial_p
    cases+=1
    if u0==1 and right_tail==0 and k in (0,1,2):examples.append({'initial_word':u0,'initial_scale':initial_p,'output_word':v,'right_tail':right_tail,'ordinary_steps':elapsed,'trace':trace})
 out={'statements_checked':len(expected),'independent_reconstruction_matches':True,'all_new_statements_delta0':True,
  'unconditional_bounded_transform_tails':True,'whole_A_clearing_return_contract':True,
  'ordinary_step_and_original_beta_format':True,'no_intermediate_annotations_in_exit_or_barrier':True,
  'finite_block_examples':256,'finite_return_cases':cases,'finite_ordinary_steps':steps_count,
  'finite_tests_are_not_formal_proofs':True,'complete_left_counter':False,'whole_machine_nonhalting':False,'examples':examples}
 (PTH/'skelet10_clear_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='examples'},indent=2))
if __name__=='__main__':main()
