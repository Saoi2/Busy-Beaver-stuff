"""Extend the combined database over the unchanged trusted core."""
import json,types
import resume_project as resume
m=resume.m;nd,b,a=m.nd,m.b,m.a
A,M,Q,L,O,Z=m.A,m.M,m.Q,m.L,m.O,m.Z
num=a.num;two=num(2)
CF=[m.declare('ladderC'+s,'term') for s in ('q','l','b','r')]
NF=[m.declare('ladderN'+s,'term') for s in ('q','l','b','r')]
TABLES={'bb1':[(5,1,1),(5,1,1)],'bb2':[(1,1,1),(1,0,1),(0,0,1),(5,1,1)],'cycler':[(1,1,1),(1,1,0),(0,0,0),(5,1,1)]}
def parts(table,c,d,j):
 q,l,bit,r=c;nq,nl,nb,nr=d;state,read=divmod(j,2);qs,direction,w=table[j]
 eqs=[Q(nl,A(M(two,l),num(w))),Q(r,A(M(two,nr),nb))] if direction else [Q(nr,A(M(two,r),num(w))),Q(l,A(M(two,nl),nb))]
 return [Q(q,num(state)),Q(bit,num(read)),Q(nq,num(qs)),*eqs,b.Or(Q(nb,Z),Q(nb,O))]
def STEP(c,d,kind='cycler'):return nd.OR([nd.AND(parts(TABLES[kind],c,d,j)) for j in range(len(TABLES[kind]))])
def cfg(c,vs):return nd.AND([Q(v,num(k)) for v,k in zip(c,vs)])
CYCLE=[(0,0,0,0),(1,1,0,0),(0,0,1,0),(1,0,0,0)]
def INV(c):return nd.OR([cfg(c,v) for v in CYCLE])
finish=m.finish
use=m.invoke

def contradiction(ctx,v,i,j,goal):
 p=a.trans(num(i),v,num(j),a.sym(v,num(i),ctx.get(Q(v,num(i))),ctx.g),ctx.get(Q(v,num(j))),ctx.g)
 if i>j:p=a.sym(num(i),num(j),p,ctx.g)
 lo,hi=sorted((i,j));m.bound(ctx,num(lo),num(hi),num(hi-lo-1))
 m.rewrite(ctx,L(num(lo),a.E),num(hi),num(lo),a.sym(num(lo),num(hi),p,ctx.g))
 bad=L(num(lo),num(lo));ctx.put(b.Not(bad),b.ax('O1',ctx.g,t=num(lo)));return ctx.explode(bad,goal)
def finite_trace(kind):
 table=TABLES[kind];c=(0,0,0,0);rows=[c];root=nd.Ctx();steps=[]
 while c[0]!=5:
  q,l,bit,r=c;j=2*q+bit;nq,d,w=table[j]
  nxt=(nq,2*l+w,r%2,r//2) if d else (nq,l//2,l%2,2*r+w)
  cc,dd=[num(v) for v in c],[num(v) for v in nxt];fields=parts(table,cc,dd,j)
  for f in fields[:-1]:m.eq(root,f[1],f[2])
  root.put(Q(dd[2],dd[2]),b.refl(root.g,dd[2]));nd.disj(root,list(fields[-1][1:]),nxt[2])
  nd.conj(root,fields);nd.disj(root,[nd.AND(parts(table,cc,dd,k)) for k in range(len(table))],j)
  steps.append(STEP(cc,dd,kind));rows.append(nxt);c=nxt
 nd.conj(root,steps);m.save('skelet17-ladder-'+kind+'-halting-trace',root,nd.AND(steps),'Explicit ordinary blank-to-halt trace. No induction. Not an exhaustive Busy Beaver upper bound.')
 return rows
traces={k:finite_trace(k) for k in ('bb1','bb2')}
def closure():
 fs=[INV(CF),STEP(CF,NF)];prem=b.And(*fs);goal=INV(NF);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
 def config(ec,k):
  old=CYCLE[k];equals=[Q(v,num(z)) for v,z in zip(CF,old)];nd.unpack(ec,equals)
  def move(sc,j):
   pf=parts(TABLES['cycler'],CF,NF,j);nd.unpack(sc,pf)
   if j//2!=old[0]:return contradiction(sc,CF[0],old[0],j//2,goal)
   if j%2!=old[2]:return contradiction(sc,CF[2],old[2],j%2,goal)
   nxt=CYCLE[(k+1)%4];direction=TABLES['cycler'][j][1]
   quotient=NF[3] if direction else NF[1];rem=NF[2];constant=old[3] if direction else old[1]
   m.eq(sc,A(M(two,quotient),rem),A(M(two,num(constant//2)),num(constant%2)),[m.flip(sc,pf[4]),*equals])
   def bit(dc,t):
    m.bound(dc,num(t),two,num(1-t));return m.rewrite(dc,L(a.E,two),num(t),rem,dc.get(m.flip(dc,Q(rem,num(t)))))
   nd.cases(sc,list(pf[-1][1:]),L(rem,two),bit)
   m.bound(sc,num(constant%2),two,num(1-constant%2));m.quotient_unique(sc,two,quotient,rem,num(constant//2),num(constant%2))
   pushed=NF[1] if direction else NF[3];m.eq(sc,pushed,num(nxt[1] if direction else nxt[3]),[pf[3],*equals])
   nd.conj(sc,[Q(v,num(z)) for v,z in zip(NF,nxt)]);return nd.disj(sc,[cfg(NF,v) for v in CYCLE],(k+1)%4)
  return nd.cases(ec,[nd.AND(parts(TABLES['cycler'],CF,NF,j)) for j in range(4)],goal,move)
 nd.cases(ctx,[cfg(CF,v) for v in CYCLE],goal,config)
 finish('skelet17-ladder-cycler-local',root,prem,goal,ctx,'Exact reachable configurations closed under ordinary Step, including unused halting branch. No induction.')
closure()
p=m.P;s=(p/'build_history.py').read_text();s=s[s.index('nd,b,a=m.nd,m.b,m.a'):s.index("if __name__=='__main__'")]
s=s.replace("m.declare('s17offset')","m.declare('ladderOffset','term')")
s=s.replace('b.And(m.STEP(SV[:4],SV[4:]),m.GO(SV[:4]))','m.STEP(SV[:4],SV[4:])')
s=s.replace('res=b.And(m.STEP(CF,NF),m.GO(CF));pc.mp(b.And(acur,atnext),res,pp);nd.unpack(pc,list(res[1:]))','res=m.STEP(CF,NF);pc.mp(b.And(acur,atnext),res,pp)')
s=s.replace('nd.conj(pc,[icur,m.STEP(CF,NF),m.GO(CF)])','nd.conj(pc,[icur,m.STEP(CF,NF)])')
s=s.replace('skelet17-right-scan-local','skelet17-ladder-cycler-local').replace('skelet17-right-scan-history','skelet17-ladder-cycler-history').replace('skelet17-lt-add-cancel','skelet17-ladder-lt-add-cancel')
s=s.replace('Conditional right-scan window theorem. Exactly one bounded-induction instance. No claim that the entire blank run satisfies the scan guard.','Ordinary cycler supplied-history propagation. One bounded induction; no extra scan guard.')
shim=types.SimpleNamespace(nd=nd,b=b,a=a,declare=m.declare,finish=finish,use=use,CF=CF,NF=NF,INV=INV,STEP=STEP)
h={'m':shim};exec(compile(s,'ladder_history_generated.py','exec'),h)
(p/'ladder_history_generated.py').write_text(s)
exec(compile((p/'ladder_endpoint.py').read_text(),'ladder_endpoint.py','exec'),globals())
exec(compile((p/'ladder_translated.py').read_text(),'ladder_translated.py','exec'),globals())
exec(compile((p/'ladder_counter.py').read_text(),'ladder_counter.py','exec'),globals())
exec(compile((p/'ladder_bouncer.py').read_text(),'ladder_bouncer.py','exec'),globals())
exec(compile((p/'ladder_fractal.py').read_text(),'ladder_fractal.py','exec'),globals())
exec(compile((p/'ladder_finned3_sweeps.py').read_text(),'ladder_finned3_sweeps.py','exec'),globals())
exec(compile((p/'ladder_finned3_global.py').read_text(),'ladder_finned3_global.py','exec'),globals())
exec(compile((p/'ladder_finned3_history.py').read_text(),'ladder_finned3_history.py','exec'),globals())
from ladder_skelet10 import add_skelet10
z10api=add_skelet10(m)
(p/'skelet10_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if '-skelet10-' in k},indent=2)+'\n')
from ladder_skelet10_left import add_skelet10_left
z10left=add_skelet10_left(m,z10api)
(p/'skelet10_left_theorems.json').write_text(json.dumps({'skelet17-ladder-skelet10-'+k:b.tok(m.theorems['skelet17-ladder-skelet10-'+k]) for k in z10left},indent=2)+'\n')
from ladder_skelet10_spread import add_skelet10_spread
spread_before=set(m.theorems)
spreadapi=add_skelet10_spread(m)
(p/'skelet10_spread_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in spread_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_inverse import add_skelet10_inverse
inverse_before=set(m.theorems)
add_skelet10_inverse(m,spreadapi)
(p/'skelet10_inverse_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in inverse_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_return import add_skelet10_return
return_before=set(m.theorems)
returnapi=add_skelet10_return(m,z10api)
(p/'skelet10_return_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in return_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_right import add_skelet10_right
from ladder_skelet10_right_history import add_skelet10_right_history
right_before=set(m.theorems)
rightapi=add_skelet10_right(m,z10api,returnapi)
add_skelet10_right_history(m,z10api,rightapi,returnapi)
(p/'skelet10_right_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in right_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_blocks import add_skelet10_blocks
from ladder_skelet10_clear import add_skelet10_clear
from ladder_skelet10_clear_history import add_skelet10_clear_history
clear_before=set(m.theorems)
blocksapi=add_skelet10_blocks(m,spreadapi)
clearapi=add_skelet10_clear(m,z10api,spreadapi,returnapi)
add_skelet10_clear_history(m,z10api,clearapi,returnapi)
(p/'skelet10_clear_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in clear_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_full_left import add_skelet10_full_left
from ladder_skelet10_full_left_steps import add_skelet10_full_left_steps
from ladder_skelet10_full_left_history import add_skelet10_full_left_history
full_left_before=set(m.theorems)
instructionapi=add_skelet10_left(m,z10api,stage='contracts')
full_left=add_skelet10_full_left(m,z10api,spreadapi,rightapi,clearapi,instructionapi,blocksapi)
add_skelet10_full_left_steps(m,z10api,spreadapi,rightapi,clearapi,full_left)
add_skelet10_full_left_history(m,z10api,full_left,returnapi)
(p/'skelet10_full_left_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in full_left_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_sync import add_skelet10_sync
sync_before=set(m.theorems)
add_skelet10_sync(m,rightapi)
(p/'skelet10_sync_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in sync_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_sync_inverse import add_skelet10_sync_inverse
inverse_carry_before=set(m.theorems)
add_skelet10_sync_inverse(m,rightapi)
(p/'skelet10_inverse_carry_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in inverse_carry_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_carry_odd_inverse import add_skelet10_carry_odd_inverse
odd_carry_before=set(m.theorems)
add_skelet10_carry_odd_inverse(m,rightapi,z10api)
(p/'skelet10_odd_carry_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in odd_carry_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_carry_unique import add_skelet10_carry_unique
unique_carry_before=set(m.theorems)
add_skelet10_carry_unique(m,rightapi,z10api)
(p/'skelet10_unique_carry_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in unique_carry_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_boundaries import add_skelet10_boundaries
boundary_before=set(m.theorems)
canonical_boundary_api=add_skelet10_boundaries(m,z10api,spreadapi,rightapi)
(p/'skelet10_boundaries_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in boundary_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_alignments import add_skelet10_alignments
align_before=set(m.theorems)
finite_alignment_api=add_skelet10_alignments(m,z10api,rightapi)
(p/'skelet10_alignments_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in align_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_history_tools import add_history_tools
history_tools_before=set(m.theorems)
shared_history=add_history_tools(m,z10api)
(p/'history_tools_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in history_tools_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_history_assembly import add_history_assembly
assembly_before=set(m.theorems)
history_assembly_api=add_history_assembly(m,z10api,shared_history,rightapi,full_left)
(p/'history_assembly_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in assembly_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_odd_cycle import add_skelet10_odd_cycle
odd_cycle_before=set(m.theorems)
cycle_api=add_skelet10_odd_cycle(m,z10api,spreadapi,rightapi,full_left,shared_history,history_assembly_api,canonical_boundary_api,finite_alignment_api)
(p/'skelet10_odd_cycle_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in odd_cycle_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_even_zero_cycle import add_skelet10_even_zero_cycle
even_zero_before=set(m.theorems)
finite_cycle_api=add_skelet10_even_zero_cycle(m,z10api,spreadapi,rightapi,full_left,shared_history,history_assembly_api,canonical_boundary_api,cycle_api,instructionapi)
(p/'skelet10_even_zero_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in even_zero_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_even_one_cycle import add_skelet10_even_one_cycle
even_one_before=set(m.theorems)
finite_cycle_api['instructions']=instructionapi
one_cycle_api=add_skelet10_even_one_cycle(m,z10api,spreadapi,rightapi,full_left,shared_history,history_assembly_api,canonical_boundary_api,finite_alignment_api,cycle_api,finite_cycle_api)
(p/'skelet10_even_one_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in even_one_before and k.startswith('skelet17-')},indent=2)+'\n')
from ladder_skelet10_boundary_progress import add_skelet10_boundary_progress
from ladder_skelet10_boundary_maximum import add_skelet10_boundary_maximum
from ladder_skelet10_boundary_exclusion import add_skelet10_boundary_exclusion
from ladder_skelet10_blank_endpoint import add_skelet10_blank_endpoint
progress_before=set(m.theorems)
progress_api=add_skelet10_boundary_progress(m,z10api,spreadapi,rightapi,shared_history,history_assembly_api,canonical_boundary_api,cycle_api,finite_cycle_api,one_cycle_api)
(p/'skelet10_progress_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in progress_before and k.startswith('skelet17-')},indent=2)+'\n')
maximum_before=set(m.theorems)
maximum_api=add_skelet10_boundary_maximum(m,z10api,shared_history,history_assembly_api,canonical_boundary_api)
(p/'skelet10_maximum_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in maximum_before and k.startswith('skelet17-')},indent=2)+'\n')
global_before=set(m.theorems)
exclusion_api=add_skelet10_boundary_exclusion(m,z10api,shared_history,history_assembly_api,canonical_boundary_api,progress_api,maximum_api)
add_skelet10_blank_endpoint(m,z10api,spreadapi,rightapi,shared_history,history_assembly_api,canonical_boundary_api,cycle_api,maximum_api,exclusion_api)
(p/'skelet10_global_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if k not in global_before and k.startswith('skelet17-')},indent=2)+'\n')

(p/'ladder_traces.json').write_text(json.dumps(traces,indent=2)+'\n')
with (p/'idelta0_machines_raw.mm').open('w') as stream:
 for line in b.lines:
  for pos in range(0,len(line),1048576):stream.write(line[pos:pos+1048576])
  stream.write('\n')
print('Complete raw project written',flush=True)
(p/'ladder_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if 'ladder-' in k},indent=2)+'\n')
