# Embedding the Skelet #10 routines in one ordinary history

This stage connects the earlier routine theorems to a known decoded row
inside the original supplied computation history. It does not yet prove
that every canonical boundary reaches another one, or prove blank-start
nonhalting. All proofs remain in idelta0_machines.mm.

## The fixed history and notation

Use the original four quotient/remainder codes B_j,C_j and coordinate/
quotient bound H. At_o(i,c) means that the quadruple c is decoded at
absolute index o+i. TOTAL(o,N) supplies a quadruple below H at every
relative index i<N+1. STEPS(o,N) relates any two bounded decoded rows
at i,i+1, for i<N, by the original Skelet #10 Step. HISTORY_TOOLS.md
gives the complete first-order expansions. The machine is unchanged:

    1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB.

The former undefined E0 transition is still completed by 1RZ. Its write,
move and final row remain part of every ordinary Step/history definition.
State Z=5 has no outgoing ordinary step.

## 1. A nonhalting row can advance before an alleged final halt

`skelet17-ladder-history-advance-before-halt` assumes TOTAL(o,N),
STEPS(o,N), a bounded decoded final row h with At_o(N,h) and q(h)=5,
and a bounded decoded current row c at i<N+1 with q(c) unequal to 5.
It concludes

    i<N and exists d_0<H ... exists d_3<H:
        At_o(i+1,d) and Step(c,d).

The derivation uses no induction:

1. The discrete-order lemma gives i<N or i=N.
2. In the equality case, row uniqueness identifies c with h. Its state
   would be 5, contradicting the current-state premise. Therefore i<N.
3. Addition preserves strict order, so i+1<N+1. Instantiate TOTAL at
   i+1 to obtain a bounded decoded row d.
4. Instantiate STEPS at i and the two actual rows c,d. Their At
   assertions yield Step(c,d).
5. Reintroduce the four bounded existential witnesses and conjoin i<N.

This is useful when a finite alignment would otherwise require many
separate cases for a history shorter than the alignment. Start with its
known state A, B, C or D, prove that it differs from 5, and apply this
lemma for the next row. The ordinary alignment theorem then determines
the next state. Repeat only for the fixed number of moves needed.
No extra assumption about available running time is introduced.

## 2. A positive-index row has a binary scanned bit

`skelet17-ladder-history-positive-row-bit` assumes TOTAL(o,N),
STEPS(o,N), i<N, and a bounded row d with At_o(i+1,d). It concludes

    b(d)<2.

TOTAL supplies a bounded preceding row c at i. STEPS gives Step(c,d).
Every one of the ten ordinary instruction clauses explicitly contains
b(d)=0 or b(d)=1; both alternatives imply b(d)<2. That last instruction
fact is proved once as the shared private theorem z10-assembly-step-bit.

The initial row need not be binary for this implication, since it concerns
a row reached by an ordinary Step. This theorem resolves the bit-bound
issue for strictly later routine outputs without strengthening their old
endpoint statements or annotating a history. It uses no induction.

## 3. A known right-counter entry has a strictly later output

`skelet17-ladder-skelet10-right-embedded-halting-barrier` assumes:

- TOTAL(o,N) and STEPS(o,N), with the unchanged codes and H;
- k+n=N, using an equation rather than a subtraction symbol;
- a bounded actual row c with At_o(k,c) satisfying the previously proved
  right-entry predicate;
- a bounded final row h with At_o(N,h) and q(h)=5.

It concludes that there are an index e<N+1 and a bounded decoded row d
such that

    k<e, At_o(e,d), RightEndpoint(d), and b(d)<2.

RightEntry(c) is the original formula

    q(c)=B, L(c)=2ell+1, 2R(c)+b(c)=w, b(c)<2, Sparse(w).

RightEndpoint(d) is likewise unchanged:

    q(d)=D, 2L(d)+b(d)=ell, J(w,R(d)), Sparse(R(d)).

The proof does not assume a sequence of phases, carry witnesses, ranks,
or endpoint witnesses. It constructs an output witness as follows.

1. Apply the verified suffix lemmas to obtain TOTAL(o+k,n) and
   STEPS(o+k,n), using the same codes and the same H.
2. To meet the old routine theorem's universally quantified initial-row
   premise, take any bounded row v decoded at relative index 0 of this
   suffix. Associativity identifies that absolute index with o+k.
   Row uniqueness gives c=v coordinate by coordinate. Equality
   substitution transports the known RightEntry(c) to RightEntry(v).
   Discharge the assumption and introduce the four bounded universal
   quantifiers. Thus the universal premise is proved from the known row.
3. The old final halt row is decoded at suffix index n, because
   (o+k)+n=o+N. Apply the existing right-window-halting-barrier theorem.
   It supplies a suffix index j<n+1 and a bounded row d satisfying
   At_(o+k)(j,d) and RightEndpoint(d).
4. Prove j>0. If j=0, row uniqueness identifies d with c. But the entry
   state is B and the endpoint state is D, distinct arithmetic numerals.
   The trichotomy alternative j<0 is ruled out by the order axioms.
5. Eliminate a positive-gap witness to write j=p+1, without subtraction.
   From j<n+1 infer p<n. The preceding theorem, instantiated for the
   suffix, gives b(d)<2 from its preceding supplied ordinary Step.
6. Put e=k+j. Order preservation gives e<N+1 and k<e. Associativity
   transports the suffix At assertion back to At_o(e,d). Package e
   and the four coordinates of d as bounded existential witnesses.

The conclusion uses an index in the original history, not a new history
code, and progress k<e is explicit.

## 4. The same embedding for the left counter

`skelet17-ladder-skelet10-left-embedded-halting-barrier` proves the
same original-history conclusion for the complete left routine. Its
entry predicate is

    q(c)=D, b(c)<2, Sparse(w), T(w,2L(c)+b(c)), R(c)=4r+3.

Its endpoint predicate is

    q(d)=A, 2R(d)+b(d)=r,
    exists V<3w+2: J(w,V), T(V,L(d)), Sparse(V).

The proof construction is shared with the right embedding. Only the old
routine contract and its entry/endpoint state numerals change. In the
strict-progress step, D is incompatible with A. The existential V in the
endpoint is retained exactly; it is not supplied as an extra hypothesis.
The earlier carry-uniqueness result can identify it when a complete
boundary composition is built.

## Trust, induction and exact scope

The two shared history theorems have zero bounded-induction dependencies.
Each embedded routine theorem reuses the two induction constructions in
its already verified routine proof (bounded division and that routine's
history induction). This stage adds no induction construction and no
trusted declaration. Dependency counts measure these actual proofs,
not a lower bound on the strength needed for the statements.

check_history_assembly.py reconstructs all four public formulas separately
from the proof generator, checks their Delta-0 form, and runs supplementary
finite tests on ordinary halting histories. The Metamath kernel checks the
universal deductions; finite tests never stand in for a formal proof.
The generator is ladder_history_assembly.py, integrated into build_ladder.py.

Completed here are the known-row-to-universal-entry conversion, suffix
application of both routine barriers, output transport to the original
history, strict progress, endpoint bit bounds, and a shared advancement
lemma for finite-prefix assembly. The remaining obligations are the three
full canonical boundary compositions, their use in the global bounded
remaining-length induction, and the blank-start connection. Skelet #10
whole-machine nonhalting remains unfinished.
