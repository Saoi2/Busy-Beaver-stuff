"""Independent statement and finite interpretation checks for bounded spread."""
from pathlib import Path
import json
from check_skelet10_scope import parse,plus,times,eq,lt,implies,both,AND,num,ALL,EX,power
from check_skelet10_left import norm
P=Path(__file__).resolve().parent
TWO,FOUR,TEN=map(num,(2,4,10))
def square(x):return times(x,x)
def bit(x,p):
 q,r='binQuotient','binRemainder'
 return EX(q,plus(x,'1'),EX(r,p,eq(x,plus(plus(times(q,times(TWO,p)),p),r))))
def dil(x,z):
 p,q,w='dilForwardPlace','dilBackPlace','dilWitnessPlace'
 f=ALL(p,plus(x,'1'),implies(both(power(p),bit(x,p)),bit(z,square(p))))
 r=ALL(q,plus(z,'1'),implies(both(power(q),bit(z,q)),EX(w,plus(x,'1'),AND([power(w),eq(q,square(w)),bit(x,w)]))))
 return both(f,r)
def transform(x,t):
 z='dilTransformWitness'
 return EX(z,plus(t,'1'),both(eq(t,times(TEN,z)),dil(x,z)))
x,p,d='t','u','v';push=plus(times(TWO,x),d)
expect={
 'bit-support-bound':implies(bit(x,p),lt(p,plus(x,'1'))),
 'zero-has-no-one-bit':implies(lt('0',p),('-.',bit('0',p))),
 'bit-push-forward':implies(both(bit(x,p),lt(d,TWO)),bit(push,times(TWO,p))),
 'bit-push-back':implies(AND([lt('0',p),lt(d,TWO),bit(push,times(TWO,p))]),bit(x,p)),
 'bit-low-digit':implies(lt('u',TWO),both(implies(bit(plus(times(TWO,'t'),'u'),'1'),eq('u','1')),implies(eq('u','1'),bit(plus(times(TWO,'t'),'u'),'1')))),
 'spread-zero':dil('0','0'),
 'spread-push':implies(both(dil('t','u'),lt('v',TWO)),dil(plus(times(TWO,'t'),'v'),plus(times(FOUR,'u'),'v'))),
 'spread-exists-quadratic':EX('dilTotalValue',plus(square('t'),'1'),dil('t','dilTotalValue')),
 'transform-zero':transform('0','0'),
 'transform-prefix-0':implies(transform('t','u'),transform(times(TWO,'t'),times(FOUR,'u'))),
 'transform-prefix-10':implies(transform('t','u'),transform(plus(times(FOUR,'t'),'1'),plus(times(num(16),'u'),TEN))),
 'transform-exists-quadratic':EX('dilTransformOutput',plus(times(TEN,square('t')),'1'),transform('t','dilTransformOutput')),
}
def bounded(f):
 op=f[0]
 if op in ('A.','E.'):
  guard,body=f[2][1:];assert f[2][0]==('->' if op=='A.' else '/\\')
  assert guard[0]=='<' and guard[1]==f[1] and f[1] not in flatten(guard[2]);return bounded(body)
 if op=='-.':return bounded(f[1])
 if op in ('=','<'):return True
 return bounded(f[1]) and bounded(f[2])
def flatten(t):return [t] if isinstance(t,str) else sum((flatten(v) for v in t[1:]),[])
def powers(limit):
 p=1
 while p<=limit:yield p;p*=2

def one(x,p):return p>0 and (x//p)%2==1
def graph(x,z):
 ps=list(powers(x))
 return all(not one(x,p) or one(z,p*p) for p in ps) and all(not one(z,q) or any(q==p*p and one(x,p) for p in ps) for q in powers(z))
def spread(x):
 z=0;p=1
 while x:
  z+=(x%2)*p;x//=2;p*=4
 return z

def main():
 actual=json.loads((P/'skelet10_spread_theorems.json').read_text());assert len(actual)==len(expect)
 for name,f in expect.items():
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(f),label
 assert bounded(dil('t','u')) and bounded(transform('t','u'))
 for value in range(65):
  expanded=value>0 and all(k==1 or k%2==0 for k in range(1,value+1) if value%k==0)
  assert expanded==(value in powers(value))
 grid=0
 for x in range(24):
  for z in range(512):assert graph(x,z)==(z==spread(x));grid+=1
 for x in range(128):
  z=spread(x);assert graph(x,z) and z<=x*x
  for d in (0,1):assert graph(2*x+d,4*z+d) and 4*z+d<=(2*x+d)**2
  assert spread(2*x)==4*z and 10*spread(4*x+1)==16*(10*z)+10
 for x in range(64):
  for p in range(1,33):
   for d in (0,1):
    assert one(2*x+d,2*p)==one(x,p)
    if one(x,p):assert p<=x
    assert one(2*x+d,1)==(d==1)
 out={'statements_checked':len(expect),'independent_reconstruction_matches':True,
  'dil_and_transform_definitions_delta0':True,'finite_uniqueness_grid_cases':grid,
  'quadratic_witness_examples':128,'finite_tests_are_not_formal_proofs':True,
  'formal_graph_uniqueness_claimed':False,'full_machine_nonhalting':False,
  'original_machine_history_encoding_unchanged':True,
  'example_spread':{'0':spread(0),'1':spread(1),'2':spread(2),'5':spread(5),'10':spread(10)}}
 (P/'skelet10_spread_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
