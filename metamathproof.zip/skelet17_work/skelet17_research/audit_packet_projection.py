"""Audit the checked original-emission projection and its actual dependencies."""
from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse,rewrite
original,old,_=parse((P/'scan_checked.mm').read_text())
records,rules,_=parse((P/'packet_projection_checked.mm').read_text())
def trusted(rs,ds):
    return {r['label']:(r['expr'],[ds[h]['expr'] for h in r['hyps']],sorted(r['dv'])) for r in rs if r['kind']=='a'}
assert trusted(original,old)==trusted(records,rules)
assert len(trusted(records,rules))==93
log=(P/'packet_projection_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
deps={r['label']:rewrite(r,{})[1] for r in records if r['kind']=='p'}
def closure(root):
    seen=set();todo=[root]
    while todo:
        k=todo.pop()
        if k in seen:continue
        seen.add(k);todo.extend(deps.get(k,()))
    return seen
metrics={}
for r in records:
    k=r.get('label','')
    if r['kind']!='p' or not (k.startswith('skelet17-packet-parser-') or k.startswith('skelet17-packet-original-emission-')):continue
    if r['expr'][0]!='|-':continue
    nodes=sorted(v for v in closure(k) if 'ax-ind-bounded' in deps.get(v,set()))
    metrics[k]={'bounded_induction_application_nodes':nodes,'induction_application_count':len(nodes)}
for name,count in [
    ('skelet17-packet-parser-one-sets-pending',0),
    ('skelet17-packet-parser-guarded-original-step',0),
    ('skelet17-packet-parser-valid-word-removes-totalization',1),
    ('skelet17-packet-parser-original-certificate-exists',2),
    ('skelet17-packet-original-emission-projection',0),
    ('skelet17-packet-original-emission-run',0),
    ('skelet17-packet-original-emission-certificate',2)]:
    assert metrics[name]['induction_application_count']==count,(name,metrics[name])
files=['resume_packets.py','compact_cases.py','build_packet_parser.py','build_packet_parser_generated.py',
       'build_packet_projection.py','packet_projection_checked.mm','packet_projection_theorems.json',
       'packet_projection_verification.log','audit_packet_projection.py','PACKET_PROJECTION.md']
out={'global_original_partial_emission_certificate_proved':True,
     'certificate_bound':'R < 32*(x+1)^5',
     'original_control_relation':'low three bits of the same joint records; no separate base-8 tape code is constructed',
     'sparse_emissions_encoded_in_global_record_integer':True,
     'separate_packed_flags_or_values_constructed':False,
     'new_induction_constructions_added':0,
     'total_induction_constructions_in_certificate_dependency_closure':2,
     'counting_proved':False,'compressed_Gray_decoder_totality_proved':False,
     'whole_machine_nonhalting_proved':False,'trusted_declarations_unchanged':True,
     'trusted_count':93,'verifier_log_clean':True,
     'proved_statement_count':sum(r['kind']=='p' for r in records),'public_interfaces':metrics,
     'files':{s:{'bytes':(P/s).stat().st_size,'sha256':hashlib.sha256((P/s).read_bytes()).hexdigest()} for s in files}}
(P/'packet_projection_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('files','public_interfaces')},indent=2))
