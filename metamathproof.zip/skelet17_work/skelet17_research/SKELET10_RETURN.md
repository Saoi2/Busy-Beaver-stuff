# Skelet #10: a complete D1 return-phase contract in I-Delta-0

The project now proves termination and safety contracts for an entire
return phase of `1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB`. Its length is arbitrary;
it is not a fixed unrolling of a few steps. The proofs use the original
ordinary Step and bounded quotient-and-remainder history definitions.

This file explains the D1 return subroutine. A subsequent extension now
proves the entire right-counter routine; see SKELET10_RIGHT_ROUTINE.md.
The left-counter routine, complete two-counter cycle, synchronization
and whole-machine nonhalting remain unfinished.

## What this phase does

Write a configuration as c=(q,L,b,R), and put W=2L+b. W includes the
scanned bit and the complete left half. The return phase repeatedly uses
D1: write 0, move left, remain in D. Consequently

    W = 2*W_new + 1,       R_new = 2R.

The routine removes a block of left-side 1 markers and puts the same
number of 0s on the right. It stops being this return phase when it has
removed the designated marker block. The actual machine continues from
that endpoint according to its ordinary instruction table.

Two parameters describe the desired endpoint: ell is its whole left
word, and v is its right half. Define the reading abbreviation

    Mark(c,s) :=
      q=D and b<2 and Pow2(s) and
      W+1 = s*(ell+1) and s*R=v.

The positive power-of-two s measures the remaining marker block. Define

    End(c) := q=D and W=ell and R=v.

These are explicit formulas in 0,1,+,*,< when expanded. Pow2 is exactly the
existing bounded divisor predicate, not a new exponentiation function.

If s=1, Mark(c,s) implies End(c). If the endpoint has not been reached,
s cannot be 1. The existing Pow2 halving theorem supplies a positive
Pow2 h with s=2h. The equation W+1=2h*(ell+1) forces the low bit of W
to be 1. Thus the actual instruction must be D1, and its successor has

    W_new+1 = h*(ell+1),       h*R_new=v.

So Mark(c_new,h) holds, with h<s. The formal proof considers all ten
ordinary instruction alternatives and excludes the nine wrong cases.
No special return instruction is added to the machine.

For example, choose ell=2, initial marker P=8, and initial R=3. Then v=24:

| Ordinary steps | q | L | b | R | Whole left W | Remaining marker s |
|---:|---|---:|---:|---:|---:|---:|
| 0 | D | 11 | 1 | 3 | 23 | 8 |
| 1 | D | 5 | 1 | 6 | 11 | 4 |
| 2 | D | 2 | 1 | 12 | 5 | 2 |
| 3 | D | 1 | 0 | 24 | 2 | 1 |

Every row satisfies W+1=s*(ell+1) and s*R=v. The last row satisfies End.

## The history statements

The parameters H,n,offset,Bj,Cj have the same roles as in the earlier
proofs; only their variable names acquire a `return` prefix.

    beta_j(k,x) := exists u<H,
      Bj=u*(1+(k+1)*Cj)+x and x<1+(k+1)*Cj.

At(i,c) conjoins the four coordinate predicates at offset+i. TOTAL says
that a row with all coordinates below H exists at every i<n+1. STEPS
requires the original ordinary Step between every pair of adjacent
supplied rows. INITIAL says that each supplied initial row satisfies
Mark(c,P), for the chosen initial marker P.

The main exit theorem assumes only TOTAL, INITIAL, STEPS and P<n+1. It
concludes

    exists j<n+1, exists c<H,
      At(j,c) and End(c).

The tuple quantifier `exists c<H` means four bounded quantifiers. Thus a
supplied ordinary history of length at least P must visit the endpoint.
No marker s_i is supplied at intermediate history rows. No axiom says
that every finite execution has a beta code. All quantified output
witnesses are bounded, so universal closures of these expanded
statements are Pi-1 arithmetic sentences.

The halting-barrier theorem instead assumes that the supplied history
has a final bounded row at index n whose state is Z=5. It concludes the
same bounded existential endpoint statement, with no condition n>=P.
Thus the history cannot reach halt while still in this return phase.
This theorem permits later machine behavior after the endpoint; it does
not say that every continuation from that endpoint is nonhalting.

## The one bounded induction

As an intermediate hypothesis, AVOID says that every supplied row at
an index i<n+1 fails End. Under AVOID the proof constructs, rather than
assumes, a marker and a clock inequality at every row:

    Inv(i,c) := exists s<P+1,
      Mark(c,s) and i+s<P+1.

Use the induction formula

    Phi(i) := i<n+1 ->
      forall c<H, At(i,c) -> Inv(i,c).

Every quantifier in Phi is bounded. Its bounds include P+1, H, the
arithmetic beta moduli, and the bounded Pow2 divisor witnesses. Hence it
is a permitted instance of I-Delta-0 induction.

At index 0, INITIAL supplies Mark(c,P), and 0+P<P+1 gives the clock.
For the successor, TOTAL supplies the preceding row. STEPS supplies its
ordinary transition, and AVOID excludes its being an endpoint. The local
marker theorem supplies a smaller marker h<s. The old clock i+s<=P
implies i+1+h<=P. Moreover h<s<=P bounds the new witness by P+1.
These facts establish the successor instance.

At index n, the marker is positive and n+s<=P. Therefore n<P. This gives
the target-avoidance bound. If n>=P, avoidance is impossible, and classical
first-order logic gives a bounded existential endpoint. If the final row
is halting, avoidance is also impossible: the constructed marker says its
state is D, while the final-row hypothesis says Z.

The time bound P is deliberately coarse. In the displayed standard
example the phase needs three steps, while P is eight. A logarithm or
exponential sequence is unnecessary for the bounded-history proof.

## Exact public labels and proof dependencies

All labels start `skelet17-ladder-skelet10-`.

| Label suffix | Content | Induction constructions in its dependency closure |
|---|---|---:|
| `return-marker-step` | Every unfinished ordinary return step preserves the target with a strictly smaller marker. | 0 |
| `return-window-invariant` | Under AVOID, construct bounded markers and the clock at every supplied row. | 1 |
| `return-window-bound` | A target-avoiding supplied history has final index n<P. | 1 |
| `return-window-exit` | Every supplied history with n>=P visits the endpoint. | 1 |
| `return-window-halting-barrier` | Every supplied history ending at halt has visited the endpoint. | 1 |

All four history results share the same single induction construction.
The arithmetic predecessor and clock lemmas require no induction. These
are dependency counts for the actual proofs, not lower bounds on theory
strength. The original 93 trusted declarations remain unchanged.

## Verification and remaining work

`ladder_skelet10_return.py` generates the proofs in the canonical
`idelta0_machines.mm`. `check_skelet10_return.py` independently reconstructs
all five statements, checks bounded syntax and the absence of supplied
intermediate markers in the exit/barrier statements, and tests 1,440
standard return cases comprising 6,480 ordinary steps. Finite simulation
is supplementary; the Metamath verifier checks the formal derivations.
The scope and dependency checks are integrated into `audit_ladder.py`.

The return phase has now been connected to the B/A/C carry scan in the
whole-right-counter extension. SKELET10_RIGHT_ROUTINE.md gives the checked
statements and proof. SKELET10_RIGHT_PLAN.md retains its historical design.
The left-counter routine and full synchronization are the next major tasks.
