from pathlib import Path
import json,os
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_skelet10_spread import add_skelet10_spread
from ladder_skelet10_return import add_skelet10_return
from ladder_skelet10_blocks import add_skelet10_blocks
from ladder_skelet10_clear import add_skelet10_clear
m=r.m;P=Path(__file__).resolve().parent
if 'skelet17-ladder-skelet10-transform-decompose-0' in m.theorems:raise SystemExit('Input already contains this extension.')
m.nd.OUTPUT_PREFIX='ladder-z10-clear-';m.a.OUTPUT_PREFIX='ladder-z10-clear-';old=set(m.theorems)
api=add_skelet10(m,proofs=False);sp=add_skelet10_spread(m,proofs=False);ret=add_skelet10_return(m,api,proofs=False)
add_skelet10_blocks(m,sp)
clear=add_skelet10_clear(m,api,sp,ret)
if os.environ.get('CLEAR_STAGE','all')!='local':
 from ladder_skelet10_clear_history import add_skelet10_clear_history
 add_skelet10_clear_history(m,api,clear,ret)
with (P/'skelet10_clear_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'skelet10_clear_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Left return and block-tail extension generated.',flush=True)
