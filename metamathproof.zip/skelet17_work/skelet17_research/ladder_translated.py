"""Direct invariant for 1RB1RA_1LA---; executed in builder namespace."""
TABLES['translated']=[(1,1,1),(0,1,1),(0,0,1),(5,1,1)]
oldSTEP=STEP
# Capture the old function as a default argument to avoid recursive rebinding.
def STEP(c,d,kind='translated',previous=oldSTEP):return previous(c,d,kind)
oddvar=m.declare('translatedOdd');oddfresh=m.declare('translatedOddFresh')
def odd(l):return nd.BEX(oddvar,A(l,O),Q(l,A(M(two,oddvar),O)))
def clauses(c):
 q,l,bit,r=c
 return [nd.AND([Q(q,Z),Q(r,Z)]),nd.AND([Q(q,Z),Q(bit,O),Q(r,O)]),nd.AND([Q(q,O),Q(bit,Z),Q(r,Z),odd(l)])]
def INV(c):return nd.OR(clauses(c))
def unpack_clause(ctx,c,k):
 fs=[[Q(c[0],Z),Q(c[3],Z)],[Q(c[0],Z),Q(c[2],O),Q(c[3],O)],[Q(c[0],O),Q(c[2],Z),Q(c[3],Z),odd(c[1])]][k]
 nd.unpack(ctx,fs);return fs

def translated_closure():
 fs=[INV(CF),STEP(CF,NF)];prem=b.And(*fs);goal=INV(NF);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
 def region(ec,k):
  eqs=unpack_clause(ec,CF,k)
  def move(sc,j):
   pf=parts(TABLES['translated'],CF,NF,j);nd.unpack(sc,pf)
   state=0 if k<2 else 1
   if j//2!=state:return contradiction(sc,CF[0],state,j//2,goal)
   if k==1 and j%2!=1:return contradiction(sc,CF[2],1,0,goal)
   if k==2 and j%2!=0:return contradiction(sc,CF[2],0,1,goal)
   def pop(dc,quotient,remainder,qval,rval,equality):
    m.eq(dc,A(M(two,quotient),remainder),A(M(two,qval),rval),[m.flip(dc,equality),*[f for f in eqs if f[0]=='=']])
    def bit(bc,t):
     m.bound(bc,num(t),two,num(1-t));return m.rewrite(bc,L(a.E,two),num(t),remainder,bc.get(m.flip(bc,Q(remainder,num(t)))))
    nd.cases(dc,list(pf[-1][1:]),L(remainder,two),bit)
    m.bound(dc,rval,two,Z if rval==O else O)
    return m.quotient_unique(dc,two,quotient,remainder,qval,rval)
   if k<2:
    pop(sc,NF[3],NF[2],Z,Z if k==0 else O,pf[4])
    if j==1:
     sc.both(Q(NF[0],Z),Q(NF[3],Z));return nd.disj(sc,clauses(NF),0)
    # A0 -> B0, pushing 1 makes the new left half odd.
    m.eq(sc,NF[1],A(M(two,CF[1]),O),[pf[3]])
    m.bound(sc,CF[1],A(NF[1],O),A(CF[1],O),[pf[3]])
    m.bex_intro(sc,oddvar,A(NF[1],O),Q(NF[1],A(M(two,oddvar),O)),CF[1])
    nd.conj(sc,[Q(NF[0],O),Q(NF[2],Z),Q(NF[3],Z),odd(NF[1])]);return nd.disj(sc,clauses(NF),2)
   def haveodd(dc):
    # Pop the odd old left half, hence the next scanned bit is 1.
    leq=Q(CF[1],A(M(two,oddfresh),O));eqs.append(leq)
    pop(dc,NF[1],NF[2],oddfresh,O,pf[4])
    m.eq(dc,NF[3],O,[pf[3],Q(CF[3],Z)])
    nd.conj(dc,[Q(NF[0],Z),Q(NF[2],O),Q(NF[3],O)])
    return nd.disj(dc,clauses(NF),1)
   return m.bex_elim(sc,oddvar,A(CF[1],O),Q(CF[1],A(M(two,oddvar),O)),oddfresh,goal,haveodd)
  return nd.cases(ec,[nd.AND(parts(TABLES['translated'],CF,NF,j)) for j in range(4)],goal,move)
 nd.cases(ctx,clauses(CF),goal,region)
 finish('skelet17-ladder-translated-local',root,prem,goal,ctx,'Three-region invariant for the actual translated cycler. No induction and no additional tape information in Step.')
translated_closure()
ts=s.replace('skelet17-ladder-cycler-','skelet17-ladder-translated-').replace('skelet17-ladder-lt-add-cancel','skelet17-ladder-translated-lt-add-cancel').replace("'ladderOffset'","'ladderTranslatedOffset'")
shim=types.SimpleNamespace(nd=nd,b=b,a=a,declare=m.declare,finish=finish,use=use,CF=CF,NF=NF,INV=INV,STEP=STEP)
h={'m':shim};exec(compile(ts,'translated_history_generated.py','exec'),h)
(p/'translated_history_generated.py').write_text(ts)
ep=(p/'ladder_endpoint.py').read_text().replace('ladderInitial','translatedInitial').replace('skelet17-ladder-cycler-','skelet17-ladder-translated-')
ep=ep.replace('nd.disj(ac,[cfg(fresh,v) for v in CYCLE],0)', "nd.unpack(ac,[Q(v,Z) for v in fresh]);ac.both(Q(fresh[0],Z),Q(fresh[3],Z));nd.disj(ac,clauses(fresh),0)")
ep=ep.replace('nd.unpack(ec,[Q(v,num(z)) for v,z in zip(NF,CYCLE[k])])\n return contradiction(ec,NF[0],CYCLE[k][0],5,bad)', 'unpack_clause(ec,NF,k)\n return contradiction(ec,NF[0],0 if k<2 else 1,5,bad)')
ep=ep.replace('nd.cases(ctx,[cfg(NF,v) for v in CYCLE],bad,exclude)','nd.cases(ctx,clauses(NF),bad,exclude)')
exec(compile(ep,'translated_endpoint_generated.py','exec'),globals())
(p/'translated_endpoint_generated.py').write_text(ep)
