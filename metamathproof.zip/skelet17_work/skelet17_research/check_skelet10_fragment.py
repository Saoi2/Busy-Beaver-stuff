"""Independent finite interpretation checks; not a replacement for Metamath."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent
TEXT='1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB'
def table(text):
 out=[]
 for row in text.split('_'):
  for ins in (row[:3],row[3:]):
   out.append((5,True,1) if ins=='---' else (ord(ins[2])-65,ins[1]=='R',int(ins[0])))
 return out
T=table(TEXT)
def sparse(x):return x&(x>>1)==0
def scan(c):
 q,l,b,r=c
 return q==0 and b==0 and sparse(r) or q==1 and l%2==1 and sparse(2*r+b) or q==2 and b==1
def step(c):
 q,l,b,r=c;nq,right,w=T[2*q+b]
 return (nq,2*l+w,r%2,r//2) if right else (nq,l//2,l%2,2*r+w)
def expanded_power(p):
 return p>0 and all(d==1 or d%2==0 for d in range(1,p+1) if p%d==0)
def expanded_sparse(x):
 # Eliminate r by its displayed equality while retaining exactly its bound.
 return all(not (0<=x-(4*p*q+3*p)<p)
            for p in range(x+1) if expanded_power(p)
            for q in range(x+1))
for value in range(512):assert expanded_sparse(value)==sparse(value)
assert sparse(0)
pop_cases=odd_cases=0
for x in range(4096):
 if sparse(x):
  assert sparse(x//2);assert sparse(2*x);assert sparse(4*x+1);pop_cases+=1
  for d in (0,1):
   if d==0 or x%2==0:assert sparse(2*x+d)
 if sparse(2*x+1):
  assert x%2==0;odd_cases+=1
assert scan(step((0,0,0,0)))
cases=0
for q in range(5):
 for l in range(64):
  for b in (0,1):
   for r in range(64):
    c=q,l,b,r
    if scan(c):
     d=step(c);assert scan(d) or d[0]==3,(c,d);cases+=1
c=(0,0,0,0);steps=[]
while c[0]!=3:
 steps.append(c);c=step(c)
steps.append(c)
assert len(steps)==4 and c==(3,0,0,1)
out={'machine':TEXT,'finite_checks_only':True,'expanded_sparse_definition_checked_through':511,'pop_cases':pop_cases,'odd_tail_cases':odd_cases,
 'scan_configurations_checked':cases,'blank_first_D_trace':steps,'whole_machine_nonhalting_proved':False}
(P/'skelet10_fragment_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
