"""Interpretation checks for the new global joint-record code."""
from itertools import product
from pathlib import Path
import json
from gray_transducer import transition,word,decode
CONTROL=[[0,4],[0,5],[0,6],[0,7],[2,4],[3,5],[0,5],[1,4]]
def advance(record,bit):
    old=record%8;c=CONTROL[old][bit];f=int(old>=4 and bit==1);v=c%2 if f else 0
    return c+8*f+16*v
def make(x):
    code=state=0
    for ch in bin(x)[2:] if x else '':state=advance(state,int(ch));code=32*code+state
    return code
def verify(x,R):
    if not x:assert R==0;return
    P=1<<(x.bit_length()-1);assert P<=x<2*P and R<32*P**5 and R<32*(x+1)**5
    p=1
    while p<=x:
        before=R//((2*p)**5)%32;bit=x//p%2;after=R//(p**5)%32
        assert advance(before,bit)==after;p*=2
if __name__=='__main__':
    for x in range(16384):verify(x,make(x))
    count=0
    for size in range(1,8):
        for xs in product(range(4),repeat=size):
            w=word(xs);x=int(w,2) if w else 0;R=make(x);verify(x,R)
            state=(0,0,0);source=[];p=1<<(len(w)-1) if w else 0;bits=[]
            for ch in w:
                state,out=transition(state,int(ch));record=R//(p**5)%32
                assert record%8==4*state[0]+2*state[1]+state[2]
                f=record//8%2;v=record//16%2
                assert (f,v)==(int(out is not None),out if out is not None else 0)
                if f:bits.append(v)
                p//=2
            if state[0]:bits.append(state[1]^state[2])
            assert bits==decode(w)[1];count+=1
    report={'status':'Regression evidence; formal original-parser projection remains pending.',
        'all_binary_inputs_checked':16384,'valid_list_inputs_checked':count,
        'base':32,'packet':'control + 8*flag + 16*digit','place_weight':'p^5',
        'code_bound':'R < 32*(x+1)^5'}
    Path(__file__).with_name('packet_checks.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
