# Skelet #10: a checked right-counter fragment

Machine: `1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB`.

This checkpoint proves its right-counter safety fragment in the single
`idelta0_machines.mm` project. It **does not yet prove Skelet #10 nonhalting**.
The missing obligation is a bounded arithmetic relation synchronizing the
left and right counter representations across the D boundary.

## What is represented

The original configuration remains `(q,L,b,R)`: L and R are binary tape
halves with the nearest bit least significant; b is the scanned bit.
A=0, B=1, C=2, D=3, E=4 and halt Z=5. The ordinary transition relation
has all ten instruction cases, including E0 completed as 1RZ. No word
property or extra annotation has been added to this relation.

The right counter uses words without adjacent 1s, the syntax of Zeckendorf
representations. We need this syntactic property, rather than Fibonacci
values or a total Fibonacci function, for the present fragment.

Use the existing bounded divisor predicate

    Pow2(p) := 0<p and forall d<p+1,
        (exists e<p+1, d*e=p) ->
        (d=1 or exists z<d+1, d=2z).

Define the following abbreviation, fully expanded in each Metamath theorem:

    Sparse(x) := forall p<x+1,
        Pow2(p) -> forall q<x+1, forall r<p,
            not (x = (4*p)*q + 3*p + r).

The equation locates a two-bit field equal to binary 11 at place p.
The q part contains the more distant bits; r contains the nearer bits.
For example, 6=3*2 has an 11 field at p=2, q=0, r=0. And
13=3*4+1 has one at p=4, q=0, r=1. Numbers 0, 1, 2, 5 and 10
have no adjacent 1s. In standard arithmetic Pow2 ranges over the binary
places 1,2,4,8,..., giving the stated interpretation.

Every quantifier in Sparse and Pow2 has an explicit arithmetic bound.
Thus Sparse is a Delta-0 formula in the original language 0,1,+,*,<.
There is no exponentiation symbol, axiom of exponential totality, or
unbounded search in this definition. Bounds for a forbidden field's p
and q are proved within the individual derivations before Sparse is used.

## Public theorems

All labels below begin `skelet17-ladder-skelet10-`.

| Label suffix | Statement, using the abbreviations above |
|---|---|
| `sparse-zero` | Sparse(0). |
| `sparse-pop` | Sparse(x), x=2y+d, d<2 imply Sparse(y). |
| `sparse-odd-tail` | Sparse(2x+1) implies Even(x). |
| `double-window-bound` | 2x+d<2y implies x<y. |
| `sparse-push` | Sparse(x), d<2, and (d=0 or Even(x)) imply Sparse(2x+d). |
| `sparse-prefix-0` | Sparse(x) implies Sparse(2x). |
| `sparse-prefix-10` | Sparse(x) implies Sparse(4x+1). |
| `right-scan-to-D` | Scan(c) and ordinary Step(c,c') imply Scan(c') or c'.state=D. |
| `blank-enters-right-scan` | Any ordinary first step from blank enters Scan. |

Even(x) is the existing bounded formula `exists z<x+1, x=2z`.
The prefix strings are written **nearest bit first**. Thus adding `10`
means pushing a 0 and then a 1: x becomes 4x+1. This is consistent with
the original binary tape convention.

These are reusable lemmas and one machine fragment, rather than nine
independent nonhalting results. Each named statement is a proved `$p`.
No `$a` declarations were added.

## Why the word lemmas hold

Deleting a low bit shifts a forbidden 11 field at p to one at 2p.
Its lower remainder becomes 2r+d, which is below 2p by the existing
arithmetic field-range lemma. Pow2 doubling supplies the shifted place.
Consequently a forbidden field in the shortened word would contradict
Sparse of the original word.

For Sparse(2x+1), divide x by 2. An odd remainder would produce the
forbidden low field 11 at p=1. Therefore x is even.

For pushing a bit, suppose that a forbidden field appears. The existing
Pow2 halving lemma says its place is either 1 or twice another Pow2 place.
At place 1, quotient uniqueness forces the newly pushed bit and the old
low bit both to be 1, contradicting the premise. At a larger place,
divide the lower remainder by 2. Quotient uniqueness transfers the
forbidden field back into the old word, contradicting Sparse(x).
The helper double-window-bound supplies the required halved-remainder
bound. This argument introduces no new induction instance.

The 0 and 10 constructors are short consequences of the general push
lemma, with explicit bounded witnesses for evenness.

The Metamath kernel checks variable freshness syntactically. A bound name
in an outer assumption therefore cannot simply be reused for universal
generalization in these proofs. The helper proves the new universal
statement with separate fresh names, then applies a proved bound-variable
renaming implication. This changes variable names, not the machine or
the mathematical assumptions.

## The right-scan invariant

Scan(q,L,b,R) is the disjunction of exactly these three regions:

| Region | Requirements |
|---|---|
| A | q=A, b=0, Sparse(R). |
| B | q=B, Odd(L), Sparse(2R+b). |
| C | q=C, b=1. |

Odd(L) means `exists z<L+1, L=2z+1`.

Every ordinary instruction branch is considered in the formal proof.
Wrong source states or scanned bits are excluded by arithmetic. The
matching branches have the following effects:

* A0 writes 1 and moves right to B. The new L is odd. The old R is
  exactly the new scanned bit followed by the new right half, so its
  Sparse property gives the B region.
* B0 writes 0 and moves left to C. Odd(L) makes the popped bit 1,
  establishing the C region.
* B1 writes 1 and moves right to A. Sparse(2R+1) makes R even, so the
  newly scanned bit is 0. Deleting low bits preserves Sparse of the
  remaining right half, establishing the A region.
* C1 writes 1 and moves left to D. D is the boundary returned by the
  theorem. The theorem supplies no invariant for a further D step.

There is no C0 scan case, hence no path to E during this fragment.
The theorem's conclusion is the explicit disjunction `Scan(c') or q'=3`;
state D is not silently treated as an absorbing machine state.

The blank configuration takes three ordinary steps to its first D row:

| Step | q | L | b | R |
|---:|---|---:|---:|---:|
| 0 | A | 0 | 0 | 0 |
| 1 | B | 1 | 0 | 0 |
| 2 | C | 0 | 1 | 0 |
| 3 | D | 0 | 0 | 1 |

The first-step entry theorem is formally checked. This displayed complete
three-step trace is independently simulated as an interpretation check;
it is not a new existential beta-history theorem.

## Verification and limits

The official Metamath verifier checks the expanded first-order natural
deduction proofs against the original 93 trusted declarations. The
right-scan theorem depends on the already proved bounded division
induction construction. No new induction schema instance is introduced
by this module. Exact dependency counts are in ladder_manifest.json.
They describe these proofs, not lower bounds or independence results.

An independent statement checker reconstructs all nine conclusions,
including the standard machine table and the stopping-at-D disjunction.
Supplementary finite tests check 6,528 scan configurations with L,R<64,
377 Sparse pop/constructor cases, and 233 odd-tail cases below 4096.
The expanded Sparse formula is also compared with its bit-string meaning
on inputs through 511. These finite tests are not the formal proofs.

The unchanged beta-history format continues to be used for the earlier
completed nonhalting examples. This module has not yet added a whole
Skelet #10 history invariant or nonhalting endpoint. It supplies no
BB classification or generic CPS/RWL correctness claim.

## What remains

A complete proof must relate the left-side transformed word to the right
word and show that the D return re-enters a valid scan domain. It must
also give bounds on any auxiliary word witnesses and derive their
existence along raw ordinary beta histories. Assuming synchronized
counter annotations as part of a run would not discharge these tasks.

The right-word grammar is now available as bounded formulas with explicit
proofs of deletion and construction. The next step is to encode the
left-word transformation and the successor relation using this grammar.

## References and reproduction

* Shawn Ligocki, [Skelet #10: Double Fibonacci Counter](https://www.sligocki.com/2023/03/14/skelet-10.html), 14 March 2023.
* [BusyCoq/Skelet10.v](https://github.com/ccz181078/Coq-BB5/blob/main/BusyCoq/Skelet10.v), notably `dorf`, `Z`, `T`, `incr_right`, `incr_left`, and `incr_D`.

The present Metamath proofs were constructed directly in first-order
bounded arithmetic; the Rocq source is a guide to the machine's structure,
not a trusted imported theorem.

Run `python3 rebuild_project.py --metamath /path/to/metamath` to regenerate,
simplify, verify, and audit the full project. `ladder_skelet10.py` is the
new proof generator. `resume_canonical.py` and `extend_skelet10.py` support
incremental development from a previous checked canonical snapshot;
they never replace proved statements by axioms. Run the incremental raw
output through prune.py and simplify_metamath.py before verification, just
as in the full build; this limits unused variable conditions in each proof.


Subsequent checkpoint: SKELET10_LEFT_COUNTER.md records four checked finite
left-counter contracts, including a synchronized boundary return to Scan.
The complete left/right synchronization and whole-machine nonhalting
remain unfinished.

Further arithmetic progress: SKELET10_SPREAD.md records a bounded
bit-spread relation, its digit constructors and universal quadratic
witness existence, together with the corresponding left-word relation.
These do not yet complete synchronization or nonhalting.
