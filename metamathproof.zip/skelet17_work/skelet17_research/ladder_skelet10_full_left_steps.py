"""One ordinary-step proof for the factored full left-counter invariant."""
def add_skelet10_full_left_steps(m,api,sp,right,clear,F,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;use=m.invoke
 two,three,four,eight=map(ar.num,(2,3,4,8));T=sp['transform'];sparse=api['sparse'];carry=right['carry']
 cf,nf=api['current'],api['next'];step=api['step'];word,tail=F['word'],F['tail'];S,W,PB,K=F['S'],F['W'],F['PB'],F['K']
 rank,endpoint=F['rank'],F['endpoint'];rho=F['rho'];push=F['push'];double=F['double'];core=F['core'];wl,wr=F['wl'],F['wr']
 nrank=F['nrank'];fq,fd,eq=F['dq'],F['dd'],F['eq'];bt=m.declare('blockTail');ft=F['ft']
 fr=m.declare('leftFreshRank')
 def positive_safe():
  if 'z10-right-positive-add' not in m.theorems:
   x,y=b.t,b.u;gg=m.declare('leftPositiveGap');root=nd.Ctx();prem=L(Z,y);c=root.push(prem);goal=L(Z,A(x,y))
   m.gap_elim(c,Z,y,gg,goal,lambda cc,e:m.bound(cc,Z,A(x,y),A(x,gg),[e]));m.finish('z10-right-positive-add',root,prem,goal,c)
  r=b.t;prem=rank(cf,r);root=nd.Ctx();c=root.push(prem);goal=L(Z,r)
  def scanpos(cc):
   def found(dc,j,p,s,u,a,t):
    const=ar.num([8,7,6,5,4,7,6,5][j]);m.bound(dc,Z,const,ar.num([7,6,5,4,3,6,5,4][j]))
    use(dc,'z10-right-positive-add',{'t':A(K,M(eight,u)),'u':const})
    return m.rewrite(dc,L(Z,ar.E),rho(j,u),r,ar.sym(r,rho(j,u),dc.get(Q(r,rho(j,u))),dc.g))
   return F['scan_cases'](cc,cf,r,goal,found)
  def retpos(cc):
   return F['return_cases'](cc,cf,r,goal,lambda dc,v:use(dc,'z10-clear-rank-positive',{'t':r,**F['cmap'](v)}))
  nd.cases(c,[F['scan'](cf,r),F['returning'](cf,r)],goal,lambda cc,j:scanpos(cc) if j==0 else retpos(cc))
  m.finish('z10-full-left-rank-positive',root,prem,goal,c,'Every left-counter phase has positive rank. No induction.')
  root=nd.Ctx();c=root.push(prem);bad=Q(cf[0],ar.num(5));bc=c.push(bad)
  def scanbad(cc):
   return F['scan_cases'](cc,cf,r,L(Z,Z),lambda dc,j,p,s,u,a,t:api['neq'](dc,cf[0],[3,2,4,1,0,2,3,2][j],5,L(Z,Z)))
  def retbad(cc):
   def found(dc,v):use(dc,'z10-clear-rank-safe',{'t':r,**F['cmap'](v)});return dc.explode(bad,L(Z,Z))
   return F['return_cases'](cc,cf,r,L(Z,Z),found)
  nd.cases(bc,[F['scan'](cf,r),F['returning'](cf,r)],L(Z,Z),lambda cc,j:scanbad(cc) if j==0 else retbad(cc))
  bc.put(b.Not(L(Z,Z)),b.ax('O1',bc.g,t=Z));c.put(b.Not(bad),ar.not_intro(c.g,bad,L(Z,Z),bc.get(L(Z,Z)),bc.get(b.Not(L(Z,Z)))))
  m.finish('z10-full-left-rank-safe',root,prem,b.Not(bad),c,'The E phase scans 1; every scan and return phase excludes halt. No induction.')
 if proofs:positive_safe()
 def local():
  r=b.t;prem=nd.AND([rank(cf,r),b.Not(endpoint(cf)),step(cf,nf)]);goal=nd.BEX(nrank,r,rank(nf,nrank));root=nd.Ctx();c=root.push(prem);nd.unpack(c,[rank(cf,r),b.Not(endpoint(cf)),step(cf,nf)])
  def emit(cc,j,p,s,u,a=Z,t=Z):
   rr=rho(j,u);cc.put(Q(rr,rr),b.refl(cc.g,rr));F['pack_scan'](cc,nf,rr,j,p,s,u,a,t);return m.bex_intro(cc,nrank,r,rank(nf,nrank),rr)
  def drop_one(cc,j,u):
   off=[8,7,6,5,4,7,6,5][j];return use(cc,'z10-full-left-unit-drop',{'t':A(K,M(eight,u)),'u':ar.num(off-1),'w':r})
  def pop_sparse(cc,x,y,d,e):
   m.bound(cc,d,two,O if d==Z else Z);nd.conj(cc,[sparse(x),e,L(d,two)]);return use(cc,'skelet17-ladder-skelet10-sparse-pop',{'t':x,'u':y,'v':d})
  def scanbranch(cc):
   def found(dc,j,p,s,u,a,t):
    prefix=Q(word,A(M(p,u),s));pe=Q(p,A(M(three,s),O))
    def odd_right(ic,ins,nextj,kfactor):
     def divided(qc,q,d):
      req=Q(cf[3],push(q,d));peq=Q(A(cf[3],O),M(two,double(core(p),kfactor-1)))
      nd.conj(qc,[peq,req,L(d,two)]);use(qc,'z10-return-even-predecessor',{'t':cf[3],'u':double(core(p),kfactor-1),'v':q,'w':d})
      nd.unpack(qc,[Q(d,O),Q(A(q,O),double(core(p),kfactor-1))]);m.eq(qc,cf[3],push(q,O),[req,Q(d,O)]);m.bound(qc,O,two,Z)
      F['tape_step'](qc,ins,q,F['leftshape'](j,t),O)
      m.rewrite(qc,Q(A(ar.E,O),double(core(p),kfactor-1)),q,nf[3],ar.sym(nf[3],q,qc.get(Q(nf[3],q)),qc.g))
      F['tail_bound'](qc,nextj,t);drop_one(qc,j,u);return emit(qc,nextj,p,s,u,a,t)
     return F['divides'](ic,cf[3],goal,divided)
    if j==0:
     def decoded(ic,av,odd):
      nx=M(two,av) if not odd else A(M(four,av),O)
      m.rewrite(ic,T(ar.E,wl(cf)),u,nx)
      use(ic,'skelet17-ladder-skelet10-transform-decompose-'+('10' if odd else '0'),{'t':av,'u':wl(cf)})
      scale=ar.num(16) if odd else four;offset=ar.num(10) if odd else Z
      db=b.And(Q(wl(cf),A(M(scale,bt),offset)),T(av,bt))
      def tail_found(tc):
       encoded=A(M(scale,ft),offset);nd.unpack(tc,[Q(wl(cf),encoded),T(av,ft)])
       nextj=5 if odd else 1;nextL=F['leftshape'](5,ft) if odd else ft;digit=O if odd else Z;knownL=push(nextL,digit)
       m.eq(tc,wl(cf),push(knownL,Z),[Q(wl(cf),encoded)]);m.bound(tc,Z,two,O);m.quotient_unique(tc,two,cf[1],cf[2],knownL,Z)
       m.bound(tc,digit,two,Z if odd else O);F['tape_step'](tc,6,nextL,cf[3],digit)
       F['right_plus'](tc,double(core(p),2));F['tail_bound'](tc,nextj,ft);drop_one(tc,0,u)
       return emit(tc,nextj,p,s,u,av,ft)
      return m.bex_elim(ic,bt,A(wl(cf),O),db,ft,goal,tail_found)
     def divided(ic,q,d):
      udiv=Q(u,push(q,d));ic.both(L(q,A(u,O)),L(u,W));use(ic,'skelet17-binary-le-lt-trans',{'t':q,'u':u,'v':W})
      use(ic,'skelet17-binary-digit-cases',{'t':d})
      def digit_branch(qc,k):
       if k==0:
        e=Q(u,push(q,Z));m.eq(qc,*e[1:],[udiv,Q(d,Z)]);pop_sparse(qc,u,q,Z,e);m.eq(qc,u,M(two,q),[e])
        return decoded(qc,q,False)
       e=Q(u,push(q,O));m.eq(qc,*e[1:],[udiv,Q(d,O)]);pop_sparse(qc,u,q,O,e)
       m.rewrite(qc,sparse(ar.E),u,push(q,O),qc.get(e));use(qc,'skelet17-ladder-skelet10-sparse-odd-tail',{'t':q})
       def even_found(ec):
        ae=Q(q,M(two,eq));m.eq(ec,q,push(eq,Z),[ae]);pop_sparse(ec,q,eq,Z,Q(q,push(eq,Z)))
        ec.both(L(eq,A(q,O)),L(q,W));use(ec,'skelet17-binary-le-lt-trans',{'t':eq,'u':q,'v':W})
        m.eq(ec,u,A(M(four,eq),O),[e,ae]);return decoded(ec,eq,True)
       return m.bex_elim(qc,m.pz,A(q,O),Q(q,M(two,m.pz)),eq,goal,even_found)
      return nd.cases(ic,[Q(d,Z),Q(d,O)],goal,digit_branch)
     return F['divides'](dc,u,goal,divided)
    if j in (1,2,3):return odd_right(dc,{1:4,2:9,3:3}[j],j+1,{1:3,2:2,3:1}[j])
    if j in (5,6):
     target=6 if j==5 else 7;ins=5 if j==5 else 6;newL=push(t,O) if j==5 else t;digit=Z if j==5 else O
     m.bound(dc,digit,two,O if digit==Z else Z);F['tape_step'](dc,ins,newL,cf[3],digit)
     F['right_plus'](dc,double(core(p),3 if j==5 else 4));F['tail_bound'](dc,target,t);drop_one(dc,j,u);return emit(dc,target,p,s,u,a,t)
    if j==7:
     def divided(ic,q,d):
      teq=Q(t,push(q,d));m.eq(ic,cf[1],push(q,d),[Q(cf[1],t),teq]);F['tape_step'](ic,5,q,cf[3],d)
      F['right_plus'](ic,double(core(p),5));m.eq(ic,t,wl(nf),[teq,Q(nf[1],q),Q(nf[2],d)]);m.rewrite(ic,T(a,ar.E),t,wl(nf))
      np,ns=double(p,2),A(double(s,2),O)
      use(ic,'skelet17-binary-power-double',{'t':p});use(ic,'skelet17-binary-power-double',{'t':M(two,p)})
      m.eq(ic,np,A(M(three,ns),O),[pe]);m.eq(ic,word,A(M(np,a),ns),[prefix,Q(u,A(M(four,a),O)),pe])
      ic.both(Q(np,A(M(three,ns),O)),Q(word,A(M(np,a),ns)));use(ic,'z10-right-prefix-bounds',{'t':np,'u':ns,'v':word,'w':a});nd.unpack(ic,[L(np,S),L(ns,W),L(a,W)])
      use(ic,'z10-full-left-square-shift',{'t':two,'u':p,'v':A(tail,O)},False)
      oldright=double(core(p),6);newright=double(core(np),2)
      m.rewrite(ic,Q(A(nf[3],O),ar.E),oldright,newright,ar.sym(newright,oldright,ic.get(Q(newright,oldright)),ic.g))
      m.bound(ic,a,u,M(three,a),[Q(u,A(M(four,a),O))]);m.bound(ic,Z,ar.num(5),four);nd.conj(ic,[L(a,u),L(Z,ar.num(5)),Q(r,rho(7,u))])
      use(ic,'z10-full-left-carry-drop',{'t':a,'u':u,'v':eight,'w':ar.num(5),'leftRankOffset':K,'leftRankValue':r});return emit(ic,0,np,ns,a)
     return F['divides'](dc,t,goal,divided)
    assert j==4
    def divided(ic,q,d):
     req=Q(cf[3],push(q,d));F['tape_step'](ic,1,q,F['leftshape'](4,t),d)
     m.eq(ic,cf[3],wr(nf),[req,Q(nf[3],q),Q(nf[2],d)]);m.rewrite(ic,Q(A(ar.E,O),core(p)),cf[3],wr(nf))
     outword=A(M(four,a),O);outvalue=M(p,outword);outleft=A(M(ar.num(16),t),ar.num(10))
     use(ic,'skelet17-ladder-skelet10-transform-prefix-10',{'t':a,'u':t});m.eq(ic,nf[1],outleft,[Q(nf[1],push(F['leftshape'](4,t),Z))])
     m.rewrite(ic,T(outword,ar.E),outleft,nf[1],ar.sym(nf[1],outleft,ic.get(Q(nf[1],outleft)),ic.g));use(ic,'skelet17-ladder-skelet10-sparse-prefix-10',{'t':a})
     jp,js,ja=right['jp'],right['js'],right['ja']
     def cp(pv,sv,av):return [m.power2(pv),Q(pv,A(M(three,sv),O)),Q(word,A(M(pv,M(two,av)),sv)),Q(outvalue,M(pv,A(M(four,av),O)))]
     m.eq(ic,word,A(M(p,M(two,a)),s),[prefix,Q(u,M(two,a))]);ic.put(Q(outvalue,outvalue),b.refl(ic.g,outvalue));nd.conj(ic,cp(p,s,a))
     m.bex_intro(ic,ja,W,nd.AND(cp(p,s,ja)),a);m.bex_intro(ic,js,W,nd.BEX(ja,W,nd.AND(cp(p,js,ja))),s);m.bex_intro(ic,jp,S,nd.BEX(js,W,nd.BEX(ja,W,nd.AND(cp(jp,js,ja)))),p)
     use(ic,'z10-full-left-carry-output-bound',{'t':word,'u':outvalue})
     nd.unpack(ic,list(m.power2(p)[1:]));use(ic,'skelet17-binary-factor-bound',{'t':outword,'u':p})
     m.eq(ic,S,A(PB,O));m.rewrite(ic,L(p,ar.E),S,A(PB,O))
     mp={**F['cmap'](outvalue),'t':p,'u':outword,**{z[1]:x for z,x in zip(cf,nf)}}
     prem0=m.sub(m.theorems['z10-full-left-clear-pack'],mp)[1]
     ic.put(Q(M(p,outword),outvalue),b.refl(ic.g,outvalue))
     # Each core field has already been established; recurse over the exact
     # constructor conjunction so no predicate definition is changed.
     def collect(f):
      if f[0]=='/\\':collect(f[1]);collect(f[2]);ic.both(f[1],f[2])
      else:ic.get(f)
     collect(prem0);use(ic,'z10-full-left-clear-pack',mp)
     ic.both(carry(word,outvalue),F['clear_rank'](nf,M(two,p),outvalue));F['pack_return'](ic,nf,M(two,p),outvalue)
     use(ic,'z10-full-left-eight-split',{},False);m.rewrite(ic,Q(r,A(A(M(ar.E,S),M(ar.E,u)),four)),eight,A(two,ar.num(6)))
     ic.both(L(p,S),Q(r,A(A(M(A(two,ar.num(6)),S),M(A(two,ar.num(6)),u)),four)));use(ic,'z10-full-left-exit-drop',{'t':p,'u':S,'v':ar.num(6),'w':u,'leftRankValue':r})
     return m.bex_intro(ic,nrank,r,rank(nf,nrank),M(two,p))
    return F['divides'](dc,cf[3],goal,divided)
   return F['scan_cases'](cc,cf,r,goal,found)
  def returnbranch(cc):
   def found(dc,value):
    ce=m.sub(clear['endpoint'](cf),F['cmap'](value));ec=dc.push(ce)
    nd.unpack(ec,[Q(cf[0],Z),Q(wr(cf),tail),T(value,cf[1]),sparse(value)])
    nd.conj(ec,[carry(word,value),T(value,cf[1]),sparse(value)]);m.bex_intro(ec,F['v'],S,nd.AND([carry(word,F['v']),T(F['v'],cf[1]),sparse(F['v'])]),value)
    nd.conj(ec,[Q(cf[0],Z),Q(wr(cf),tail),nd.BEX(F['v'],S,nd.AND([carry(word,F['v']),T(F['v'],cf[1]),sparse(F['v'])]))])
    ec.explode(endpoint(cf),L(Z,Z));ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z));dc.put(b.Not(ce),ar.not_intro(dc.g,ce,L(Z,Z),ec.get(L(Z,Z)),ec.get(b.Not(L(Z,Z)))))
    dc.both(F['clear_rank'](cf,r,value),b.Not(ce));nd.conj(dc,[F['clear_rank'](cf,r,value),b.Not(ce),step(cf,nf)])
    use(dc,'skelet17-ladder-skelet10-left-return-step',{'t':r,**F['cmap'](value)})
    def rank_found(rc):
     F['pack_return'](rc,nf,fr,value);return m.bex_intro(rc,nrank,r,rank(nf,nrank),fr)
    return m.bex_elim(dc,clear['outscale'],r,F['clear_rank'](nf,clear['outscale'],value),fr,goal,rank_found)
   return F['return_cases'](cc,cf,r,goal,found)
  nd.cases(c,[F['scan'](cf,r),F['returning'](cf,r)],goal,lambda cc,j:scanbranch(cc) if j==0 else returnbranch(cc))
  m.finish('skelet17-ladder-skelet10-left-counter-step',root,prem,goal,c,'Every ordinary step before the correct left-counter A output preserves a bounded phase with smaller rank. Existing instruction contracts and the complete clearing return are reused.')
 if proofs:local()
