"""Refresh exact interfaces and trusted-core signatures without retaining proofs.

This is an append-only refresh. It checks all old mandatory hypotheses and
mandatory DV pairs, plus every new interface's actual canonical statement.
The independent Metamath kernel must already have verified the full file.
"""
from pathlib import Path
from collections import defaultdict
import sys,re,json,hashlib,itertools,resource
P=Path(__file__).resolve().parent;path=P/'idelta0_machines.mm'
r=json.loads((P/'simplification_report.json').read_text());prior=json.loads((P/'preceding_checkpoint_report.json').read_text())
exports={}
for name in sys.argv[1:]:exports.update(json.loads((P/name).read_text()))
targets=set(r['interface_digests'])|set(exports);expected={k:['|-','[]','=>',*v.split()] for k,v in exports.items()}
with path.open('rb') as f:
 full=hashlib.sha256();prefix=hashlib.sha256();remaining=prior['output_bytes']
 while remaining:
  block=f.read(min(1048576,remaining));assert block;prefix.update(block);full.update(block);remaining-=len(block)
 assert prefix.hexdigest()==prior['output_sha256'],'This refresh requires an unchanged old prefix'
 for block in iter(lambda:f.read(1048576),b''):full.update(block)
source=(P/'audit_streaming.py').read_text();scanner=source[source.index('def tokens():'):source.index('floats={}')]
ns={'path':path,'re':re};exec(compile(scanner,'streaming_tokens','exec'),ns);it=ns['it'];take=ns['take'];until=ns['until']
variables=set();floats=[];essential=[];adj=defaultdict(set);undo=[];scopes=[];interfaces={};axioms={};pcount=0;publics=set()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
for label,position in it:
 if label=='${':scopes.append((len(floats),len(essential),len(undo)));continue
 if label=='$}':
  nf,ne,nu=scopes.pop();del floats[nf:];del essential[ne:]
  while len(undo)>nu:
   x,y=undo.pop();adj[x].remove(y);adj[y].remove(x)
  continue
 if label in ('$c','$v','$d'):
  values=list(until('$.'))
  if label=='$v':variables.update(values)
  if label=='$d':
   for x,y in itertools.combinations(values,2):
    if y in adj[x]:continue
    adj[x].add(y);adj[y].add(x)
    if scopes:undo.append((x,y))
  continue
 assert label!='$['
 kind,_=take();assert kind in ('$f','$e','$a','$p')
 if kind=='$f':floats.append(list(until('$.')));continue
 if kind=='$e':essential.append(list(until('$.')));continue
 ispublic=label.startswith('skelet17-') or '-skelet17-' in label
 if ispublic:publics.add(label)
 capture=label in targets or kind=='$a';expr=[] if capture else None
 for token in until('$.') if kind=='$a' else until('$='):
  if capture:expr.append(token)
 if capture:
  used=set(expr)&variables
  for e in essential:used.update(set(e)&variables)
  hypotheses=[('f',f) for f in floats if f[1] in used]+[('e',e) for e in essential]
  dv=sorted((x,y) for x in used for y in adj[x]&used if x<y)
  exact={'expr':expr,'hypotheses':hypotheses,'dv':dv};signature=digest(exact)
  if kind=='$a':axioms[label]=exact;assert signature==r['axiom_digests'][label],label
  else:
   interfaces[label]=signature
   if label in r['interface_digests']:assert signature==r['interface_digests'][label],label
   if label in expected:assert expr==expected[label],label
 if kind=='$p':
  pcount+=1
  for token in until('$.'):pass
assert not scopes and len(axioms)==93 and digest(axioms)==r['trusted_core_digest']
assert publics==targets and set(interfaces)==targets,(publics-targets,targets-publics)
for key,value in prior['interface_digests'].items():assert interfaces[key]==value,key
log=(P/'ladder_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
assert int(re.search(r'93 are \$a and (\d+) are \$p',log).group(1))==pcount
assert ('... '+str(path.stat().st_size)+' bytes') in log
r.update(output_bytes=path.stat().st_size,output_sha256=full.hexdigest(),output_proofs=pcount,named_interfaces=len(interfaces),interface_digests=interfaces,official_verification='passed',preceding_checkpoint_interfaces_preserved=len(prior['interface_digests']),incremental_append_after_last_simplification=True,exact_named_interfaces_preserved=True,exact_trusted_declarations_preserved=True,interface_audit_method='streaming exact mandatory hypotheses and mandatory DV pairs')
(P/'simplification_report.json').write_text(json.dumps(r,indent=2)+'\n')
print({k:r[k] for k in ('output_bytes','output_sha256','output_proofs','named_interfaces','preceding_checkpoint_interfaces_preserved')},flush=True)
print({'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},flush=True)
