"""Independent statement and ordinary-trace checks for the n=8b+2 cycle."""
from pathlib import Path
import json
import check_history_tools as ht
from check_skelet10_scope import AND,eq,lt,plus,times,num,implies,parse,EX,sparse
from check_skelet10_boundaries import boundary
from check_skelet10_spread import transform,bounded,spread
from check_skelet10_right import carry,jval,sparse_num
from check_skelet10_left import norm,raw_step
P=Path(__file__).resolve().parent;H,N,o,k=ht.H,ht.N,ht.o,ht.k;c=ht.c
two,three,four=map(num,(2,3,4));n='cycleInput';word='oneCycleWord';ba='boundaryA'
halt=['assemblyHalt'+s for s in ('Q','L','Bit','R')];ei='cycleOutputIndex';er=['cycleOutput'+s for s in ('Q','L','Bit','R')]
def wl(row):return plus(times(two,row[1]),row[2])
def bounds(row):return [lt(x,H) for x in row]
even=EX(ba,plus(n,'1'),AND([eq(n,times(two,ba)),transform(ba,wl(c)),carry(ba,c[3])]))
prem=AND([ht.total(o,N,ht.ti),ht.steps(o,N,ht.si,ht.SV),*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5)),*bounds(c),lt(k,plus(N,'1')),ht.at(o,k,c),eq(c[0],three),lt(c[2],two),sparse(n),sparse(c[3]),even,eq(n,plus(times(num(8),word),two))])
expected=implies(prem,EX(ei,plus(N,'1'),ht.bexs(er,AND([lt(k,ei),ht.at(o,ei,er),boundary(c[3],er)]))))
def main():
 data=json.loads((P/'skelet10_even_one_theorems.json').read_text());label='skelet17-ladder-skelet10-even-one-boundary-cycle'
 assert set(data)=={label};assert norm(parse(data[label]))==norm(expected);assert bounded(expected)
 count=moves=maxmoves=0
 for b in range(1024):
  if not sparse_num(b):continue
  t=10*spread(b);v=jval(b)[0];r=4*v;row=(3,8*t+5,0,r)
  assert sparse_num(8*b+2) and sparse_num(r)
  target=(3,20*spread(v),0,jval(2*v)[0]);cap=4+32*b+24+2+1+20*(2*v)+18
  for j in range(1,cap+1):
   assert row[0]!=5;row=raw_step(row)
   if row==target:break
  else:raise AssertionError((b,row,target,cap))
  assert j>0 and sparse_num(row[3]);count+=1;moves+=j;maxmoves=max(maxmoves,j)
 out={'statements_checked':1,'independent_reconstruction_matches':True,'statement_delta0':True,'original_beta_history_and_step_unchanged':True,'complete_n_equals_8b_plus_2_composition':True,'both_counter_outputs_constructed':True,'two_return_clearing_steps_included':True,'no_intermediate_outputs_assumed':True,'no_new_induction_construction':True,'finite_even_one_cycles':count,'ordinary_moves_checked':moves,'maximum_cycle_length_checked':maxmoves,'finite_tests_are_not_formal_proof':True,'global_nonhalting_assembled':False}
 (P/'skelet10_even_one_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
