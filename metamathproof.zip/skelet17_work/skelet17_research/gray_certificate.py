"""Linear-bit-size certificates for the auxiliary decoder.

Executable mathematical prototype. NOT a Metamath proof or a proof that
IDelta0 constructs these certificates. No change to the TM/history encoding.
"""
from pathlib import Path
from itertools import product
import json
from gray_transducer import transition,word,source_value

def pack(values,width):return sum(v<<(width*i) for i,v in enumerate(values))
def field(code,width,index):return (code>>(width*index))&((1<<width)-1)
def state_number(s):return s[0]+2*s[1]+4*s[2]
def state_tuple(s):return (s&1,(s>>1)&1,(s>>2)&1)

def build(w):
    # Tags: 0,1 ordinary input; 2 end-of-input; 3 inactive padding.
    tags=list(map(int,w))+[2]
    size=1
    while size<len(tags):size*=2
    tags += [3]*(size-len(tags))
    states=[(0,0,0)];flags=[];digits=[]
    for tag in tags:
        s=states[-1]
        if tag<2:ns,d=transition(s,tag)
        elif tag==2:ns,d=s,(s[2]^s[1]) if s[0] else None
        else:ns,d=s,None
        states.append(ns);flags.append(int(d is not None));digits.append(d or 0)
    levels=[flags]
    while len(levels[-1])>1:
        xs=levels[-1];levels.append([xs[i]+xs[i+1] for i in range(0,len(xs),2)])
    # At height j, a count is at most 2^j and fits j+1 bits.
    count_code=offset=0
    for j,xs in enumerate(levels):
        count_code |= pack(xs,j+1)<<offset
        offset += len(xs)*(j+1)
    out=0
    for f,d in zip(flags,digits):
        if f:out=2*out+d
    return {'size':size,'tags':pack(tags,2),'states':pack(list(map(state_number,states)),3),
            'flags':pack(flags,1),'digits':pack(digits,1),'counts':count_code,
            'count_bits':offset,'output':out}

def check(w,c):
    m=c['size'];assert m>0 and m&(m-1)==0 and len(w)+1<=m<2*(len(w)+1)
    def tag(i):return field(c['tags'],2,i)
    def state(i):return state_tuple(field(c['states'],3,i))
    def flag(i):return field(c['flags'],1,i)
    def digit(i):return field(c['digits'],1,i)
    for key,width in [('tags',2*m),('states',3*(m+1)),('flags',m),('digits',m),('counts',c['count_bits'])]:
        assert 0<=c[key]<1<<width
    assert state(0)==(0,0,0)
    for i in range(m):
        expected=int(w[i]) if i<len(w) else 2 if i==len(w) else 3
        assert tag(i)==expected
        s=state(i)
        if tag(i)<2:ns,d=transition(s,tag(i))
        elif tag(i)==2:ns,d=s,(s[2]^s[1]) if s[0] else None
        else:ns,d=s,None
        assert state(i+1)==ns and flag(i)==int(d is not None) and digit(i)==(d or 0)
    offsets=[];offset=0;j=0
    while m>>j:
        offsets.append(offset);offset+=(m>>j)*(j+1);j+=1
    def count(j,i):return field(c['counts']>>offsets[j],j+1,i)
    for i in range(m):assert count(0,i)==flag(i)
    for j in range(1,len(offsets)):
        for i in range(m>>j):assert count(j,i)==count(j-1,2*i)+count(j-1,2*i+1)
    assert offset==c['count_bits'] and offset<4*m
    total=count(len(offsets)-1,0)
    assert c['output']<1<<total
    for leaf in range(m):
        # Rank uses only O(log m) counts, not a stored output at every prefix.
        rank=0;node=leaf;nodes=[node];ranks=[rank]
        for j in range(len(offsets)-1):
            if node&1:rank+=count(j,node-1)
            node//=2;nodes.append(node);ranks.append(rank)
        # One local path witness per leaf: no global table of all ranks.
        width=m.bit_length();path=pack(nodes+ranks,width)
        assert 2*width*width<=8*m
        for j in range(width):
            ni=field(path,width,j);ri=field(path,width,width+j)
            assert ni==leaf>>j and ri<=m
            if j+1<width:
                nn=field(path,width,j+1);rn=field(path,width,width+j+1)
                assert ni//2==nn and rn==ri+(count(j,ni-1) if ni&1 else 0)
        assert field(path,width,width*2-1)==rank
        if flag(leaf):assert (c['output']>>(total-1-rank))&1==digit(leaf)
    # Combined widths for tags, states, flags, digits and counts.
    bits=2*m+3*(m+1)+m+m+offset
    assert bits<12*m+4
    x=int(w,2) if w else 0
    # Valid lower words are empty or begin with 1. Avoid logarithms here.
    assert not w or w[0]=='1'
    bound=(4*(x+1))**32
    assert (1<<bits)<bound
    assert (1<<(2*width*width))<bound
    return bits

if __name__=='__main__':
    cases=0;maxbits=0
    for size in range(1,8):
        for xs in product(range(4),repeat=size):
            w=word(xs);c=build(w);maxbits=max(maxbits,check(w,c))
            assert c['output']==source_value(xs)
            cases+=1
    example=[0,2,4,0];w=word(example);cert=build(w);check(w,cert)
    report={'status':'Prototype only. Certificate existence and verifier correctness are not Metamath-checked.',
            'cases':cases,'maximum_allocated_bits':maxbits,'combined_code_bound':'(4*(x+1))^32',
            'example':{'list_nearest_first':example,'word':w,'certificate':cert}}
    Path(__file__).with_name('gray_certificate_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print({k:v for k,v in report.items() if k!='example'})
