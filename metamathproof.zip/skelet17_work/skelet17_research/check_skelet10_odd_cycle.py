"""Independent odd-boundary statement and ordinary-cycle trace checks."""
from pathlib import Path
import json
import check_history_tools as ht
from check_skelet10_scope import AND,eq,lt,plus,times,num,implies,parse,EX,sparse
from check_skelet10_boundaries import boundary
from check_skelet10_spread import transform,bounded,spread
from check_skelet10_right import carry,jval,sparse_num
from check_skelet10_left import norm,raw_step
P=Path(__file__).resolve().parent;H,N,o,k=ht.H,ht.N,ht.o,ht.k;c=ht.c
two,three,four=map(num,(2,3,4));n='cycleInput';ba,bt,bv='boundaryA','boundaryT','boundaryV'
halt=['assemblyHalt'+s for s in ('Q','L','Bit','R')]
ei='cycleOutputIndex';er=['cycleOutput'+s for s in ('Q','L','Bit','R')]
def wl(row):return plus(times(two,row[1]),row[2])
def bounds(row):return [lt(x,H) for x in row]
odd=EX(ba,plus(n,'1'),EX(bt,plus(wl(c),'1'),EX(bv,plus(c[3],'1'),AND([eq(n,plus(times(four,ba),'1')),eq(wl(c),plus(times(four,bt),two)),transform(ba,bt),eq(c[3],times(two,bv)),carry(ba,bv)]))))
prem=AND([ht.total(o,N,ht.ti),ht.steps(o,N,ht.si,ht.SV),*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5)),*bounds(c),lt(k,plus(N,'1')),ht.at(o,k,c),eq(c[0],three),lt(c[2],two),sparse(n),sparse(c[3]),odd])
goal=EX(ei,plus(N,'1'),ht.bexs(er,AND([lt(k,ei),ht.at(o,ei,er),boundary(c[3],er)])))
expected=implies(prem,goal)
def main():
 data=json.loads((P/'skelet10_odd_cycle_theorems.json').read_text());label='skelet17-ladder-skelet10-odd-boundary-cycle'
 assert set(data)=={label};assert norm(parse(data[label]))==norm(expected);assert bounded(expected)
 count=moves=maxmoves=0
 for a in range(1024):
  if not sparse_num(a):continue
  v=jval(a)[0];encoded=10*spread(a);r=2*v;assert sparse_num(4*a+1) and sparse_num(r)
  row=(3,2*encoded+1,0,r);targetwhole=10*spread(v);targetright=jval(v)[0];cap=32*a+24+20*v+18+3
  for j in range(1,cap+1):
   assert row[0]!=5;row=raw_step(row)
   if row[0]==3 and 2*row[1]+row[2]==targetwhole and row[3]==targetright:break
  else:raise AssertionError(('no canonical output within routine bound',a,row,cap))
  assert j>0 and row[2]<2 and sparse_num(row[3]);count+=1;moves+=j;maxmoves=max(maxmoves,j)
 out={'statements_checked':1,'independent_reconstruction_matches':True,'statement_delta0':True,'original_beta_history_and_step_unchanged':True,'complete_odd_boundary_composition':True,'next_boundary_input_is_old_right_half':True,'strict_progress_at_original_index':True,'no_routine_or_alignment_outputs_assumed':True,'no_new_induction_construction':True,'finite_odd_cycles':count,'ordinary_moves_checked':moves,'maximum_cycle_length_checked':maxmoves,'finite_tests_are_not_formal_proof':True,'remaining_even_boundary_cases':2,'global_nonhalting_assembled':False}
 (P/'skelet10_odd_cycle_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
