"""Independent formula reconstruction and numerical checks of the D return."""
from pathlib import Path
import json
from check_skelet10_scope import parse,plus,times,eq,lt,implies,both,AND,num,ALL,EX,power,step
from check_skelet10_left import norm,raw_step
from check_skelet10_spread import bounded
PTH=Path(__file__).resolve().parent
TWO,THREE=map(num,(2,3))
left,value='returnLeft','returnValue';H,n,offset,P=['return'+s for s in ('H','N','Offset','InitialScale')]
def whole(c):return plus(times(TWO,c[1]),c[2])
def marker(c,s):return AND([eq(c[0],THREE),lt(c[2],TWO),power(s),eq(plus(whole(c),'1'),times(s,plus(left,'1'))),eq(times(s,c[3]),value)])
def endpoint(c):return AND([eq(c[0],THREE),eq(whole(c),left),eq(c[3],value)])
def alls(vs,upper,body):
 for v in reversed(vs):body=ALL(v,upper,body)
 return body
def exs(vs,upper,body):
 for v in reversed(vs):body=EX(v,upper,body)
 return body
def at(i,row):
 out=[];q='returnBetaQuotient'
 for j,v in enumerate(row):
  mod=plus('1',times(plus(plus(offset,i),'1'),'returnC'+str(j)))
  out.append(EX(q,H,both(eq('returnB'+str(j),plus(times(q,mod),v)),lt(v,mod))))
 return AND(out)
TV=['returnTotalRow'+s for s in ('Q','L','Bit','R')];IV=['returnInitialRow'+s for s in ('Q','L','Bit','R')]
SV=['returnStepRow'+str(j)+s for j in (0,1) for s in ('Q','L','Bit','R')]
EV=['returnAvoidRow'+s for s in ('Q','L','Bit','R')];IP=['returnIndRow'+s for s in ('Q','L','Bit','R')]
HR=['returnHalt'+s for s in ('Q','L','Bit','R')];ER=['returnExitRow'+s for s in ('Q','L','Bit','R')]
ti,si,ai,i='returnTotalIndex','returnStepIndex','returnAvoidIndex','returnIndex';scale='returnHistoryScale'
total=ALL(ti,plus(n,'1'),exs(TV,H,at(ti,TV)))
initial=alls(IV,H,implies(at('0',IV),marker(IV,P)))
steps=ALL(si,n,alls(SV,H,implies(both(at(si,SV[:4]),at(plus(si,'1'),SV[4:])),step(SV[:4],SV[4:]))))
avoid=ALL(ai,plus(n,'1'),alls(EV,H,implies(at(ai,EV),('-.',endpoint(EV)))))
def inv(index,row):return EX(scale,plus(P,'1'),both(marker(row,scale),lt(plus(index,scale),plus(P,'1'))))
invariant=ALL(i,plus(n,'1'),alls(IP,H,implies(at(i,IP),inv(i,IP))))
exit_index='returnExitIndex';exit_goal=EX(exit_index,plus(n,'1'),exs(ER,H,both(at(exit_index,ER),endpoint(ER))))
cf=['z10Current'+s for s in ('Q','L','Bit','R')];nf=['z10Next'+s for s in ('Q','L','Bit','R')];h='returnOutputScale'
expected={
 'return-marker-step':implies(AND([marker(cf,'t'),('-.',endpoint(cf)),step(cf,nf)]),EX(h,'t',marker(nf,h))),
 'return-window-invariant':implies(AND([total,initial,steps,avoid]),invariant),
 'return-window-bound':implies(AND([total,initial,steps,avoid]),lt(n,P)),
 'return-window-exit':implies(AND([total,initial,steps,lt(P,plus(n,'1'))]),exit_goal),
 'return-window-halting-barrier':implies(AND([total,initial,steps,*[lt(x,H) for x in HR],at(n,HR),eq(HR[0],num(5))]),exit_goal),
}
def main():
 actual=json.loads((PTH/'skelet10_return_theorems.json').read_text());assert len(actual)==len(expected),(len(actual),len(expected))
 for name,f in expected.items():
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(f),label
  assert bounded(f),label
 for name in ('return-window-exit','return-window-halting-barrier'):
  text=actual['skelet17-ladder-skelet10-'+name]
  for forbidden in ('returnHistoryScale','returnFreshScale','returnFreshNextScale'):
   assert forbidden not in text,(name,forbidden)
 cases=0;steps_checked=0;examples=[]
 for ell in range(12):
  for k in range(10):
   for r in range(12):
    p=2**k
    w=p*(ell+1)-1;c=(3,w//2,w%2,r);v=p*r;initial_p=p;elapsed=0;rows=[c]
    while not (2*c[1]+c[2]==ell and c[3]==v):
     assert c[0]==3 and c[2] in (0,1) and p>1
     assert 2*c[1]+c[2]+1==p*(ell+1) and p*c[3]==v
     assert elapsed+p<=initial_p
     nxt=raw_step(c);h=p//2
     assert h<p and nxt[0]==3 and 2*nxt[1]+nxt[2]+1==h*(ell+1) and h*nxt[3]==v
     c,p=nxt,h;elapsed+=1;steps_checked+=1;rows.append(c)
    assert elapsed==k and elapsed<=initial_p
    assert all(t<initial_p for t in range(elapsed))
    if ell==2 and r==3 and k in (0,1,3):examples.append({'ell':ell,'initial_scale':initial_p,'target_value':v,'steps_to_exit':elapsed,'rows':rows})
    cases+=1
 out={'statements_checked':len(expected),'independent_reconstruction_matches':True,'all_new_statements_delta0':True,
  'original_ordinary_step_and_beta_format':True,'intermediate_markers_not_supplied_in_exit_or_barrier':True,
  'return_cases_tested':cases,'ordinary_return_steps_tested':steps_checked,'finite_tests_are_not_formal_proofs':True,
  'whole_machine_nonhalting':False,'complete_counter_cycle':False,'examples':examples}
 (PTH/'skelet10_return_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
