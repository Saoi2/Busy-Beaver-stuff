Status update: this plan has now been implemented; see SKELET10_CARRY_UNIQUENESS.md and the current verification/audit outputs. The original proposal is retained below as development history.

# Proposed bounded uniqueness induction

This is an unproved development plan. Both carry inverses are now
kernel-verified. The following argument has not yet been encoded as a
Metamath proof.

A convenient target is uniqueness only on Sparse inputs:

    Sparse(x) and J(x,y) and J(x,z) imply y=z.

The machine synchronization uses precisely these inputs. It does not need
universal J totality or uniqueness of the transformed-word graph T.

## Keep one fixed output bound

Fix a free term parameter H. Define U(x,H) as

    forall y<H forall z<H,
      (Sparse(x) and J(x,y) and J(x,z)) -> y=z.

This is Delta-0. Use ordinary bounded induction on i with formula

    forall x<i+1, U(x,H).

This is a bounded strong-induction construction: at the successor stage,
the old range covers every strictly smaller input. H is a parameter held
fixed during the induction. This avoids first having to prove a separate
sharp upper bound for every smaller carry output.

For the base x=0, the even inverse with a=0 makes both outputs equal 1.
For a successor input x, divide it by 2.

- If x=2a, the even inverse gives y=z=4a+1 directly.
- If x is odd and Sparse, existing Sparse-pop and odd-tail lemmas give
  x=4a+1 and Sparse(a). Both recursive carry inverses give bounded
  v<y+1 and w<z+1 with y=4v, z=4w, J(a,v), J(a,w).

In the odd branch a<x follows from x=4a+1 with explicit gap 3a.
Since v<y+1 and y<H, the existing non-strict/strict transitivity lemma
implies v<H; similarly w<H. The induction hypothesis at a therefore
applies with the SAME H. It gives v=w and hence y=z.

After proving U(x,H) for arbitrary H, instantiate H=y+z+1. Both y<H
and z<H have explicit additive-gap proofs. This removes the auxiliary
bound parameter from the final uniqueness statement.

## Formal obligations

The proof must explicitly construct all bounded universal introductions,
use fresh binder names distinct from those bound inside the induction
hypothesis, and prove the necessary alpha-renaming implications. The
existing bounded strong-induction construction in the spread-totality
proof provides a working pattern.

When the input is split by division, transport J and Sparse only in their
input slots. When eliminating each recursive output existential, retain
the given bound v<y+1, derive v<H, instantiate the already bounded
universal induction hypothesis, and finally discharge the existential.
No complete history or extra machine annotation is supplied.

This plan would introduce one new bounded induction construction and
reuse existing bounded division. Its actual dependency count must be
computed from the completed proof; no minimality claim is made here.
The global routine synchronization and blank-start nonhalting argument
remain separate tasks after uniqueness.
