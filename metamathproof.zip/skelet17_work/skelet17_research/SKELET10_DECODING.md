# Skelet #10: decoding the counter words in I-Delta-0

This checkpoint proves that the bounded word representation can be read
backwards. All six results are in the same `idelta0_machines.mm`, with the
same 93 trusted declarations and the same machine and history encoding.
They complete another arithmetic prerequisite for the counter proof.
**Skelet #10 nonhalting is not yet proved.**

## Why the reverse direction matters

The preceding checkpoint showed how to construct a word representation:

    Dil(x,z) and d<2 imply Dil(2x+d,4z+d).

Here Dil moves an input bit at binary place p to output place p*p.
For example Dil(5,17): binary 101 becomes binary 10001. A machine carry
removes bits from a word already on its tape. Consequently the machine
proof needs the reverse direction, including a bound on the decoded tail.
It is not enough to display one possible encoding of a chosen word.

The main new theorem is:

    Dil(2x+d,z) and d<2 imply
      exists u<z+1, z=4u+d and Dil(x,u).

It concerns every pair satisfying the original relation, not a new,
annotated representation of tape words. Both the digit equation and the
smaller graph are recovered. The witness bound uses the actual output z.

For example, encode input 11=2*5+1 as 69=4*17+1. Decoding gives the tail
pair Dil(5,17). Encode input 10=2*5+0 as 68=4*17+0, and decoding gives
the same tail pair. A candidate output with a 1 in binary place 2 is
rejected by the relation, since 2 is not the square of any binary place.

## The definitions have not changed

See SKELET10_SPREAD.md for the fully expanded definitions of Pow2, One,
Dil, and T. In abbreviated mathematical notation:

    One(x,p) := exists q<x+1, exists r<p,
                  x=q*(2p)+p+r.

    Dil(x,z) :=
      [forall p<x+1,
         (Pow2(p) and One(x,p)) -> One(z,p*p)]
      and
      [forall q<z+1,
         (Pow2(q) and One(z,q)) ->
           exists p<x+1,
             Pow2(p) and q=p*p and One(x,p)].

    T(x,t) := exists z<t+1, t=10z and Dil(x,z).

All quantifiers displayed here and in the decoding theorem are bounded.
The Metamath statements expand these reading abbreviations. No relation
symbol, function symbol, defining axiom, sequence-totality principle or
machine annotation has been added.

## The six public statements

All labels start `skelet17-ladder-skelet10-`.

| Label suffix | Statement |
|---|---|
| `spread-low-digit` | Dil(2x+d,2z+e), d<2 and e<2 imply d=e. |
| `spread-second-bit-zero` | Dil(x,z) implies not One(z,2). |
| `spread-pop` | Dil(2x+d,4z+d) and d<2 imply Dil(x,z). |
| `spread-decompose` | Dil(2x+d,z) and d<2 imply there is u<z+1 with z=4u+d and Dil(x,u). |
| `transform-pop-0` | T(2x,4t) implies T(x,t). |
| `transform-pop-10` | T(4x+1,16t+10) implies T(x,t). |

Together with the earlier constructor theorems, the last two give both
directions of the two encoded grammar rules. They apply to arbitrary
inputs, so restricting them to the Sparse counter grammar is permitted
without changing their definitions.

## How the decoding proof works

First, three private arithmetic lemmas analyze squares of binary places.
A Pow2 place is either 1 or twice another Pow2 place, by the already proved
halving theorem. In the even case its square is divisible by 4. Quotient
uniqueness therefore proves that a Pow2 square is 1 only when its root is
1, that it cannot be 2, and that a square equal to 4q has a bounded half-root
whose square is q. These are proved lemmas, not additional axioms.

For the low-digit theorem, the forward graph clause sends an input bit at
place 1 to output place 1. The reverse graph clause says an output bit at
place 1 must have come from a root whose square is 1; that root is 1.
The previously proved binary low-digit lemma then identifies the two
digits. The reverse graph clause similarly excludes output place 2.

For `spread-pop`, consider an input one-bit place p in the smaller word x.
Pushing d gives a bit at 2p in 2x+d. The forward graph sends it to
(2p)*(2p)=4*p*p. Popping two output bits recovers a bit at p*p in z.
For the reverse clause, a bit at q in the smaller output gives a bit at
4q in the original output. Its graph witness has square 4q. Halving that
root gives a Pow2 place p with square q; popping the input digit recovers
the corresponding bit in x. This establishes both clauses of Dil(x,z).

For `spread-decompose`, bounded division gives:

    z=2q+e,   q=2u+f,   e<2,   f<2.

The low-digit theorem proves e=d. If f=1, the output would have a bit at
place 2, contradicting the second-bit theorem. Thus f=0, so z=4u+d.
The matched-digit pop theorem proves Dil(x,u). The two division bounds
give u<=q<=z, hence u<z+1.

Finally unfold T. Apply decoding once for a 0 prefix, twice for a 10
prefix. The factor 10 is transported using generic associative and
distributive identities. Quotient uniqueness cancels factors 4 or 16;
ordinary additive cancellation handles the offset 10. This proves the
two reverse T rules without assuming that the graph is unique.

## Induction and remaining scope

No new induction construction is used. The low-digit theorem has no
induction dependencies at all. Each of the other five public results
has one bounded-induction construction in its complete
dependency closure: the earlier bounded division proof. These are
dependency counts for these particular proofs, not claims of minimal
logical strength.

Formal graph uniqueness is still not claimed. The reverse rules and
bounded decomposition do not require it. The next mathematical task is
to connect the decoded words to entire left/right counter cycles, prove
their synchronization, and propagate a safety invariant through the raw
beta-coded histories. An arbitrary D row is still not known to be safe.

## Verification

`ladder_skelet10_inverse.py` generates the derived proofs;
`extend_skelet10_inverse.py` supports incremental development. The full
`rebuild_project.py` also includes them. `check_skelet10_inverse.py`
independently reconstructs all six expanded conclusions and checks their
bounded syntax. It additionally tests 16,384 numerical decoding cases and
128 transform examples. Those finite tests supplement, and do not replace,
verification of the Metamath proofs. `audit_ladder.py` checks the actual
conclusions, trusted core and induction dependency counts.
