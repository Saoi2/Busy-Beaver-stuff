"""Executed in the ladder builder namespace after history propagation."""
H,n=h['H'],h['n'];AV,IP=h['AV'],h['IP'];AT=h['AT'];TOTAL,STEPS,INITIAL,PHI=h['TOTAL'],h['STEPS'],h['INITIAL'],h['PHI']
blank=nd.balls(AV,H,b.Imp(AT(Z,AV),cfg(AV,(0,0,0,0))))
fresh=[m.declare('translatedInitial'+str(i),'var') for i in range(4)]
fields=[TOTAL(),STEPS(),blank,*[L(v,H) for v in NF],AT(n,NF),Q(NF[0],num(5))]
prem=nd.AND(fields);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
def initial_body(vs):return b.Imp(AT(Z,vs),INV(vs))
def establish_initial(cc):
 at=AT(Z,fresh);ac=cc.push(at)
 _,p0=nd.inst_balls(ac,AV,H,b.Imp(AT(Z,AV),cfg(AV,(0,0,0,0))),fresh)
 ac.mp(at,cfg(fresh,(0,0,0,0)),p0)
 nd.unpack(ac,[Q(v,Z) for v in fresh]);ac.both(Q(fresh[0],Z),Q(fresh[3],Z));nd.disj(ac,clauses(fresh),0)
 cc.intro(at,INV(fresh),ac);return cc.get(initial_body(fresh))
h['bforall'](ctx,fresh,H,initial_body(fresh),establish_initial)
h['rename_block'](ctx,fresh,AV,initial_body)
nd.conj(ctx,[TOTAL(),INITIAL(),STEPS()]);use(ctx,'skelet17-ladder-translated-history')
ctx.all_elim(h['IV'],PHI(h['IV']),n);m.successor(ctx,n)
ctx.mp(L(n,A(n,O)),nd.balls(IP,H,b.Imp(AT(n,IP),INV(IP))))
_,pp=nd.inst_balls(ctx,IP,H,b.Imp(AT(n,IP),INV(IP)),NF);ctx.mp(AT(n,NF),INV(NF),pp)
bad=L(Z,Z)
def exclude(ec,k):
 unpack_clause(ec,NF,k)
 return contradiction(ec,NF[0],0 if k<2 else 1,5,bad)
nd.cases(ctx,clauses(NF),bad,exclude)
ctx.put(b.Not(bad),b.ax('O1',ctx.g,t=Z))
result=b.Not(prem)
proof=b.apply('nd-not-intro',{'ga':root.g,'ph':prem,'ps':bad},[ctx.get(bad),ctx.get(b.Not(bad))])
root.put(result,proof)
m.save('skelet17-ladder-translated-no-blank-halting-history',root,result,
       'No total bounded beta-coded ordinary computation window starts blank and ends in Z=5. One bounded induction in its dependency closure. No history-totality axiom or added tape invariant.')
