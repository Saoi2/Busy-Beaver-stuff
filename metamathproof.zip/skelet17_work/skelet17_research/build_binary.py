"""Derived arithmetic for bounded packed-word certificates.

Every assertion is a Metamath $p over the original 93 trusted declarations.
These are arithmetic prerequisites, not a Skelet17 nonhalting invariant.
"""
from pathlib import Path
import sys,json
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension/proof_tools'))
import nd
b,a=nd.b,nd.a
A,M,Q,L=b.Add,b.Mul,b.Eq,b.Lt
O,Z,N=b.O,b.Z,b.NIL
two=A(O,O)
theorems={}
def declare(name,typ='var'):
    old=list(b.metas)
    b.lines.extend(['$v '+name+' $.','f-'+name+' $f '+typ+' '+name+' $.'])
    b.metas[name]=typ;b.floats[name]='f-'+name
    for other in old:
        if typ=='var' or b.metas[other]=='var':b.lines.append('$d '+name+' '+other+' $.')
    return (b.V if typ=='var' else b.T)(name)
def save(name,ctx,f,comment=''):
    b.theorem(name,f,ctx.get(f),comment);theorems[name]=f;print(name,flush=True)
def finish(name,root,prem,goal,ctx,comment=''):
    root.intro(prem,goal,ctx);save(name,root,b.Imp(prem,goal),comment)
def sub(ast,mapping):
    if ast[0] in ('var','term','wff','ctx'):return mapping.get(ast[1],ast)
    return (ast[0],*(sub(v,mapping) if isinstance(v,tuple) else v for v in ast[1:]))
def invoke(ctx,name,mapping={},mp=True):
    f=sub(theorems[name],mapping);p=ctx.theorem(f,b.apply(name,mapping))
    return ctx.mp(f[1],f[2],p) if mp else p
def eq(ctx,l,r,fs=()):
    return ctx.put(Q(l,r),a.constrained_equal(ctx.g,l,r,[(f[1],f[2],ctx.get(f)) for f in fs]))
def flip(ctx,f):
    out=Q(f[2],f[1]);ctx.put(out,a.sym(f[1],f[2],ctx.get(f),ctx.g));return out
def rewrite(ctx,body,old,new,proof=None,source=None):
    target,_=b.subst(body,a.E,new,True);before,_=b.subst(body,a.E,old,True)
    return ctx.put(target,a.replace(ctx.g,body,old,new,proof or ctx.get(Q(old,new)),source or ctx.get(before)))
def translt(ctx,l,m,r):
    ctx.both(L(l,m),L(m,r));return ctx.put(L(l,r),b.mp(ctx.g,b.And(L(l,m),L(m,r)),L(l,r),b.ax('O2',ctx.g,t=l,u=m,v=r),ctx.get(b.And(L(l,m),L(m,r)))))
def bound(ctx,l,r,gap,fs=()):
    return ctx.put(L(l,r),a.boundless_lt(ctx.g,l,r,gap,eq(ctx,r,A(A(l,gap),O),fs)))
def successor(ctx,t):return bound(ctx,t,A(t,O),Z)
def ltadd(ctx,l,r,t):
    f=L(A(l,t),A(r,t));return ctx.put(f,b.mp(ctx.g,L(l,r),f,b.ax('O5',ctx.g,t=l,u=r,v=t),ctx.get(L(l,r))))
def bex_elim(ctx,var,upper,body,fresh,goal,prove):
    full=b.And(L(var,upper),body);actual,_=b.subst(full,var,fresh,True)
    ch=ctx.push(actual);nd.unpack(ch,list(actual[1:]));ch.put(goal,prove(ch))
    return ctx.ex_elim(var,full,fresh,goal,ch)
def bex_intro(ctx,var,upper,body,val):
    inst,_=b.subst(body,var,val,True);ctx.both(L(val,upper),inst)
    return ctx.ex_intro(var,b.And(L(var,upper),body),val)
def gap_elim(ctx,l,r,fresh,goal,prove):
    v,body,p=a.lt_witness(ctx.g,l,r,ctx.get(L(l,r)))
    actual,_=b.subst(body,v,fresh,True);ch=ctx.push(actual);ch.put(goal,prove(ch,actual))
    return ctx.ex_elim(v,body,fresh,goal,ch,p)
def induction(ctx,i,phi,base,step):
    f0,s0=b.subst(phi,i,Z,True);f1,s1=b.subst(phi,i,A(i,O),True)
    assert base==f0 and step==b.All(i,b.Imp(phi,f1))
    ante=b.And(base,step);out=b.All(i,phi)
    ctx.put(b.Imp(ante,out),b.apply('ax-ind-bounded',{'ga':ctx.g,'x':i,'ph':phi,'ps':f0,'ch':f1},[nd.classify(phi),s0,s1]))
    ctx.both(base,step);return ctx.mp(ante,out)

gap=declare('binGap')
def elementary():
    x,y=b.t,b.u
    root=nd.Ctx();goal=b.Or(Q(x,Z),L(Z,x));tri=[L(x,Z),Q(x,Z),L(Z,x)]
    root.put(nd.OR(tri),b.ax('O3',N,t=x,u=Z))
    def branch(c,k):
        if k==0:
            c.put(b.Not(L(x,Z)),b.ax('O4',c.g,t=x));return c.explode(L(x,Z),goal)
        return nd.disj(c,list(goal[1:]),k-1)
    nd.cases(root,tri,goal,branch);save('skelet17-binary-zero-or-positive',root,goal)
    root=nd.Ctx();prem=L(x,y);c=root.push(prem);goal=b.Or(L(A(x,O),y),Q(A(x,O),y))
    def fromgap(ec,geq):
        invoke(ec,'skelet17-binary-zero-or-positive',{'t':gap},False)
        def branch(cc,k):
            if k==0:
                eq(cc,A(x,O),y,[geq,Q(gap,Z)]);return nd.disj(cc,list(goal[1:]),1)
            ltadd(cc,Z,gap,A(x,O));eq(cc,A(Z,A(x,O)),A(x,O))
            rewrite(cc,L(a.E,A(gap,A(x,O))),A(Z,A(x,O)),A(x,O))
            eq(cc,A(gap,A(x,O)),y,[geq]);rewrite(cc,L(A(x,O),a.E),A(gap,A(x,O)),y)
            return nd.disj(cc,list(goal[1:]),0)
        return nd.cases(ec,[Q(gap,Z),L(Z,gap)],goal,branch)
    gap_elim(c,x,y,gap,goal,fromgap);finish('skelet17-binary-successor-cases',root,prem,goal,c)
    root=nd.Ctx();prem=L(x,A(y,O));c=root.push(prem);goal=b.Or(L(x,y),Q(x,y))
    def fromgap(ec,geq):
        eq(ec,A(y,O),A(A(x,gap),O),[geq])
        imp=b.Imp(Q(A(y,O),A(A(x,gap),O)),Q(y,A(x,gap)))
        ec.theorem(imp,b.apply('add-cancel',{'t':y,'u':A(x,gap),'v':O}));ec.mp(imp[1],imp[2])
        invoke(ec,'skelet17-binary-zero-or-positive',{'t':gap},False)
        def branch(cc,k):
            if k==0:
                eq(cc,x,y,[Q(y,A(x,gap)),Q(gap,Z)]);return nd.disj(cc,list(goal[1:]),1)
            ltadd(cc,Z,gap,x);eq(cc,A(Z,x),x);rewrite(cc,L(a.E,A(gap,x)),A(Z,x),x)
            eq(cc,A(gap,x),y,[Q(y,A(x,gap))]);rewrite(cc,L(x,a.E),A(gap,x),y)
            return nd.disj(cc,list(goal[1:]),0)
        return nd.cases(ec,[Q(gap,Z),L(Z,gap)],goal,branch)
    gap_elim(c,x,A(y,O),gap,goal,fromgap);finish('skelet17-binary-below-successor',root,prem,goal,c)
elementary()

i=declare('binIndex');q=declare('binQuotient');r=declare('binRemainder')
fq=declare('binFreshQuotient');fr=declare('binFreshRemainder')
def division_formula(x,m):return nd.BEX(q,A(x,O),nd.BEX(r,m,Q(x,A(M(m,q),r))))
def division():
    m=b.u;prem=L(Z,m);root=nd.Ctx();c=root.push(prem)
    phi=division_formula(i,m);base=division_formula(Z,m)
    successor(c,Z);eq(c,Z,A(M(m,Z),Z));bex_intro(c,r,m,Q(Z,A(M(m,Z),r)),Z)
    bex_intro(c,q,A(Z,O),nd.BEX(r,m,Q(Z,A(M(m,q),r))),Z)
    sc=c.push(phi);out=division_formula(A(i,O),m)
    def haveq(qc):
        def haver(rc):
            equation=Q(i,A(M(m,fq),fr));invoke(rc,'skelet17-binary-successor-cases',{'t':fr,'u':m})
            opts=[L(A(fr,O),m),Q(A(fr,O),m)]
            def branch(ec,k):
                if k==0:
                    successor(ec,A(i,O));translt(ec,fq,A(i,O),A(A(i,O),O))
                    eq(ec,A(i,O),A(M(m,fq),A(fr,O)),[equation])
                    bex_intro(ec,r,m,Q(A(i,O),A(M(m,fq),r)),A(fr,O))
                    return bex_intro(ec,q,A(A(i,O),O),nd.BEX(r,m,Q(A(i,O),A(M(m,q),r))),fq)
                ltadd(ec,fq,A(i,O),O);rev=flip(ec,opts[1])
                eq(ec,A(i,O),A(M(m,A(fq,O)),Z),[equation,rev])
                bex_intro(ec,r,m,Q(A(i,O),A(M(m,A(fq,O)),r)),Z)
                return bex_intro(ec,q,A(A(i,O),O),nd.BEX(r,m,Q(A(i,O),A(M(m,q),r))),A(fq,O))
            return nd.cases(rc,opts,out,branch)
        return bex_elim(qc,r,m,Q(i,A(M(m,fq),r)),fr,out,haver)
    bex_elim(sc,q,A(i,O),nd.BEX(r,m,Q(i,A(M(m,q),r))),fq,out,haveq)
    c.intro(phi,out,sc);step=b.All(i,b.Imp(phi,out));c.all_intro(i,b.Imp(phi,out))
    induction(c,i,phi,base,step);c.all_elim(i,phi,b.t)
    finish('skelet17-bounded-division-exists',root,prem,division_formula(b.t,m),c,
           'One bounded induction: quotient <= dividend and remainder < positive divisor. No exponentiation.')
division()

def arithmetic_support():
    x,y,z=b.t,b.u,b.v
    root=nd.Ctx();prem=b.And(L(x,A(y,O)),L(y,z));c=root.push(prem);nd.unpack(c,list(prem[1:]));goal=L(x,z)
    invoke(c,'skelet17-binary-below-successor',{'t':x,'u':y})
    def branch(ec,k):
        if k==0:return translt(ec,x,y,z)
        return rewrite(ec,L(a.E,z),y,x,a.sym(x,y,ec.get(Q(x,y)),ec.g))
    nd.cases(c,[L(x,y),Q(x,y)],goal,branch);finish('skelet17-binary-le-lt-trans',root,prem,goal,c)
    root=nd.Ctx();prem=L(x,two);c=root.push(prem);goal=b.Or(Q(x,Z),Q(x,O))
    invoke(c,'skelet17-binary-below-successor',{'t':x,'u':O})
    def branch(ec,k):
        if k==1:return nd.disj(ec,list(goal[1:]),1)
        eq(ec,O,A(Z,O));rewrite(ec,L(x,a.E),O,A(Z,O))
        invoke(ec,'skelet17-binary-below-successor',{'t':x,'u':Z})
        def small(cc,j):
            if j==1:return nd.disj(cc,list(goal[1:]),0)
            cc.put(b.Not(L(x,Z)),b.ax('O4',cc.g,t=x));return cc.explode(L(x,Z),goal)
        return nd.cases(ec,[L(x,Z),Q(x,Z)],goal,small)
    nd.cases(c,[L(x,O),Q(x,O)],goal,branch);finish('skelet17-binary-digit-cases',root,prem,goal,c)
    root=nd.Ctx();prem=L(Z,y);c=root.push(prem);goal=L(x,A(M(y,x),O))
    gap_elim(c,Z,y,gap,goal,lambda ec,geq:bound(ec,x,A(M(y,x),O),M(gap,x),[geq]))
    finish('skelet17-binary-factor-bound',root,prem,goal,c)
    root=nd.Ctx();prem=L(Z,x);c=root.push(prem);goal=L(x,M(two,x))
    ltadd(c,Z,x,x);eq(c,A(Z,x),x);rewrite(c,L(a.E,A(x,x)),A(Z,x),x)
    eq(c,A(x,x),M(two,x));rewrite(c,L(x,a.E),A(x,x),M(two,x))
    finish('skelet17-binary-double-larger',root,prem,goal,c)
arithmetic_support()

digit=declare('binDigit');fd=declare('binFreshDigit');fh=declare('binFreshHalfQuotient')
def fields(x,p,base):return nd.BEX(q,A(x,O),nd.BEX(digit,base,nd.BEX(r,p,Q(x,A(A(M(M(base,p),q),M(p,digit)),r)))))
def digits(x,p):return fields(x,p,two)
def field_exists():
    x,p,base=b.t,b.u,b.v;prem=b.And(L(Z,p),L(Z,base));root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));goal=fields(x,p,base)
    invoke(c,'skelet17-bounded-division-exists',{'t':x,'u':p})
    def outerq(qc):
        def outerr(rc):
            first=Q(x,A(M(p,fq),fr));invoke(rc,'skelet17-bounded-division-exists',{'t':fq,'u':base})
            def innerq(hc):
                def innerr(dc):
                    second=Q(fq,A(M(base,fh),fd));dc.both(L(fh,A(fq,O)),L(fq,A(x,O)))
                    invoke(dc,'skelet17-binary-le-lt-trans',{'t':fh,'u':fq,'v':A(x,O)})
                    eq(dc,x,A(A(M(M(base,p),fh),M(p,fd)),fr),[first,second])
                    bex_intro(dc,r,p,Q(x,A(A(M(M(base,p),fh),M(p,fd)),r)),fr)
                    bex_intro(dc,digit,base,nd.BEX(r,p,Q(x,A(A(M(M(base,p),fh),M(p,digit)),r))),fd)
                    return bex_intro(dc,q,A(x,O),nd.BEX(digit,base,nd.BEX(r,p,Q(x,A(A(M(M(base,p),q),M(p,digit)),r)))),fh)
                return bex_elim(hc,r,base,Q(fq,A(M(base,fh),r)),fd,goal,innerr)
            return bex_elim(rc,q,A(fq,O),nd.BEX(r,base,Q(fq,A(M(base,q),r))),fh,goal,innerq)
        return bex_elim(qc,r,p,Q(x,A(M(p,fq),r)),fr,goal,outerr)
    bex_elim(c,q,A(x,O),nd.BEX(r,p,Q(x,A(M(p,q),r))),fq,goal,outerq)
    finish('skelet17-bounded-field-exists',root,prem,goal,c,
           'A packed field at any positive scale and positive base exists. Division is reused twice; no additional induction schema.')
field_exists()
def digit_exists():
    x,p=b.t,b.u;prem=L(Z,p);root=nd.Ctx();c=root.push(prem);goal=digits(x,p)
    bound(c,Z,two,O);c.both(L(Z,p),L(Z,two))
    invoke(c,'skelet17-bounded-field-exists',{'t':x,'u':p,'v':two})
    finish('skelet17-bounded-digit-exists',root,prem,goal,c)
digit_exists()

def quotient_unique(ctx,mod,qa,ra,qb,rb):
    lhs=A(M(mod,qa),ra);rhs=A(M(mod,qb),rb)
    prem=b.And(Q(lhs,rhs),b.And(L(ra,mod),L(rb,mod)));nd.conj(ctx,[Q(lhs,rhs),L(ra,mod),L(rb,mod)])
    goal=b.And(Q(qa,qb),Q(ra,rb));imp=b.Imp(prem,goal)
    ctx.theorem(imp,b.apply('division-unique',{'t':mod,'u':qa,'v':qb,'w':ra,'r':rb}))
    ctx.mp(prem,goal);nd.unpack(ctx,list(goal[1:]));return ctx.get(goal)
def false_zero_one(ctx,goal):
    bound(ctx,Z,O,Z);rewrite(ctx,L(Z,a.E),O,Z,a.sym(Z,O,ctx.get(Q(Z,O)),ctx.g))
    ctx.put(b.Not(L(Z,Z)),b.ax('O1',ctx.g,t=Z));return ctx.explode(L(Z,Z),goal)
def positive_factor():
    x,y=b.t,b.u;prem=L(Z,M(x,y));root=nd.Ctx();c=root.push(prem);goal=L(Z,x)
    invoke(c,'skelet17-binary-zero-or-positive',{'t':x},False)
    def branch(ec,k):
        if k==1:return ec.get(goal)
        eq(ec,M(x,y),Z,[Q(x,Z)]);rewrite(ec,L(Z,a.E),M(x,y),Z)
        ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z));return ec.explode(L(Z,Z),goal)
    nd.cases(c,[Q(x,Z),goal],goal,branch);finish('skelet17-binary-positive-factor',root,prem,goal,c)
positive_factor()

pd=declare('grayDivisor');pe=declare('grayQuotient');pz=declare('grayHalf')
df=declare('grayFreshDivisor');ef=declare('grayFreshQuotient')
dh=declare('grayDivisorHalf');db=declare('grayDivisorBit')
eh=declare('grayQuotientHalf');eb=declare('grayQuotientBit')
def divides(d,p):return nd.BEX(pe,A(p,O),Q(M(d,pe),p))
def even(d):return nd.BEX(pz,A(d,O),Q(d,M(two,pz)))
def power_body(p,d):return b.Imp(divides(d,p),b.Or(Q(d,O),even(d)))
def power2(p):return b.And(L(Z,p),nd.BALL(pd,A(p,O),power_body(p,pd)))
def rename_all(ctx,source,target,bodyfn):
    old=b.All(source,bodyfn(source));new=b.All(target,bodyfn(target))
    root=nd.Ctx();c=root.push(old);c.all_elim(source,bodyfn(source),target);c.all_intro(target,bodyfn(target));root.intro(old,new,c)
    ctx.theorem(b.Imp(old,new),root.get(b.Imp(old,new)));return ctx.mp(old,new)
def use_power(ctx,p,d):
    nd.unpack(ctx,list(power2(p)[1:]));ctx.all_elim(pd,b.Imp(L(pd,A(p,O)),power_body(p,pd)),d)
    ctx.mp(L(d,A(p,O)),power_body(p,d));return ctx.mp(divides(d,p),b.Or(Q(d,O),even(d)))
def even_intro(ctx,d,halfval):return bex_intro(ctx,pz,A(d,O),Q(d,M(two,pz)),halfval)
def power_one():
    root=nd.Ctx();goal=power2(O);bound(root,Z,O,Z)
    guard=L(df,A(O,O));c=root.push(guard);dc=c.push(divides(df,O));out=b.Or(Q(df,O),even(df))
    def havee(ec):
        invoke(ec,'skelet17-binary-digit-cases',{'t':df})
        def branch(cc,k):
            if k==1:return nd.disj(cc,list(out[1:]),0)
            eq(cc,Z,O,[flip(cc,Q(M(df,ef),O)),Q(df,Z)]);return false_zero_one(cc,out)
        return nd.cases(ec,[Q(df,Z),Q(df,O)],out,branch)
    bex_elim(dc,pe,A(O,O),Q(M(df,pe),O),ef,out,havee)
    c.intro(divides(df,O),out,dc);root.intro(guard,power_body(O,df),c);root.all_intro(df,b.Imp(guard,power_body(O,df)))
    rename_all(root,df,pd,lambda d:b.Imp(L(d,A(O,O)),power_body(O,d)))
    root.both(*goal[1:]);save('skelet17-binary-power-one',root,goal)
power_one()

def power_double():
    p=b.t;prem=power2(p);root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));twop=M(two,p);goal=power2(twop)
    invoke(c,'skelet17-binary-double-larger',{'t':p});translt(c,Z,p,twop)
    guard=L(df,A(twop,O));gc=c.push(guard);dc=gc.push(divides(df,twop));out=b.Or(Q(df,O),even(df))
    def havee(ec):
        product=flip(ec,Q(M(df,ef),twop));bound(ec,Z,two,O)
        invoke(ec,'skelet17-bounded-division-exists',{'t':df,'u':two})
        def havedh(hc):
            def havedb(bc):
                dform=Q(df,A(M(two,dh),db));invoke(bc,'skelet17-binary-digit-cases',{'t':db})
                def dcase(cc,k):
                    if k==0:
                        eq(cc,df,M(two,dh),[dform,Q(db,Z)]);even_intro(cc,df,dh);return nd.disj(cc,list(out[1:]),1)
                    dodd=Q(df,A(M(two,dh),O));eq(cc,*dodd[1:],[dform,Q(db,O)])
                    invoke(cc,'skelet17-bounded-division-exists',{'t':ef,'u':two})
                    def haveeh(h2):
                        def haveeb(b2):
                            eform=Q(ef,A(M(two,eh),eb));invoke(b2,'skelet17-binary-digit-cases',{'t':eb})
                            def ecase(c2,j):
                                if j==1:
                                    oddq=A(A(M(two,M(dh,eh)),dh),eh)
                                    eq(c2,A(M(two,p),Z),A(M(two,oddq),O),[product,dodd,eform,Q(eb,O)])
                                    bound(c2,O,two,Z);quotient_unique(c2,two,p,Z,oddq,O);return false_zero_one(c2,out)
                                eq(c2,A(M(two,p),Z),A(M(two,M(df,eh)),Z),[product,eform,Q(eb,Z)])
                                quotient_unique(c2,two,p,Z,M(df,eh),Z);peq=Q(p,M(df,eh))
                                rewrite(c2,L(Z,a.E),p,M(df,eh));invoke(c2,'skelet17-binary-positive-factor',{'t':df,'u':eh})
                                eq(c2,M(df,eh),M(eh,df));rewrite(c2,L(Z,a.E),M(df,eh),M(eh,df))
                                invoke(c2,'skelet17-binary-positive-factor',{'t':eh,'u':df})
                                invoke(c2,'skelet17-binary-factor-bound',{'t':eh,'u':df})
                                eq(c2,A(M(df,eh),O),A(p,O),[peq]);rewrite(c2,L(eh,a.E),A(M(df,eh),O),A(p,O))
                                eq(c2,M(df,eh),p,[peq]);bex_intro(c2,pe,A(p,O),Q(M(df,pe),p),eh)
                                invoke(c2,'skelet17-binary-factor-bound',{'t':df,'u':eh})
                                eq(c2,A(M(eh,df),O),A(p,O),[peq]);rewrite(c2,L(df,a.E),A(M(eh,df),O),A(p,O))
                                return use_power(c2,p,df)
                            return nd.cases(b2,[Q(eb,Z),Q(eb,O)],out,ecase)
                        return bex_elim(h2,r,two,Q(ef,A(M(two,eh),r)),eb,out,haveeb)
                    return bex_elim(cc,q,A(ef,O),nd.BEX(r,two,Q(ef,A(M(two,q),r))),eh,out,haveeh)
                return nd.cases(bc,[Q(db,Z),Q(db,O)],out,dcase)
            return bex_elim(hc,r,two,Q(df,A(M(two,dh),r)),db,out,havedb)
        return bex_elim(ec,q,A(df,O),nd.BEX(r,two,Q(df,A(M(two,q),r))),dh,out,havedh)
    bex_elim(dc,pe,A(twop,O),Q(M(df,pe),twop),ef,out,havee)
    gc.intro(divides(df,twop),out,dc);c.intro(guard,power_body(twop,df),gc);c.all_intro(df,b.Imp(guard,power_body(twop,df)))
    rename_all(c,df,pd,lambda d:b.Imp(L(d,A(twop,O)),power_body(twop,d)))
    c.both(*goal[1:]);finish('skelet17-binary-power-double',root,prem,goal,c,
        'The bounded divisor-based power-of-two predicate is closed under doubling. Parity uses bounded division.')
power_double()

place=declare('binPlace');placefresh=declare('binFreshPlace')
def leading_exists(x):return nd.BEX(place,A(x,O),b.And(power2(place),L(x,M(two,place))))
def leading_phi(x):return b.Or(Q(x,Z),leading_exists(x))
def leading_power():
    root=nd.Ctx();phi=leading_phi(i);base=leading_phi(Z)
    root.put(Q(Z,Z),b.refl(N,Z));nd.disj(root,list(base[1:]),0)
    sc=root.push(phi);out=leading_phi(A(i,O))
    def witness(ctx,p):
        ctx.both(power2(p),L(A(i,O),M(two,p)))
        bex_intro(ctx,place,A(A(i,O),O),b.And(power2(place),L(A(i,O),M(two,place))),p)
        return nd.disj(ctx,list(out[1:]),1)
    def branch(c,k):
        if k==0:
            invoke(c,'skelet17-binary-power-one',{},False)
            bound(c,O,A(A(i,O),O),Z,[Q(i,Z)]);bound(c,A(i,O),M(two,O),Z,[Q(i,Z)])
            return witness(c,O)
        def haveplace(ec):
            nd.unpack(ec,[power2(placefresh),L(i,M(two,placefresh))])
            invoke(ec,'skelet17-binary-successor-cases',{'t':i,'u':M(two,placefresh)})
            opts=[L(A(i,O),M(two,placefresh)),Q(A(i,O),M(two,placefresh))]
            def choose(cc,j):
                if j==0:
                    successor(cc,A(i,O));translt(cc,placefresh,A(i,O),A(A(i,O),O));return witness(cc,placefresh)
                doubled=M(two,placefresh);invoke(cc,'skelet17-binary-power-double',{'t':placefresh})
                nd.unpack(cc,list(power2(doubled)[1:]));invoke(cc,'skelet17-binary-double-larger',{'t':doubled})
                successor(cc,A(i,O));rewrite(cc,L(a.E,A(A(i,O),O)),A(i,O),doubled)
                flip(cc,opts[1]);rewrite(cc,L(a.E,M(two,doubled)),doubled,A(i,O))
                return witness(cc,doubled)
            return nd.cases(ec,opts,out,choose)
        return bex_elim(c,place,A(i,O),b.And(power2(place),L(i,M(two,place))),placefresh,out,haveplace)
    nd.cases(sc,[Q(i,Z),leading_exists(i)],out,branch)
    root.intro(phi,out,sc);step=b.All(i,b.Imp(phi,out));root.all_intro(i,b.Imp(phi,out))
    induction(root,i,phi,base,step);root.all_elim(i,phi,b.t)
    save('skelet17-bounded-leading-power-or-zero',root,leading_phi(b.t),
         'A bounded binary place value exists below every positive input. One additional bounded induction; no total exponential function.')
    x=b.t;prem=L(Z,x);rroot=nd.Ctx();c=rroot.push(prem);goal=leading_exists(x)
    invoke(c,'skelet17-bounded-leading-power-or-zero',{},False)
    def nonzero(ec,k):
        if k==1:return ec.get(goal)
        rewrite(ec,L(Z,a.E),x,Z);ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z));return ec.explode(L(Z,Z),goal)
    nd.cases(c,[Q(x,Z),goal],goal,nonzero);finish('skelet17-bounded-leading-power',rroot,prem,goal,c)
leading_power()

fgap=declare('fieldFreshGap')
def field_range():
    val,rem,scale,base=b.t,b.u,b.v,b.w
    prem=b.And(L(val,base),L(rem,scale));goal=L(A(M(scale,val),rem),M(scale,base))
    root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]))
    def first(ec,baseeq):
        def second(cc,scaleeq):
            return bound(cc,A(M(scale,val),rem),M(scale,base),A(fgap,M(scale,gap)),[baseeq,scaleeq])
        return gap_elim(ec,rem,scale,fgap,goal,second)
    gap_elim(c,val,base,gap,goal,first)
    finish('skelet17-binary-field-range',root,prem,goal,c)
field_range()

qa,va,ra,qb,vb,rb=[declare('field'+n,'term') for n in ('QA','VA','RA','QB','VB','RB')]
def whole(scale,base,q,val,rem):return A(A(M(M(base,scale),q),M(scale,val)),rem)
def equal_via(ctx,l,r,known):
    lp=a.constrained_equal(ctx.g,l,known[1],[]);rp=a.constrained_equal(ctx.g,known[2],r,[])
    p=a.trans(known[1],known[2],r,ctx.get(known),rp,ctx.g)
    return ctx.put(Q(l,r),a.trans(l,known[1],r,lp,p,ctx.g))
def field_unique():
    scale,base=b.t,b.u;mod=M(base,scale)
    equation=Q(whole(scale,base,qa,va,ra),whole(scale,base,qb,vb,rb))
    fs=[L(va,base),L(ra,scale),L(vb,base),L(rb,scale),equation]
    prem=nd.AND(fs);goal=nd.AND([Q(qa,qb),Q(va,vb),Q(ra,rb)])
    root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
    for val,rem in [(va,ra),(vb,rb)]:
        c.both(L(val,base),L(rem,scale))
        invoke(c,'skelet17-binary-field-range',{'t':val,'u':rem,'v':scale,'w':base})
        eq(c,M(scale,base),mod);rewrite(c,L(A(M(scale,val),rem),a.E),M(scale,base),mod)
    equal_via(c,A(M(mod,qa),A(M(scale,va),ra)),A(M(mod,qb),A(M(scale,vb),rb)),equation)
    quotient_unique(c,mod,qa,A(M(scale,va),ra),qb,A(M(scale,vb),rb))
    quotient_unique(c,scale,va,ra,vb,rb)
    nd.conj(c,[Q(qa,qb),Q(va,vb),Q(ra,rb)])
    finish('skelet17-bounded-field-unique',root,prem,goal,c,
           'Any two representations of one packed field agree in quotient, field value and lower remainder. No induction.')
field_unique()

def bit0(x,p):return nd.BEX(q,A(x,O),nd.BEX(r,p,Q(x,A(M(q,M(two,p)),r))))
def bit1(x,p):return nd.BEX(q,A(x,O),nd.BEX(r,p,Q(x,A(A(M(q,M(two,p)),p),r))))
def bit_dichotomy():
    x,p=b.t,b.u;prem=L(Z,p);root=nd.Ctx();c=root.push(prem);goal=b.Or(bit0(x,p),bit1(x,p))
    invoke(c,'skelet17-bounded-digit-exists',{'t':x,'u':p})
    def haveq(qc):
        def haved(dc):
            def haver(rc):
                equation=Q(x,whole(p,two,fq,fd,fr))
                invoke(rc,'skelet17-binary-digit-cases',{'t':fd})
                def branch(ec,k):
                    if k==0:
                        eq(ec,x,A(M(fq,M(two,p)),fr),[equation,Q(fd,Z)])
                        bex_intro(ec,r,p,Q(x,A(M(fq,M(two,p)),r)),fr)
                        bex_intro(ec,q,A(x,O),nd.BEX(r,p,Q(x,A(M(q,M(two,p)),r))),fq)
                    else:
                        eq(ec,x,A(A(M(fq,M(two,p)),p),fr),[equation,Q(fd,O)])
                        bex_intro(ec,r,p,Q(x,A(A(M(fq,M(two,p)),p),r)),fr)
                        bex_intro(ec,q,A(x,O),nd.BEX(r,p,Q(x,A(A(M(q,M(two,p)),p),r))),fq)
                    return nd.disj(ec,list(goal[1:]),k)
                return nd.cases(rc,[Q(fd,Z),Q(fd,O)],goal,branch)
            return bex_elim(dc,r,p,Q(x,whole(p,two,fq,fd,r)),fr,goal,haver)
        return bex_elim(qc,digit,two,nd.BEX(r,p,Q(x,whole(p,two,fq,digit,r))),fd,goal,haved)
    bex_elim(c,q,A(x,O),nd.BEX(digit,two,nd.BEX(r,p,Q(x,whole(p,two,q,digit,r)))),fq,goal,haveq)
    finish('skelet17-binary-bit-dichotomy',root,prem,goal,c,
           'At every positive place value exactly one bit value is available; this theorem supplies the disjunction. Exclusivity is separate.')
bit_dichotomy()

de1=declare('powerDivisorWitness');de2=declare('powerMultipleWitness')
pd2=declare('powerNestedDivisor');dh2=declare('powerHalfWitness')
def factors(ctx,left,right,n,equation):
    """Derived positive factor bounds, all within the current proof context."""
    rev=flip(ctx,equation);rewrite(ctx,L(Z,a.E),n,M(left,right))
    invoke(ctx,'skelet17-binary-positive-factor',{'t':left,'u':right})
    eq(ctx,M(left,right),M(right,left));rewrite(ctx,L(Z,a.E),M(left,right),M(right,left))
    invoke(ctx,'skelet17-binary-positive-factor',{'t':right,'u':left})
    for x,y in [(left,right),(right,left)]:
        invoke(ctx,'skelet17-binary-factor-bound',{'t':x,'u':y})
        eq(ctx,A(M(y,x),O),A(n,O),[rev]);rewrite(ctx,L(x,a.E),A(M(y,x),O),A(n,O))
def divisor_transitive():
    d,p,n=b.t,b.u,b.v
    fs=[L(Z,n),divides(d,p),divides(p,n)];prem=nd.AND(fs);goal=divides(d,n)
    root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
    def first(ec):
        def second(cc):
            equation=Q(M(d,M(de1,de2)),n)
            eq(cc,*equation[1:],[flip(cc,Q(M(p,de2),n)),flip(cc,Q(M(d,de1),p))])
            factors(cc,d,M(de1,de2),n,equation)
            return bex_intro(cc,pe,A(n,O),Q(M(d,pe),n),M(de1,de2))
        return bex_elim(ec,pe,A(n,O),Q(M(p,pe),n),de2,goal,second)
    bex_elim(c,pe,A(p,O),Q(M(d,pe),p),de1,goal,first)
    finish('skelet17-binary-divisibility-transitive',root,prem,goal,c)
divisor_transitive()

def power_divisor():
    p,h=b.t,b.u;prem=b.And(power2(p),divides(h,p));goal=power2(h)
    root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));nd.unpack(c,list(power2(p)[1:]))
    def havew(ec):
        factors(ec,h,de1,p,Q(M(h,de1),p))
        guard=L(pd2,A(h,O));gc=ec.push(guard);dc=gc.push(divides(pd2,h));out=b.Or(Q(pd2,O),even(pd2))
        nd.conj(dc,[L(Z,p),divides(pd2,h),divides(h,p)])
        invoke(dc,'skelet17-binary-divisibility-transitive',{'t':pd2,'u':h,'v':p})
        dc.both(L(pd2,A(h,O)),L(h,A(p,O)))
        invoke(dc,'skelet17-binary-le-lt-trans',{'t':pd2,'u':h,'v':A(p,O)})
        use_power(dc,p,pd2)
        gc.intro(divides(pd2,h),out,dc);ec.intro(guard,power_body(h,pd2),gc)
        ec.all_intro(pd2,b.Imp(guard,power_body(h,pd2)))
        rename_all(ec,pd2,pd,lambda d:b.Imp(L(d,A(h,O)),power_body(h,d)))
        return ec.both(*goal[1:])
    bex_elim(c,pe,A(p,O),Q(M(h,pe),p),de1,goal,havew)
    finish('skelet17-binary-power-divisor',root,prem,goal,c,
           'Every positive divisor of a Pow2 number is Pow2. No induction.')
power_divisor()

def power_halving():
    p=b.t;half_exists=nd.BEX(pz,A(p,O),b.And(Q(p,M(two,pz)),power2(pz)))
    prem=power2(p);goal=b.Or(Q(p,O),half_exists);root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]))
    ltadd(c,Z,p,O);eq(c,A(Z,O),O);rewrite(c,L(a.E,A(p,O)),A(Z,O),O)
    eq(c,M(p,O),p);bex_intro(c,pe,A(p,O),Q(M(p,pe),p),O);successor(c,p)
    use_power(c,p,p)
    def branch(ec,k):
        if k==0:return nd.disj(ec,list(goal[1:]),0)
        def haveh(cc):
            relation=Q(p,M(two,dh2));prod=Q(M(dh2,two),p);eq(cc,*prod[1:],[relation])
            factors(cc,dh2,two,p,prod);bex_intro(cc,pe,A(p,O),Q(M(dh2,pe),p),two)
            cc.both(power2(p),divides(dh2,p));invoke(cc,'skelet17-binary-power-divisor',{'t':p,'u':dh2})
            cc.both(relation,power2(dh2))
            bex_intro(cc,pz,A(p,O),b.And(Q(p,M(two,pz)),power2(pz)),dh2)
            return nd.disj(cc,list(goal[1:]),1)
        return bex_elim(ec,pz,A(p,O),Q(p,M(two,pz)),dh2,goal,haveh)
    nd.cases(c,[Q(p,O),even(p)],goal,branch)
    finish('skelet17-binary-power-halving',root,prem,goal,c,
           'Pow2(p) implies p=1 or a bounded Pow2 half. No induction.')
power_halving()

oq=declare('bitOneFreshQuotient');orr=declare('bitOneFreshRemainder')
def bit_exclusive():
    x,p=b.t,b.u;prem=bit0(x,p);root=nd.Ctx();c=root.push(prem);oc=c.push(bit1(x,p));bad=L(Z,Z)
    def zeroq(qc):
        def zeror(rc):
            def oneq(hc):
                def oner(dc):
                    e0=Q(x,A(M(fq,M(two,p)),fr));e1=Q(x,A(A(M(oq,M(two,p)),p),orr))
                    zwhole=whole(p,two,fq,Z,fr);owhole=whole(p,two,oq,O,orr)
                    eq(dc,x,zwhole,[e0]);eq(dc,x,owhole,[e1])
                    dc.put(Q(zwhole,owhole),a.trans(zwhole,x,owhole,a.sym(x,zwhole,dc.get(Q(x,zwhole)),dc.g),dc.get(Q(x,owhole)),dc.g))
                    bound(dc,Z,two,O);bound(dc,O,two,Z)
                    fs=[L(Z,two),L(fr,p),L(O,two),L(orr,p),Q(zwhole,owhole)];nd.conj(dc,fs)
                    invoke(dc,'skelet17-bounded-field-unique',{'t':p,'u':two,'fieldQA':fq,'fieldVA':Z,'fieldRA':fr,'fieldQB':oq,'fieldVB':O,'fieldRB':orr})
                    nd.unpack(dc,[Q(fq,oq),Q(Z,O),Q(fr,orr)])
                    return false_zero_one(dc,bad)
                return bex_elim(hc,r,p,Q(x,A(A(M(oq,M(two,p)),p),r)),orr,bad,oner)
            return bex_elim(rc,q,A(x,O),nd.BEX(r,p,Q(x,A(A(M(q,M(two,p)),p),r))),oq,bad,oneq)
        return bex_elim(qc,r,p,Q(x,A(M(fq,M(two,p)),r)),fr,bad,zeror)
    bex_elim(oc,q,A(x,O),nd.BEX(r,p,Q(x,A(M(q,M(two,p)),r))),fq,bad,zeroq)
    oc.put(b.Not(bad),b.ax('O1',oc.g,t=Z))
    goal=b.Not(bit1(x,p));c.put(goal,a.not_intro(c.g,bit1(x,p),bad,oc.get(bad),oc.get(b.Not(bad))))
    finish('skelet17-binary-bit-exclusive',root,prem,goal,c,
           'The bounded Zero and One predicates are disjoint at every place value. No induction.')
bit_exclusive()

sp=declare('fieldShiftScale','term');sb=declare('fieldShiftBase','term')
def field_shift():
    x,y,low,radix=b.t,b.u,b.v,b.w
    old=whole(sp,sb,qa,va,ra);scale=M(radix,sp);rem=A(M(radix,ra),low)
    new=whole(scale,sb,qa,va,rem)
    fs=[Q(x,A(M(radix,y),low)),L(low,radix),Q(y,old),L(ra,sp)]
    prem=nd.AND(fs);goal=b.And(Q(x,new),L(rem,scale));root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
    eq(c,x,new,[fs[0],fs[2]])
    c.both(L(ra,sp),L(low,radix));invoke(c,'skelet17-binary-field-range',{'t':ra,'u':low,'v':radix,'w':sp})
    c.both(*goal[1:]);finish('skelet17-binary-field-shift',root,prem,goal,c,
           'Appending one radix digit shifts every old field by the radix and gives an explicitly bounded new lower remainder. No induction.')
field_shift()

def write():
    (P/'binary_raw.mm').write_text('\n'.join(b.lines)+'\n')
    (P/'binary_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in theorems.items()},indent=2)+'\n')
if __name__=='__main__':write()
