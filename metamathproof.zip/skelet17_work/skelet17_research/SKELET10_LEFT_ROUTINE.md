# Complete left-counter contract for Skelet #10

Machine: `1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB`.
All active formal proofs are in `idelta0_machines.mm`. This document
explains the six `skelet17-ladder-skelet10-left-...` interfaces. The
separate Python generators produce ordinary Metamath deductions over the
same 93 trusted declarations; they are not trusted proof oracles.

## What the routine promises

A configuration is `(q,L,b,R)`, with A=0, B=1, C=2, D=3, E=4, halt=5.
The bit under the head is `b`; the nearest bits of each half-tape are the
least significant bits of `L` and `R`. Thus `2L+b` is the whole left word,
and `2R+b` is the whole right word. These are the original definitions.

The earlier bounded graph `T(x,t)` encodes a Sparse binary word `x` as a
left-tape word `t`. Informally, T is ten times the map that moves binary
bit place `2^i` to `4^i`. The actual definition uses only bounded
quantifiers and multiplication, not exponentiation. `Sparse(x)` says that
no adjacent binary places are both 1. These informal descriptions do not
replace the explicit formulas used in the proof.

Fix arbitrary input `w` and right tail `r`. The entry conditions are

- state D, and `b<2`;
- `Sparse(w)` and `T(w,2L+b)`;
- `R=4r+3`.

The correct output is a row satisfying

- state A and `2R+b=r`;
- some `V<3w+2` satisfies `J(w,V)`, `T(V,L)` and `Sparse(V)`.

Here the existing bounded carry graph is

`J(w,V)` iff there exist `p<3w+2`, `s<w+1`, `a<w+1` such that
`Pow2(p)`, `p=3s+1`, `w=p(2a)+s` and `V=p(4a+1)`.

Thus the left routine implements the same counter relation as the
already verified right routine. The output graph is not assumed total or
unique. The routine proof derives an output witness from the supplied
ordinary computation history.

## Proof organization

Set `S=3w+2`, `K=8S`. A bounded rank certificate is a disjunction:

1. a D/C/E/B carry-scan certificate;
2. a bounded output `V<S` satisfying `J(w,V)`, together with an instance
   of the already proved A clearing-return certificate.

The common scan data are bounded `p<S`, `s<w+1`, `u<w+1` with
`Pow2(p)`, `p=3s+1`, `w=pu+s`, and `Sparse(u)`. At a D search row,
`T(u,2L+b)`, `R+1=4p²(r+1)`, and rank is `K+8u+8`.
The remaining seven scan phases factor out these same common facts,
avoiding duplicated full invariants.

Put `F=p²(r+1)`. In the following table `t` satisfies `T(a,t)` and
`Sparse(a)`. Rank is `K+8u` plus the last column.

| Phase | State/read | Left half L | R+1 | Restriction | Offset |
|---|---|---|---|---|---:|
| Search | D / any bit<2 | specified by T(u,2L+b) | 4F | none | 8 |
| Exit 1 | C / 0 | t | 8F | u=2a | 7 |
| Exit 2 | E / 1 | 2t+1 | 4F | u=2a | 6 |
| Exit 3 | B / 1 | 4t+2 | 2F | u=2a | 5 |
| Exit 4 | A / 1 | 8t+5 | F | u=2a | 4 |
| Carry 1 | C / 1 | 4t+2 | 8F | u=4a+1 | 7 |
| Carry 2 | D / 0 | 2t+1 | 16F | u=4a+1 | 6 |
| Carry 3 | C / 1 | t | 32F | u=4a+1 | 5 |

At Search, bounded division and the Sparse low-bit lemma distinguish
`u=2a` from `u=4a+1`. The stronger T decomposition theorems recover a
bounded encoded tail `t` without assuming a tape block shape.
Quotient uniqueness identifies the scanned bit and left half. Each next
phase follows from the unchanged ordinary instruction relation.

The exit path reaches the main clearing phase with current scale `p`,
local word `4a+1` and output `V=p(4a+1)`. The original common equations
supply the three witnesses for `J(w,V)`. Elementary arithmetic gives
`V<=3w+1`, so `V<S`. The reused clearing contract then shifts this word
into its final encoded position and restores the right tail.

The carry path returns to Search with
`p'=4p`, `s'=4s+1`, `u'=a`. Its rank decreases because `a<4a+1=u`.
The common equations and bounds are preserved. Squared scale factors are
kept factored in the formal arithmetic, avoiding large repeated expansions.

Every phase has positive rank and a nonhalting state. Every ordinary
step before correct output has another bounded certificate of strictly
smaller rank. The initial rank is `K+8w+8=32w+24`. This intentionally loose
polynomial bound is enough; no logarithms, exponentiation, or optimal
running-time calculation is required.

## The six formal interfaces

| Suffix after `skelet17-ladder-skelet10-` | Conclusion |
|---|---|
| `left-counter-entry` | Entry implies a rank certificate at rank 32w+24. |
| `left-counter-step` | A certified row, not yet at output, and an ordinary Step imply a certified next row at some smaller rank. |
| `left-window-invariant` | In a target-avoiding raw history, every row has a bounded certificate, with elapsed index plus rank at most 32w+24. |
| `left-window-bound` | Such a target-avoiding history has final index n<32w+24. |
| `left-window-exit` | Any supplied history of at least 32w+24 steps from entry visits a correct output. |
| `left-window-halting-barrier` | Any supplied history from entry ending at halt already visited a correct output. |

The supplied history uses the same four quotient-and-remainder beta codes
as earlier proofs. Its premises require bounded rows at all indices,
the entry at index zero, and the ordinary machine instruction relation
between adjacent rows. No phase, carry witness, transformed intermediate
word, or rank is supplied as computation data.

One new bounded induction constructs the rank certificate along a
hypothetical output-avoiding history. Every quantified variable is bounded
by a term, including the four row coordinates and the certificate
witnesses. The induction formula is therefore Delta-0. The local proof
reuses earlier bounded division; the four history interfaces have two
induction dependencies in total. These are dependency counts for these
particular proofs, not lower bounds on proof strength.

Negating the bounded correct-output search gives the avoidance premise.
The rank bound contradicts a sufficiently long history. For a history
ending at halt, the constructed final certificate instead contradicts its
nonhalting state. This gives the barrier even when that history is short.
The final exit and barrier formulas contain no intermediate certificate.

## Concrete examples

With right tail r=0, the ordinary routine runs include:

| Input w | Encoded entry whole-left word | Carry output V | Final A left half | Steps |
|---:|---:|---:|---:|---:|
| 0 | 0 | 1 | 10 | 5 |
| 1 | 10 | 4 | 160 | 13 |
| 5 | 170 | 16 | 2560 | 21 |

Each entry has R=3. Each displayed output has b=0 and R=0, hence
whole right word 0. For example the w=1 run removes one transformed
carry block, performs the base exit and clears the pending return bits.
These examples illustrate the theorem; its parameters are arbitrary.

## Verification and remaining task

`check_skelet10_full_left.py` independently reconstructs all six formulas,
checks their Delta-0 syntax and compares them to the exported statements.
It also runs the separate finite phase experiment: 220 inputs/tails and
2,156 ordinary transitions. Finite testing is supplementary; the official
Metamath verifier checks the universal formal deductions.

The complete left and right routines are now available separately. The
remaining task is to prove the synchronization relation at their boundaries,
bound its auxiliary witnesses inside an arbitrary supplied raw history,
and lift the global invariant to blank-start nonhalting. The halting
barrier for one routine does not itself prove whole-machine nonhalting.
