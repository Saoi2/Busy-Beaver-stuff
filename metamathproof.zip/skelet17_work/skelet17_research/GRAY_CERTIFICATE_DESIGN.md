# A bounded-certificate design for the Gray decoder

Status: mathematical construction and executable prototype. This is not a new
Metamath theorem. Existence of these witnesses in every model of IDelta0 has
not been established. The checked machine proofs remain unchanged.

## The specific coding problem

The auxiliary decoder consumes a lower-list word

    (10)^a_l 1 (10)^a_(l-1) ... 1 (10)^a_0

from the outer end toward the head. It emits the inverse-Gray digits for
`a_l,...,a_1`; the final run `a_0` is omitted. Its eight control states consist
of three bits: a pending 1, the current run parity, and the cumulative XOR.
An end-of-input action is essential when the last 1 is a separator before
an empty final run.

Bounding the decoded integer by the tape integer is not enough. A naive
certificate records the growing output integer after every input character.
For input length ell, this can require quadratically many bits. Such a code
can be superpolynomial in the numeric input x. We must bound the whole
certificate, not just its final output.

## A certificate with linearly many bits

Append one explicit end marker. Let m be the least power of two at least
ell+1, so ell+1 <= m < 2(ell+1). Pad the remaining leaves with inactive
symbols. This changes only the auxiliary certificate, not the machine tape
or its halting definition.

Use these fields:

| Field | Allocated bits |
| --- | --- |
| Input tags: 0, 1, end marker, inactive padding | 2m |
| The eight-state control at all m+1 boundaries | 3(m+1) |
| One emission flag per leaf | m |
| One emitted digit per leaf, zero if inactive | m |
| Balanced tree of emission counts | Less than 4m |

At height j, each node covers 2^j leaves. Its count is at most 2^j and
fits j+1 bits. There are m/2^j nodes at that height. If m=2^k, the total
count allocation is

    sum(j=0..k) (m/2^j)(j+1) = 4m-k-3 < 4m.

Thus all the main fields can be concatenated into fewer than 12m+4 bits.
The prototype stores the individual fields rather than their redundant
concatenation; the allocation proves the same bound for a concatenated code.

The control checks are local: each boundary state and input tag determine
one next state, whether a bit is emitted, and its value. At a count-tree leaf,
the count equals the emission flag. At an internal node, its count is the
sum of its two child counts.

## Relating emitted positions to the compressed output

The final output integer n is stored separately. We must check that its bits
are exactly the digits at the emitting input positions, in order.

For each emitting leaf, compute its rank by ascending the tree. Start with
rank 0. Whenever the node is a right child, add the count of its left sibling.
At the root, the sum is the number of emitting leaves strictly before the
chosen leaf. If the total emitted count is e and the rank is r, the emitted
digit must equal output bit e-1-r. Also require n < 2^e.

Crucially, do not store the rank at every input position. A separate local
witness can be used under a bounded universal quantifier for each leaf.
One ascent uses k+1 node indices and k+1 partial sums, each at most m, hence
at most k+1 bits each. A path certificate needs

    2(k+1)^2 <= 8m bits.

The inequality follows from (k+1)^2 <= 4*2^k, proved by ordinary induction
(with the first small cases handled directly). The executable verifier
packs and checks such a local path for every leaf.

The offset of the packed count level need not be stored as a whole table.
Writing v=m/2^j, its offset o satisfies

    o + 2(j+2)v = 4m.

The count of node i at level j begins at bit o+(j+1)i. These are polynomial
arithmetic relations once the relevant powers/bit positions are available.

## Explicit polynomial bounds

A nonempty lower-list word begins with 1. If its numeric value is x and
its bit length is ell, then x >= 2^(ell-1). The empty word has x=0.
Consequently the single bound

    K(x) = (4(x+1))^32

exceeds the main concatenated certificate and every individual local rank
certificate. Indeed the main allocation is less than 24ell+28 bits, and
a local rank path uses fewer than 16(ell+1) bits. For ell>0,
K(x) >= 2^(32ell+32), which dominates both allocations. The empty word
satisfies the bound directly. The decoded output fits the same bound.

The exponent 32 is a fixed numeral: K is an ordinary polynomial term, not
an invocation of total exponentiation in the object theory. The numerical
exponentials used in this paragraph are part of the ordinary metatheoretic
size argument. Formalizing that argument in IDelta0 remains necessary.

## Ordinary finite correctness argument

For each finite valid input word, its deterministic control sequence and
emission digits are constructed by processing the word. Construct the count
tree from the leaf flags upward. Induction on tree height proves that each
count is the number of emitting leaves in its subtree. Induction along a
leaf's ancestor chain then proves that the rank sum counts precisely the
emissions preceding that leaf.

Form n by concatenating the emitted digits. The rank equations hold by
construction. Conversely, the local control checks fix every emission,
the tree equations fix the counts, and the path equations fix the ranks.
The output-bit checks, together with n<2^e, therefore fix the compressed
output uniquely. The earlier run-parity/XOR argument identifies this output
with the source Gray-counter value.

This is a finite mathematical argument and a certificate architecture.
It is not a proof that the object theory can perform every construction.

## What still prevents a kernel-checked existence theorem

The present Metamath arithmetic library has no developed bit/power or packed
sequence infrastructure. To turn this design into the desired theorem, we
still need:

1. Explicit bounded formulas for partial powers, bit positions and packed
   fields, with their arithmetic properties proved from the existing axioms.
2. A bounded arithmetic definition of the certificate verifier, including
   the local path witnesses for ranks.
3. Existence proofs for the control annotations, the packed count tree, the
   rank paths and the output word, with all witnesses below K(x).
4. A proof that the verified decoder computes the source Gray counter.
5. The separate higher-level invariant excluding B111 across all phases.

In particular, calling the decoder finite-state does not discharge items
1-4. Nor does proving a polynomial size bound alone establish witness
existence in nonstandard models. No Exp, comprehension or finite-state
recursion axiom has been added to Metamath.

## Executable checks

Run `python3 skelet17_research/gray_certificate.py` from the archive root.
It constructs and checks certificates for all 21,844 lists of lengths 1
through 7 with each exponent 0 through 3, including empty runs. The verifier
checks local transitions, count-tree equations, packed rank paths, output
bits and the polynomial bounds. It compares the output with the original
recursive definition. These are regression tests, not a formal proof.

## An explicit Delta0 input predicate, with checked syntax

Some input parsing can be stated without an exponentiation symbol. Abbreviate
bounded formulas (all inequalities shown below are strict bounds):

    Div(d,p) := exists e<p+1 (d*e=p)
    Even(d)  := exists z<d+1 (d=2z)
    Pow2(p)  := 0<p and
                  forall d<p+1 (Div(d,p) -> (d=1 or Even(d)))
    One(x,p) := exists q<x+1 exists r<p
                  (x=q*(2p)+p+r)
    LowerWord(x) := forall p<x+1
      ((Pow2(p) and 2p<x+1) -> (One(x,p) or One(x,2p))).

In standard natural numbers Pow2 characterizes the positive powers of two,
and One extracts a bit by its place value p. LowerWord says that there are
no adjacent zeros within the significant binary word; it also accepts the
empty word x=0. These are exactly the words generated by concatenating 10
pairs and single-1 separators, with the last run allowed to be empty.

The generator `build_gray_syntax.py` expands these definitions into the
original first-order language and generates a Metamath syntactic
boundedness certificate. `gray_syntax_checked.mm` passes the official
verifier. Its named conclusion is `bnd LowerWord(t)`, NOT a logical assertion
`|- LowerWord(t)` and NOT a theorem of decoder existence. The semantic
characterizations just described have not been proved in that file. The
formula is provided in expanded notation in `gray_word_formula.txt`.

To regenerate and check this separate syntax file:

    python3 skelet17_research/build_gray_syntax.py
    python3 skelet17_research/prune.py gray_syntax_raw.mm gray_syntax_checked.mm
    metamath 'read "skelet17_research/gray_syntax_checked.mm"' 'verify proof *' exit

## Subsequent checked control-only construction

See CONTROL_ANNOTATIONS.md and annotations_checked.mm. IDelta0 now proves
existence of control annotations in an alternative layout: a control
digit at base-8 weight p^3 for each input-bit weight p. The bound is
S<8*(x+1)^3. This covers only significant input bits, not the explicit
EOF/padding slots of the prototype above. The table is totalized at invalid
parser transitions, and formal LowerWord correspondence remains pending.
This establishes one witness-existence component in a revised layout; it
does not establish the count tree, rank paths, compressed output or
whole decoder certificate. The earlier general size analysis remains a
metatheoretic design, not a kernel-checked construction of all its fields.
