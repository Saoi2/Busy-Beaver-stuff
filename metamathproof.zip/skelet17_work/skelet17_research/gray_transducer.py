"""Experimental auxiliary decoder, NOT a Metamath theorem.

Read a lower-list word from its outer end toward the head. A word is
(10)^a_l 1 (10)^a_(l-1) ... 1 (10)^a_0. Emit the inverse-Gray binary
digits for a_l,...,a_1; the final run a_0 is deliberately omitted.
The machine encoding itself is unchanged.
"""
from itertools import product
from pathlib import Path
import json

def transition(state,bit):
    pending,parity,xor=state
    if not pending:
        if bit==0:raise ValueError('0 cannot start a pair or separator')
        return (1,parity,xor),None
    if bit==0:return (0,parity^1,xor),None  # completed 10 pair
    xor^=parity
    return (1,0,xor),xor  # previous 1 was separator; new 1 is pending

def decode(word):
    state=(0,0,0);out=[]
    for bit in map(int,word):
        state,emitted=transition(state,bit)
        if emitted is not None:out.append(emitted)
    pending,parity,xor=state
    if pending:
        # The final 1 is a separator preceding the empty a_0 run.
        out.append(xor^parity)
    # If there is no pending 1, the current run is a_0; do not emit it.
    n=0
    for bit in out:n=2*n+bit
    return n,out

def source_value(exponents):
    xor=n=0
    for a in reversed(exponents[1:]):xor^=a%2;n=2*n+xor
    return n

def word(exponents):return '1'.join('10'*a for a in reversed(exponents))

if __name__=='__main__':
    checks=0;max_ratio=0
    for size in range(1,8):
        for xs in product(range(4),repeat=size):
            w=word(xs);n,bits=decode(w)
            assert n==source_value(xs),(xs,w,n,source_value(xs))
            assert len(bits)==size-1
            x=int(w,2) if w else 0
            assert n<=2*x+1
            checks+=1
    table=[]
    for state in product(range(2),repeat=3):
        for bit in range(2):
            try:out,emitted=transition(state,bit)
            except ValueError:out,emitted=None,None
            table.append({'state':state,'input':bit,'next':out,'output':emitted})
    result={'status':'Experimental; no I-Delta-0 proof of decoder existence or correctness yet.',
            'exhaustive_list_cases':checks,'list_lengths':[1,7],'exponent_values':[0,3],
            'checked_bound':'decoded n <= 2*tape_word+1','state_count':8,'table':table}
    Path(__file__).with_name('gray_transducer_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k!='table'})
