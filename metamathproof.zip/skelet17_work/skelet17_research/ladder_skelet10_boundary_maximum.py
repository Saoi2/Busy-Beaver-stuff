"""One explicit bounded-induction instance: greatest boundary index."""
def add_skelet10_boundary_maximum(m,api,h,assembly,bd,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,Q,L=m.A,m.Q,m.L;Z,O=m.Z,m.O
 H,N,o=[h[x] for x in ('H','n','offset')];AT=h['AT'];apply=assembly['apply']
 inp=m.declare('maximumBoundaryInput')
 row=[m.declare('maximumBoundaryRow'+s) for s in ('Q','L','Bit','R')]
 iv,mv,jv,u,v,t=[m.declare('maximumBoundary'+s) for s in ('Index','Greatest','Scan','Witness','OldGreatest','Induction')]
 jf=m.declare('maximumBoundaryFreshScan')
 def P(i):return nd.BEX(inp,H,nd.bexs(row,H,b.And(AT(o,i,row),bd['boundary'](inp,row))))
 def nonempty(top):return nd.BEX(iv,A(top,O),P(iv))
 def body(top,w):return b.And(P(w),nd.BALL(jv,A(top,O),b.Imp(P(jv),L(jv,A(w,O)))))
 def maximum(top):return nd.BEX(mv,A(top,O),body(top,mv))
 def phi(top):return b.Imp(nonempty(top),maximum(top))
 def rename_scan():
  top,w=b.t,b.u;source=nd.BALL(jf,A(top,O),b.Imp(P(jf),L(jf,A(w,O))))
  target=nd.BALL(jv,A(top,O),b.Imp(P(jv),L(jv,A(w,O))))
  root=nd.Ctx();c=root.push(source);c.all_elim(jf,source[2],jv);c.all_intro(jv,target[2])
  m.finish('z10-maximum-scan-alpha',root,source,target,c,'Rename the bounded maximum scan binder from an empty-context deduction. Pure first-order logic; no induction.')
 def rename(c,top,w):return m.invoke(c,'z10-maximum-scan-alpha',{'t':top,'u':w})
 def trivial_top(c,top):
  # If the top index itself satisfies P, it is already a greatest witness.
  m.successor(c,top);guard=L(jf,A(top,O));dc=c.push(guard);ec=dc.push(P(jf))
  ec.get(guard);dc.intro(P(jf),guard,ec);c.intro(guard,b.Imp(P(jf),guard),dc)
  c.all_intro(jf,b.Imp(guard,b.Imp(P(jf),guard)));rename(c,top,top);c.both(P(top),body(top,top)[2])
  return m.bex_intro(c,mv,A(top,O),body(top,mv),top)
 def prove():
  root=nd.Ctx()
  # Base. Every natural index below 1 is 0.
  bc=root.push(nonempty(Z));basegoal=maximum(Z)
  def base_witness(dc):
   apply(dc,'skelet17-binary-below-successor',{'t':u,'u':Z})
   def small(ec,j):
    if not j:
     ec.put(b.Not(L(u,Z)),b.ax('O4',ec.g,t=u));return ec.explode(L(u,Z),basegoal)
    m.rewrite(ec,P(ar.E),u,Z);return trivial_top(ec,Z)
   return nd.cases(dc,[L(u,Z),Q(u,Z)],basegoal,small)
  m.bex_elim(bc,iv,A(Z,O),P(iv),u,basegoal,base_witness)
  root.intro(nonempty(Z),basegoal,bc)
  # Successor. Either the newly added top point satisfies P, or the old
  # nonempty set has the same greatest point as before.
  sc=root.push(phi(t));top=A(t,O);newgoal=maximum(top);nc=sc.push(nonempty(top))
  nc.put(b.Or(P(top),b.Not(P(top))),b.apply('nd-excluded-middle',{'ga':nc.g,'ph':P(top)}))
  def top_case(dc,j):
   if not j:return trivial_top(dc,top)
   oldnon=nonempty(t)
   def lower_witness(ec):
    apply(ec,'skelet17-binary-below-successor',{'t':u,'u':top})
    def lower(fc,k):
     if not k:return m.bex_intro(fc,iv,A(t,O),P(iv),u)
     m.rewrite(fc,P(ar.E),u,top);return fc.explode(P(top),oldnon)
    return nd.cases(ec,[L(u,top),Q(u,top)],oldnon,lower)
   m.bex_elim(dc,iv,A(top,O),P(iv),u,oldnon,lower_witness);dc.mp(oldnon,maximum(t))
   def old_maximum(ec):
    nd.unpack(ec,[P(v),body(t,v)[2]]);m.successor(ec,top);m.translt(ec,v,top,A(top,O))
    guard=L(jf,A(top,O));fc=ec.push(guard);gc=fc.push(P(jf));want=L(jf,A(v,O))
    apply(gc,'skelet17-binary-below-successor',{'t':jf,'u':top})
    def scan(hc,k):
     if not k:
      hc.all_elim(jv,body(t,v)[2][2],jf);hc.mp(L(jf,A(t,O)),b.Imp(P(jf),want));return hc.mp(P(jf),want)
     m.rewrite(hc,P(ar.E),jf,top);return hc.explode(P(top),want)
    nd.cases(gc,[L(jf,top),Q(jf,top)],want,scan)
    fc.intro(P(jf),want,gc);ec.intro(guard,b.Imp(P(jf),want),fc)
    ec.all_intro(jf,b.Imp(guard,b.Imp(P(jf),want)));rename(ec,top,v);ec.both(P(v),body(top,v)[2])
    return m.bex_intro(ec,mv,A(top,O),body(top,mv),v)
   return m.bex_elim(dc,mv,A(t,O),body(t,mv),v,newgoal,old_maximum)
  nd.cases(nc,[P(top),b.Not(P(top))],newgoal,top_case)
  sc.intro(nonempty(top),newgoal,nc);root.intro(phi(t),phi(top),sc)
  root.all_intro(t,b.Imp(phi(t),phi(top)))
  m.induction(root,t,phi(t),phi(Z),b.All(t,b.Imp(phi(t),phi(top))))
  root.all_elim(t,phi(t),N)
  m.save('skelet17-ladder-skelet10-boundary-index-maximum',root,phi(N),'Greatest index for the bounded boundary predicate. Exactly one explicit Delta-0 induction construction; no machine-step, history-totality, coding-totality, or maximum axiom is assumed.')
 if proofs:rename_scan();prove()
 return {'P':P,'nonempty':nonempty,'maximum':maximum,'body':body,'index':iv,'greatest':mv,'scan':jv,'input':inp,'row':row,'induction_variable':t,'phi':phi}
