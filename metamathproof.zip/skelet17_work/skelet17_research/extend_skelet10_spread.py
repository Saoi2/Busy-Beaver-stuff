from pathlib import Path
import json,os
import resume_canonical as r
from ladder_skelet10_spread import add_skelet10_spread
m=r.m;P=Path(__file__).resolve().parent
if 'skelet17-ladder-skelet10-spread-zero' in m.theorems:raise SystemExit('Input already contains this extension.')
m.nd.OUTPUT_PREFIX='ladder-z10-spread-';m.a.OUTPUT_PREFIX='ladder-z10-spread-'
old=set(m.theorems)
add_skelet10_spread(m,stage=os.environ.get('SPREAD_STAGE','all'))
with (P/'skelet10_spread_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'skelet10_spread_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Spread extension generated.',flush=True)
