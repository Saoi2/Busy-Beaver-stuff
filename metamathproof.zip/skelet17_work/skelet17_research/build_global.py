"""Unrestricted blank-history reduction to B111. No added induction."""
import build_terminal as t
h,m,nd,b,a=t.h,t.m,t.nd,t.b,t.a
A,M,Q,L,N,O,Z,H,n=h.A,h.M,h.Q,h.L,h.N,h.O,h.Z,h.H,h.n
pred=m.declare('s17pred','var');pf=m.declare('s17predFresh','var')
pp=[m.declare('s17pre'+str(k),'var') for k in range(3)]
J=m.declare('s17badTime','var')
shortrows=[[m.declare('s17short'+str(k)+s,'var') for s in ('q','l','b','r')] for k in range(2)]
def succ3(x):return A(A(A(x,O),O),O)
def save(name,ctx,f):
    b.theorem(name,f,ctx.get(f));m.theorems[name]=f;print(name,flush=True)
def invoke(ctx,name,mapping={}):
    def sub(x):
        if x[0] in ('term','var','wff','ctx'):return mapping.get(x[1],x)
        return (x[0],*(sub(v) if isinstance(v,tuple) else v for v in x[1:]))
    f=sub(m.theorems[name]);return f,ctx.theorem(f,b.apply(name,mapping))

def predecessor():
    x=b.t;ex=b.Ex(pred,Q(x,A(pred,O)));goal=b.Or(Q(x,Z),ex)
    root=nd.Ctx();tri=[L(x,Z),Q(x,Z),L(Z,x)]
    root.put(nd.OR(tri),b.ax('O3',root.g,t=x,u=Z))
    def branch(c,k):
        if k==0:return a.contradiction(c.g,L(x,Z),goal,c.get(L(x,Z)),b.ax('O4',c.g,t=x))
        if k==1:return nd.disj(c,[Q(x,Z),ex],0)
        v,body,p=a.lt_witness(c.g,Z,x,c.get(L(Z,x)))
        actual,_=b.subst(body,v,pf,True);ec=c.push(actual)
        eq=a.constrained_equal(ec.g,x,A(pf,O),[(x,actual[2],ec.get(actual))])
        ec.put(Q(x,A(pf,O)),eq);ec.ex_intro(pred,Q(x,A(pred,O)),pf)
        nd.disj(ec,[Q(x,Z),ex],1)
        return c.ex_elim(v,body,pf,goal,ec,p)
    nd.cases(root,tri,goal,branch);save('skelet17-zero-or-successor',root,goal)
predecessor()

def split():
    x=b.t;options=[Q(x,a.num(k)) for k in range(3)]+[nd.BEX(J,A(x,O),Q(x,succ3(J)))]
    goal=nd.OR(options);root=nd.Ctx()
    def descend(c,depth,current,chain):
        f,p=invoke(c,'skelet17-zero-or-successor',{'t':current})
        def branch(ec,k):
            if k==0:
                fs=chain+[Q(current,Z)]
                ec.put(options[depth],a.constrained_equal(ec.g,x,a.num(depth),m.constraints(ec,fs)))
                return nd.disj(ec,options,depth)
            fresh=pp[depth];body=Q(current,A(pred,O));actual,_=b.subst(body,pred,fresh,True)
            sc=ec.push(actual);newchain=chain+[actual]
            if depth<2:descend(sc,depth+1,fresh,newchain)
            else:
                eq=a.constrained_equal(sc.g,x,succ3(fresh),m.constraints(sc,newchain));sc.put(Q(x,succ3(fresh)),eq)
                upper=A(x,O);rhs=A(A(fresh,a.num(3)),O)
                e=a.constrained_equal(sc.g,upper,rhs,m.constraints(sc,newchain))
                sc.put(L(fresh,upper),a.boundless_lt(sc.g,fresh,upper,a.num(3),e))
                sc.both(L(fresh,upper),Q(x,succ3(fresh)));sc.ex_intro(J,b.And(L(J,upper),Q(x,succ3(J))),fresh)
                nd.disj(sc,options,3)
            return ec.ex_elim(pred,body,fresh,goal,sc)
        return nd.cases(c,list(f[1:]),goal,branch)
    descend(root,0,x,[]);save('skelet17-time-split',root,goal)
split()

def BLANK():return nd.balls(h.AV,H,b.Imp(h.AT(Z,h.AV),nd.AND([Q(v,Z) for v in h.AV])))
def BAD(i):
    # terminalIndex is a term parameter: replace structurally, not as an object variable.
    def replace(x):return i if x==t.j else (x[0],*(replace(v) if isinstance(v,tuple) else v for v in x[1:]))
    return nd.bexs(t.bind,H,replace(t.bad_body(t.bind)))

def full():
    last=t.last;fields=[h.TOTAL(),t.PLAIN_STEPS(),BLANK(),*[L(v,H) for v in last],h.AT(n,last),Q(last[0],a.num(5))]
    prem=nd.AND(fields);goal=nd.BEX(J,A(n,O),BAD(J));root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
    f,p=invoke(ctx,'skelet17-time-split',{'t':n})
    options=[Q(n,a.num(k)) for k in range(3)]+[nd.BEX(J,A(n,O),Q(n,succ3(J)))]
    def branch(c,k):
        if k==3:
            fresh=m.declare('s17globalTime','var')
            body=b.And(L(J,A(n,O)),Q(n,succ3(J)));actual,_=b.subst(body,J,fresh,True)
            ec=c.push(actual);nd.unpack(ec,list(actual[1:]))
            fs=[h.TOTAL(),t.PLAIN_STEPS(),Q(n,succ3(fresh)),*[L(v,H) for v in last],h.AT(n,last),Q(last[0],a.num(5))]
            nd.conj(ec,fs);m.use(ec,'skelet17-history-terminal-danger',{t.j[1]:fresh})
            ec.both(L(fresh,A(n,O)),BAD(fresh));ec.ex_intro(J,b.And(L(J,A(n,O)),BAD(J)),fresh)
            return c.ex_elim(J,body,fresh,goal,ec)
        # Short history: use the final tuple directly at time k.
        c.put(h.AT(a.num(k),last),a.replace(c.g,h.AT(a.E,last),n,a.num(k),c.get(Q(n,a.num(k))),c.get(h.AT(n,last))))
        def init(ec,row):
            _,p=nd.inst_balls(ec,h.AV,H,b.Imp(h.AT(Z,h.AV),nd.AND([Q(v,Z) for v in h.AV])),row)
            ec.mp(h.AT(Z,row),nd.AND([Q(v,Z) for v in row]),p);nd.unpack(ec,[Q(v,Z) for v in row])
        def move(ec,i,src,dst):
            s=a.num(i);_,p=ec.all_elim(b.V('si'),t.PLAIN_STEPS()[2],s)
            inner,_=b.subst(t.PLAIN_STEPS()[2][2],b.V('si'),s,True)
            eq=a.constrained_equal(ec.g,n,A(A(s,a.num(k-i-1)),O),[(n,a.num(k),ec.get(Q(n,a.num(k))))])
            ec.put(L(s,n),a.boundless_lt(ec.g,s,n,a.num(k-i-1),eq));ec.mp(L(s,n),inner,p)
            # (1+1) is our numeral 2; 0+1 requires equality transport.
            nxt=A(s,O)
            ec.put(h.AT(nxt,dst),a.replace(ec.g,h.AT(a.E,dst),a.num(i+1),nxt,a.equal(a.num(i+1),nxt),ec.get(h.AT(a.num(i+1),dst))) if ec.g==N else a.replace(ec.g,h.AT(a.E,dst),a.num(i+1),nxt,ec.theorem(Q(a.num(i+1),nxt),a.equal(a.num(i+1),nxt)),ec.get(h.AT(a.num(i+1),dst))))
            stepbody=b.Imp(b.And(h.AT(s,h.SV[:4]),h.AT(nxt,h.SV[4:])),m.STEP(h.SV[:4],h.SV[4:]))
            _,p=nd.inst_balls(ec,h.SV,H,stepbody,src+dst);ec.both(h.AT(s,src),h.AT(nxt,dst));ec.mp(b.And(h.AT(s,src),h.AT(nxt,dst)),m.STEP(src,dst),p)
        def finish_short(ec):
            cs=[*shortrows[:k],last];init(ec,cs[0])
            for i in range(k):
                move(ec,i,cs[i],cs[i+1]);m.selected(ec,cs[i],cs[i+1],0 if i==0 else 2)
                if i==0 and k==2:
                    m.bit_bound(ec,cs[1][2]);ec.theorem(L(Z,a.num(2)),m.const_lt(0,2))
                    left=A(M(a.num(2),cs[1][3]),cs[1][2]);right=A(M(a.num(2),Z),Z)
                    eq=a.constrained_equal(ec.g,left,right,[(left,cs[0][3],a.sym(cs[0][3],left,ec.get(Q(cs[0][3],left)),ec.g)),(cs[0][3],Z,ec.get(Q(cs[0][3],Z)))])
                    m.quotient_unique(ec,cs[1][3],cs[1][2],Z,Z,eq)
            return m.contradiction(ec,last[0],k,5,goal)
        def take(ec,i):
            if i==k:return finish_short(ec)
            s=a.num(i);upper=A(n,O);eq=a.constrained_equal(ec.g,upper,A(A(s,a.num(k-i)),O),[(n,a.num(k),ec.get(Q(n,a.num(k))))])
            ec.put(L(s,upper),a.boundless_lt(ec.g,s,upper,a.num(k-i),eq))
            _,p=ec.all_elim(b.V('ti'),h.TOTAL()[2],s);ec.mp(L(s,upper),nd.bexs(h.TV,H,h.AT(s,h.TV)),p)
            return h.bex_elim(ec,h.TV,H,h.AT(s,h.TV),shortrows[i],goal,lambda child:take(child,i+1))
        return take(c,0)
    nd.cases(ctx,options,goal,branch);m.finish('skelet17-blank-halting-history-has-danger',root,prem,goal,ctx,
        'Every supplied blank-start halting beta-history has a bounded B111 witness. All halting times included. No induction.')
full()
if __name__=='__main__':m.write()
