"""Independent statement and ordinary-trace checks for the n=4b cycle."""
from pathlib import Path
import json
import check_history_tools as ht
from check_skelet10_scope import AND,eq,lt,plus,times,num,implies,parse,EX,sparse
from check_skelet10_boundaries import boundary
from check_skelet10_spread import transform,bounded,spread
from check_skelet10_right import carry,jval,sparse_num
from check_skelet10_left import norm,raw_step
P=Path(__file__).resolve().parent;H,N,o,k=ht.H,ht.N,ht.o,ht.k;c=ht.c
two,three,four=map(num,(2,3,4));n='cycleInput';word='zeroCycleWord';ba='boundaryA'
halt=['assemblyHalt'+s for s in ('Q','L','Bit','R')];ei='cycleOutputIndex';er=['cycleOutput'+s for s in ('Q','L','Bit','R')]
def wl(row):return plus(times(two,row[1]),row[2])
def bounds(row):return [lt(x,H) for x in row]
even=EX(ba,plus(n,'1'),AND([eq(n,times(two,ba)),transform(ba,wl(c)),carry(ba,c[3])]))
prem=AND([ht.total(o,N,ht.ti),ht.steps(o,N,ht.si,ht.SV),*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5)),*bounds(c),lt(k,plus(N,'1')),ht.at(o,k,c),eq(c[0],three),lt(c[2],two),sparse(n),sparse(c[3]),even,eq(n,times(four,word))])
expected=implies(prem,EX(ei,plus(N,'1'),ht.bexs(er,AND([lt(k,ei),ht.at(o,ei,er),boundary(c[3],er)]))))
def main():
 data=json.loads((P/'skelet10_even_zero_theorems.json').read_text());label='skelet17-ladder-skelet10-even-zero-boundary-cycle'
 assert set(data)=={label};assert norm(parse(data[label]))==norm(expected);assert bounded(expected)
 count=moves=maxmoves=0
 for b in range(1024):
  if not sparse_num(b):continue
  t=10*spread(b);r=4*b+1;row=(3,2*t,0,r);v=jval(b)[0]
  assert sparse_num(4*b) and sparse_num(r)
  target=(3,2*t+1,0,2*v);cap=4+1+20*b+18+1
  for j in range(1,cap+1):
   assert row[0]!=5;row=raw_step(row)
   if row==target:break
  else:raise AssertionError((b,row,target,cap))
  assert j>0 and sparse_num(row[3]);count+=1;moves+=j;maxmoves=max(maxmoves,j)
 out={'statements_checked':1,'independent_reconstruction_matches':True,'statement_delta0':True,'original_beta_history_and_step_unchanged':True,'complete_n_equals_4b_composition':True,'required_final_D1_alignment_included':True,'no_intermediate_outputs_assumed':True,'no_new_induction_construction':True,'finite_even_zero_cycles':count,'ordinary_moves_checked':moves,'maximum_cycle_length_checked':maxmoves,'finite_tests_are_not_formal_proof':True,'global_nonhalting_assembled':False}
 (P/'skelet10_even_zero_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
