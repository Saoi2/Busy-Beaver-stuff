"""Instantiate the valid-word proof for the 32-state joint recorder.

This only changes auxiliary record fields, never the Turing-machine encoding.
The generated Metamath proof is checked by the original kernel.
"""
from pathlib import Path
import json,sys
if '--resume' in sys.argv:import resume_packets
P=Path(__file__).resolve().parent
source=(P/'build_parser.py').read_text()
source=source.replace('import build_annotations as n','import build_packets_generated as n')
source=source.replace('m,nd,b,a=n.m,n.nd,n.b,n.a',
    'm,nd,b,a=n.m,n.nd,n.b,n.a\nfrom compact_cases import install\ninstall(nd)')
source=source.replace('range(4,8)','HIGH_VALUES')
source=source.replace('def HIGH(v):','HIGH_VALUES=[4,5,6,7,12,29]\ndef HIGH(v):')
source=source.replace('range(8)','range(32)')
source=source.replace('if i>=4 or j==1','if i%8>=4 or j==1')
source=source.replace('n.TABLE[i][j]-4','HIGH_VALUES.index(n.TABLE[i][j])')
source=source.replace('conflict(hc,aa,i,k+4,goal)','conflict(hc,aa,i,HIGH_VALUES[k],goal)')
source=source.replace('n.cube','n.power5')
source=source.replace('skelet17-parser-','skelet17-packet-parser-')
source=source.replace('skelet17-annotation-','skelet17-packet-')
source=source.replace('parser_raw.mm','packet_parser_raw.mm').replace('parser_theorems.json','packet_parser_theorems.json')
source=source.replace("if 'parser-' in k","if 'packet-parser-' in k")
source=source.replace('twelve parser transitions','48 partial joint-recorder transitions')
# Prove constant inequalities once in an empty context. Re-expanding their
# arithmetic under every large finite-table case causes needless duplication.
start=source.index('def conflict(');stop=source.index('\ndef pending():',start)
source=source[:start]+'''constant_inequalities={}
def unequal_constants(i,j):
    lo,hi=sorted((i,j));key=(lo,hi)
    if key in constant_inequalities:return constant_inequalities[key]
    root=nd.Ctx();left,right=a.num(lo),a.num(hi);prem=Q(left,right)
    bound(root,left,right,a.num(hi-lo-1))
    ctx=root.push(prem)
    rewrite(ctx,L(left,a.E),right,left,a.sym(left,right,ctx.get(prem),ctx.g))
    bad=L(left,left);ctx.put(b.Not(bad),b.ax('O1',ctx.g,t=left))
    out=b.Not(prem)
    proof=b.apply('nd-not-intro',{'ga':root.g,'ph':prem,'ps':bad},[ctx.get(bad),ctx.get(b.Not(bad))])
    root.put(out,proof)
    name='packet-bridge-constant-unequal-'+str(lo)+'-'+str(hi)
    b.theorem(name,out,proof)
    constant_inequalities[key]=b.apply(name)
    return constant_inequalities[key]
def conflict(ctx,v,i,j,goal):
    lo,hi=sorted((i,j));left,right=a.num(lo),a.num(hi)
    p=a.trans(left,v,right,a.sym(v,left,ctx.get(Q(v,left)),ctx.g),ctx.get(Q(v,right)),ctx.g)
    fact=Q(left,right);ctx.put(fact,p)
    ctx.theorem(b.Not(fact),unequal_constants(lo,hi))
    return ctx.explode(fact,goal)
''' +source[stop:]
(P/'build_packet_parser_generated.py').write_text(source)
namespace={'__name__':__name__,'__file__':str(P/'build_packet_parser_generated.py')}
exec(compile(source,str(P/'build_packet_parser_generated.py'),'exec'),namespace)
globals().update({k:v for k,v in namespace.items() if not k.startswith('__')})
