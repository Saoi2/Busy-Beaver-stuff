"""Independently reconstruct the claimed endpoint formula in bare FOL.

This checks the public statement's encoding/scope, not its derivation.
The independent Metamath verifier checks its derivation separately.
"""
import json
from pathlib import Path
P=Path(__file__).resolve().parent
def parse(text):
 tokens=iter(text.split())
 def expr():
  t=next(tokens)
  if t=='(':
   a=expr();op=next(tokens);c=expr();assert next(tokens)==')'
   return op,a,c
  if t in ('A.','E.'):return t,next(tokens),expr()
  if t=='-.':return t,expr()
  return t
 result=expr();assert next(tokens,None) is None;return result
def add(x,y):return '+',x,y
def mul(x,y):return '*',x,y
def eq(x,y):return '=',x,y
def lt(x,y):return '<',x,y
def imp(x,y):return '->',x,y
def both(x,y):return '/\\',x,y
def either(x,y):return '\\/',x,y
def num(n):return '0' if n==0 else '1' if n==1 else add(num(n-1),'1')
def AND(xs):return xs[0] if len(xs)==1 else both(xs[0],AND(xs[1:]))
def OR(xs):return xs[0] if len(xs)==1 else either(xs[0],OR(xs[1:]))
def all_b(vs,bound,body):
 for x in reversed(vs):body='A.',x,imp(lt(x,bound),body)
 return body
def ex_b(vs,bound,body):
 for x in reversed(vs):body='E.',x,both(lt(x,bound),body)
 return body
H='mh';n='mn';offset='ladderFinnedOffset'
def at(i,c):
 out=[]
 for j,v in enumerate(c):
  mod=add('1',mul(add(add(offset,i),'1'),'C'+str(j)))
  out.append(ex_b(['bu'],H,both(eq('B'+str(j),add(mul('bu',mod),v)),lt(v,mod))))
 return AND(out)
# The machine table is independently written from its standard transition text.
text='1RB1RE_1LC1RB_0RA0LD_1LB1LD_---0RA'.replace('_','')
table=[]
for i in range(0,len(text),3):
 ins=text[i:i+3]
 table.append((5,True,1) if ins=='---' else (ord(ins[2])-ord('A'),ins[1]=='R',int(ins[0])))
def step(c,d):
 q,l,b,r=c;nq,nl,nb,nr=d;rows=[];two=num(2)
 for j,(nextq,right,write) in enumerate(table):
  equations=[eq(nl,add(mul(two,l),num(write))),eq(r,add(mul(two,nr),nb))] if right else [eq(nr,add(mul(two,r),num(write))),eq(l,add(mul(two,nl),nb))]
  rows.append(AND([eq(q,num(j//2)),eq(b,num(j%2)),eq(nq,num(nextq)),*equations,either(eq(nb,'0'),eq(nb,'1'))]))
 return OR(rows)
tv=['tq','tl','tb','tr'];av=['iq','il','ib','ir'];sv=['sq','sl','sb','sr','nq','nl','nb','nr']
nf=['ladderNq','ladderNl','ladderNb','ladderNr']
total=all_b(['ti'],add(n,'1'),ex_b(tv,H,at('ti',tv)))
steps=all_b(['si'],n,all_b(sv,H,imp(both(at('si',sv[:4]),at(add('si','1'),sv[4:])),step(sv[:4],sv[4:]))))
blank=all_b(av,H,imp(at('0',av),AND([eq(x,'0') for x in av])))
expected='-.',AND([total,steps,blank,*[lt(x,H) for x in nf],at(n,nf),eq(nf[0],num(5))])
statements=json.loads((P/'ladder_theorems.json').read_text())
label='skelet17-ladder-finned3-no-blank-halting-history'
actual=parse(statements[label]);assert actual==expected,'Endpoint has a different statement/encoding from the intended raw-history theorem.'
for marker in ('finnedBoundParameter','finnedLiftWitness','grayDivisor','grayQuotient'):
 assert marker not in statements[label],marker
out={'theorem':label,'matches_independent_raw_history_formula':True,
     'ordinary_instructions':len(table),'auxiliary_certificates_in_statement':False,
     'history_encoding':'original four-coordinate bounded beta predicates',
     'scope':'statement check; derivation is verified by Metamath'}
(P/'finned3_endpoint_scope.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
