"""Executable interpretation checks, not a substitute for the Metamath proof.

All parameters are positive powers of two.  The formulas in interpret()
specify state/read bit and polynomial relations on the ordinary tape halves.
advance() gives explicit candidate witness updates under ONE ordinary step.
"""
from itertools import product
from pathlib import Path
import json

MACHINE='1RB1RE_1LC1RB_0RA0LD_1LB1LD_---0RA'
TABLE=[(1,1,1),(4,1,1),(2,0,1),(1,1,1),(0,1,0),
       (3,0,0),(1,0,1),(3,0,1),(5,1,1),(0,1,0)]
ARITIES={'A0':1,'A1':2,'B1':4,'B0-work':2,'B0-final':1,
         'C1':2,'C0-final':1,'D1':4,'D0':3,'E1':2}
def power2(x):return x>0 and x&(x-1)==0
def interpret(kind,args):
 if not all(power2(x) for x in args):return None
 if kind=='A0':
  p,=args;q,bit,l3,r=0,0,2*p*p-2,p-1
 elif kind=='A1':
  s,w=args;q,bit,l3,r=0,1,2*s*s-2,8*s*w**3-2*w*w-1
 elif kind=='B1':
  p,w,z,v=args
  if w*z!=p*v*v:return None
  q,bit,l3,r=1,1,w*(2*p*p+1)-3,z*(2*v-1)-1
 elif kind=='B0-work':
  p,v=args;q,bit,l3,r=1,0,2*p*v*v*(2*p*p+1)-3,v-1
 elif kind=='B0-final':
  w,=args;q,bit,l3,r=1,0,0,8*w**3-2*w*w-1
 elif kind=='C1':
  p,v=args;q,bit,l3,r=2,1,p*v*v*(2*p*p+1)-3,2*v-1
 elif kind=='C0-final':
  w,=args;q,bit,l3,r=2,0,0,16*w**3-4*w*w-1
 elif kind=='D1':
  s,w,u,v=args
  if 8*u*w!=s*v*v:return None
  q,bit,l3,r=3,1,w*(2*s*s+1)-3,u*(2*v-1)-1
 elif kind=='D0':
  s,u,v=args
  if 4*u!=s*v*v:return None
  q,bit,l3,r=3,0,s*s-1,u*(2*v-1)-1
 elif kind=='E1':
  s,w=args;q,bit,l3,r=4,1,s*s-1,2*s*w**3-w*w-1
 else:raise ValueError(kind)
 if l3<0 or r<0 or l3%3:return None
 return q,l3//3,bit,r

def advance(kind,args):
 if kind=='A0':
  p,=args
  return ('B0-work',(p,1)) if p==1 else ('B1',(p,2,p//2,1))
 if kind=='A1':
  s,w=args;return 'E1',(2*s,w)
 if kind=='B1':
  p,w,z,v=args
  return ('B0-work',(p,v)) if z==1 else ('B1',(p,2*w,z//2,v))
 if kind=='B0-work':return 'C1',args
 if kind=='B0-final':return 'C0-final',args
 if kind=='C1':
  p,v=args;k=p*v*v
  return ('D0',(p,1,2*v)) if k==1 else ('D1',(p,k//2,1,2*v))
 if kind=='C0-final':
  w,=args;return 'A1',(1,w)
 if kind=='D1':
  s,w,u,v=args
  return ('D0',(s,2*u,v)) if w==1 else ('D1',(s,w//2,2*u,v))
 if kind=='D0':
  s,u,v=args
  return ('B0-final',(v//2,)) if s==1 else ('B1',(s//2,1,2*u,v))
 if kind=='E1':
  s,w=args
  return ('A0',(s,)) if w==1 else ('A1',(s,w//2))
 raise ValueError(kind)

def raw_step(c):
 q,l,bit,r=c;nq,right,write=TABLE[2*q+bit]
 return (nq,2*l+write,r%2,r//2) if right else (nq,l//2,l%2,2*r+write)

def check():
 powers=[1<<e for e in range(8)];counts={}
 for kind,arity in ARITIES.items():
  count=0
  for args in product(powers,repeat=arity):
   c=interpret(kind,args)
   if c is None:continue
   nxt=advance(kind,args);d=interpret(*nxt)
   assert d==raw_step(c),(kind,args,c,nxt,d,raw_step(c))
   hist_bound=1+max(*c,*d);uniform_bound=16*(hist_bound+1)
   assert all(x<uniform_bound for x in (*args,*nxt[1])),(kind,args,nxt)
   # A fixed linear term suffices for all auxiliary witnesses in this test.
   assert all(x<16*(c[1]+c[3]+1) for x in args),(kind,args,c)
   count+=1
  counts[kind]=count
 c=(0,0,0,0);cert=('A0',(1,));return_points=0
 for _ in range(100000):
  assert interpret(*cert)==c,(cert,c)
  if cert[0]=='A0':return_points+=1
  cert=advance(*cert);c=raw_step(c)
 out={'machine':MACHINE,'phase_parameter_exponents_tested':[0,7],
      'valid_certificates_checked':counts,'total':sum(counts.values()),
      'raw_run_steps_checked':100000,'A0_return_points':return_points,
      'uniform_history_witness_bound_checked':True,
      'scope':'finite interpretation checks only; full nonhalting proof is independently verified in idelta0_machines.mm'}
 Path(__file__).with_name('finned3_certificate_checks.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':check()
