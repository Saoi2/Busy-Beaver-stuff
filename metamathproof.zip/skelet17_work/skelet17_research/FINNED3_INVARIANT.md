# Finned #3: a bounded arithmetic nonhalting proof

Machine: `1RB1RE_1LC1RB_0RA0LD_1LB1LD_---0RA`.

The whole-machine nonhalting theorem is now assembled as
`skelet17-ladder-finned3-no-blank-halting-history` in the single project.
It excludes every supplied ordinary blank-start halting history in the
original bounded beta format. Its only undefined
instruction is E0, completed by the same ordinary 1RZ convention as the
other machines. Configurations, ordinary steps, and bounded beta-coded
histories have not been changed. All Metamath results belong to the same
canonical `idelta0_machines.mm` file.

## Why counting matters here

The published discussion by Iijil identifies configurations
`(10)^n A0 1^m`. When n=m these return to the same form with both lengths
increased by one; when n differs from m they eventually halt. It follows
that no regular-language safety invariant can separate all the reachable
configurations from every configuration that eventually halts.

Source: <https://discuss.bbchallenge.org/t/10756090-finned-3-is-irregular/137>.
That argument motivates a numerical invariant rather than another search
over a fixed finite set of tape patterns. It is not an independence result
for bounded arithmetic.

In the project's binary tape encoding, the boundary configuration
`(10)^n A0 1^n` satisfies

    3L+2 = 2(R+1)^2.

For example, the first four pairs (L,R) are (0,0), (2,1), (10,3), (42,7).
Indeed, a block of n ones has numeric value 2^n-1, while the left alternating
block has value 2(4^n-1)/3. The invariant uses the displayed polynomial
equation; these explanatory exponential expressions are not terms in the
formal language.

## The bounded invariant covering every intermediate phase

In this table every auxiliary parameter is required to satisfy the
existing bounded formula Pow2. A square or cube abbreviates an explicit
fixed multiplication term. No exponential function is introduced. The
table describes a set of configurations, not a modification of Step.

| Phase | Parameters | Equations in addition to the indicated state and bit |
|---|---|---|
| A0 | p | 3L+2=2p^2; R+1=p |
| A1 | s,w | 3L+2=2s^2; R+1+2w^2=8sw^3 |
| B1 | p,w,z,v | 3(L+1)=w(2p^2+1); R+1+z=2zv; wz=pv^2 |
| B0-work | p,v | 3(L+1)=2pv^2(2p^2+1); R+1=v |
| B0-final | w | L=0; R+1+2w^2=8w^3 |
| C1 | p,v | 3(L+1)=pv^2(2p^2+1); R+1=2v |
| C0-final | w | L=0; R+1+4w^2=16w^3 |
| D1 | s,w,u,v | 3(L+1)=w(2s^2+1); R+1+u=2uv; 8uw=sv^2 |
| D0 | s,u,v | 3L+1=s^2; R+1+u=2uv; 4u=sv^2 |
| E1 | s,w | 3L+1=s^2; R+1+w^2=2sw^3 |

The work/final names distinguish two clauses for the same actual state and
read bit; they do not add machine states. There is no E0 clause.

Fix the same H that bounds the coordinates of every supplied history row.
Put U=16*(H+1), and quantify each auxiliary parameter in the table below U.
The disjunction of these ten bounded existential formulas is Inv_H(c).
It is Delta-0: all parameter, divisor, and quotient quantifiers are bounded
by terms in the original first-order language.

H and U help the proof bound its auxiliary witnesses. They do not add
annotations to the machine or the definition of a computation.

Four new arithmetic interfaces establish the uniform bounds without any
induction:

| Interface suffix | Main conclusion, assuming the tape coordinate is below H |
|---|---|
| tape-linear-bound | 3L+4<U |
| square-scale-bound | a^2=3L+1 and a>0 imply a<U |
| left-scale-bound | 3(L+1)=w(2s^2+1) implies w<U |
| right-scales-bound | R+1+u=2uv and u,v>0 imply u,v<U |

The suffixes have prefix `skelet17-ladder-finned3-`. The square and left
product estimates follow from the earlier elementary factor bound. For the
right equation, write v=k+1. Additive cancellation gives
R+1=u(2k+1), hence u<R+2. Writing u=a+1 also gives the explicit gap

    R+2 = v + (2*a*k+a+k) + 1,

so v<R+2. Fixed polynomial slack then puts both below U. These arguments
use only the discrete ordered semiring axioms and natural deduction.

Carried parameters retain their bounds. A half h<x+1 inherits h<U from
x<U. Constants 1 and 2 are below U by explicit polynomial inequalities.
New doubles and the C1 half-product receive their bounds from the target
tape equations using the interfaces above. This is why the witnesses
remain uniformly bounded even as the computation grows.

## Verified one-step witness updates

Each row describes one ordinary step, including its popped bit. The
parameters on the right refer to those on the left unless renamed.
The divisions in this explanatory table denote witnesses supplied by
the existing Pow2-halving theorem; division is not a new language symbol.

| Source | Condition | Target and its parameters |
|---|---|---|
| A0(p) | p=1 | B0-work(p,1) |
| A0(p) | p=2h | B1(p,2,h,1) |
| A1(s,w) | always | E1(2s,w) |
| B1(p,w,z,v) | z=1 | B0-work(p,v) |
| B1(p,w,z,v) | z=2h | B1(p,2w,h,v) |
| B0-work(p,v) | always | C1(p,v) |
| B0-final(w) | always | C0-final(w) |
| C1(p,v) | pv^2=1 | D0(p,1,2v) |
| C1(p,v) | pv^2=2h | D1(p,h,1,2v) |
| C0-final(w) | always | A1(1,w) |
| D1(s,w,u,v) | w=1 | D0(s,2u,v) |
| D1(s,w,u,v) | w=2h | D1(s,h,2u,v) |
| D0(s,u,v) | s=1 and v=2h | B0-final(h) |
| D0(s,u,v) | s=2h | B1(h,1,2u,v) |
| E1(s,w) | w=1 | A0(s) |
| E1(s,w) | w=2h | A1(s,h) |

For D0 with s=1, the alternative v=1 is impossible: its equation
`4u=sv^2` would make an even number equal to 1. With v=2h, cancelling
4 in `4u=4h^2` gives u=h^2 and yields the final B clause.

For C1, the split requires Pow2(pv^2). The new theorem
`skelet17-ladder-finned3-power-product` proves the required general
multiplication closure. Its bounded strong-induction formula is

    Phi(i;y) := forall x<i+1, (Pow2(x) -> Pow2(x*y)),

with Pow2(y) among the assumptions. For x=1 the result is Pow2(y).
For x=2h, Pow2(h) and h<x let the induction hypothesis supply Pow2(h*y);
the earlier doubling theorem gives Pow2(x*y). The base excludes a
positive Pow2 number below 1. Fresh variables and explicit alpha-renaming
handle generalization without violating Metamath's syntactic distinct-
variable requirements. Every quantifier in Phi is bounded, including
those inside Pow2, so this is an ordinary Delta-0 induction instance.

This closes multiplication for two *given* Pow2 numbers. It does not
construct 2^n for arbitrary n or assume that exponentiation is total.

## Local phase proofs

The A/E interfaces in `ladder_finned3_sweeps.py` are:

* `skelet17-ladder-finned3-a0-to-b`:
  an A0 certificate and an ordinary step imply the B0-work certificate
  or a B1 certificate with a bounded half witness.
* `skelet17-ladder-finned3-a1-to-e1`:
  an A1 certificate and an ordinary step imply E1(2s,w), including the
  assertion that the new scanned bit is 1.
* `skelet17-ladder-finned3-e1-to-a`:
  an E1 certificate and an ordinary step imply A0(s), or A1(s,h)
  for a bounded h with w=2h supplied during the proof.

The other seven phase-preservation interfaces are:

* `skelet17-ladder-finned3-b1-scan`
* `skelet17-ladder-finned3-b0-work-to-c1`
* `skelet17-ladder-finned3-b0-final-to-c0`
* `skelet17-ladder-finned3-c0-final-to-a1`
* `skelet17-ladder-finned3-d1-scan`
* `skelet17-ladder-finned3-d0-to-b`
* `skelet17-ladder-finned3-c1-to-d`

Together these ten interfaces cover every source phase in the table.
Their premise uses the full ordinary ten-instruction Step disjunction,
including E0's halting instruction. Each proof eliminates all mismatching
state/read branches and derives the stated target certificate.

Here the phase parameters are free arithmetic parameters of each local
theorem. Its premise assumes the phase equations and Pow2 conditions.
The new bounded assembly eliminates the source's existential witnesses,
uses one of these ten ordinary-step lemmas, derives uniform bounds on
the output witnesses, and reintroduces bounded existential quantifiers.
Its main public theorem is `skelet17-ladder-finned3-local`:

    Inv_H(c) and Step(c,d) and d.L<H and d.R<H -> Inv_H(d).

The two target tape bounds already hold for supplied history rows. No
extra condition is added to Step. Consult `ladder_manifest.json` for
verification and actual induction-dependency counts.

The A1 proof illustrates why E0 is avoided. The right tape equation is

    R+1+2w^2 = 8sw^3.

A right step satisfies R=2R'+b'. If b'=0, this yields

    2(R'+w^2)+1 = 2(4sw^3),

contradicting uniqueness of remainders below 2. Hence b'=1. Dividing the
resulting equality by the constant 2 gives the E1 right tape equation.
The left tape equation changes by the corresponding ordinary push of 1,
and the scale s doubles. The only power-of-two closure needed here is
the already proved doubling theorem.

In E1, split w into 1 or a bounded half 2h. When w=1, the popped bit must
be 0, yielding A0. When w=2h, it must be 1, yielding A1(s,h). Both bit
claims use the same explicit quotient/remainder uniqueness argument.
No induction on the length of a sweep is needed for these local lemmas.

## From local preservation to nonhalting

The blank tuple (A,0,0,0) has its A0 certificate with p=1. The induction
formula is

    Phi(i) := i<n+1 -> forall q,L,b,R<H,
              (At(i,(q,L,b,R)) -> Inv_H(q,L,b,R)).

At uses the same bounded beta quotient-and-remainder predicates as the
previous ladder proofs. TOTAL supplies a preceding row; the induction
hypothesis supplies its bounded certificate; STEPS supplies the ordinary
transition to the next supplied row. The local theorem then constructs a
bounded certificate for that next row. Every quantifier in Phi is bounded,
including the new existential witnesses below U. This is one ordinary
Delta-0 induction instance.

The final row must therefore belong to one of the ten phases. Their states
are all A through E, numbered 0 through 4. The halting state is Z=5, so
that row cannot be a halting row. The final theorem negates the conjunction
of TOTAL, STEPS, BLANK, all four final coordinate bounds, At(n,final),
and final.state=5. Its free code parameters are arbitrary.

The final statement contains no phase predicate, Pow2 condition, auxiliary
certificate, or extra tape guard. `check_finned3_endpoint_scope.py` rebuilds
that formula independently from the machine's transition text and the raw
beta-history definitions. The audit compares it with the actual public
Metamath conclusion. Independent Metamath verification checks the proof.

The final nonhalting theorem has three bounded-induction application nodes
in its dependency closure: the earlier bounded division proof, the Pow2
multiplication proof, and the new history induction. The witness-bound
lemmas require none. These counts describe this proof, not a lower bound
on the strength or number of induction instances necessary.

No theorem asserting that every finite computation has a beta code, no
exponential-totality axiom, and no new arithmetic axiom is used. The result
is the same supplied-history nonhalting formulation as the earlier
individual machine proofs. It does not by itself establish BB(5), a general
CPS/RWL decider theorem, or Skelet17 nonhalting. Those broader targets
remain unfinished.

`check_finned3_certificate.py` also supplies supplementary tests: 774 valid
certificate instances with parameter exponents 0 through 7, and 100,000
ordinary blank-start steps. These finite tests are not the formal proof.
The stronger per-configuration bound tested there is not needed for the
formal theorem, which uses the uniform history bound U=16*(H+1).
