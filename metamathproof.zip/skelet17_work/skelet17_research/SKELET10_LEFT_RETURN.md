# Skelet #10: bounded block decoding and the complete A1 return

This extension supplies two arithmetic interfaces needed by the left
counter and a contract for its entire A-state clearing return. It uses
the same machine, ordinary Step relation, tape encoding and bounded
beta-history format as the earlier proofs. No defining axiom, function
symbol or intermediate history annotation is added.

The whole right-counter contract remains available. The left counter's
preceding D/C carry scan is still unfinished, so these results do not yet
prove the full left counter or Skelet #10 nonhalting.

## Block tails can now be recovered

The bounded relation T(x,z) represents the left-word encoding
10*Spread(x). Previously the project proved the constructors

    T(x,t) -> T(2x,4t),
    T(x,t) -> T(4x+1,16t+10),

and their inverse implications when the output block shape was already
known. The new statements recover that shape and a bounded tail:

    T(2x,z) -> exists t<z+1, z=4t and T(x,t),
    T(4x+1,z) -> exists t<z+1, z=16t+10 and T(x,t).

They apply to every output z satisfying the existing relation. They do
not choose an independently constructed encoding and assume it equals
the tape value. No graph uniqueness theorem is required.

Unfold T as a bounded spread witness with z=10u. The already proved
spread-decomposition theorem removes one binary/base-four digit, or two
for the 10 constructor. Scaling its smaller witness by 10 gives the
required t. The exact output equation bounds t by z; multiplication by
a positive coefficient cannot make the factor larger than the result.
The proof keeps coefficients factored rather than expanding 16*10.
These statements reuse the earlier bounded division proof and add no
induction construction.

For example T(5,170) holds. Since 5=4*1+1, the second theorem gives the
tail t=10 with 170=16*10+10 and T(1,10). The first theorem applied to
T(10,680), with 10=2*5, gives t=170 and T(5,170).

## What the A1 return does

A configuration remains c=(q,L,b,R), with scanned bit b and nearest
half-tape bits least significant. Put

    WholeRight(c)=2R+b.

The instruction A1 writes 0, moves right, and remains in A. Thus it
doubles L and removes one nearest 1 bit from the whole right word.
Two A1 instructions multiply L by 4. This matches the already proved
constructor T(u,t) -> T(2u,4t): the represented word doubles after two
ordinary moves.

Fix three parameters:

* P is the initial return scale, with Pow2(P).
* V is the desired represented output word.
* r is the right word that must remain after clearing the pending markers.

At entry there is a bounded current word u<=V with

    q=A, b<2, T(u,L), Sparse(u),
    P*u=V, WholeRight+1=P*P*(r+1).

This describes the pending right-side markers without a tape-length
function. For ordinary P=2^k, there are 2k pending 1s; the formal statement
uses only Pow2(P) and multiplication. P=1 means the desired endpoint has
already been reached.

The output contract is

    q=A, WholeRight=r, T(V,L), Sparse(V).

The actual machine can continue from that A row. The routine contract
ends at this specified logical boundary.

## Two bounded phases

The current scale p and represented word u are existential witnesses
with p<P+1 and u<V+1. They are constructed inside the history proof.
The half-step phase also has an encoded tail t<L+1.

| Phase | Conditions in addition to q=A, b<2, Pow2(p), Sparse(u) | Rank |
|---|---|---|
| Main | T(u,L); p*u=V; WholeRight+1=p*p*(r+1) | 2p |
| Half-step | T(u,t); L=2t; (2p)*u=V; WholeRight+1=2*p*p*(r+1) | 2p+1 |

The half-step scale p is already half the preceding main-phase scale.
The two occurrences of p in adjacent rows must not be read as the same
unchanging value.

At a main row with p=1, the equations give WholeRight=r and u=V, so the
row satisfies the output contract. Before the output, p cannot be 1.
The existing Pow2 halving lemma gives p=2h with positive Pow2 h.
Then WholeRight+1=4*h*h*(r+1) is even, forcing the scanned bit to be 1.
One ordinary A1 move reaches the half-step phase with scale h and old
left word t. Its rank 2h+1 is smaller than the old rank 4h.

At a half-step row, WholeRight+1=2*p*p*(r+1) again forces a scanned 1.
One more A1 move gives left half 4t. The existing transform constructor
supplies T(2u,4t), and the Sparse zero-prefix lemma supplies Sparse(2u).
Update the current word to 2u and keep the smaller scale p. The equation
p*(2u)=V is preserved. Its rank 2p is smaller than 2p+1.

The new word's bound follows from p>0 and p*(2u)=V, which give 2u<=V.
The half-step encoded tail is bounded by the actual new left coordinate,
since that coordinate is 2t. Thus every witness has an arithmetic bound
available in the current formula. No total exponentiation or uniqueness
property of T is used.

## Example: four actual clearing steps

Take P=4, initial u=1, desired output V=4, and right tail r=0. The initial
left encoding is T(1,10), and WholeRight+1=16. The ordinary run is:

| Step | State | L | b | R | Phase | Current p | Current u | Rank |
|---:|---|---:|---:|---:|---|---:|---:|---:|
| 0 | A | 10 | 1 | 7 | Main | 4 | 1 | 8 |
| 1 | A | 20 | 1 | 3 | Half-step | 2 | 1 | 5 |
| 2 | A | 40 | 1 | 1 | Main | 2 | 2 | 4 |
| 3 | A | 80 | 1 | 0 | Half-step | 1 | 2 | 3 |
| 4 | A | 160 | 0 | 0 | Main | 1 | 4 | 2 |

The final row has WholeRight=0 and T(4,160). Four 1s were cleared from
the right; four 0s were written on the left. The proof handles arbitrary
scales and words, not only this example.

## Whole computation histories

The six return interfaces use the original four-coordinate beta format.
H bounds history coordinates and beta quotients; n is the final index;
Bj,Cj are numerical history-code parameters, unrelated to machine states
B and C. At(i,c) uses the four coordinate equations at offset+i.

TOTAL supplies a row below H at every i<n+1. STEPS requires the original
ordinary Step between adjacent supplied rows. INITIAL requires the entry
conditions above of every supplied initial row. It supplies no marker,
word or phase at any intermediate row.

If all supplied rows avoid the output, bounded induction constructs

    i<n+1 -> forall c<H,
      At(i,c) -> exists rho<2P+1,
        Rank(c,rho) and i+rho<2P+1.

Rank is the bounded disjunction of the two phases above. All of its
quantifiers, all beta quotients and all Sparse/Pow2 witnesses are bounded,
so this is a permitted Delta-0 induction formula. The base uses rank 2P.
An ordinary step before the output yields a smaller positive rank, which
advances the clock inequality. At the final row positivity gives n<2P.

Consequently a supplied history with n>=2P must visit the correct A
output. Independently, a supplied history ending at halt must already
have visited that output: otherwise the derived final phase would have
state A, contradicting halt. These conclusions do not assume that every
finite execution has a beta code. Their output witnesses are bounded;
the universally closed arithmetic sentences are Pi-1.

## Public labels and verification

All labels start `skelet17-ladder-skelet10-`.

| Label suffix | Content | Induction constructions in its dependency closure |
|---|---|---:|
| `transform-decompose-0` | Recover a bounded encoded tail from T(2x,z). | 1 |
| `transform-decompose-10` | Recover a bounded encoded tail from T(4x+1,z). | 1 |
| `left-return-entry` | Derive the bounded clearing rank from entry. | 0 |
| `left-return-step` | An ordinary clearing step before the output strictly decreases rank. | 1 |
| `left-return-window-invariant` | Construct intermediate phases, words, encoded tails and ranks. | 2 |
| `left-return-window-bound` | A target-avoiding supplied history has n<2P. | 2 |
| `left-return-window-exit` | A supplied history with n>=2P visits the correct A output. | 2 |
| `left-return-window-halting-barrier` | A supplied history ending at halt has visited the correct A output. | 2 |

The two dependencies of a history result are the earlier bounded division
construction and one new bounded history induction. These are counts of
the actual proof constructions, not lower bounds on the theory needed.
The original 93 trusted declarations are unchanged.

`check_skelet10_clear.py` independently reconstructs all eight statements,
checks bounded syntax and the absence of supplied intermediate annotations
in the exit/barrier interfaces, and tests 256 block examples and 1,344
standard clearing routines comprising 9,408 ordinary moves. Simulation
supplements the independent Metamath verification. The generators are
`ladder_skelet10_blocks.py`, `ladder_skelet10_clear.py` and
`ladder_skelet10_clear_history.py`; the full rebuild includes all three.

## Remaining work

The missing piece of the full left routine is its D/C carry scan, including
the finite C/E/B exit into this A return. SKELET10_LEFT_SCAN_PLAN.md gives
explicit proposed microphases and bounds, marked as unproved. The right
counter is already complete; full left-counter correctness, global
synchronization and blank-start Skelet #10 nonhalting remain unfinished.
