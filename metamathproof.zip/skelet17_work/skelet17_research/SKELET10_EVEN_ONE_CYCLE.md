# Boundary composition for n=8b+2

The public target is
skelet17-ladder-skelet10-even-one-boundary-cycle. It uses the same
ordinary machine 1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB, with E0 completed
by 1RZ, and the same supplied bounded beta history. Write W=2L+s and
V=2R+s for a quadruple (q,L,s,R). No invariant is added to Step, At,
TOTAL, STEPS, or the definition of halting.

## Statement

Fix H, the original length N, offset o, and four beta code pairs. Assume
TOTAL and STEPS, a bounded halt row at N, and a bounded decoded current
row c at k<N+1. Assume q(c)=D, s(c)<2, Sparse(n), Sparse(R(c)), the
canonical even clause, and n=8b+2. The even clause is the original
bounded existential assertion n=2a, T(a,W(c)), J(a,R(c)).

The conclusion constructs e<N+1 and a bounded decoded row d with
k<e and Boundary(R(c),d). In particular, every routine entry and output
is obtained inside the SAME history. No intermediate output or window
length assumption occurs in the public premises. The next input R(c)
is below H because it is an old row coordinate.

## Source arithmetic and four actual carry moves

Quotient/remainder uniqueness gives a=4b+1. Sparse pop lemmas give
Sparse(b). The carry inverse supplies a bounded v with R(c)=4v and
J(b,v). The transform inverse supplies a bounded t with
W(c)=16t+10 and T(b,t). Binary uniqueness gives L(c)=8t+5 and s(c)=0.
Existing bounded division supplies t=2x+d with d<2. Put r=R(c).

| Point | State | L | s | R |
|---|---|---|---|---|
| Source | D | 8t+5 | 0 | r |
| After D0 | C | 4t+2 | 1 | 2r+1 |
| After C1 | D | 2t+1 | 0 | 4r+3 |
| After D0 | C | t | 1 | 8r+7 |
| After C1 | D | x | d | 16r+15 |

The table is a derived description of actual decoded rows. At each
nonhalting-state row, history-advance-before-halt supplies an actual
successor and ordinary Step. The shared instruction contracts and
coordinate equality transport identify that successor. The last popped
bit is the division remainder d; its bound d<2 is used directly.

Thus the final row has W=t, T(b,W), Sparse(b), and
R=4(4r+3)+3. These are precisely the full left routine's entry premises
with input b and right tail 4r+3. Its bit bound follows from d<2 and
the derived scanned-bit equality.

## Both routines and the two clearing moves

The embedded left barrier constructs a strictly later actual A output
with V=4r+3 and a bounded transformed carry output. Since J(b,v) was
already obtained from the original boundary, Sparse carry uniqueness
identifies that output with v: T(v,L) and Sparse(v).

Two ordinary A1 moves remove the two low 1 bits of V=4r+3. Their
existence again comes from advancement inside the alleged halting
history. The first one-step alignment establishes the intermediate A
state; the existing two-step return theorem gives the final A row with
left half 4L and whole-right word r=4v.

The transform prefix constructor yields T(2v,4L), and the Sparse prefix
constructor gives Sparse(2v). Since the whole-right word is 2(2v), the
next ordinary A0 step enters the right routine with input 2v and left
target 4L. The embedded right barrier supplies its actual D output with
whole-left 4L and J(2v,R). The even boundary constructor now supplies
Boundary(2(2v),output). Rewriting 2(2v)=r gives the required next input.

All four prefix successors, both routine outputs, both clearing
successors and the A0 successor are bounded decoded history rows.
Additive remaining-length witnesses are constructed from index bounds.
The strict routine-index inequalities and the four prefix moves prove
k<e. Bounded witnesses are discharged using natural deduction.

## Verification and remaining work

The generator is ladder_skelet10_even_one_cycle.py. The independent
checker check_skelet10_even_one_cycle.py reconstructs the entire public
formula without importing its generator. Its supplementary numerical
checks cover 144 cycles, 2,720 ordinary moves, and maximum tested length
54. These examples do not replace kernel verification.

The proof reuses bounded division, left and right history induction,
and Sparse carry uniqueness: four existing induction constructions.
It adds no induction construction or trusted axiom. This is an upper
bound on dependencies of this proof, not a lower bound on strength.

Consult ladder_verification.log, simplification_report.json and
streaming_audit_report.json for the actual verification status and
canonical source hash. A generated candidate is not a verified proof.
The general combination of boundary cases, global bounded induction,
and blank-start connection are separate deductions, now completed. This numerical
case alone is not a whole-machine nonhalting theorem.

## Current project endpoint

The general case combination, bounded maximum argument and ordinary
blank-start nonhalting endpoint are now proved. The case-level discussion
above records the numerical component; SKELET10_NONHALTING.md and STATUS.md
give the completed global result and current verification status.
