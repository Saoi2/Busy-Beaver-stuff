# Finned #3 completed; verification and handoff

The ten local phase proofs, uniform auxiliary-witness bounds, bounded
existential invariant assembly, ordinary history propagation and final
blank-start nonhalting theorem are now assembled in idelta0_machines.mm.
Read FINNED3_INVARIANT.md for the mathematics and ladder_manifest.json
for checked scope, induction dependencies and file hashes.

Main interfaces:

* skelet17-ladder-finned3-local
* skelet17-ladder-finned3-history
* skelet17-ladder-finned3-no-blank-halting-history

The final theorem excludes raw halting histories; auxiliary certificates
are not supplied as part of the computation predicate. Its exact formula
is independently reconstructed by check_finned3_endpoint_scope.py.

Build order: build_ladder.py executes the earlier ladder generators,
ladder_finned3_sweeps.py, ladder_finned3_global.py (which includes
finned3_bounds.py), and ladder_finned3_history.py. Then prune the raw
file, run merge_previous_results.py and simplify_metamath.py, verify with
official Metamath, then run audit_simplification.py and audit_ladder.py.
The wrapper rebuild_project.py performs this complete sequence. Retain the original 93 trusted declarations.

The raw and generated history/endpoint files are reproducible outputs.
The single canonical active proof database is idelta0_machines.mm.
Earlier standalone proof files are preserved build inputs.

The next unfinished ladder targets include the higher-parameter CPS,
repeated-word, overflow and other irregular examples. Skelet17
nonhalting and complete BB classifications remain unfinished. Do not
infer their completion from this one machine's successful proof.
