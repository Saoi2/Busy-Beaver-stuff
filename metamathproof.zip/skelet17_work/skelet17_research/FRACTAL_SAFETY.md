# A four-state fractal with an elementary safety proof

The target is `1RB0LA_1RC---_0RD0RC_1LD0LA`. Its recursive growth
pattern is described at <https://wiki.bbchallenge.org/wiki/Fractal>.
The proof here concerns nonhalting, not that detailed growth pattern.

## The ordinary transition relation

The configuration is the same quadruple `(q,L,b,R)` used elsewhere in this
project. A=0, B=1, C=2, D=3, and the global halting state Z=5. The scanned
bit is b. L and R encode the tape to the left and right, with the nearest
bit in the units place. The scanned bit belongs to neither half.

| Instruction | Write | Direction | New state |
|---|---|---|---|
| A0 | 1 | right | B |
| A1 | 0 | left | A |
| B0 | 1 | right | C |
| B1 | 1 | right | Z |
| C0 | 0 | right | D |
| C1 | 0 | right | C |
| D0 | 1 | left | D |
| D1 | 0 | left | A |

The undefined B1 instruction is completed by 1RZ, as in the other machine
proofs. The final movement is part of Step. Step is the disjunction of
these eight ordinary instructions, not a transition predicate supplemented
by a safety condition.

For a right move writing w, the equations are

    L' = 2L+w,     R = 2R'+b',     b'=0 or b'=1.

For a left move writing w, they are

    R' = 2R+w,     L = 2L'+b',     b'=0 or b'=1.

## The invariant

Define the following bounded formula, using only addition, multiplication,
order, equality and first-order logical operations:

    Even(R) := exists u<R+1, R=2u.

Now put

    Inv(q,L,b,R) :=
        (q=0 and Even(R))
        or (q=1 and b=0)
        or q=2
        or q=3.

There is deliberately no claim that every tuple in Inv is reachable.
It suffices that blank belongs to Inv, that Step preserves Inv, and that
no tuple in Inv has state 5. Nothing is added to the definition of a run.

## Why each instruction preserves it

The formal local theorem has the exact shape

    (Inv(c) and Step(c,d)) -> Inv(d).

The generator emits natural-deduction case elimination over the four
invariant clauses and the eight instruction clauses. Mismatching state
equalities yield contradictions in the unchanged arithmetic core. The
matching cases are as follows.

| Instruction | Required source information | Derived target clause |
|---|---|---|
| A0 | R=2u for some u<R+1 | R=2R'+b', so b'=0; target is B0 |
| A1 | state A | R'=2R; target is A with even R' |
| B0 | state B, b=0 | target is C |
| B1 | state B, b=0 | impossible because instruction assumes b=1 |
| C0 | state C | target is D |
| C1 | state C | target is C |
| D0 | state D | target is D |
| D1 | state D | R'=2R; target is A with even R' |

For A0, the arithmetic argument uses uniqueness of quotient and remainder:
`2R'+b'=2u+0`, with both remainders below 2, implies `b'=0`.
The bound on b' follows by eliminating its explicit zero-or-one disjunction.
The source witness u is eliminated by ordinary existential elimination.

For A1 and D1, R witnesses Even(R'), because R'=2R and R<R'+1.
This last inequality follows directly from the discrete ordered semiring
axioms. It requires no induction. The same is true of the quotient/remainder
uniqueness argument; division *existence* is not needed.

The blank configuration has q=L=b=R=0 and satisfies the A clause using
u=0. No invariant clause permits q=5.

## The history induction

The project retains its existing bounded quotient-and-remainder history
encoding. For coordinate j, a supplied history records value v at index k
by the bounded formula

    beta_j(k,v) := exists u<H,
       Bj = u*(1+(k+1)*Cj)+v and v<1+(k+1)*Cj.

`At(i,c)` applies the four coordinate predicates at offset+i. `TOTAL`
supplies a tuple with all coordinates below H at each index up to n.
`STEPS` asserts ordinary Step between every adjacent pair of supplied
tuples. `BLANK` requires the supplied initial tuples to be all zero.
No axiom asserting existence of a history code is used.

One bounded induction propagates Inv, using

    Phi(i) := i<n+1 -> forall q,L,b,R<H,
                    (At(i,(q,L,b,R)) -> Inv(q,L,b,R)).

Every quantifier in this formula is bounded, including those in At and
Even. Consequently Phi is a Delta-0 formula in the original language.
The base case uses BLANK and the blank invariant. For the successor case,
TOTAL supplies the preceding tuple, the induction hypothesis gives Inv
there, STEPS gives the ordinary transition to the current tuple, and the
local theorem supplies its invariant. The bounded-quantifier guards and
the indices outside the computation window are handled explicitly by the
same history proof construction used for the previous ladder machines.

The endpoint theorem negates the conjunction of TOTAL, STEPS, BLANK,
the final coordinate bounds, At(n,final), and final.state=5. Thus it
excludes every supplied blank-start halting history in the unchanged format.

## Checked interfaces and limits

All three public assertions are in the single `idelta0_machines.mm` file:

* `skelet17-ladder-fractal-local`
* `skelet17-ladder-fractal-history`
* `skelet17-ladder-fractal-no-blank-halting-history`

The local theorem has no induction application in its dependency closure.
The history and endpoint theorems each have one bounded-induction
application. These are properties of this proof, not lower bounds on the
strength needed for the result.

`check_fractal_invariant.py` also tests all 98,304 invariant configurations
with L,R<128, and 100,000 steps from blank. A one-bit finite abstraction
has 20 reachable abstract configurations and never reaches B1. Those checks
help catch interpretation errors; they do not replace the unbounded
Metamath proof or its independent verification.

This example illustrates a useful distinction for the ladder: a recursive,
self-similar computation can have a simple reason why its halt instruction
is unreachable. The proof establishes neither a general fractal decider
nor the detailed recursion shown by the spacetime diagram.
