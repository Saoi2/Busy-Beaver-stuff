# Skelet #10: four finite left-counter contracts

Machine: `1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB`.

Four new theorems in `idelta0_machines.mm` prove finite pieces of the
left-counter routine. Each supplies an explicit ordinary path and proves
the endpoint of every ordinary run of the same length from its source.
One boundary case returns to the previously proved right-scan invariant.
**Whole-machine nonhalting remains unproved.**

All four contracts use no induction and add no trusted declaration. The
existing arithmetic axioms and natural deduction suffice for these fixed
finite computations. Their parameters are arbitrary, so these are not
just numerical tests of particular tape lengths.

## The same tape encoding

A configuration is `(q,L,b,R)`. L and R store the two binary tape halves,
with the nearest bit least significant; b is the scanned bit. States
A,B,C,D,E have codes 0,1,2,3,4, and halt Z has code 5.

Writing a bit e and moving right gives L'=2L+e, R=2R'+b'.
Moving left gives R'=2R+e, L=2L'+b'. The ordinary Step relation is
unchanged, including the E0 instruction completed as 1RZ. Every new
proof considers all ten instruction alternatives when establishing
which successor is possible. No macro instruction is added to Step.

For readability, put P(x,e)=2x+e. The formal statements expand P using
multiplication and addition. The nested P expressions in the source
are exactly the polynomials displayed below.

## What a contract states

Suppose c0,...,ck are the displayed configurations. A contract proves:

1. Step(c0,c1) and ... and Step(c(k-1),ck).
2. If arbitrary configurations a1,...,ak satisfy
   Step(c0,a1), Step(a1,a2), ..., Step(a(k-1),ak), then ak=ck
   coordinate by coordinate.

The second part is essential: the displayed path is forced by the actual
ordinary machine, rather than merely being one selected path in a larger
relation. The intermediate a-rows are free term parameters, not supplied
annotations. There is no assumption that a finite computation has a
particular beta history code.

In the final contract the second conclusion additionally gives Scan(ak),
the same right-scan predicate used in the preceding checkpoint. It is
proved for the actual final row of any matching four-step run.

## 1. Five-step left exit

For arbitrary x,y and d<2:

| Step | q | L | b | R |
|---:|---|---|---|---|
| 0 | D | 2x | 0 | 8y+4d+3 |
| 1 | C | x | 0 | 16y+8d+7 |
| 2 | E | 2x+1 | 1 | 8y+4d+3 |
| 3 | B | 4x+2 | 1 | 4y+2d+1 |
| 4 | A | 8x+5 | 1 | 2y+d |
| 5 | A | 16x+10 | d | y |

The instruction sequence is D0, C0, E1, B1, A1. This is the finite
exit at a pair of left zeros, with a two-1 prefix on the right. The
higher left and right tape contents x and y are arbitrary.

Label: `skelet17-ladder-skelet10-left-exit-five-step`.

## 2. Four-step left carry

For arbitrary x,y and d<2:

| Step | q | L | b | R |
|---:|---|---|---|---|
| 0 | D | 16x+8d+5 | 0 | y |
| 1 | C | 8x+4d+2 | 1 | 2y+1 |
| 2 | D | 4x+2d+1 | 0 | 4y+3 |
| 3 | C | 2x+d | 1 | 8y+7 |
| 4 | D | x | d | 16y+15 |

The instruction sequence is D0, C1, D0, C1. To understand the block
operation, include the scanned bit in the left word: W=2L+b. At the
source W=16(2x+d)+10. At the target W=2x+d. Thus four low bits,
conventionally written binary 1010, have been removed from the left.
At the same time four 1s have been pushed onto R.

This is an unrolling step for the recursive carry. It does not by itself
prove that an arbitrarily long succession of such blocks is safe or
that the eventual boundary has the required synchronized word.

Label: `skelet17-ladder-skelet10-left-carry-four-step`.

## 3. Four-step return clearing

For arbitrary x,y and d<2:

| Step | q | L | b | R |
|---:|---|---|---|---|
| 0 | A | x | 1 | 16y+8d+7 |
| 1 | A | 2x | 1 | 8y+4d+3 |
| 2 | A | 4x | 1 | 4y+2d+1 |
| 3 | A | 8x | 1 | 2y+d |
| 4 | A | 16x | d | y |

Four A1 moves consume four pending right-side 1s and write four zeros
on the left. Together with the carry contract, this supplies the two
finite sides of the recursive unroll/return argument.

Label: `skelet17-ladder-skelet10-return-clear-four-step`.

## 4. The synchronized 00/10 boundary returns to Scan

Assume Sparse(y), the already formalized bounded predicate saying that
y has no adjacent binary 1s. Then:

| Step | q | L | b | R |
|---:|---|---|---|---|
| 0 | D | 2x | 0 | 4y+1 |
| 1 | C | x | 0 | 8y+3 |
| 2 | E | 2x+1 | 1 | 4y+1 |
| 3 | B | 4x+2 | 1 | 2y |
| 4 | A | 8x+5 | 0 | y |

Here the left word ends in 00 and the right word begins with 10,
reading the right side nearest cell first. The final A0 configuration
satisfies the earlier Scan predicate because Sparse(y) holds.

The intermediate B configuration has even L. Consequently it need not
satisfy the earlier Scan invariant, which required odd L in its B region.
The new proof follows the four actual instructions and establishes Scan
at the final A row. It does not change the previous theorem or assume
that every intermediate row satisfies Scan.

Label: `skelet17-ladder-skelet10-left-zero-return-to-scan`.

## How the formal proofs are constructed

Six private instruction contracts cover A1, B1, C0, C1, D0 and E1.
Each proves its ordinary transition and uniqueness of its successor.
The proof splits the full Step disjunction, excludes wrong states or
read bits, and uses the existing division-uniqueness lemma to identify
the popped digit and quotient. All bit bounds are explicitly proved.

The public contracts compose these instruction results. In the arbitrary
run, equality substitution transports the next raw Step to the known
source row; successor uniqueness identifies the next row. Repeating this
four or five times gives the actual endpoint. Equality is substituted
only in the configuration coordinate slots, so numerical coefficients
inside Step keep their intended role.

These are proof-generation conveniences. Every resulting mathematical
assertion is a Metamath `$p`, checked by the independent verifier against
the unchanged 93 trusted declarations. No instruction contract is an axiom.

## A candidate for the remaining synchronization relation

The following is **exploratory, not yet a Metamath theorem**.

Let Spread(w) replace binary place values 1,2,4,8,... by 1,4,16,64,...
while keeping the digits. For example Spread(5)=17. Put T(w)=10*Spread(w).
On Sparse words the two grammar constructors satisfy

    T(2w)=4T(w),       T(4w+1)=16T(w)+10.

This matches the left-counter block operations. Let NextSparse(w,r)
mean that r is the least Sparse number strictly greater than w. In the
original arithmetic language this latter relation has the bounded form

    w<r and Sparse(r) and
    forall s<r, (w<s -> not Sparse(s)).

A proposed canonical D boundary is

    q=D,   2L+b=floor(T(w)/4),   NextSparse(w,R),   Sparse(w).

A direct simulation finds the first 100 such boundaries consecutively,
through ordinary step 1525. The first ones are:

| Word w | Raw step | Configuration (q,L,b,R) |
|---:|---:|---|
| 0 | 3 | (D,0,0,1) |
| 1 | 11 | (D,1,0,2) |
| 2 | 25 | (D,5,0,4) |
| 4 | 39 | (D,20,0,5) |

These boundary checks support the proposed relation but do not prove it.
In particular they do not formalize Spread as a function in I-Delta-0.
A bounded graph for the bit-spread relation was still missing at that
checkpoint. The subsequent SKELET10_SPREAD.md gives its explicit Delta-0
definition, digit constructors and bounded existence. Synchronization
itself remains unfinished.

The candidate offers useful bounds: NextSparse(w,R) explicitly gives
w<R, and a computation row already has R<H. The quotient relation
T(w)=4(2L+b)+e with e<4 would also bound a spread witness by a fixed
linear term in H. Those bounds are a proposed route to a Delta-0
existential invariant; their full integration is not yet formalized.

## What remains for nonhalting

The finite contracts do not yet establish the full left counter routine,
the right counter's exact successor behavior, or their synchronization.
A complete proof still needs a bounded word-transform relation, phase
invariants linking the finite pieces through arbitrarily long carries,
and propagation of the resulting safety invariant through the original
raw beta histories. The absence of a halting endpoint must then follow
without supplying counter annotations in the history predicate.

## Checks and reproduction

The independent statement checker reconstructs all four conclusions
using the standard machine table and the expanded polynomials above.
It compares the same logical structure after semiring normalization of
arithmetic terms. It also checks 1,664 concrete parameter cases by raw
simulation. These checks supplement the formal proofs.

`explore_skelet10_boundaries.py` separately reproduces the unproved
100-boundary experiment. Its output is explicitly marked experimental.

Use `rebuild_project.py --metamath /path/to/metamath` for the complete
project. The new proof module is `ladder_skelet10_left.py`; the new
statement and simulation checker is `check_skelet10_left.py`. The active
proofs remain in the single `idelta0_machines.mm` file.

References: [BusyCoq/Skelet10.v](https://github.com/ccz181078/Coq-BB5/blob/main/BusyCoq/Skelet10.v)
and [Ligocki's analysis](https://www.sligocki.com/2023/03/14/skelet-10.html).
The Rocq proof guides the routine decomposition; its theorems are not
imported as trusted arithmetic facts.
