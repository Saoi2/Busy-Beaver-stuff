"""A parity safety proof for 1RB0LA_1RC---_0RD0RC_1LD0LA.

The recursive spacetime behavior is not needed to exclude B1.  Every
configuration in A has even R; every configuration in B scans zero.
No restrictions on the other tape half, or on C and D, are required.
"""
TABLES['fractal']=[(1,1,1),(0,0,0),(2,1,1),(5,1,1),
                   (3,1,0),(2,1,0),(3,0,1),(0,0,0)]
def STEP(c,d,kind='fractal',previous=STEP):return previous(c,d,kind)
frEven=m.declare('fractalEven');frFresh=m.declare('fractalEvenFresh')
def fr_even(r):return nd.BEX(frEven,A(r,O),Q(r,M(two,frEven)))
def fractal_fields(c,k):
 return [[Q(c[0],Z),fr_even(c[3])],
         [Q(c[0],O),Q(c[2],Z)],
         [Q(c[0],two)],
         [Q(c[0],num(3))]][k]
def clauses(c):return [nd.AND(fractal_fields(c,k)) for k in range(4)]
def INV(c):return nd.OR(clauses(c))
def unpack_clause(ctx,c,k):
 fs=fractal_fields(c,k);nd.unpack(ctx,fs);return fs
def fractal_even_push(ctx,old,new,eq):
 m.eq(ctx,new,M(two,old),[eq])
 m.bound(ctx,old,A(new,O),old,[eq])
 return m.bex_intro(ctx,frEven,A(new,O),Q(new,M(two,frEven)),old)
def fractal_closure():
 prem=b.And(INV(CF),STEP(CF,NF));goal=INV(NF)
 root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]))
 def region(ec,k):
  unpack_clause(ec,CF,k)
  def move(sc,j):
   pf=parts(TABLES['fractal'],CF,NF,j);nd.unpack(sc,pf)
   if j//2!=k:return contradiction(sc,CF[0],k,j//2,goal)
   if j==3:return contradiction(sc,CF[2],0,1,goal)
   if j==0:
    def evenright(vc):
     req=Q(CF[3],M(two,frFresh))
     m.eq(vc,A(M(two,NF[3]),NF[2]),A(M(two,frFresh),Z),[m.flip(vc,pf[4]),req])
     def bit(dc,t):
      m.bound(dc,num(t),two,num(1-t))
      return m.rewrite(dc,L(a.E,two),num(t),NF[2],dc.get(m.flip(dc,Q(NF[2],num(t)))))
     nd.cases(vc,list(pf[-1][1:]),L(NF[2],two),bit)
     m.bound(vc,Z,two,O)
     m.quotient_unique(vc,two,NF[3],NF[2],frFresh,Z)
     nd.conj(vc,fractal_fields(NF,1));return nd.disj(vc,clauses(NF),1)
    return m.bex_elim(sc,frEven,A(CF[3],O),Q(CF[3],M(two,frEven)),frFresh,goal,evenright)
   target={1:0,2:2,4:3,5:2,6:3,7:0}[j]
   if target==0:fractal_even_push(sc,CF[3],NF[3],pf[3])
   nd.conj(sc,fractal_fields(NF,target))
   return nd.disj(sc,clauses(NF),target)
  return nd.cases(ec,[nd.AND(parts(TABLES['fractal'],CF,NF,j)) for j in range(8)],goal,move)
 nd.cases(ctx,clauses(CF),goal,region)
 finish('skelet17-ladder-fractal-local',root,prem,goal,ctx,
        'Parity safety invariant for the four-state fractal. Excludes B1 without a recursive macro analysis. No induction.')
fractal_closure()
fsrc=cs.replace('skelet17-ladder-counter-','skelet17-ladder-fractal-').replace("'ladderCounterOffset'","'ladderFractalOffset'")
shim=types.SimpleNamespace(nd=nd,b=b,a=a,declare=m.declare,finish=finish,use=use,CF=CF,NF=NF,INV=INV,STEP=STEP)
h={'m':shim};exec(compile(fsrc,'fractal_history_generated.py','exec'),h)
(p/'fractal_history_generated.py').write_text(fsrc)
fep=(p/'ladder_endpoint.py').read_text().replace('ladderInitial','fractalInitial').replace('skelet17-ladder-cycler-','skelet17-ladder-fractal-')
initial='''nd.unpack(ac,[Q(v,Z) for v in fresh])
 m.eq(ac,fresh[3],M(two,Z),[Q(fresh[3],Z)])
 m.bound(ac,Z,A(fresh[3],O),Z,[Q(fresh[3],Z)])
 m.bex_intro(ac,frEven,A(fresh[3],O),Q(fresh[3],M(two,frEven)),Z)
 nd.conj(ac,fractal_fields(fresh,0));nd.disj(ac,clauses(fresh),0)'''
fep=fep.replace('nd.disj(ac,[cfg(fresh,v) for v in CYCLE],0)',initial)
fep=fep.replace('nd.unpack(ec,[Q(v,num(z)) for v,z in zip(NF,CYCLE[k])])\n return contradiction(ec,NF[0],CYCLE[k][0],5,bad)',
                'unpack_clause(ec,NF,k)\n return contradiction(ec,NF[0],k,5,bad)')
fep=fep.replace('nd.cases(ctx,[cfg(NF,v) for v in CYCLE],bad,exclude)','nd.cases(ctx,clauses(NF),bad,exclude)')
exec(compile(fep,'fractal_endpoint_generated.py','exec'),globals())
(p/'fractal_endpoint_generated.py').write_text(fep)
