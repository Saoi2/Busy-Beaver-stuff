# Complete odd canonical boundary composition

The theorem skelet17-ladder-skelet10-odd-boundary-cycle is proved in the
single canonical file idelta0_machines.mm. This stage was regenerated
from the recorded construction after the unsaved workspace was lost.
Its full proof is verified again; earlier verification is not used as an axiom.

Write W=2L+b. Fix an arbitrary original bounded beta history with TOTAL,
STEPS, length N, offset o, bound H and an alleged final halt. Assume a
bounded decoded current row c at k<N+1 satisfying the odd canonical clause:
q=D, b<2, Sparse(n), Sparse(R), and bounded witnesses a,t,v such that
n=4a+1, W=4t+2, T(a,t), R=2v, J(a,v). The existential bounds are
exactly those in SKELET10_BOUNDARY_CONNECTIONS.md. They belong to the
proof invariant; no invariant or phase is added to the history definition.

The conclusion constructs e<N+1 and a quadruple d below H with
k<e, At_o(e,d), and Boundary(R(c),d). Thus the next canonical input is
old R, automatically below H. No intermediate alignment or routine
output is supplied as a hypothesis.

## Proof construction

Two existing Sparse pop rules give Sparse(a) from Sparse(4a+1).
Advance twice using the ordinary supplied history and the D0,C1 alignment.
The actual D row has W=t and right half 4R(c)+3, so it satisfies the
complete left-routine entry with input a and tail old R. A bounded
additive remaining-length witness permits application of the embedded
left barrier in the SAME original history.

Its strictly later A output has whole-right old R and a bounded
transformed output z with J(a,z), T(z,L), Sparse(z). Sparse carry
uniqueness identifies z with the already tracked v. Hence this actual
A row has T(v,L), Sparse(v), and whole-right 2v. Advance once. The
even-whole-right entry theorem derives its zero scanned bit and proves
that its ordinary A0 successor enters the right routine with input v
and left target equal to the actual A left coordinate.

The embedded right barrier supplies a strictly later D output with
W equal to that target, J(v,R), Sparse(R), and a derived bit bound.
Equality transports T(v,L) to T(v,W). The existing even-boundary
constructor gives Boundary(2v,d), and old R=2v gives the requested
Boundary(old R,d). Combine strict index inequalities and discharge all
bounded intermediate witnesses by natural deduction.

## Strength, checking and remaining work

No new induction construction or axiom is added. The proof graph reuses
four existing bounded-induction constructions: division, the left routine
history induction, the right routine history induction, and carry
uniqueness. These counts describe this proof, not a lower bound.

check_skelet10_odd_cycle.py reconstructs the whole public formula
independently and checks its Delta-0 form. Its 144 numerical odd cycles
cover 2,720 ordinary moves, with maximum checked cycle length 50. These
are supplementary examples; the Metamath kernel checks the universal proof.

The machine remains 1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB, with E0
completed by the same 1RZ transition. The tape and raw history definitions
are unchanged. Both even numerical cases are now also proved; see
SKELET10_EVEN_ZERO_CYCLE.md and SKELET10_EVEN_ONE_CYCLE.md. At this component stage the general combination, global induction
and blank-start connection were still pending; they are now complete. No whole-machine nonhalting theorem is claimed here.

## Current project endpoint

The general case combination, bounded maximum argument and ordinary
blank-start nonhalting endpoint are now proved. The case-level discussion
above records the numerical component; SKELET10_NONHALTING.md and STATUS.md
give the completed global result and current verification status.
