"""The odd canonical boundary composition in the original supplied history."""
def add_skelet10_odd_cycle(m,api,sp,right,left,h,assembly,bd,align,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 H,N,o,k=[h[x] for x in ('H','n','offset','start')];AT=h['AT'];cf,nf=api['current'],api['next']
 two,three,four=map(ar.num,(2,3,4));T=sp['transform'];J=right['carry'];sparse=api['sparse'];step=api['step']
 apply,unpack,collect,elim_rows,pack_rows,bounds=[assembly[x] for x in ('apply','unpack','collect','elim_rows','pack_rows','bounds')]
 halt=assembly['halt'];ninput=m.declare('cycleInput','term')
 rem,gap=m.declare('cycleRemainingValue'),m.declare('cycleRemainingGap')
 outindex=m.declare('cycleOutputIndex');outrow=[m.declare('cycleOutput'+s) for s in ('Q','L','Bit','R')]
 aa,tt,vv=[m.declare('cycleOdd'+s) for s in ('A','T','V')]
 r1=[m.declare('cycleOddFirst'+s) for s in ('Q','L','Bit','R')]
 r2=[m.declare('cycleOddSecond'+s) for s in ('Q','L','Bit','R')]
 re=[m.declare('cycleOddRightEntry'+s) for s in ('Q','L','Bit','R')]
 def wl(row):return A(M(two,row[1]),row[2])
 def wr(row):return A(M(two,row[3]),row[2])
 def remaining():
  i,u=b.t,b.u;prem=L(i,A(u,O));goal=nd.BEX(rem,A(u,O),Q(A(i,rem),u))
  root=nd.Ctx();c=root.push(prem);apply(c,'skelet17-binary-below-successor',{'t':i,'u':u})
  def kind(dc,j):
   if j==1:
    m.bound(dc,Z,A(u,O),u);m.eq(dc,A(i,Z),u,[Q(i,u)])
    return m.bex_intro(dc,rem,A(u,O),Q(A(i,rem),u),Z)
   def found(ec,eq):
    val=A(gap,O);m.bound(ec,val,A(u,O),i,[eq]);m.eq(ec,A(i,val),u,[eq])
    return m.bex_intro(ec,rem,A(u,O),Q(A(i,rem),u),val)
   return m.gap_elim(dc,i,u,gap,goal,found)
  nd.cases(c,[L(i,u),Q(i,u)],goal,kind)
  m.finish('z10-compose-remaining-length',root,prem,goal,c,'A bounded additive remaining-length witness, without subtraction or induction.')
 def safe(c,row,state):
  bad=Q(row[0],ar.num(5));goal=b.Not(bad);dc=c.push(bad);false=L(Z,Z)
  dc.put(false,api['neq'](dc,row[0],state,5,false));dc.put(b.Not(false),b.ax('O1',dc.g,t=Z))
  return c.put(goal,ar.not_intro(c.g,bad,false,dc.get(false),dc.get(b.Not(false))))
 def advance(c,row,i,state,newrow,goal,fn):
  safe(c,row,state);mp={h['index'][1]:i,**{v[1]:x for v,x in zip(cf,row)}}
  apply(c,'skelet17-ladder-history-advance-before-halt',mp);m.ltadd(c,i,N,O)
  def found(dc):unpack(dc,b.And(AT(o,A(i,O),newrow),step(row,newrow)));return fn(dc)
  return elim_rows(c,h['TV'],b.And(AT(o,A(i,O),h['TV']),step(row,h['TV'])),newrow,goal,found)
 def run_counter(c,kind,row,i,params,goal,fn):
  routine=right if kind=='right' else left
  rr=m.declare('cycle'+kind.title()+'Remaining');ei=m.declare('embedded'+kind.title()+'AbsoluteIndex')
  er=[m.declare('embedded'+kind.title()+'OutputRow'+s) for s in ('Q','L','Bit','R')]
  wi=m.declare('cycle'+kind.title()+'ExitIndex');rows=[m.declare('cycle'+kind.title()+'ExitRow'+s) for s in ('Q','L','Bit','R')]
  apply(c,'z10-compose-remaining-length',{'t':i,'u':N})
  def have_length(dc):
   mp={h['start'][1]:i,h['length'][1]:rr,**params,**{v[1]:x for v,x in zip(cf,row)}}
   f=apply(dc,'skelet17-ladder-skelet10-'+kind+'-embedded-halting-barrier',mp)
   def result(j,rc):return nd.AND([L(i,j),AT(o,j,rc),m.sub(routine['endpoint'](rc),params),L(rc[2],two)])
   assert f==nd.BEX(ei,A(N,O),nd.bexs(er,H,result(ei,er)))
   def have_index(ic):
    def have_rows(rc):unpack(rc,result(wi,rows));return fn(rc,wi,rows)
    return elim_rows(ic,er,result(wi,er),rows,goal,have_rows)
   return m.bex_elim(dc,ei,A(N,O),nd.bexs(er,H,result(ei,er)),wi,goal,have_index)
  return m.bex_elim(c,rem,A(N,O),Q(A(i,rem),N),rr,goal,have_length)
 def prove():
  fs=[h['total'](o,N),h['steps'](o,N),*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5)),*bounds(cf),L(k,A(N,O)),AT(o,k,cf),Q(cf[0],three),L(cf[2],two),sparse(ninput),sparse(cf[3]),bd['odd'](ninput,cf)]
  prem=nd.AND(fs)
  def result(i,row):return nd.AND([L(k,i),AT(o,i,row),bd['boundary'](cf[3],row)])
  goal=nd.BEX(outindex,A(N,O),nd.bexs(outrow,H,result(outindex,outrow)))
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);ba,bt,bv=bd['ba'],bd['bt'],bd['bv']
  def odd_fields(a,t,v):return [Q(ninput,A(M(four,a),O)),Q(wl(cf),A(M(four,t),two)),T(a,t),Q(cf[3],M(two,v)),J(a,v)]
  def have_a(ac):
   def have_t(tc):
    def have_v(vc):
     fields=odd_fields(aa,tt,vv);nd.unpack(vc,fields)
     m.rewrite(vc,sparse(ar.E),ninput,A(M(four,aa),O));m.bound(vc,O,two,Z);m.eq(vc,A(M(four,aa),O),A(M(two,M(two,aa)),O))
     apply(vc,'skelet17-ladder-skelet10-sparse-pop',{'t':A(M(four,aa),O),'u':M(two,aa),'v':O})
     m.bound(vc,Z,two,O);m.eq(vc,M(two,aa),A(M(two,aa),Z));apply(vc,'skelet17-ladder-skelet10-sparse-pop',{'t':M(two,aa),'u':aa,'v':Z})
     def first(dc):
      apply(dc,'z10-align-d0',{'t':tt,**{v[1]:x for v,x in zip(nf,r1)}})
      def second(ec):
       apply(ec,'skelet17-ladder-skelet10-left-entry-two-step',{'t':tt,**{v[1]:x for v,x in zip(align['middle'],r1)},**{v[1]:x for v,x in zip(nf,r2)}})
       m.rewrite(ec,T(aa,ar.E),tt,wl(r2),ar.sym(wl(r2),tt,ec.get(Q(wl(r2),tt)),ec.g))
       leftparams={left['word'][1]:aa,left['tail'][1]:cf[3]};collect(ec,m.sub(left['entry'](r2),leftparams))
       def left_output(lc,li,lr):
        apply(lc,'skelet17-ladder-skelet10-left-output-identify',{'t':aa,'v':vv,'w':cf[3],**{v[1]:x for v,x in zip(cf,lr)}})
        m.eq(lc,wr(lr),M(two,vv),[Q(wr(lr),cf[3]),fields[3]])
        def enter_right(rc):
         apply(rc,'skelet17-ladder-skelet10-even-right-enters-counter',{'t':vv,**{v[1]:x for v,x in zip(cf,lr)},**{v[1]:x for v,x in zip(nf,re)}})
         rightparams={right['word'][1]:vv,right['ell'][1]:lr[1]}
         def right_output(fc,fi,fr):
          m.rewrite(fc,T(vv,ar.E),lr[1],wl(fr),ar.sym(wl(fr),lr[1],fc.get(Q(wl(fr),lr[1])),fc.g))
          apply(fc,'skelet17-ladder-skelet10-boundary-even-output',{'t':vv,**{v[1]:x for v,x in zip(cf,fr)}})
          m.rewrite(fc,bd['boundary'](ar.E,fr),M(two,vv),cf[3],ar.sym(cf[3],M(two,vv),fc.get(fields[3]),fc.g))
          k2=A(A(k,O),O);m.bound(fc,k,k2,O);m.translt(fc,k,k2,li);m.successor(fc,li);m.translt(fc,k,li,A(li,O));m.translt(fc,k,A(li,O),fi)
          nd.conj(fc,[L(k,fi),AT(o,fi,fr),bd['boundary'](cf[3],fr)]);pack_rows(fc,outrow,result(fi,outrow),fr)
          return m.bex_intro(fc,outindex,A(N,O),nd.bexs(outrow,H,result(outindex,outrow)),fi)
         return run_counter(rc,'right',re,A(li,O),rightparams,goal,right_output)
        return advance(lc,lr,li,0,re,goal,enter_right)
       return run_counter(ec,'left',r2,A(A(k,O),O),leftparams,goal,left_output)
      return advance(dc,r1,A(k,O),2,r2,goal,second)
     return advance(vc,cf,k,3,r1,goal,first)
    return m.bex_elim(tc,bv,A(cf[3],O),nd.AND(odd_fields(aa,tt,bv)),vv,goal,have_v)
   return m.bex_elim(ac,bt,A(wl(cf),O),nd.BEX(bv,A(cf[3],O),nd.AND(odd_fields(aa,bt,bv))),tt,goal,have_t)
  m.bex_elim(c,ba,A(ninput,O),nd.BEX(bt,A(wl(cf),O),nd.BEX(bv,A(cf[3],O),nd.AND(odd_fields(ba,bt,bv)))),aa,goal,have_a)
  m.finish('skelet17-ladder-skelet10-odd-boundary-cycle',root,prem,goal,c,'Complete odd canonical boundary-to-boundary composition in the same raw history. Constructs all finite alignments, both routine outputs and the next boundary with input old R. No new induction construction or axioms.')
 if proofs:remaining();prove()
 return {'input':ninput,'output_index':outindex,'output_row':outrow,'advance':advance,'run_counter':run_counter,'safe':safe,'remaining':remaining}
