"""Finite regression tests. These do not replace Metamath proofs."""
from pathlib import Path
from math import lcm,prod
import json
TABLE=[(1,1,1),(5,1,1),(2,0,0),(4,1,1),(3,0,0),
       (2,0,1),(0,1,1),(1,0,1),(1,1,0),(0,1,0)]
def step(c):
    q,l,b,r=c
    if q==5:return None
    nq,d,w=TABLE[2*q+b]
    return (nq,2*l+w,r%2,r//2) if d else (nq,l//2,l%2,2*r+w)
def right_product(c):
    q,l,b,r=c;x=b+2*r
    return (3*l+2)*(3*x+1) if q==1 else (3*l+1)*(3*x+2)
def left_product(c,phase):
    q,l,b,r=c;y=b+2*l
    return (3*r+1+phase)*(3*y+2-phase)
counts={'right_steps':0,'left_steps':0,'four_left_moves':0,'three_step_characterizations':0,'coded_scan_windows':0}
for q in range(5):
    for l in range(16):
        for b in range(2):
            for r in range(64):
                c=(q,l,b,r);d=step(c)
                idx=2*q+b
                if idx in (3,8):
                    assert right_product(c)==right_product(d);counts['right_steps']+=1
                if idx in (4,7,2,5):
                    assert left_product(c,b)==left_product(d,1-b);counts['left_steps']+=1
                seq=[c,d]
                for _ in range(2):
                    if seq[-1][0]==5:break
                    seq.append(step(seq[-1]))
                if len(seq)==4:
                    mid2=seq[2]
                    danger=q==1 and b==1 and r==4*mid2[3]+3
                    assert (seq[-1][0]==5)==danger
                    counts['three_step_characterizations']+=1
for r in range(16):
    for tail in range(64):
        y=16*tail+10;c=(2,y//2,y%2,r);seq=[c]
        for i in range(4):seq.append(step(seq[-1]))
        assert [x[0] for x in seq]==[2,3,1,2,2]
        assert left_product(seq[0],0)==left_product(seq[-1],0)
        assert seq[-1][3]==16*r+5
        assert seq[-1][2]+2*seq[-1][1]==tail
        counts['four_left_moves']+=1
def crt(values,mods):
    modulus=prod(mods)
    return sum(v*(modulus//m)*pow(modulus//m,-1,m) for v,m in zip(values,mods))%modulus
for pairs in range(1,6):
    for offset in (0,7):
        x=sum(1<<(2*i) for i in range(pairs));seq=[(1,3,1,x//2)]
        # Stop in E, with the last 0 not yet consumed: a truncated scan.
        for i in range(2*pairs-1):seq.append(step(seq[-1]))
        n=len(seq)-1;C=lcm(*range(1,n+1))*(1+max(max(c) for c in seq))
        mods=[1+(offset+i+1)*C for i in range(n+1)]
        Bs=[crt([c[j] for c in seq],mods) for j in range(4)]
        H=1+max(*Bs,C,*[v for c in seq for v in c])
        K=right_product(seq[0])
        for i,c in enumerate(seq):
            assert right_product(c)==K
            for j,v in enumerate(c):
                quotient,remainder=divmod(Bs[j],mods[i])
                assert remainder==v and quotient<H and v<H
        assert seq[-1][0]==4
        counts['coded_scan_windows']+=1
out={'counts':counts,'purpose':'Finite regression tests, not a proof of nonhalting.'}
Path(__file__).with_name('transition_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
