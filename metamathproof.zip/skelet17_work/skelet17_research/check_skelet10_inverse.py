"""Independent reconstruction of six decoding statements and finite checks."""
from pathlib import Path
import json
from check_skelet10_scope import parse,plus,times,eq,lt,implies,both,AND,num,EX
from check_skelet10_left import norm
from check_skelet10_spread import dil,transform,bit,graph,spread,bounded
P=Path(__file__).resolve().parent
TWO,FOUR,TEN=map(num,(2,4,10))
def push(x,d):return plus(times(TWO,x),d)
x,z,d,e='t','u','v','w';v='inverseOutputTail'
expect={
 'spread-low-digit':implies(AND([dil(push(x,d),push(z,e)),lt(d,TWO),lt(e,TWO)]),eq(d,e)),
 'spread-second-bit-zero':implies(dil(x,z),('-.',bit(z,TWO))),
 'spread-pop':implies(both(dil(push(x,d),plus(times(FOUR,z),d)),lt(d,TWO)),dil(x,z)),
 'spread-decompose':implies(both(dil(push(x,d),z),lt(d,TWO)),EX(v,plus(z,'1'),both(eq(z,plus(times(FOUR,v),d)),dil(x,v)))),
 'transform-pop-0':implies(transform(times(TWO,x),times(FOUR,z)),transform(x,z)),
 'transform-pop-10':implies(transform(plus(times(FOUR,x),'1'),plus(times(num(16),z),TEN)),transform(x,z)),
}
def main():
 actual=json.loads((P/'skelet10_inverse_theorems.json').read_text());assert len(actual)==len(expect)
 for name,f in expect.items():
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(f),label
  assert bounded(f),label
 count=0
 for x in range(16):
  for z in range(512):
   if graph(x,z):assert not ((z//2)%2)
   for d in (0,1):
    assert graph(2*x+d,4*z+d)==graph(x,z)
    if graph(2*x+d,z):assert z%4==d and graph(x,z//4) and z//4<=z
    for e in (0,1):
     if graph(2*x+d,2*z+e):assert d==e
    count+=1
 # Nonvacuous inverse examples, including both grammar branches.
 for x in range(128):
  t=10*spread(x)
  assert 10*spread(2*x)==4*t
  assert 10*spread(4*x+1)==16*t+10
 out={'statements_checked':len(expect),'all_expanded_statements_delta0':True,
  'independent_reconstruction_matches':True,'finite_decode_cases':count,
  'finite_transform_examples':128,'finite_tests_are_not_formal_proofs':True,
  'new_induction_constructions':0,'formal_graph_uniqueness_claimed':False,
  'whole_machine_nonhalting':False,'original_machine_history_encoding_unchanged':True}
 (P/'skelet10_inverse_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
