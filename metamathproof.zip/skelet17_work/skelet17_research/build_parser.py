"""Remove the totalized auxiliary parser transitions on valid words."""
import json
import build_annotations as n
m,nd,b,a=n.m,n.nd,n.b,n.a
A,M,Q,L,O,Z,N=n.A,n.M,n.Q,n.L,n.O,n.Z,n.N
two,eight=n.two,n.eight
eq,rewrite,bound,invoke,finish,save,flip=n.eq,n.rewrite,n.bound,n.invoke,n.finish,n.save,n.flip
aa,bb,cc,dd=[m.declare('parser'+s,'term') for s in ('A','B','C','D')]
def HIGH(v):return nd.OR([Q(v,a.num(i)) for i in range(4,8)])
ROWS=[(i,j) for i in range(8) for j in range(2)]
VALID=[(i,j) for i,j in ROWS if i>=4 or j==1]
def clause(av,bv,cv,i,j):return nd.AND([Q(av,a.num(i)),Q(bv,a.num(j)),Q(cv,a.num(n.TABLE[i][j]))])
def PARTIAL(av,bv,cv):return nd.OR([clause(av,bv,cv,i,j) for i,j in VALID])
def conflict(ctx,v,i,j,goal):
    lo,hi=sorted((i,j));ei=ctx.get(Q(v,a.num(i)));ej=ctx.get(Q(v,a.num(j)))
    p=a.trans(a.num(i),v,a.num(j),a.sym(v,a.num(i),ei,ctx.g),ej,ctx.g)
    if i>j:p=a.sym(a.num(i),a.num(j),p,ctx.g)
    bound(ctx,a.num(lo),a.num(hi),a.num(hi-lo-1))
    rewrite(ctx,L(a.num(lo),a.E),a.num(hi),a.num(lo),a.sym(a.num(lo),a.num(hi),p,ctx.g))
    bad=L(a.num(lo),a.num(lo));ctx.put(b.Not(bad),b.ax('O1',ctx.g,t=a.num(lo)));return ctx.explode(bad,goal)
def pending():
    fs=[n.DELTA(aa,bb,cc),Q(bb,O)];prem=b.And(*fs);goal=HIGH(cc)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    def branch(ec,k):
        i,j=ROWS[k];nd.unpack(ec,[Q(aa,a.num(i)),Q(bb,a.num(j)),Q(cc,a.num(n.TABLE[i][j]))])
        if j==0:return conflict(ec,bb,0,1,goal)
        return nd.disj(ec,[Q(cc,a.num(v)) for v in range(4,8)],n.TABLE[i][j]-4)
    nd.cases(ctx,[clause(aa,bb,cc,i,j) for i,j in ROWS],goal,branch)
    finish('skelet17-parser-one-sets-pending',root,prem,goal,ctx)
pending()
def compatible():
    guard=b.Or(Q(bb,O),HIGH(aa));fs=[n.DELTA(aa,bb,cc),guard];prem=b.And(*fs);goal=PARTIAL(aa,bb,cc)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    def branch(ec,k):
        i,j=ROWS[k];nd.unpack(ec,[Q(aa,a.num(i)),Q(bb,a.num(j)),Q(cc,a.num(n.TABLE[i][j]))])
        if (i,j) in VALID:return nd.disj(ec,[clause(aa,bb,cc,u,v) for u,v in VALID],VALID.index((i,j)))
        def guardcase(gc,l):
            if l==0:return conflict(gc,bb,0,1,goal)
            return nd.cases(gc,[Q(aa,a.num(v)) for v in range(4,8)],goal,lambda hc,k:conflict(hc,aa,i,k+4,goal))
        return nd.cases(ec,[Q(bb,O),HIGH(aa)],goal,guardcase)
    nd.cases(ctx,[clause(aa,bb,cc,i,j) for i,j in ROWS],goal,branch)
    finish('skelet17-parser-guarded-original-step',root,prem,goal,ctx)
compatible()

q1,r1,q2,r2=[m.declare('parser'+s) for s in ('Q1','R1','Q2','R2')]
def field_unique():
    fs=[L(aa,n.B),L(bb,n.B),n.FIELD(n.x,n.P,n.B,aa),n.FIELD(n.x,n.P,n.B,bb)]
    prem=nd.AND(fs);goal=Q(aa,bb);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    def firstq(qc):
        def firstr(rc):
            def secondq(sc):
                def secondr(tc):
                    w1=m.whole(n.P,n.B,q1,aa,r1);w2=m.whole(n.P,n.B,q2,bb,r2)
                    tc.put(Q(w1,w2),a.trans(w1,n.x,w2,a.sym(n.x,w1,tc.get(Q(n.x,w1)),tc.g),tc.get(Q(n.x,w2)),tc.g))
                    nd.conj(tc,[L(aa,n.B),L(r1,n.P),L(bb,n.B),L(r2,n.P),Q(w1,w2)])
                    invoke(tc,'skelet17-bounded-field-unique',{'t':n.P,'u':n.B,'fieldQA':q1,'fieldVA':aa,'fieldRA':r1,'fieldQB':q2,'fieldVB':bb,'fieldRB':r2})
                    nd.unpack(tc,[Q(q1,q2),goal,Q(r1,r2)]);return tc.get(goal)
                return m.bex_elim(sc,n.fr,n.P,Q(n.x,m.whole(n.P,n.B,q2,bb,n.fr)),r2,goal,secondr)
            return m.bex_elim(rc,n.fq,A(n.x,O),nd.BEX(n.fr,n.P,Q(n.x,m.whole(n.P,n.B,n.fq,bb,n.fr))),q2,goal,secondq)
        return m.bex_elim(qc,n.fr,n.P,Q(n.x,m.whole(n.P,n.B,q1,aa,n.fr)),r1,goal,firstr)
    m.bex_elim(ctx,n.fq,A(n.x,O),nd.BEX(n.fr,n.P,Q(n.x,m.whole(n.P,n.B,n.fq,aa,n.fr))),q1,goal,firstq)
    finish('skelet17-parser-field-value-unique',root,prem,goal,ctx)
field_unique()
def one_field():
    prem=m.bit1(n.x,n.P);goal=n.FIELD(n.x,n.P,two,O);root=nd.Ctx();ctx=root.push(prem)
    def first(ec):
        def second(cc):
            eq(cc,n.x,m.whole(n.P,two,q1,O,r1),[Q(n.x,A(A(M(q1,M(two,n.P)),n.P),r1))])
            m.bex_intro(cc,n.fr,n.P,Q(n.x,m.whole(n.P,two,q1,O,n.fr)),r1)
            return m.bex_intro(cc,n.fq,A(n.x,O),nd.BEX(n.fr,n.P,Q(n.x,m.whole(n.P,two,n.fq,O,n.fr))),q1)
        return m.bex_elim(ec,m.r,n.P,Q(n.x,A(A(M(q1,M(two,n.P)),n.P),m.r)),r1,goal,second)
    m.bex_elim(ctx,m.q,A(n.x,O),nd.BEX(m.r,n.P,Q(n.x,A(A(M(m.q,M(two,n.P)),n.P),m.r))),q1,goal,first)
    finish('skelet17-parser-one-field',root,prem,goal,ctx)
one_field()
def head_bit():
    fs=[L(n.P,A(n.x,O)),L(n.x,M(two,n.P)),L(bb,two),n.FIELD(n.x,n.P,two,bb)]
    prem=nd.AND(fs);goal=Q(bb,O);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    def haveq(qc):
        def haver(rc):
            xe=Q(n.x,m.whole(n.P,two,q1,bb,r1));rem=A(M(n.P,bb),r1);mod=M(two,n.P)
            rc.both(L(bb,two),L(r1,n.P));invoke(rc,'skelet17-binary-field-range',{'t':bb,'u':r1,'v':n.P,'w':two})
            eq(rc,M(n.P,two),mod);rewrite(rc,L(rem,a.E),M(n.P,two),mod)
            m.equal_via(rc,A(M(mod,q1),rem),A(M(mod,Z),n.x),flip(rc,xe))
            m.quotient_unique(rc,mod,q1,rem,Z,n.x)
            invoke(rc,'skelet17-binary-digit-cases',{'t':bb})
            def bit(ec,k):
                if k==1:return ec.get(goal)
                eq(ec,n.x,r1,[xe,Q(q1,Z),Q(bb,Z)]);rewrite(ec,L(a.E,n.P),r1,n.x,ec.get(flip(ec,Q(n.x,r1))))
                invoke(ec,'skelet17-binary-below-successor',{'t':n.P,'u':n.x})
                def order(cc,j):
                    if j==0:m.translt(cc,n.x,n.P,n.x)
                    else:rewrite(cc,L(n.x,a.E),n.P,n.x)
                    bad=L(n.x,n.x);cc.put(b.Not(bad),b.ax('O1',cc.g,t=n.x));return cc.explode(bad,goal)
                return nd.cases(ec,[L(n.P,n.x),Q(n.P,n.x)],goal,order)
            return nd.cases(rc,[Q(bb,Z),Q(bb,O)],goal,bit)
        return m.bex_elim(qc,n.fr,n.P,Q(n.x,m.whole(n.P,two,q1,bb,n.fr)),r1,goal,haver)
    m.bex_elim(ctx,n.fq,A(n.x,O),nd.BEX(n.fr,n.P,Q(n.x,m.whole(n.P,two,n.fq,bb,n.fr))),q1,goal,haveq)
    finish('skelet17-parser-leading-bit-one',root,prem,goal,ctx)
head_bit()
weight=m.declare('parserWeight')
na,nb,nc=[m.declare('parserNeighbor'+v) for v in ('A','B','C')]
def WORD(x):return nd.BALL(weight,A(x,O),b.Imp(b.And(m.power2(weight),L(M(two,weight),A(x,O))),b.Or(m.bit1(x,weight),m.bit1(x,M(two,weight)))))
def OBODY(x,S,p,a0,b0,c0):return nd.AND(n.list_body(x,S,p,a0,b0,c0)[:3]+[PARTIAL(a0,b0,c0)])
def OLOCAL(x,S,p):return nd.BEX(n.av,eight,nd.BEX(n.bv,two,nd.BEX(n.cv,eight,OBODY(x,S,p,n.av,n.bv,n.cv))))
def ORUN(x,S):return nd.BALL(n.place,A(x,O),b.Imp(m.power2(n.place),OLOCAL(x,S,n.place)))
def unpack_local(ctx,x,S,p,vs,goal,fn):
    va,vb,vc=vs
    def first(ac):
        def second(bc):
            def third(cc):
                nd.unpack(cc,n.list_body(x,S,p,va,vb,vc));return fn(cc)
            return m.bex_elim(bc,n.cv,eight,n.BODY(x,S,p,va,vb,n.cv),vc,goal,third)
        return m.bex_elim(ac,n.bv,two,nd.BEX(n.cv,eight,n.BODY(x,S,p,va,n.bv,n.cv)),vb,goal,second)
    return m.bex_elim(ctx,n.av,eight,nd.BEX(n.bv,two,nd.BEX(n.cv,eight,n.BODY(x,S,p,n.av,n.bv,n.cv))),va,goal,first)
def original_intro(ctx,p):
    aa0,bb0,cc0=n.af,n.bf,n.cf
    nd.conj(ctx,n.list_body(n.x,n.s,p,aa0,bb0,cc0)[:3]+[PARTIAL(aa0,bb0,cc0)])
    m.bex_intro(ctx,n.cv,eight,OBODY(n.x,n.s,p,aa0,bb0,n.cv),cc0)
    m.bex_intro(ctx,n.bv,two,nd.BEX(n.cv,eight,OBODY(n.x,n.s,p,aa0,n.bv,n.cv)),bb0)
    return m.bex_intro(ctx,n.av,eight,nd.BEX(n.bv,two,nd.BEX(n.cv,eight,OBODY(n.x,n.s,p,n.av,n.bv,n.cv))),aa0)
def value_unique(ctx,x,p,base,v,w):
    nd.conj(ctx,[L(v,base),L(w,base),n.FIELD(x,p,base,v),n.FIELD(x,p,base,w)])
    return invoke(ctx,'skelet17-parser-field-value-unique',{'annInput':x,'annScale':p,'annBase':base,'parserA':v,'parserB':w})
def force_one(ctx,p,v):
    invoke(ctx,'skelet17-parser-one-field',{'annScale':p})
    bound(ctx,O,two,Z);return value_unique(ctx,n.x,p,two,v,O)
def original_step(ctx,p,high=False):
    guard=b.Or(Q(n.bf,O),HIGH(n.af));nd.disj(ctx,[Q(n.bf,O),HIGH(n.af)],1 if high else 0)
    ctx.both(n.DELTA(n.af,n.bf,n.cf),guard)
    invoke(ctx,'skelet17-parser-guarded-original-step',{'parserA':n.af,'parserB':n.bf,'parserC':n.cf})
    return original_intro(ctx,p)
def eliminate_totalization():
    fs=[WORD(n.x),n.RUN(n.x,n.s)];prem=b.And(*fs);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    p=n.pf;guard=L(p,A(n.x,O));gc=ctx.push(guard);pc=gc.push(m.power2(p));goal=OLOCAL(n.x,n.s,p)
    _,pr=pc.all_elim(n.place,n.RUN(n.x,n.s)[2],p);pc.mp(guard,b.Imp(m.power2(p),n.LOCAL(n.x,n.s,p)),pr);pc.mp(m.power2(p),n.LOCAL(n.x,n.s,p))
    def current(ec):
        top=M(two,p);upper=A(n.x,O);tri=[L(top,upper),Q(top,upper),L(upper,top)]
        ec.put(nd.OR(tri),b.ax('O3',ec.g,t=top,u=upper))
        def region(rc,k):
            if k:
                m.successor(rc,n.x)
                if k==1:rewrite(rc,L(n.x,a.E),upper,top,rc.get(flip(rc,Q(top,upper))))
                else:m.translt(rc,n.x,upper,top)
                nd.conj(rc,[guard,L(n.x,top),L(n.bf,two),n.FIELD(n.x,p,two,n.bf)])
                invoke(rc,'skelet17-parser-leading-bit-one',{'annScale':p,'parserB':n.bf})
                return original_step(rc,p)
            _,wp=rc.all_elim(weight,WORD(n.x)[2],p);ante=b.And(m.power2(p),L(top,upper));rc.both(*ante[1:])
            choices=b.Or(m.bit1(n.x,p),m.bit1(n.x,top))
            rc.mp(guard,b.Imp(ante,choices),wp);rc.mp(ante,choices)
            def which(wc,j):
                if j==0:
                    force_one(wc,p,n.bf);return original_step(wc,p)
                invoke(wc,'skelet17-binary-power-double',{'t':p})
                _,tp=wc.all_elim(n.place,n.RUN(n.x,n.s)[2],top)
                wc.mp(L(top,upper),b.Imp(m.power2(top),n.LOCAL(n.x,n.s,top)),tp);wc.mp(m.power2(top),n.LOCAL(n.x,n.s,top))
                def neighbor(hc):
                    force_one(hc,top,nb);hc.both(n.DELTA(na,nb,nc),Q(nb,O))
                    invoke(hc,'skelet17-parser-one-sets-pending',{'parserA':na,'parserB':nb,'parserC':nc})
                    value_unique(hc,n.s,n.cube(top),eight,nc,n.af)
                    rewrite(hc,HIGH(a.E),nc,n.af)
                    return original_step(hc,p,True)
                return unpack_local(wc,n.x,n.s,top,[na,nb,nc],goal,neighbor)
            return nd.cases(rc,list(choices[1:]),goal,which)
        return nd.cases(ec,tri,goal,region)
    unpack_local(pc,n.x,n.s,p,[n.af,n.bf,n.cf],goal,current)
    gc.intro(m.power2(p),goal,pc);ctx.intro(guard,b.Imp(m.power2(p),goal),gc);ctx.all_intro(p,b.Imp(guard,b.Imp(m.power2(p),goal)))
    m.rename_all(ctx,p,n.place,lambda w:b.Imp(L(w,A(n.x,O)),b.Imp(m.power2(w),OLOCAL(n.x,n.s,w))))
    finish('skelet17-parser-valid-word-removes-totalization',root,prem,ORUN(n.x,n.s),ctx,
           'Every locally annotated valid word satisfies the original partial parser table at every significant binary place. No artificial parser transition survives. No output or nonhalting theorem.')
eliminate_totalization()
def OCERT_BODY(x,p,S):return nd.AND([m.power2(p),L(x,M(two,p)),L(S,M(eight,n.cube(p))),ORUN(x,S)])
def original_certificate():
    fs=[WORD(n.x),L(Z,n.x)];prem=b.And(*fs)
    goal=nd.BEX(n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),OCERT_BODY(n.x,n.lead,n.codevar)))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    invoke(ctx,'skelet17-annotation-positive-certificate')
    def haveplace(pc):
        def havecode(sc):
            nd.unpack(sc,[m.power2(n.lp),L(n.x,M(two,n.lp)),L(n.st,M(eight,n.cube(n.lp))),n.RUN(n.x,n.st)])
            sc.both(WORD(n.x),n.RUN(n.x,n.st));invoke(sc,'skelet17-parser-valid-word-removes-totalization',{'annStates':n.st})
            nd.conj(sc,[m.power2(n.lp),L(n.x,M(two,n.lp)),L(n.st,M(eight,n.cube(n.lp))),ORUN(n.x,n.st)])
            m.bex_intro(sc,n.codevar,n.K(n.x),OCERT_BODY(n.x,n.lp,n.codevar),n.st)
            return m.bex_intro(sc,n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),OCERT_BODY(n.x,n.lead,n.codevar)),n.lp)
        return m.bex_elim(pc,n.codevar,n.K(n.x),n.CERT_BODY(n.x,n.lp,n.codevar),n.st,goal,havecode)
    m.bex_elim(ctx,n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),n.CERT_BODY(n.x,n.lead,n.codevar)),n.lp,goal,haveplace)
    finish('skelet17-parser-original-certificate-exists',root,prem,goal,ctx,
           'Every positive valid word has a polynomially bounded control certificate using only the original twelve parser transitions. Does not include EOF or output compression.')
original_certificate()
def write():
    (m.P/'parser_raw.mm').write_text('\n'.join(b.lines)+'\n')
    (m.P/'parser_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if 'parser-' in k},indent=2)+'\n')
if __name__=='__main__':write()
