"""Bounded bit-spreading relation for Skelet #10. No new function symbols."""
def add_skelet10_spread(m,stage='all',proofs=True):
 nd,b,a=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 two,four,ten=map(a.num,(2,4,10));use=m.invoke
 def sq(x):return M(x,x)
 def push(x,d):return A(M(two,x),d)
 def bp(x,p,q,r):return Q(x,A(A(M(q,M(two,p)),p),r))
 aq,ar,bq,br,rr,rb=[m.declare('dil'+s) for s in ('Q','R','OtherQ','OtherR','HalfR','RBit')]
 gap=m.declare('dilGap')
 def pack_bit(c,x,p,q,r):
  m.bex_intro(c,m.r,p,bp(x,p,q,m.r),r)
  return m.bex_intro(c,m.q,A(x,O),nd.BEX(m.r,p,bp(x,p,m.q,m.r)),q)
 def bit_elim(c,x,p,goal,fn,q=aq,r=ar):
  return m.bex_elim(c,m.q,A(x,O),nd.BEX(m.r,p,bp(x,p,m.q,m.r)),q,goal,
   lambda qc:m.bex_elim(qc,m.r,p,bp(x,p,q,m.r),r,goal,lambda rc:fn(rc,q,r,bp(x,p,q,r))))
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+name,root,prem,goal,c,comment)
 def bit_support():
  x,p=b.t,b.u;prem=m.bit1(x,p);root=nd.Ctx();c=root.push(prem);goal=L(p,A(x,O))
  bit_elim(c,x,p,goal,lambda cc,q,r,eq:m.bound(cc,p,A(x,O),A(M(q,M(two,p)),r),[eq]))
  finish('bit-support-bound',root,prem,goal,c,'A one bit at place p implies p<=x. No induction.')
  root=nd.Ctx();prem=L(Z,p);c=root.push(prem);bc=c.push(m.bit1(Z,p));bad=L(Z,Z)
  def impossible(cc,q,r,eq):
   def positive(dc,pg):
    value=eq[2];m.bound(dc,Z,value,A(A(M(q,M(two,p)),gap),r),[pg])
    m.rewrite(dc,L(Z,a.E),value,Z,a.sym(Z,value,dc.get(eq),dc.g));return dc.get(bad)
   return m.gap_elim(cc,Z,p,gap,bad,positive)
  bit_elim(bc,Z,p,bad,impossible);bc.put(b.Not(bad),b.ax('O1',bc.g,t=Z))
  c.put(b.Not(m.bit1(Z,p)),a.not_intro(c.g,m.bit1(Z,p),bad,bc.get(bad),bc.get(b.Not(bad))))
  finish('zero-has-no-one-bit',root,prem,b.Not(m.bit1(Z,p)),c,'Zero has no one bit at any positive place. No induction.')
 if proofs: bit_support()
 def bit_push_forward():
  x,p,d=b.t,b.u,b.v;new=push(x,d);scale=M(two,p)
  fs=[m.bit1(x,p),L(d,two)];prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);goal=m.bit1(new,scale)
  def found(cc,q,r,eq):
   low=push(r,d);cc.both(L(r,p),L(d,two));use(cc,'skelet17-binary-field-range',{'t':r,'u':d,'v':two,'w':p})
   m.bound(cc,x,A(new,O),A(x,d));nd.conj(cc,[L(q,A(x,O)),L(x,A(new,O))])
   use(cc,'skelet17-binary-le-lt-trans',{'t':q,'u':x,'v':A(new,O)})
   m.eq(cc,*bp(new,scale,q,low)[1:],[eq]);return pack_bit(cc,new,scale,q,low)
  bit_elim(c,x,p,goal,found)
  finish('bit-push-forward',root,prem,goal,c,'Appending a binary digit shifts every old one bit to twice its place. No induction.')
 if proofs: bit_push_forward()
 def bit_push_back():
  x,p,d=b.t,b.u,b.v;new=push(x,d)
  fs=[L(Z,p),L(d,two),m.bit1(new,M(two,p))];prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);goal=m.bit1(x,p)
  def found(cc,q,r,eq):
   m.bound(cc,Z,two,O);use(cc,'skelet17-bounded-division-exists',{'t':r,'u':two})
   def halfq(qc):
    def halfr(rc):
     re=Q(r,push(rr,rb));m.eq(rc,new,push(A(A(M(q,M(two,p)),p),rr),rb),[eq,re])
     m.quotient_unique(rc,two,x,d,A(A(M(q,M(two,p)),p),rr),rb)
     m.rewrite(rc,L(a.E,M(two,p)),r,push(rr,rb),rc.get(re))
     use(rc,'skelet17-ladder-skelet10-double-window-bound',{'t':rr,'u':p,'v':rb})
     xe=bp(x,p,q,rr)
     def positive(dc,pg):
      return m.bound(dc,q,A(x,O),A(A(M(q,A(M(two,gap),O)),p),rr),[xe,pg])
     m.gap_elim(rc,Z,p,gap,L(q,A(x,O)),positive)
     return pack_bit(rc,x,p,q,rr)
    return m.bex_elim(qc,m.r,two,Q(r,push(rr,m.r)),rb,goal,halfr)
   return m.bex_elim(cc,m.q,A(r,O),nd.BEX(m.r,two,Q(r,push(m.q,m.r))),rr,goal,halfq)
  bit_elim(c,new,M(two,p),goal,found)
  finish('bit-push-back',root,prem,goal,c,'A one bit above the appended digit comes from the old word. Reuses bounded division; no new induction.')
 if proofs: bit_push_back()
 def bit_low():
  x,d=b.t,b.u;new=push(x,d);prem=L(d,two);root=nd.Ctx();c=root.push(prem)
  bc=c.push(m.bit1(new,O))
  def found(cc,q,r,eq):
   m.eq(cc,O,A(Z,O));m.rewrite(cc,L(r,a.E),O,A(Z,O))
   use(cc,'skelet17-binary-below-successor',{'t':r,'u':Z})
   def rem(dc,k):
    if k==0:
     dc.put(b.Not(L(r,Z)),b.ax('O4',dc.g,t=r));return dc.explode(L(r,Z),Q(d,O))
    m.eq(dc,push(x,d),push(q,O),[eq,Q(r,Z)])
    m.bound(dc,O,two,Z);m.quotient_unique(dc,two,x,d,q,O);return dc.get(Q(d,O))
   return nd.cases(cc,[L(r,Z),Q(r,Z)],Q(d,O),rem)
  bit_elim(bc,new,O,Q(d,O),found);c.intro(m.bit1(new,O),Q(d,O),bc)
  dc=c.push(Q(d,O));m.bound(dc,Z,O,Z);m.bound(dc,x,A(new,O),A(x,d))
  m.eq(dc,*bp(new,O,x,Z)[1:],[Q(d,O)]);pack_bit(dc,new,O,x,Z)
  c.intro(Q(d,O),m.bit1(new,O),dc)
  goal=b.And(b.Imp(m.bit1(new,O),Q(d,O)),b.Imp(Q(d,O),m.bit1(new,O)));c.both(*goal[1:])
  finish('bit-low-digit',root,prem,goal,c,'The low bit of 2x+d is one exactly when d=1, for d<2. No induction.')
 if proofs: bit_low()
 def low_use(c,x,d):
  use(c,'skelet17-ladder-skelet10-bit-low-digit',{'t':x,'u':d});f=m.sub(m.theorems['skelet17-ladder-skelet10-bit-low-digit'],{'t':x,'u':d})[2];nd.unpack(c,list(f[1:]));return f
 def forward(c,x,p,d):
  nd.conj(c,[m.bit1(x,p),L(d,two)]);return use(c,'skelet17-ladder-skelet10-bit-push-forward',{'t':x,'u':p,'v':d})
 def back(c,x,p,d):
  nd.conj(c,[L(Z,p),L(d,two),m.bit1(push(x,d),M(two,p))]);return use(c,'skelet17-ladder-skelet10-bit-push-back',{'t':x,'u':p,'v':d})
 if stage=='bits':return
 # Paired support clauses: no output bit is left unconstrained.
 fp,bpvar,wp=[m.declare('dil'+s) for s in ('ForwardPlace','BackPlace','WitnessPlace')]
 pf,pb,pw=[m.declare('dilFresh'+s) for s in ('ForwardPlace','BackPlace','WitnessPlace')]
 half1,half2=[m.declare('dilScale'+s) for s in ('Half','Quarter')]
 def fbody(x,z,p):return b.Imp(b.And(m.power2(p),m.bit1(x,p)),m.bit1(z,sq(p)))
 def wbody(x,q,p):return nd.AND([m.power2(p),Q(q,sq(p)),m.bit1(x,p)])
 def witness(x,q):return nd.BEX(wp,A(x,O),wbody(x,q,wp))
 def rbody(x,z,q):return b.Imp(b.And(m.power2(q),m.bit1(z,q)),witness(x,q))
 def fwd(x,z):return nd.BALL(fp,A(x,O),fbody(x,z,fp))
 def rev(x,z):return nd.BALL(bpvar,A(z,O),rbody(x,z,bpvar))
 def dil(x,z):return b.And(fwd(x,z),rev(x,z))
 def universal(c,v,upper,body,fn):
  guard=L(v,upper);gc=c.push(guard);gc.put(body,fn(gc));c.intro(guard,body,gc);c.all_intro(v,b.Imp(guard,body))
 def fresh_fwd(c,x,z,fn):
  universal(c,pf,A(x,O),fbody(x,z,pf),fn)
  return m.rename_all(c,pf,fp,lambda p:b.Imp(L(p,A(x,O)),fbody(x,z,p)))
 def fresh_rev(c,x,z,fn):
  universal(c,pb,A(z,O),rbody(x,z,pb),fn)
  return m.rename_all(c,pb,bpvar,lambda q:b.Imp(L(q,A(z,O)),rbody(x,z,q)))
 def use_fwd(c,x,z,p):
  c.all_elim(fp,b.Imp(L(fp,A(x,O)),fbody(x,z,fp)),p);c.mp(L(p,A(x,O)),fbody(x,z,p))
  c.both(m.power2(p),m.bit1(x,p));return c.mp(b.And(m.power2(p),m.bit1(x,p)),m.bit1(z,sq(p)))
 def use_rev(c,x,z,q):
  c.all_elim(bpvar,b.Imp(L(bpvar,A(z,O)),rbody(x,z,bpvar)),q);c.mp(L(q,A(z,O)),rbody(x,z,q))
  c.both(m.power2(q),m.bit1(z,q));return c.mp(b.And(m.power2(q),m.bit1(z,q)),witness(x,q))
 def eliminate_witness(c,x,q,goal,fn):
  def found(cc):nd.unpack(cc,[m.power2(pw),Q(q,sq(pw)),m.bit1(x,pw)]);return fn(cc,pw)
  return m.bex_elim(c,wp,A(x,O),wbody(x,q,wp),pw,goal,found)
 def pack_witness(c,x,q,p):
  nd.conj(c,[m.power2(p),Q(q,sq(p)),m.bit1(x,p)])
  return m.bex_intro(c,wp,A(x,O),wbody(x,q,wp),p)
 def pow_half(c,p,goal,one,half,fresh):
  use(c,'skelet17-binary-power-halving',{'t':p})
  hb=b.And(Q(p,M(two,m.pz)),m.power2(m.pz));opts=[Q(p,O),nd.BEX(m.pz,A(p,O),hb)]
  def branch(cc,k):
   if k==0:return one(cc)
   def found(dc):nd.unpack(dc,[Q(p,M(two,fresh)),m.power2(fresh)]);return half(dc,fresh,Q(p,M(two,fresh)))
   return m.bex_elim(cc,m.pz,A(p,O),hb,fresh,goal,found)
  return nd.cases(c,opts,goal,branch)
 def graph_zero():
  root=nd.Ctx()
  def forward0(c):
   ante=b.And(m.power2(pf),m.bit1(Z,pf));cc=c.push(ante);nd.unpack(cc,list(ante[1:]));nd.unpack(cc,list(m.power2(pf)[1:]))
   use(cc,'skelet17-ladder-skelet10-zero-has-no-one-bit',{'u':pf})
   cc.explode(m.bit1(Z,pf),m.bit1(Z,sq(pf)));c.intro(ante,m.bit1(Z,sq(pf)),cc);return c.get(fbody(Z,Z,pf))
  fresh_fwd(root,Z,Z,forward0)
  def reverse0(c):
   ante=b.And(m.power2(pb),m.bit1(Z,pb));cc=c.push(ante);nd.unpack(cc,list(ante[1:]));nd.unpack(cc,list(m.power2(pb)[1:]))
   use(cc,'skelet17-ladder-skelet10-zero-has-no-one-bit',{'u':pb});cc.explode(m.bit1(Z,pb),witness(Z,pb))
   c.intro(ante,witness(Z,pb),cc);return c.get(rbody(Z,Z,pb))
  fresh_rev(root,Z,Z,reverse0);root.both(fwd(Z,Z),rev(Z,Z));m.save('skelet17-ladder-skelet10-spread-zero',root,dil(Z,Z),'The bounded two-sided bit-spread graph contains (0,0). No induction.')
 if proofs: graph_zero()
 def graph_push():
  x,z,d=b.t,b.u,b.v;nx=push(x,d);nz=push(M(two,z),d)
  prem=b.And(dil(x,z),L(d,two));root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));nd.unpack(c,list(dil(x,z)[1:]))
  def fproof(pc):
   p=pf;ante=b.And(m.power2(p),m.bit1(nx,p));cc=pc.push(ante);nd.unpack(cc,list(ante[1:]));goal=m.bit1(nz,sq(p))
   def one(dc):
    m.rewrite(dc,m.bit1(nx,a.E),p,O);low_use(dc,x,d);dc.mp(m.bit1(nx,O),Q(d,O))
    low_use(dc,M(two,z),d);dc.mp(Q(d,O),m.bit1(nz,O));m.eq(dc,O,sq(p),[Q(p,O)])
    return m.rewrite(dc,m.bit1(nz,a.E),O,sq(p))
   def half(dc,h,heq):
    nd.unpack(dc,list(m.power2(h)[1:]));m.rewrite(dc,m.bit1(nx,a.E),p,M(two,h));back(dc,x,h,d)
    use(dc,'skelet17-ladder-skelet10-bit-support-bound',{'t':x,'u':h});use_fwd(dc,x,z,h)
    m.bound(dc,Z,two,O)
    forward(dc,z,sq(h),Z);m.eq(dc,push(z,Z),M(two,z));m.rewrite(dc,m.bit1(a.E,M(two,sq(h))),push(z,Z),M(two,z))
    forward(dc,M(two,z),M(two,sq(h)),d)
    m.eq(dc,M(two,M(two,sq(h))),sq(p),[heq]);return m.rewrite(dc,m.bit1(nz,a.E),M(two,M(two,sq(h))),sq(p))
   pow_half(cc,p,goal,one,half,half1);pc.intro(ante,goal,cc);return pc.get(fbody(nx,nz,p))
  fresh_fwd(c,nx,nz,fproof)
  def rproof(pc):
   q=pb;ante=b.And(m.power2(q),m.bit1(nz,q));cc=pc.push(ante);nd.unpack(cc,list(ante[1:]));goal=witness(nx,q)
   def one(dc):
    m.rewrite(dc,m.bit1(nz,a.E),q,O);low_use(dc,M(two,z),d);dc.mp(m.bit1(nz,O),Q(d,O))
    low_use(dc,x,d);dc.mp(Q(d,O),m.bit1(nx,O));use(dc,'skelet17-binary-power-one',{},False)
    use(dc,'skelet17-ladder-skelet10-bit-support-bound',{'t':nx,'u':O});m.eq(dc,q,sq(O),[Q(q,O)])
    return pack_witness(dc,nx,q,O)
   def half(dc,h,heq):
    nd.unpack(dc,list(m.power2(h)[1:]));m.rewrite(dc,m.bit1(nz,a.E),q,M(two,h));back(dc,M(two,z),h,d)
    def oddscale(ec):
     m.rewrite(ec,m.bit1(M(two,z),a.E),h,O)
     m.bound(ec,Z,two,O);low_use(ec,z,Z);m.eq(ec,push(z,Z),M(two,z))
     m.rewrite(ec,m.bit1(a.E,O),M(two,z),push(z,Z),a.sym(push(z,Z),M(two,z),ec.get(Q(push(z,Z),M(two,z))),ec.g))
     ec.mp(m.bit1(push(z,Z),O),Q(Z,O));return m.false_zero_one(ec,goal)
    def even_scale(ec,k,keq):
     nd.unpack(ec,list(m.power2(k)[1:]));m.rewrite(ec,m.bit1(M(two,z),a.E),h,M(two,k))
     m.eq(ec,M(two,z),push(z,Z));m.rewrite(ec,m.bit1(a.E,M(two,k)),M(two,z),push(z,Z))
     m.bound(ec,Z,two,O);back(ec,z,k,Z)
     use(ec,'skelet17-ladder-skelet10-bit-support-bound',{'t':z,'u':k});use_rev(ec,x,z,k)
     def found(fc,p):
      use(fc,'skelet17-binary-power-double',{'t':p});forward(fc,x,p,d)
      use(fc,'skelet17-ladder-skelet10-bit-support-bound',{'t':nx,'u':M(two,p)})
      m.eq(fc,q,sq(M(two,p)),[heq,keq,Q(k,sq(p))]);return pack_witness(fc,nx,q,M(two,p))
     return eliminate_witness(ec,x,k,goal,found)
    return pow_half(dc,h,goal,oddscale,even_scale,half2)
   pow_half(cc,q,goal,one,half,half1);pc.intro(ante,goal,cc);return pc.get(rbody(nx,nz,q))
  fresh_rev(c,nx,nz,rproof);c.both(fwd(nx,nz),rev(nx,nz))
  finish('spread-push',root,prem,dil(nx,nz),c,'Dil(x,z) and d<2 imply Dil(2x+d,4z+d). Uses existing division and Pow2 halving/doubling, not exponential totality.')
 if proofs: graph_push()
 # A tight invariant z<=x^2 is preserved by the digit constructor. A
 # weaker (x+1)^2 upper bound would not close under a leading zero.
 def bound_step():
  x,z,d=b.t,b.u,b.v;nx=push(x,d);nz=push(M(two,z),d)
  fs=[L(z,A(sq(x),O)),L(d,two)];prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);goal=L(nz,A(sq(nx),O))
  def gapcase(cc,geq):
   eq=Q(sq(x),A(z,gap));ant=Q(A(sq(x),O),A(A(z,gap),O));m.eq(cc,*ant[1:],[geq])
   imp=b.Imp(ant,eq);cc.theorem(imp,b.apply('add-cancel',{'t':sq(x),'u':A(z,gap),'v':O}));cc.mp(ant,eq)
   use(cc,'skelet17-binary-digit-cases',{'t':d})
   def digit(dc,k):
    expanded=A(M(four,sq(x)),O) if k==0 else A(A(M(four,sq(x)),M(four,x)),two)
    re=Q(A(sq(nx),O),expanded);m.eq(dc,*re[1:],[Q(d,a.num(k))])
    slack=M(four,gap) if k==0 else A(M(four,gap),M(four,x))
    return m.bound(dc,nz,A(sq(nx),O),slack,[re,eq,Q(d,a.num(k))])
   return nd.cases(cc,[Q(d,Z),Q(d,O)],goal,digit)
  m.gap_elim(c,z,A(sq(x),O),gap,goal,gapcase)
  m.finish('z10-spread-bound-step',root,prem,goal,c,'The quadratic witness bound is closed under binary-to-base-four digit construction. No induction.')
 if proofs: bound_step()
 ti,tx,tf,tv,tvf,tq,tr=[m.declare('dilTotal'+s) for s in ('Index','Domain','FreshInput','Value','FreshValue','Half','Bit')]
 def exists_spread(x):return nd.BEX(tv,A(sq(x),O),dil(x,tv))
 def half_less():
  x,q,d=b.t,b.u,b.v;prem=b.And(Q(x,push(q,d)),L(Z,x));goal=L(q,x)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));use(c,'skelet17-binary-zero-or-positive',{'t':q},False)
  def branch(cc,k):
   if k==0:return m.rewrite(cc,L(a.E,x),Z,q,a.sym(q,Z,cc.get(Q(q,Z)),cc.g))
   return m.gap_elim(cc,Z,q,gap,goal,lambda dc,geq:m.bound(dc,q,x,A(gap,d),[Q(x,push(q,d)),geq]))
  nd.cases(c,[Q(q,Z),L(Z,q)],goal,branch)
  m.finish('z10-spread-half-less',root,prem,goal,c,'Every half quotient of a positive number is strictly smaller. No induction.')
 if proofs: half_less()
 def totality():
  root=nd.Ctx()
  use(root,'skelet17-ladder-skelet10-spread-zero',{},False)
  m.bound(root,Z,A(sq(Z),O),Z);m.bex_intro(root,tv,A(sq(Z),O),dil(Z,tv),Z)
  def phi(i):return nd.BALL(tx,A(i,O),exists_spread(tx))
  def build(parent,index,fn):
   guard=L(tf,A(index,O));gc=parent.push(guard);gc.put(exists_spread(tf),fn(gc))
   parent.intro(guard,exists_spread(tf),gc);parent.all_intro(tf,b.Imp(guard,exists_spread(tf)))
   return m.rename_all(parent,tf,tx,lambda v:b.Imp(L(v,A(index,O)),exists_spread(v)))
  def base(cc):
   use(cc,'skelet17-binary-below-successor',{'t':tf,'u':Z})
   def branch(dc,k):
    if k==0:
     dc.put(b.Not(L(tf,Z)),b.ax('O4',dc.g,t=tf));return dc.explode(L(tf,Z),exists_spread(tf))
    return m.rewrite(dc,exists_spread(a.E),Z,tf,a.sym(tf,Z,dc.get(Q(tf,Z)),dc.g))
   return nd.cases(cc,[L(tf,Z),Q(tf,Z)],exists_spread(tf),branch)
  build(root,Z,base)
  sc=root.push(phi(ti))
  def successor(cc):
   goal=exists_spread(tf);use(cc,'skelet17-binary-below-successor',{'t':tf,'u':A(ti,O)})
   def apply_ih(dc,value):
    dc.all_elim(tx,b.Imp(L(tx,A(ti,O)),exists_spread(tx)),value);return dc.mp(L(value,A(ti,O)),exists_spread(value))
   def branch(dc,k):
    if k==0:return apply_ih(dc,tf)
    m.bound(dc,Z,tf,ti,[Q(tf,A(ti,O))]);m.bound(dc,Z,two,O)
    use(dc,'skelet17-bounded-division-exists',{'t':tf,'u':two})
    def halfq(qc):
     def halfbit(rc):
      eq=Q(tf,push(tq,tr));rc.both(eq,L(Z,tf));use(rc,'z10-spread-half-less',{'t':tf,'u':tq,'v':tr})
      m.rewrite(rc,L(tq,a.E),tf,A(ti,O));apply_ih(rc,tq)
      def witness_found(wc):
       nd.unpack(wc,list(dil(tq,tvf)[1:]));wc.both(dil(tq,tvf),L(tr,two))
       use(wc,'skelet17-ladder-skelet10-spread-push',{'t':tq,'u':tvf,'v':tr})
       value=push(M(two,tvf),tr)
       m.rewrite(wc,dil(a.E,value),push(tq,tr),tf,a.sym(tf,push(tq,tr),wc.get(eq),wc.g))
       wc.both(L(tvf,A(sq(tq),O)),L(tr,two));use(wc,'z10-spread-bound-step',{'t':tq,'u':tvf,'v':tr})
       m.rewrite(wc,L(value,A(sq(a.E),O)),push(tq,tr),tf,a.sym(tf,push(tq,tr),wc.get(eq),wc.g))
       return m.bex_intro(wc,tv,A(sq(tf),O),dil(tf,tv),value)
      return m.bex_elim(rc,tv,A(sq(tq),O),dil(tq,tv),tvf,goal,witness_found)
     return m.bex_elim(qc,m.r,two,Q(tf,push(tq,m.r)),tr,goal,halfbit)
    return m.bex_elim(dc,m.q,A(tf,O),nd.BEX(m.r,two,Q(tf,push(m.q,m.r))),tq,goal,halfq)
   return nd.cases(cc,[L(tf,A(ti,O)),Q(tf,A(ti,O))],goal,branch)
  build(sc,A(ti,O),successor)
  root.intro(phi(ti),phi(A(ti,O)),sc);step=b.All(ti,b.Imp(phi(ti),phi(A(ti,O))))
  root.all_intro(ti,b.Imp(phi(ti),phi(A(ti,O))));m.induction(root,ti,phi(ti),phi(Z),step)
  root.all_elim(ti,phi(ti),b.t);m.successor(root,b.t)
  root.all_elim(tx,b.Imp(L(tx,A(b.t,O)),exists_spread(tx)),b.t);root.mp(L(b.t,A(b.t,O)),exists_spread(b.t))
  m.save('skelet17-ladder-skelet10-spread-exists-quadratic',root,exists_spread(b.t),
   'Every input has a bounded bit-spread witness z<=x*x. One new bounded strong-induction construction; no total exponentiation and no uniqueness claim.')
 if proofs: totality()
 # Left-word transform T=10*Spread, presented as a bounded graph rather
 # than adding a function symbol or a new defining axiom.
 zw,zf,tout=[m.declare('dilTransform'+s) for s in ('Witness','FreshWitness','Output')]
 def transform(x,t):return nd.BEX(zw,A(t,O),b.And(Q(t,M(ten,zw)),dil(x,zw)))
 def pack_transform(c,x,t,z):
  c.both(Q(t,M(ten,z)),dil(x,z));return m.bex_intro(c,zw,A(t,O),b.And(Q(t,M(ten,zw)),dil(x,zw)),z)
 def transform_zero():
  root=nd.Ctx();use(root,'skelet17-ladder-skelet10-spread-zero',{},False)
  m.bound(root,Z,A(Z,O),Z);m.eq(root,Z,M(ten,Z));pack_transform(root,Z,Z,Z)
  m.save('skelet17-ladder-skelet10-transform-zero',root,transform(Z,Z),'The bounded left-word transform graph contains (0,0). No induction.')
 if proofs: transform_zero()
 def coefficient_identities():
  scale,base,z=b.t,b.u,b.v
  root=nd.Ctx();eq=Q(M(scale,M(base,z)),M(base,M(scale,z)));m.eq(root,*eq[1:])
  m.save('z10-spread-product-reorder',root,eq,'Factored coefficient interchange, with arbitrary coefficients. No induction.')
  root=nd.Ctx();eq=Q(A(M(scale,M(base,z)),base),M(base,A(M(scale,z),O)));m.eq(root,*eq[1:])
  m.save('z10-spread-affine-scale',root,eq,'Factored distributive identity, with arbitrary coefficients. No induction.')
 if proofs: coefficient_identities()
 def constructors():
  x,t=b.t,b.u
  for digits,label in [([0],'transform-prefix-0'),([0,1],'transform-prefix-10')]:
   nx=M(two,x) if len(digits)==1 else A(M(four,x),O)
   nt=M(four,t) if len(digits)==1 else A(M(a.num(16),t),ten)
   root=nd.Ctx();prem=transform(x,t);c=root.push(prem);goal=transform(nx,nt)
   def found(cc):
    eq=Q(t,M(ten,zf));nd.unpack(cc,[eq,dil(x,zf)])
    oldx,oldz=x,zf
    for digit in digits:
     d=a.num(digit);m.bound(cc,d,two,O if digit==0 else Z)
     cc.both(dil(oldx,oldz),L(d,two));use(cc,'skelet17-ladder-skelet10-spread-push',{'t':oldx,'u':oldz,'v':d})
     oldx,oldz=push(oldx,d),push(M(two,oldz),d)
    nz=M(four,zf) if len(digits)==1 else A(M(a.num(16),zf),O)
    m.eq(cc,oldx,nx);m.rewrite(cc,dil(a.E,oldz),oldx,nx)
    m.eq(cc,oldz,nz);m.rewrite(cc,dil(nx,a.E),oldz,nz)
    if len(digits)==1:
     use(cc,'z10-spread-product-reorder',{'t':four,'u':ten,'v':zf},False)
     template=Q(M(four,a.E),M(ten,nz))
    else:
     use(cc,'z10-spread-affine-scale',{'t':a.num(16),'u':ten,'v':zf},False)
     template=Q(A(M(a.num(16),a.E),ten),M(ten,nz))
    m.rewrite(cc,template,M(ten,zf),t,a.sym(t,M(ten,zf),cc.get(eq),cc.g))
    m.bound(cc,Z,ten,a.num(9));use(cc,'skelet17-binary-factor-bound',{'t':nz,'u':ten})
    m.rewrite(cc,L(nz,A(a.E,O)),M(ten,nz),nt,a.sym(nt,M(ten,nz),cc.get(Q(nt,M(ten,nz))),cc.g))
    return pack_transform(cc,nx,nt,nz)
   m.bex_elim(c,zw,A(t,O),b.And(Q(t,M(ten,zw)),dil(x,zw)),zf,goal,found)
   finish(label,root,prem,goal,c,'The bounded left-word transform respects its Zeckendorf grammar constructor. Reuses the spread digit theorem; no additional induction.')
 if proofs: constructors()
 def transform_total():
  x=b.t;root=nd.Ctx();use(root,'skelet17-ladder-skelet10-spread-exists-quadratic',{},False)
  upper=A(M(ten,sq(x)),O);goal=nd.BEX(tout,upper,transform(x,tout))
  def found(c):
   value=M(ten,tvf);m.bound(c,tvf,A(value,O),M(a.num(9),tvf));m.eq(c,value,M(ten,tvf))
   pack_transform(c,x,value,tvf)
   def boundgap(cc,geq):
    ant=Q(A(sq(x),O),A(A(tvf,gap),O));m.eq(cc,*ant[1:],[geq])
    eq=Q(sq(x),A(tvf,gap));imp=b.Imp(ant,eq)
    cc.theorem(imp,b.apply('add-cancel',{'t':sq(x),'u':A(tvf,gap),'v':O}));cc.mp(ant,eq)
    return m.bound(cc,value,upper,M(ten,gap),[eq])
   m.gap_elim(c,tvf,A(sq(x),O),gap,L(value,upper),boundgap)
   return m.bex_intro(c,tout,upper,transform(x,tout),value)
  m.bex_elim(root,tv,A(sq(x),O),dil(x,tv),tvf,goal,found)
  m.save('skelet17-ladder-skelet10-transform-exists-quadratic',root,goal,
   'Every word has a bounded left-transform output t<=10*x*x. Reuses spread totality; uniqueness and machine synchronization remain separate obligations.')
 if proofs: transform_total()

 return {'dil':dil,'transform':transform,'sq':sq,'push':push,'exists_spread':exists_spread,
  'fwd':fwd,'rev':rev,'witness':witness,'fresh_fwd':fresh_fwd,'fresh_rev':fresh_rev,
  'fbody':fbody,'rbody':rbody,'use_fwd':use_fwd,'use_rev':use_rev,
  'eliminate_witness':eliminate_witness,'pack_witness':pack_witness,
  'forward':forward,'back':back,'low_use':low_use,'pow_half':pow_half,
  'pf':pf,'pb':pb,'pack_transform':pack_transform,'zw':zw,
  'coefficient_identities':coefficient_identities}

