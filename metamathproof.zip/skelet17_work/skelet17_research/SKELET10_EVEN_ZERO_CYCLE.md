# Complete boundary composition for n=4b

The theorem skelet17-ladder-skelet10-even-zero-boundary-cycle handles the
second of the three numerical boundary cases. It works inside the same
original supplied beta history as the odd-case theorem. No routine output,
finite prefix, phase or invariant is added to the history definition.

## Statement and parameters

Write a tape quadruple as (q,L,s,R), with scanned bit s, and put W=2L+s.
Fix the original history's bound H, length N, offset o and four code pairs.
The premises are TOTAL, STEPS, a bounded final row at index N in halt
state 5, and a bounded decoded current row c at k<N+1. Its canonical
even clause gives q=D, s<2, Sparse(n), Sparse(R), and a bounded witness
a<n+1 satisfying n=2a, T(a,W), J(a,R). This case additionally assumes
n=4b; the numerical parameter b is distinct from the scanned bit s.

The conclusion constructs a bounded decoded row d at e<N+1 with
k<e and Boundary(R(c),d). Thus the next input is the OLD right half,
automatically below H. The public statement contains no intermediate
alignment or counter endpoint assumptions.

## Arithmetic decoding of the source

From 2a=4b, quotient/remainder uniqueness modulo 2 gives a=2b.
Two existing Sparse pop theorems give Sparse(b) from Sparse(4b).
The carry inverse J(2b,R) gives R=4b+1. The bounded transform inverse
for T(2b,W) supplies t<W+1 with W=4t+0 and T(b,t).
Since s<2, the equation 2L+s=4t forces L=2t and s=0.

No transform-totality or coding-totality theorem is assumed. The decoded
t is a bounded witness obtained from an existing transform assertion.

## The four ordinary prefix moves

The following table displays the values proved for the ACTUAL decoded
rows supplied by the history; it is not a macro-transition premise.

| Point | State | L | Scanned bit | R |
|---|---|---|---|---|
| Source | D | 2t | 0 | 4b+1 |
| After D0 | C | t | 0 | 8b+3 |
| After C0 | E | 2t+1 | 1 | 4b+1 |
| After E1 | B | 4t+2 | 1 | 2b |
| After B1 | A | 8t+5 | 0 | b |

At each point, its state differs from halt. The shared advancement
theorem therefore supplies an actual successor and ordinary Step in an
alleged halting history. The previously proved instruction contract
determines that successor uniquely. In particular, the E row scans 1,
so the prefix uses E1, not the halting E0 transition.

One shared private theorem, z10-compose-step-transport, transports Step
along equality of its four source coordinates. It is proved once by
first-order equality substitution and used for all prefix moves. Together with
dependency pruning, this reduced the candidate dependency file from 24,136
to 22,718 proved assertions. The difference includes pruning effects, and
these counts include earlier dependencies.

## Right routine and the essential final alignment

The A row scans 0 and has Sparse right half b. Advance once and use the
existing A0 entry theorem: the actual B successor enters the complete
right routine with input b and left target ell=8t+5.

Construct an additive remaining-length witness at that index and apply
the embedded right-counter barrier. It supplies a strictly later decoded
D output with W=8t+5, J(b,R), Sparse(R), and a derived scanned-bit bound.
This row is NOT YET the next canonical boundary.

Advance once more from D. The verified odd-output alignment theorem
forces the actual D1 move and produces W=4t+2 and right half 2v,
where v was the right counter's actual output. With T(b,t), J(b,v),
Sparse(b) and Sparse(v), its bounded odd witnesses construct
Boundary(4b+1,d). Since the original R(c)=4b+1, this is the requested
Boundary(R(c),d). The strict index inequalities give k<e.

Every row, remaining length and counter output is existentially
constructed inside the original history. All temporary witnesses are
discharged by natural deduction. There is no assumed availability of a
long-enough window: advancement and the halting barrier handle short
alleged halting histories within their proofs.

## Strength and checks

No new arithmetic axiom or induction construction is added. The proof
reuses two existing bounded-induction constructions: bounded division
and the right routine's history induction. The statement is Delta-0 when
the original history, Sparse, T, J and Boundary definitions are expanded.
This count describes the proof, not a lower bound on needed strength.

check_skelet10_even_zero_cycle.py independently reconstructs the whole
public formula. Supplementary simulation checks 144 numerical cycles,
1,504 ordinary steps and maximum checked cycle length 28. These examples
do not replace kernel verification of the universal deduction.

All active proofs are in idelta0_machines.mm. The generator is
ladder_skelet10_even_zero_cycle.py. The n=8b+2 numerical case is now also proved; see
SKELET10_EVEN_ONE_CYCLE.md. The general boundary combination, global induction and blank-start
connection were pending at this component stage and are now complete. Whole-machine nonhalting is not claimed.

## Current project endpoint

The general case combination, bounded maximum argument and ordinary
blank-start nonhalting endpoint are now proved. The case-level discussion
above records the numerical component; SKELET10_NONHALTING.md and STATUS.md
give the completed global result and current verification status.
