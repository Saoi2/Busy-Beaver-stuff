"""Instantiate the checked finite-state constructor for joint output packets.

The transformed Python is a proof generator, not a trusted rule. Its emitted
Metamath database must pass the original verifier. Original-parser projection
and removal of invalid recorder transitions are separate obligations.
"""
from pathlib import Path
import re,json,sys
P=Path(__file__).resolve().parent
control=[[0,4],[0,5],[0,6],[0,7],[2,4],[3,5],[0,5],[1,4]]
TABLE=[]
for record in range(32):
    state=record%8;row=[]
    for bit in range(2):
        c=control[state][bit];f=int(state>=4 and bit==1);v=c%2 if f else 0
        row.append(c+8*f+16*v)
    TABLE.append(row)
source=(P/'build_annotations.py').read_text()
old='TABLE=[[0,4],[0,5],[0,6],[0,7],[2,4],[3,5],[0,5],[1,4]]'
assert source.count(old)==1
source=source.replace(old,'TABLE='+repr(TABLE))
source=source.replace('eight=a.num(8)','eight=a.num(32)')
source=source.replace('range(8)','range(32)').replace('finite_cases(ctx,prev,8,goal,state)','finite_cases(ctx,prev,32,goal,state)')
source=source.replace('a.num(7-TABLE[i][j])','a.num(31-TABLE[i][j])').replace('a.num(7)','a.num(31)')
source=source.replace('bound(root,four,eight,a.num(3))','bound(root,four,eight,a.num(27))')
source=source.replace('def cube(p):return M(M(p,p),p)','def cube(p):return M(M(M(p,p),p),M(p,p))')
start=source.index('def cube_bound():');stop=source.index('\ncube_bound()',start)
source=source[:start]+'''def cube_bound():
    fs=[L(Z,P),L(P,B)];prem=b.And(*fs);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    m.translt(ctx,Z,P,B);bound(ctx,Z,O,Z)
    def prod(xs):
        out=O
        for f in xs:out=M(out,f)
        return out
    chain=[]
    for j in range(5):
        factors=[P]*(4-j)+[B]*j;k=O
        for f in factors:
            posmul(ctx,k,f);k=M(k,f)
        left=prod([P]*(5-j)+[B]*j);right=prod([P]*(4-j)+[B]*(j+1))
        mult_lt(ctx,P,B,k);norm_lt(ctx,M(P,k),M(B,k),left,right);chain.append((left,right))
    first=chain[0][0];current=chain[0][1]
    for left,right in chain[1:]:
        m.translt(ctx,first,current,right);current=right
    norm_lt(ctx,first,current,cube(P),cube(B))
    bound(ctx,Z,eight,a.num(31));mult_lt(ctx,cube(P),cube(B),eight)
    norm_lt(ctx,M(cube(P),eight),M(cube(B),eight),M(eight,cube(P)),M(eight,cube(B)))
    finish('skelet17-annotation-cube-bound',root,prem,L(M(eight,cube(P)),M(eight,cube(B))),ctx)
''' +source[stop:]
source=source.replace('skelet17-annotation-','skelet17-packet-')
source=source.replace('annotations_raw.mm','packets_raw.mm').replace('annotation_theorems.json','packet_theorems.json').replace("if 'annotation' in k","if 'packet-' in k")
source=source.replace('-cube-bound','-power-bound')
source=re.sub(r'\bcube\b','power5',source)
source=source.replace('8 controls','32 records').replace('Sixteen explicit cases','64 explicit cases')
source=source.replace('8*(x+1)^3','32*(x+1)^5').replace('8*oldcode','32*oldcode')
source=source.replace('nextstate <8','nextstate <32')
infrastructure='''
# A derived scaling identity replaces repeated expansion of 32*32 terms.
scale_formula=Q(power5(M(two,b.t)),M(eight,power5(b.t)))
b.theorem('skelet17-packet-power-double',scale_formula,a.equal(*scale_formula[1:]))
m.theorems['skelet17-packet-power-double']=scale_formula
original_eq=eq
def normalized_weight(ctx,t):
    if t==power5(O):return O,ctx.theorem(Q(t,O),a.equal(t,O))
    if t[0]=='*':
        try:base=t[1][1][1]
        except (IndexError,TypeError):base=None
        if base is not None and t==power5(base) and base[0]=='*' and base[1]==two:
            mid=M(eight,power5(base[2]));f=Q(t,mid)
            proof=ctx.theorem(f,b.apply('skelet17-packet-power-double',{'t':base[2]}))
            out,rest=normalized_weight(ctx,mid)
            return out,a.trans(t,mid,out,proof,rest,ctx.g)
    if t[0] not in ('+','*'):return t,b.refl(ctx.g,t)
    left,lp=normalized_weight(ctx,t[1]);right,rp=normalized_weight(ctx,t[2])
    out=(t[0],left,right)
    return out,a.cong2(t[0],t[1],left,t[2],right,lp,rp,ctx.g)
def eq(ctx,l,r,fs=()):
    left,right=l,r;lp=b.refl(ctx.g,l);rp=b.refl(ctx.g,r)
    for f in fs:
        nl,np=a.rewrite_term(ctx.g,left,f[1],f[2],ctx.get(f));nr,nq=a.rewrite_term(ctx.g,right,f[1],f[2],ctx.get(f))
        lp=a.trans(l,left,nl,lp,np,ctx.g);rp=a.trans(r,right,nr,rp,nq,ctx.g);left,right=nl,nr
    nl,np=normalized_weight(ctx,left);nr,nq=normalized_weight(ctx,right)
    lp=a.trans(l,left,nl,lp,np,ctx.g);rp=a.trans(r,right,nr,rp,nq,ctx.g)
    middle=b.refl(ctx.g,nl) if nl==nr else ctx.theorem(Q(nl,nr),a.equal(nl,nr))
    proof=a.trans(l,nl,nr,lp,middle,ctx.g)
    return ctx.put(Q(l,r),a.trans(l,nr,r,proof,a.sym(r,nr,rp,ctx.g),ctx.g))
'''
assert source.count('def prefix_bound():')==1
source=source.replace('def prefix_bound():',infrastructure+'\ndef prefix_bound():')
namespace={'__name__':'__main__','__file__':str(P/'build_annotations.py')}
(P/'build_packets_generated.py').write_text(source)
if '--source-only' in sys.argv:
    print(P/'build_packets_generated.py');raise SystemExit(0)
exec(compile(source,str(P/'build_packets_generated.py'),'exec'),namespace)
(P/'packet_table.json').write_text(json.dumps({'record_base':32,'record':'control + 8*flag + 16*digit','table':TABLE,
    'invalid_source_steps_totalized':True,'original_parser_correspondence_proved':False},indent=2)+'\n')
