"""Assemble existing phase lemmas into a bounded ordinary-step invariant."""
exec(compile((p/'finned3_bounds.py').read_text(),'finned3_bounds.py','exec'),globals())
FP=[m.declare('finnedBoundParameter'+str(i)) for i in range(4)]
FW=[m.declare('finnedLiftWitness'+str(i)) for i in range(4)]
FH=m.declare('finnedLiftHalfWitness')
PHASES=[fA0,fA1,fB1,fB0,fBfinal,fC1,fCfinal,fD1,fD0,fE1]
ARITIES=[1,2,4,2,1,2,1,4,3,2]
LABELS=['a0-to-b','a1-to-e1','b1-scan','b0-work-to-c1','b0-final-to-c0',
        'c1-to-d','c0-final-to-a1','d1-scan','d0-to-b','e1-to-a']
def fphase(c,k,args):return nd.AND(PHASES[k](c,*args))
def fclause(c,k):return nd.bexs(FP[:ARITIES[k]],fU,fphase(c,k,FP[:ARITIES[k]]))
def clauses(c):return [fclause(c,k) for k in range(10)]
def INV(c):return nd.OR(clauses(c))
def feliminate(ctx,vs,body,values,goal,prove,bound=fU):
 if not vs:return ctx.put(goal,prove(ctx))
 var,fresh=vs[0],values[0];rest=nd.bexs(vs[1:],bound,body)
 actual,_=b.subst(b.And(L(var,bound),rest),var,fresh,True)
 child=ctx.push(actual);nd.unpack(child,list(actual[1:]))
 newbody,_=b.subst(body,var,fresh,True)
 feliminate(child,vs[1:],newbody,values[1:],goal,prove,bound)
 return ctx.ex_elim(var,b.And(L(var,bound),rest),fresh,goal,child)
def fpack(ctx,vs,body,values):
 for j in reversed(range(len(vs))):
  actual=m.sub(body,{v[1]:t for v,t in zip(vs[:j],values[:j])})
  rest=nd.bexs(vs[j+1:],fU,actual)
  m.bex_intro(ctx,vs[j],fU,rest,values[j])
 return ctx.get(nd.bexs(vs,fU,body))
def fconstant_bound(ctx,x):
 assert x in (O,two)
 k=1 if x==O else 2
 return m.bound(ctx,x,fU,A(M(num(16),fH),num(15-k)))
def foutput(ctx,k,args,halfupper=None):
 fields=PHASES[k](NF,*args);nd.unpack(ctx,fields)
 if halfupper is not None:
  for old in FW:
   if halfupper==A(old,O):
    try:ctx.get(L(old,fU))
    except KeyError:continue
    ctx.both(L(FH,A(old,O)),L(old,fU))
    use(ctx,'skelet17-binary-le-lt-trans',{'t':FH,'u':old,'v':fU})
 def bound(j,x):
  try:return ctx.get(L(x,fU))
  except KeyError:pass
  if x in (O,two):return fconstant_bound(ctx,x)
  if k==9 and j==0:
   nd.unpack(ctx,list(m.power2(x)[1:]));relation=Q(fsq(x),A(M(three,NF[1]),O))
   m.flip(ctx,fields[-2]);nd.conj(ctx,[L(NF[1],fH),L(Z,x),relation])
   return use(ctx,'skelet17-ladder-finned3-square-scale-bound',{'t':NF[1],'u':x})
  if (k==2 or k==7) and j==1:
   relation=fields[-3];ctx.both(L(NF[1],fH),relation)
   return use(ctx,'skelet17-ladder-finned3-left-scale-bound',{'t':NF[1],'u':x,'v':args[0]})
  if (k==2 and j in (2,3)) or (k==7 and j in (2,3)) or (k==8 and j in (1,2)):
   u,v=(args[2],args[3]) if k in (2,7) else (args[1],args[2])
   for z in (u,v):nd.unpack(ctx,list(m.power2(z)[1:]))
   nd.conj(ctx,[L(NF[3],fH),L(Z,u),L(Z,v),fields[-2]])
   use(ctx,'skelet17-ladder-finned3-right-scales-bound',{'t':NF[3],'u':u,'v':v})
   nd.unpack(ctx,[L(u,fU),L(v,fU)]);return ctx.get(L(x,fU))
  raise ValueError(('missing parameter bound',k,j,b.tok(x)))
 for j,x in enumerate(args):bound(j,x)
 fpack(ctx,FP[:ARITIES[k]],fphase(NF,k,FP[:ARITIES[k]]),args)
 return ctx.get(fclause(NF,k))
def ftargets(k,args):
 # Each descriptor is (target phase, parameters, optional bound for half).
 a=args
 if k==0:return [(3,[a[0],O],None),(2,[a[0],two,fhalf,O],A(a[0],O))]
 return ftargets_rest(k,a)
def ftargets_rest(k,a):
 if k==1:return [(9,[M(two,a[0]),a[1]],None)]
 if k==2:return [(3,[a[0],a[3]],None),(2,[a[0],M(two,a[1]),fhalf,a[3]],A(a[2],O))]
 if k==3:return [(5,a,None)]
 if k==4:return [(6,a,None)]
 if k==5:return [(8,[a[0],O,M(two,a[1])],None),(7,[a[0],fhalf,O,M(two,a[1])],A(M(a[0],fsq(a[1])),O))]
 if k==6:return [(1,[O,a[0]],None)]
 if k==7:return [(8,[a[0],M(two,a[2]),a[3]],None),(7,[a[0],fhalf,M(two,a[2]),a[3]],A(a[1],O))]
 if k==8:return [(4,[fhalf],A(a[2],O)),(2,[fhalf,O,M(two,a[1]),a[2]],A(a[0],O))]
 if k==9:return [(0,[a[0]],None),(1,[a[0],fhalf],A(a[1],O))]
 raise ValueError(k)
def fbounded_phase(k):
 descriptors=ftargets(k,FW[:ARITIES[k]])
 targets=[fclause(NF,j) for j,_,_ in descriptors];goal=nd.OR(targets)
 fs=[fclause(CF,k),STEP(CF,NF),L(NF[1],fH),L(NF[3],fH)]
 prem=nd.AND(fs);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
 def have_source(ec):
  args=FW[:ARITIES[k]];source=fphase(CF,k,args);nd.unpack(ec,PHASES[k](CF,*args))
  ec.both(source,STEP(CF,NF))
  mapping={**{t[1]:v for t,v in zip(CF+NF,CF+NF)},**{t[1]:v for t,v in zip((b.t,b.u,b.v,b.w),args)}}
  name='skelet17-ladder-finned3-'+LABELS[k];use(ec,name,mapping)
  local=[]
  for j,ts,upper in descriptors:
   body=fphase(NF,j,ts);local.append(nd.BEX(fhalf,upper,body) if upper is not None else body)
  assert m.sub(m.theorems[name],mapping)[2]==nd.OR(local)
  def output(dc,index):
   j,ts,upper=descriptors[index]
   def done(cc,vals):
    foutput(cc,j,vals,upper);return nd.disj(cc,targets,index)
   if upper is None:return done(dc,ts)
   actual=[FH if t==fhalf else t for t in ts]
   return m.bex_elim(dc,fhalf,upper,fphase(NF,j,ts),FH,goal,lambda cc:done(cc,actual))
  return nd.cases(ec,local,goal,output)
 feliminate(ctx,FP[:ARITIES[k]],fphase(CF,k,FP[:ARITIES[k]]),FW[:ARITIES[k]],goal,have_source)
 name='ladder-finned3-bounded-phase-'+str(k)
 finish(name,root,prem,goal,ctx,'Internal bounded existential phase assembly; derived from the ordinary local theorem and witness bounds.')
 return name,[j for j,_,_ in descriptors]
FBOUNDED=[fbounded_phase(k) for k in range(10)]
def finned_global_closure():
 fs=[INV(CF),STEP(CF,NF),L(NF[1],fH),L(NF[3],fH)];prem=nd.AND(fs);goal=INV(NF)
 root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
 def region(ec,k):
  nd.conj(ec,[fclause(CF,k),*fs[1:]]);name,targets=FBOUNDED[k];use(ec,name)
  def out(dc,j):return nd.disj(dc,clauses(NF),targets[j])
  return nd.cases(ec,[fclause(NF,j) for j in targets],goal,out)
 nd.cases(ctx,clauses(CF),goal,region)
 finish('skelet17-ladder-finned3-local',root,prem,goal,ctx,'A single Delta-0 existential invariant preserved by ordinary Step; only target tape-coordinate bounds are used.')
finned_global_closure()
