"""Parity safety proof for 1RB---_1LC1RB_0RA0LC."""
TABLES['counter']=[(1,1,1),(5,1,1),(2,0,1),(1,1,1),(0,1,0),(2,0,0)]
def STEP(c,d,kind='counter',previous=STEP):return previous(c,d,kind)
evenvar=m.declare('counterEven');evenfresh=m.declare('counterEvenFresh')
def even(r):return nd.BEX(evenvar,A(r,O),Q(r,M(two,evenvar)))
def clauses(c):
 q,l,bit,r=c
 return [b.And(Q(q,Z),Q(bit,Z)),b.And(Q(q,O),odd(l)),b.And(Q(q,two),b.Or(Q(bit,O),even(r)))]
def INV(c):return nd.OR(clauses(c))
def unpack_clause(ctx,c,k):
 fs=[[Q(c[0],Z),Q(c[2],Z)],[Q(c[0],O),odd(c[1])],[Q(c[0],two),b.Or(Q(c[2],O),even(c[3]))]][k]
 nd.unpack(ctx,fs);return fs

def counter_closure():
 fs=[INV(CF),STEP(CF,NF)];prem=b.And(*fs);goal=INV(NF);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
 def region(ec,k):
  unpack_clause(ec,CF,k)
  def move(sc,j):
   pf=parts(TABLES['counter'],CF,NF,j);nd.unpack(sc,pf)
   if j//2!=k:return contradiction(sc,CF[0],k,j//2,goal)
   if j==1:return contradiction(sc,CF[2],0,1,goal)
   def bitbound(dc,rem):
    def bit(bc,t):
     m.bound(bc,num(t),two,num(1-t));return m.rewrite(bc,L(a.E,two),num(t),rem,bc.get(m.flip(bc,Q(rem,num(t)))))
    return nd.cases(dc,list(pf[-1][1:]),L(rem,two),bit)
   if j in (0,3):
    m.eq(sc,NF[1],A(M(two,CF[1]),O),[pf[3]])
    m.bound(sc,CF[1],A(NF[1],O),A(CF[1],O),[pf[3]])
    m.bex_intro(sc,oddvar,A(NF[1],O),Q(NF[1],A(M(two,oddvar),O)),CF[1])
    sc.both(Q(NF[0],O),odd(NF[1]));return nd.disj(sc,clauses(NF),1)
   if j==2:
    def oddleft(dc):
     leq=Q(CF[1],A(M(two,oddfresh),O))
     m.eq(dc,A(M(two,NF[1]),NF[2]),A(M(two,oddfresh),O),[m.flip(dc,pf[4]),leq])
     bitbound(dc,NF[2]);m.bound(dc,O,two,Z);m.quotient_unique(dc,two,NF[1],NF[2],oddfresh,O)
     nd.disj(dc,[Q(NF[2],O),even(NF[3])],0);dc.both(Q(NF[0],two),b.Or(Q(NF[2],O),even(NF[3])))
     return nd.disj(dc,clauses(NF),2)
    return m.bex_elim(sc,oddvar,A(CF[1],O),Q(CF[1],A(M(two,oddvar),O)),oddfresh,goal,oddleft)
   if j==5:
    m.eq(sc,NF[3],M(two,CF[3]),[pf[3]])
    m.bound(sc,CF[3],A(NF[3],O),CF[3],[pf[3]])
    m.bex_intro(sc,evenvar,A(NF[3],O),Q(NF[3],M(two,evenvar)),CF[3])
    nd.disj(sc,[Q(NF[2],O),even(NF[3])],1);sc.both(Q(NF[0],two),b.Or(Q(NF[2],O),even(NF[3])))
    return nd.disj(sc,clauses(NF),2)
   assert j==4
   def mode(dc,t):
    if t==0:return contradiction(dc,CF[2],0,1,goal)
    def evenright(vc):
     req=Q(CF[3],M(two,evenfresh))
     m.eq(vc,A(M(two,NF[3]),NF[2]),A(M(two,evenfresh),Z),[m.flip(vc,pf[4]),req])
     bitbound(vc,NF[2]);m.bound(vc,Z,two,O);m.quotient_unique(vc,two,NF[3],NF[2],evenfresh,Z)
     vc.both(Q(NF[0],Z),Q(NF[2],Z));return nd.disj(vc,clauses(NF),0)
    return m.bex_elim(dc,evenvar,A(CF[3],O),Q(CF[3],M(two,evenvar)),evenfresh,goal,evenright)
   return nd.cases(sc,[Q(CF[2],O),even(CF[3])],goal,mode)
  return nd.cases(ec,[nd.AND(parts(TABLES['counter'],CF,NF,j)) for j in range(6)],goal,move)
 nd.cases(ctx,clauses(CF),goal,region)
 finish('skelet17-ladder-counter-local',root,prem,goal,ctx,'Parity safety invariant excludes A1 without requiring a total numerical counter decoder. No induction.')
counter_closure()
cs=ts.replace('skelet17-ladder-translated-','skelet17-ladder-counter-').replace("'ladderTranslatedOffset'","'ladderCounterOffset'")
shim=types.SimpleNamespace(nd=nd,b=b,a=a,declare=m.declare,finish=finish,use=use,CF=CF,NF=NF,INV=INV,STEP=STEP)
h={'m':shim};exec(compile(cs,'counter_history_generated.py','exec'),h)
(p/'counter_history_generated.py').write_text(cs)
cep=ep.replace('skelet17-ladder-translated-','skelet17-ladder-counter-').replace('translatedInitial','counterInitial')
cep=cep.replace('ac.both(Q(fresh[0],Z),Q(fresh[3],Z))','ac.both(Q(fresh[0],Z),Q(fresh[2],Z))')
cep=cep.replace('0 if k<2 else 1,5,bad','k,5,bad')
exec(compile(cep,'counter_endpoint_generated.py','exec'),globals())
(p/'counter_endpoint_generated.py').write_text(cep)
