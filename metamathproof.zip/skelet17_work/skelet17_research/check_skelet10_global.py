"""Independently reconstruct exclusion and the ordinary blank-start endpoint."""
from pathlib import Path
import json
import check_history_tools as ht
from check_skelet10_scope import AND,eq,lt,num,implies,parse
from check_skelet10_spread import bounded
from check_skelet10_left import norm
from check_skelet10_maximum import nonempty
P=Path(__file__).resolve().parent;H,N,o=ht.H,ht.N,ht.o
halt=['assemblyHalt'+s for s in ('Q','L','Bit','R')]
av=['blankBoundaryInitial'+s for s in ('Q','L','Bit','R')]
def bounds(row):return [lt(x,H) for x in row]
common=[ht.total(o,N,ht.ti),ht.steps(o,N,ht.si,ht.SV),*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5))]
blank=ht.balls(av,implies(ht.at(o,'0',av),AND([eq(x,'0') for x in av])))
endpoint=AND([ht.total(o,N,ht.ti),ht.steps(o,N,ht.si,ht.SV),blank,*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5))])
expected={
 'skelet17-ladder-skelet10-no-halting-history-with-boundary':('-.',AND([*common,nonempty(N)])),
 'skelet17-ladder-skelet10-no-blank-halting-history':('-.',endpoint),
}
def main():
 data=json.loads((P/'skelet10_global_theorems.json').read_text());assert set(data)==set(expected)
 for label,formula in expected.items():assert norm(parse(data[label]))==norm(formula) and bounded(formula),label
 result={'statements_checked':2,'independent_reconstruction_matches':True,'both_statements_delta0_with_free_code_parameters':True,'final_endpoint_uses_only_total_steps_blank_and_final_halt':True,'no_invariant_counter_endpoint_or_window_length_added_to_halting':True,'original_TM_and_beta_history_unchanged':True,'ordinary_blank_start_is_offset_zero_instance':True,'new_induction_constructions_expected_in_global_assembly':0,'whole_machine_nonhalting_endpoint_reconstructed':True,'independent_check_is_not_kernel_verification':True}
 (P/'skelet10_global_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':main()
