"""Lift the bounded certificate invariant through unchanged raw histories."""
fhsrc=cs.replace('skelet17-ladder-counter-','skelet17-ladder-finned3-').replace("'ladderCounterOffset'","'ladderFinnedOffset'")
fhsrc=fhsrc.replace('nd.conj(pc,[icur,m.STEP(CF,NF)])',
                    'nd.conj(pc,[icur,m.STEP(CF,NF),L(NF[1],H),L(NF[3],H)])')
fhsrc=fhsrc.replace('Ordinary cycler supplied-history propagation. One bounded induction; no extra scan guard.',
                    'Propagate bounded Finned #3 certificate existence along an ordinary supplied history. One new bounded history induction; earlier arithmetic is reused.')
shim=types.SimpleNamespace(nd=nd,b=b,a=a,declare=m.declare,finish=finish,use=use,CF=CF,NF=NF,INV=INV,STEP=STEP)
h={'m':shim};exec(compile(fhsrc,'finned3_history_generated.py','exec'),h)
(p/'finned3_history_generated.py').write_text(fhsrc)
fendpoint=(p/'ladder_endpoint.py').read_text().replace('ladderInitial','finnedInitial').replace('skelet17-ladder-cycler-','skelet17-ladder-finned3-')
initial='''nd.unpack(ac,[Q(v,Z) for v in fresh])
 use(ac,'skelet17-binary-power-one',{},False)
 fs=fA0(fresh,O)
 for eq in fs[-2:]:m.eq(ac,*eq[1:],[Q(v,Z) for v in fresh])
 nd.conj(ac,fs);fconstant_bound(ac,O)
 fpack(ac,FP[:1],fphase(fresh,0,FP[:1]),[O])
 nd.disj(ac,clauses(fresh),0)'''
fendpoint=fendpoint.replace('nd.disj(ac,[cfg(fresh,v) for v in CYCLE],0)',initial)
exclude='''def done(cc):
  nd.unpack(cc,PHASES[k](NF,*FW[:ARITIES[k]]))
  return contradiction(cc,NF[0],[0,0,1,1,1,2,2,3,3,4][k],5,bad)
 return feliminate(ec,FP[:ARITIES[k]],fphase(NF,k,FP[:ARITIES[k]]),FW[:ARITIES[k]],bad,done)'''
fendpoint=fendpoint.replace('nd.unpack(ec,[Q(v,num(z)) for v,z in zip(NF,CYCLE[k])])\n return contradiction(ec,NF[0],CYCLE[k][0],5,bad)',exclude)
fendpoint=fendpoint.replace('nd.cases(ctx,[cfg(NF,v) for v in CYCLE],bad,exclude)','nd.cases(ctx,clauses(NF),bad,exclude)')
fendpoint=fendpoint.replace('One bounded induction in its dependency closure.',
                            'One new history induction plus the existing division and Pow2 product induction dependencies.')
exec(compile(fendpoint,'finned3_endpoint_generated.py','exec'),globals())
(p/'finned3_endpoint_generated.py').write_text(fendpoint)
