"""Combine the three numerical cases without strengthening the history."""
def add_skelet10_boundary_progress(m,api,sp,right,h,assembly,bd,cycles,finite,one,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 H,N,o,k=[h[x] for x in ('H','n','offset','start')];AT=h['AT'];cf=api['current']
 two,four,eight=map(ar.num,(2,4,8));T=sp['transform'];J=right['carry'];sparse=api['sparse']
 n=cycles['input'];outi,outr=cycles['output_index'],cycles['output_row'];halt=assembly['halt']
 apply,unpack,bounds=[assembly[x] for x in ('apply','unpack','bounds')]
 half,q,d,quarter=[m.declare('progress'+s) for s in ('Half','Quotient','Digit','Quarter')]
 def wl(row):return A(M(two,row[1]),row[2])
 def result(i,row):return nd.AND([L(k,i),AT(o,i,row),bd['boundary'](cf[3],row)])
 goal=nd.BEX(outi,A(N,O),nd.bexs(outr,H,result(outi,outr)))
 common=[h['total'](o,N),h['steps'](o,N),*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5)),*bounds(cf),L(k,A(N,O)),AT(o,k,cf)]
 prem=nd.AND([*common,bd['boundary'](n,cf)])
 def prove():
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,[*common,bd['boundary'](n,cf)]);unpack(c,bd['boundary'](n,cf))
  def kind(dc,j):
   if j:
    apply(dc,'skelet17-ladder-skelet10-odd-boundary-cycle');return dc.get(goal)
   ba=bd['ba']
   def fields(a):return [Q(n,M(two,a)),T(a,wl(cf)),J(a,cf[3])]
   def have_half(hc):
    fs=fields(half);nd.unpack(hc,fs);m.bound(hc,Z,two,O)
    m.rewrite(hc,sparse(ar.E),n,M(two,half),hc.get(fs[0]));m.eq(hc,M(two,half),A(M(two,half),Z))
    apply(hc,'skelet17-ladder-skelet10-sparse-pop',{'t':M(two,half),'u':half,'v':Z})
    apply(hc,'skelet17-bounded-division-exists',{'t':half,'u':two})
    def have_quotient(qc):
     def have_digit(rc):
      div=Q(half,A(M(two,q),d));apply(rc,'skelet17-binary-digit-cases',{'t':d})
      def digit(ec,j):
       if j==0:
        m.eq(ec,n,M(four,q),[fs[0],div,Q(d,Z)])
        apply(ec,'skelet17-ladder-skelet10-even-zero-boundary-cycle',{finite['word'][1]:q});return ec.get(goal)
       odd=A(M(two,q),O);m.eq(ec,half,odd,[div,Q(d,O)])
       m.rewrite(ec,sparse(ar.E),half,odd)
       apply(ec,'skelet17-ladder-skelet10-sparse-odd-tail',{'t':q})
       def have_quarter(fc):
        m.eq(fc,n,A(M(eight,quarter),two),[fs[0],div,Q(d,O),Q(q,M(two,quarter))])
        apply(fc,'skelet17-ladder-skelet10-even-one-boundary-cycle',{one['word'][1]:quarter});return fc.get(goal)
       return m.bex_elim(ec,m.pz,A(q,O),Q(q,M(two,m.pz)),quarter,goal,have_quarter)
      return nd.cases(rc,[Q(d,Z),Q(d,O)],goal,digit)
     return m.bex_elim(qc,m.r,two,Q(half,A(M(two,q),m.r)),d,goal,have_digit)
    return m.bex_elim(hc,m.q,A(half,O),nd.BEX(m.r,two,Q(half,A(M(two,m.q),m.r))),q,goal,have_quotient)
   return m.bex_elim(dc,ba,A(n,O),nd.AND(fields(ba)),half,goal,have_half)
  nd.cases(c,[bd['even'](n,cf),bd['odd'](n,cf)],goal,kind)
  m.finish('skelet17-ladder-skelet10-boundary-progress',root,prem,goal,c,'General canonical-boundary progress in an alleged halting history. Sparse arithmetic exhausts the three previously proved numerical cases; no numerical case, counter endpoint, or long-enough window is an extra premise. No new induction or axiom.')
 if proofs:prove()
 return {'input':n,'output_index':outi,'output_row':outr,'prem':prem,'goal':goal,'common':common}
