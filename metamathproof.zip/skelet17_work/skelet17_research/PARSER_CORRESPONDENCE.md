# Removing the artificial parser transitions

The new checked file `parser_checked.mm` closes the valid-word control-table
gap in the preceding checkpoint. Every ordinary input-reading transition of
a locally annotated valid word satisfies the original partial parser table.
End-of-input handling and Gray-output correctness remain unproved, as does
Skelet #17 nonhalting. No machine or machine-history encoding is changed.

## Exact scope

Keep Field, Pow2, Run and the polynomial K(x)=8*(x+1)^3 from
CONTROL_ANNOTATIONS.md. Let DeltaOriginal be the twelve original transitions:
remove the four entries with old control 0,1,2,3 and input 0 from the
sixteen-entry totalized table. Define RunOriginal exactly as Run, replacing
Delta by DeltaOriginal in every local condition.

The valid-word predicate is the earlier bounded input predicate, up to names
of bound variables:

    LowerWord(x) := forall p<x+1
      ((Pow2(p) and 2*p<x+1) -> (One(x,p) or One(x,2*p))).

Here One is the original bounded quotient/remainder formula

    exists q<x+1 exists r<p (x=q*(2*p)+p+r).

In standard binary notation the condition forbids adjacent zeros inside
the significant input word. The source lower-list words are exactly of
that form. The proof uses the displayed bounded formula directly; it does
not assume its semantic characterization as an axiom or prove an equivalence
with the Rocq list representation here.

The principal theorem `skelet17-parser-valid-word-removes-totalization` is

    LowerWord(x) and Run(x,S) -> RunOriginal(x,S).

No extra information about the tape, a chosen parsing, or a particular run
is assumed. In particular, no condition saying that the invalid transitions
are avoided is supplied as a hypothesis.

Combining this theorem with bounded annotation existence gives
`skelet17-parser-original-certificate-exists`:

    LowerWord(x) and 0<x -> exists P<x+1 exists S<K(x)
      (Pow2(P) and x<2*P and S<8*P^3 and RunOriginal(x,S)).

The earlier size-bound theorem still gives control 0 before the leading
place. This is an existence theorem for input-reading control certificates
of the original partial table, not yet for a complete Gray-decoding witness.

## Why the invalid transitions cannot occur

An invalid transition requires both input 0 and an old control in 0..3,
meaning no pending 1. The finite table proves that reading 1 always leaves
a control in 4..7, meaning a pending 1. It also proves that a totalized
transition is original whenever its input is 1 or its old control is in 4..7.
Both are finite case proofs with no induction.

Fix a significant input place p. There are two cases.

1. If 2*p>x, the digit at p must be 1. Indeed p<=x<2*p, and uniqueness of
   quotient and remainder forces the binary field at p to have value 1.
   The step is therefore original.
2. If 2*p<=x, instantiate LowerWord at p. Either the current bit is 1, in
   which case the current step is original, or the preceding bit at 2*p
   is 1. In the latter case instantiate Run at 2*p. Its transition leaves
   a control in 4..7. That after-control is the same packed field as the
   before-control at p. Field uniqueness proves their equality. The current
   step is therefore original even if its input is 0.

The proof converts One into Field(x,p,2,1) by explicit bounded witness
introduction. Packed-field uniqueness identifies this value with the digit
in the existing annotation. All field witnesses retain their original
bounds. Bounded quantifiers are eliminated and introduced explicitly.

## Induction and axioms

No new trusted declarations are added: the file uses exactly the original
93 syntax, logic, arithmetic and bounded-induction declarations.

The correspondence theorem depends on one earlier bounded-induction
construction: bounded division, used to prove Pow2(p) implies Pow2(2*p).
That supplies the neighboring place needed to instantiate Run. The new
finite-table, field-uniqueness, One-to-field and leading-digit lemmas use
no induction. The existence corollary has two induction constructions in
its dependency closure, the same two as the preceding annotation theorem.

The trusted-core and dependency comparison is recorded in parser_manifest.json.
The official Metamath verifier checks every proof in parser_checked.mm.
parser_table_checks.json independently checks all sixteen cases against
the earlier Python partial parser; this is a source-interpretation check,
not a replacement for the formal proofs.

## What remains

The source parser's end-of-input action, emission counts, compressed output,
and identification with the source Gray-counter value still require proofs.
The global Skelet #17 invariant excluding B111 is also unproved. Nothing
here proves machine nonhalting or independence.

Regenerate from the archive root:

    python3 skelet17_research/build_parser.py
    python3 skelet17_research/prune.py parser_raw.mm parser_checked.mm
    metamath 'read "skelet17_research/parser_checked.mm"' 'verify proof *' exit
    python3 skelet17_research/audit_parser.py

Capture the verifier output in parser_verification.log before the audit.
Require a clean parse as well as complete proof verification.
