"""Smaller ND case proofs using a derived propositional theorem.

The original recursive case helper accumulates every unused disjunction
tail in the context of later arithmetic branches. Here each branch is
proved in the original context plus just its own assumption. A single
derived implication lemma combines them. All emitted steps remain $p.
"""
def install(nd):
    b=nd.b
    name='packet-bridge-or-implications'
    if name in b.rules:return
    ph,ps,ch=b.ph,b.ps,b.ch
    left,right=b.Imp(ph,ch),b.Imp(ps,ch)
    prem=b.And(left,right);choice=b.Or(ph,ps)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,[left,right])
    oc=ctx.push(choice);lc=oc.push(ph);rc=oc.push(ps)
    lc.mp(ph,ch);rc.mp(ps,ch)
    oc.put(ch,b.apply('nd-or-elim',{'ga':oc.g,'ph':ph,'ps':ps,'ch':ch},[oc.get(choice),lc.get(ch),rc.get(ch)]))
    ctx.intro(choice,ch,oc);root.intro(prem,b.Imp(choice,ch),ctx)
    formula=b.Imp(prem,b.Imp(choice,ch))
    b.theorem(name,formula,root.get(formula))
    def cases(ctx,parts,goal,fn,offset=0,p=None):
        if len(parts)==1:
            if p:ctx.put(parts[0],p)
            return ctx.put(goal,fn(ctx,offset))
        source=p or ctx.get(nd.OR(parts))
        for k,part in enumerate(parts):
            child=ctx.push(part);child.put(goal,fn(child,k+offset))
            ctx.intro(part,goal,child)
        tail=parts[-1]
        for part in reversed(parts[:-1]):
            l,r=b.Imp(part,goal),b.Imp(tail,goal)
            ante=b.And(l,r);cons=b.Imp(b.Or(part,tail),goal)
            ctx.both(l,r)
            ctx.theorem(b.Imp(ante,cons),b.apply(name,{'ph':part,'ps':tail,'ch':goal}))
            ctx.mp(ante,cons);tail=b.Or(part,tail)
        return ctx.mp(tail,goal,q=source)
    nd.cases=cases
