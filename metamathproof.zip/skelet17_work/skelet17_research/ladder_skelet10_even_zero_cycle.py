"""Complete boundary composition for the n=4b numerical case."""
def add_skelet10_even_zero_cycle(m,api,sp,right,left,h,assembly,bd,cycles,instructions,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 H,N,o,k=[h[x] for x in ('H','n','offset','start')];AT=h['AT'];cf,nf=api['current'],api['next']
 two,three,four,eight,five=map(ar.num,(2,3,4,8,5));T=sp['transform'];J=right['carry'];sparse=api['sparse'];step=api['step']
 apply,unpack,collect,elim_rows,pack_rows,bounds=[assembly[x] for x in ('apply','unpack','collect','elim_rows','pack_rows','bounds')]
 advance,run_counter=cycles['advance'],cycles['run_counter'];n=cycles['input'];halt=assembly['halt']
 word=m.declare('zeroCycleWord','term');half=m.declare('zeroCycleHalf');tail=m.declare('zeroCycleTail');block=m.declare('blockTail')
 actual=[[m.declare('zeroCycleRow'+str(j)+s) for s in ('Q','L','Bit','R')] for j in range(1,5)]
 re=[m.declare('zeroCycleRightEntry'+s) for s in ('Q','L','Bit','R')]
 final=[m.declare('zeroCycleFinal'+s) for s in ('Q','L','Bit','R')]
 outi,outr=cycles['output_index'],cycles['output_row']
 src=[m.declare('prefixSource'+s,'term') for s in ('Q','L','Bit','R')]
 def wl(row):return A(M(two,row[1]),row[2])
 def push(x,d):return A(M(two,x),d)
 def transport_lemma():
  fs=[*[Q(x,y) for x,y in zip(cf,src)],step(cf,nf)];prem=nd.AND(fs)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  instructions['transport'](c,lambda row:step(row,nf),cf,src)
  m.finish('z10-compose-step-transport',root,prem,step(src,nf),c,'One shared ordinary-Step source equality transport. No induction.')
 def prefix(c,row,i,canonical,updates,actuals,goal,fn):
  """Construct finite actual rows, using the shared instruction contracts."""
  if not updates:return fn(c,row,i)
  j,t,u,v=updates[0];new=actuals[0]
  source,target,_=instructions['instruction'](j,t,u,v);assert target==canonical[1]
  for x,y,z in zip(row,source,canonical[0]):
   if y!=z:m.eq(c,x,y,[Q(x,z)])
  def found(dc):
   apply(dc,'z10-compose-step-transport',{**{x[1]:y for x,y in zip(cf,row)},**{x[1]:y for x,y in zip(nf,new)},**{x[1]:y for x,y in zip(src,source)}})
   if v in (Z,O):m.bound(dc,v,two,O if v==Z else Z)
   else:dc.get(L(v,two))
   instructions['contract'](dc,j,t,u,v,new)
   eqs=nd.AND([Q(x,y) for x,y in zip(new,target)]);dc.mp(step(source,new),eqs);unpack(dc,eqs)
   return prefix(dc,new,A(i,O),canonical[1:],updates[1:],actuals[1:],goal,fn)
  return advance(c,row,i,j//2,new,goal,found)
 def prove():
  fs=[h['total'](o,N),h['steps'](o,N),*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5)),*bounds(cf),L(k,A(N,O)),AT(o,k,cf),Q(cf[0],three),L(cf[2],two),sparse(n),sparse(cf[3]),bd['even'](n,cf),Q(n,M(four,word))]
  prem=nd.AND(fs)
  def result(i,row):return nd.AND([L(k,i),AT(o,i,row),bd['boundary'](cf[3],row)])
  goal=nd.BEX(outi,A(N,O),nd.bexs(outr,H,result(outi,outr)));root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  ba=bd['ba']
  def efields(a):return [Q(n,M(two,a)),T(a,wl(cf)),J(a,cf[3])]
  def have_half(hc):
   efs=efields(half);nd.unpack(hc,efs);m.bound(hc,Z,two,O)
   m.eq(hc,A(M(two,half),Z),A(M(two,M(two,word)),Z),[m.flip(hc,efs[0]),fs[-1]])
   m.quotient_unique(hc,two,half,Z,M(two,word),Z)
   m.rewrite(hc,T(ar.E,wl(cf)),half,M(two,word));m.rewrite(hc,J(ar.E,cf[3]),half,M(two,word))
   m.rewrite(hc,sparse(ar.E),n,M(four,word))
   m.eq(hc,M(four,word),A(M(two,M(two,word)),Z));apply(hc,'skelet17-ladder-skelet10-sparse-pop',{'t':M(four,word),'u':M(two,word),'v':Z})
   m.eq(hc,M(two,word),A(M(two,word),Z));apply(hc,'skelet17-ladder-skelet10-sparse-pop',{'t':M(two,word),'u':word,'v':Z})
   apply(hc,'skelet17-ladder-skelet10-carry-base-inverse',{'t':word,'u':cf[3]})
   apply(hc,'skelet17-ladder-skelet10-transform-decompose-0',{'t':word,'u':wl(cf)})
   body=b.And(Q(wl(cf),A(M(four,block),Z)),T(word,block))
   def have_tail(tc):
    split=Q(wl(cf),A(M(four,tail),Z));unpack(tc,b.And(split,T(word,tail)))
    m.eq(tc,wl(cf),A(M(two,M(two,tail)),Z),[split]);m.quotient_unique(tc,two,cf[1],cf[2],M(two,tail),Z)
    r0=push(push(word,Z),O);l1=push(tail,O);l2=push(l1,Z)
    updates=[(6,tail,r0,Z),(4,r0,tail,O),(9,push(word,Z),l1,O),(3,word,l2,Z)]
    rows=[]
    for j,t,u,v in updates:
     sr,tr,_=instructions['instruction'](j,t,u,v)
     if rows:assert rows[-1]==sr
     else:rows.append(sr)
     rows.append(tr)
    m.eq(tc,cf[1],rows[0][1],[Q(cf[1],M(two,tail))]);m.eq(tc,cf[3],r0,[Q(cf[3],A(M(four,word),O))])
    def completed(pc,pr,pi):
     m.rewrite(pc,sparse(ar.E),word,pr[3],ar.sym(pr[3],word,pc.get(Q(pr[3],word)),pc.g))
     def right_entry(ec):
      apply(ec,'skelet17-ladder-skelet10-a0-enters-right-counter',{**{v[1]:x for v,x in zip(cf,pr)},**{v[1]:x for v,x in zip(nf,re)}})
      ell=rows[-1][1]
      m.rewrite(ec,m.sub(right['entry'](re),{right['word'][1]:ar.E,right['ell'][1]:pr[1]}),pr[3],word)
      m.rewrite(ec,m.sub(right['entry'](re),{right['word'][1]:word,right['ell'][1]:ar.E}),pr[1],ell)
      params={right['word'][1]:word,right['ell'][1]:ell}
      def right_output(rc,ri,rr):
       m.eq(rc,wl(rr),A(M(eight,tail),five),[Q(wl(rr),ell)])
       def align(fc):
        apply(fc,'skelet17-ladder-skelet10-right-output-align-odd',{'t':word,'u':tail,**{v[1]:x for v,x in zip(cf,rr)},**{v[1]:x for v,x in zip(nf,final)}})
        m.rewrite(fc,bd['boundary'](ar.E,final),A(M(four,word),O),cf[3],ar.sym(cf[3],A(M(four,word),O),fc.get(Q(cf[3],A(M(four,word),O))),fc.g))
        entryi=A(pi,O);m.bound(fc,k,entryi,ar.num(4));m.translt(fc,k,entryi,ri);m.successor(fc,ri);m.translt(fc,k,ri,A(ri,O))
        end=A(ri,O);nd.conj(fc,[L(k,end),AT(o,end,final),bd['boundary'](cf[3],final)]);pack_rows(fc,outr,result(end,outr),final)
        return m.bex_intro(fc,outi,A(N,O),nd.bexs(outr,H,result(outi,outr)),end)
       return advance(rc,rr,ri,3,final,goal,align)
      return run_counter(ec,'right',re,A(pi,O),params,goal,right_output)
     return advance(pc,pr,pi,0,re,goal,right_entry)
    return prefix(tc,cf,k,rows,updates,actual,goal,completed)
   return m.bex_elim(hc,block,A(wl(cf),O),body,tail,goal,have_tail)
  m.bex_elim(c,ba,A(n,O),nd.AND(efields(ba)),half,goal,have_half)
  m.finish('skelet17-ladder-skelet10-even-zero-boundary-cycle',root,prem,goal,c,'Complete n=4b canonical boundary composition in the same original history. All four prefix moves, right entry, counter output and required D1 alignment are constructed. No new induction or axioms.')
 if proofs:
  if 'z10-compose-step-transport' not in m.theorems:transport_lemma()
  prove()
 return {'word':word,'prefix':prefix}
