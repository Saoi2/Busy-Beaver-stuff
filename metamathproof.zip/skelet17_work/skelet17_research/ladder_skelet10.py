"""Skelet #10 right-counter fragment in the unchanged arithmetic language.

This module does not assert whole-machine nonhalting. The unresolved part
is a synchronization invariant for the two sides after a D return.
"""
def add_skelet10(m, proofs=True):
 nd,b,a=m.nd,m.b,m.a
 A,M,Q,L=m.A,m.M,m.Q,m.L
 Z,O=m.Z,m.O;num=a.num;two,three,four=map(num,(2,3,4))
 use=m.invoke
 # Sparse forbids the two-bit field 11 at every Pow2 scale. All parameters
 # and division witnesses remain bounded by ordinary multiplication terms.
 sp,sq,sr=[m.declare('z10Sparse'+s) for s in ('Place','Quotient','Low')]
 gap=m.declare('z10PositiveGap')
 fq,fr=[m.declare('z10Division'+s) for s in ('Quotient','Bit')]
 evenfresh=m.declare('z10EvenWitness')
 def forbidden(x,p,q,r):return Q(x,A(A(M(M(four,p),q),M(three,p)),r))
 def tail(x,p):return nd.BALL(sq,A(x,O),nd.BALL(sr,p,b.Not(forbidden(x,p,sq,sr))))
 def body(x,p):return b.Imp(m.power2(p),tail(x,p))
 def sparse(x):return nd.BALL(sp,A(x,O),body(x,sp))
 def bad_bounds(c,x,p,q,r,equation):
  """A positive-scale 11 field lies within x, as does its upper quotient."""
  out=b.And(L(p,A(x,O)),L(q,A(x,O)))
  def positive(cc,peq):
   m.bound(cc,p,A(x,O),A(M(p,A(M(four,q),two)),r),[equation])
   m.bound(cc,q,A(x,O),A(A(M(A(M(four,gap),three),q),M(three,p)),r),[equation,peq])
   return cc.both(*out[1:])
  if p==O:
   # Rewriting the literal 1 by its positive-gap equation would also rewrite
   # every numerical coefficient. Use direct bounds in this constant case.
   m.bound(c,p,A(x,O),A(A(M(four,q),two),r),[equation])
   m.bound(c,q,A(x,O),A(A(M(three,q),three),r),[equation])
   c.both(*out[1:])
  else:m.gap_elim(c,Z,p,gap,out,positive)
  nd.unpack(c,list(out[1:]))
 def exclude_field(c,x,p,q,r,equation,goal):
  nd.unpack(c,list(m.power2(p)[1:]))
  bad_bounds(c,x,p,q,r,equation)
  c.all_elim(sp,b.Imp(L(sp,A(x,O)),body(x,sp)),p)
  c.mp(L(p,A(x,O)),body(x,p));c.mp(m.power2(p),tail(x,p))
  c.all_elim(sq,b.Imp(L(sq,A(x,O)),nd.BALL(sr,p,b.Not(forbidden(x,p,sq,sr)))),q)
  c.mp(L(q,A(x,O)),nd.BALL(sr,p,b.Not(forbidden(x,p,q,sr))))
  c.all_elim(sr,b.Imp(L(sr,p),b.Not(forbidden(x,p,q,sr))),r)
  c.mp(L(r,p),b.Not(equation));return c.explode(equation,goal)
 # This kernel uses syntactic DV conditions for forall introduction.
 # A binder occurring bound in an outer Sparse premise is therefore not
 # fresh enough. Prove with different names, then apply an independently
 # derived alpha-renaming implication from the empty context.
 pp,pq,pr=[m.declare('z10Proof'+v) for v in ('Place','Quotient','Low')]
 def sparse_named(x,p,q,r):
  return nd.BALL(p,A(x,O),b.Imp(m.power2(p),nd.BALL(q,A(x,O),nd.BALL(r,p,b.Not(forbidden(x,p,q,r))))))
 def fresh_tail(x,p):return nd.BALL(pq,A(x,O),nd.BALL(pr,p,b.Not(forbidden(x,p,pq,pr))))
 def fresh_body(x,p):return b.Imp(m.power2(p),fresh_tail(x,p))
 def sparse_alpha():
  x=b.t;prem=sparse_named(x,pp,pq,pr);root=nd.Ctx();c=root.push(prem)
  pg=L(sp,A(x,O));pc=c.push(pg)
  pc.all_elim(pp,b.Imp(L(pp,A(x,O)),fresh_body(x,pp)),sp)
  pc.mp(pg,fresh_body(x,sp));pw=m.power2(sp);wc=pc.push(pw);wc.mp(pw,fresh_tail(x,sp))
  qg=L(sq,A(x,O));qc=wc.push(qg)
  qc.all_elim(pq,b.Imp(L(pq,A(x,O)),nd.BALL(pr,sp,b.Not(forbidden(x,sp,pq,pr)))),sq)
  qc.mp(qg,nd.BALL(pr,sp,b.Not(forbidden(x,sp,sq,pr))))
  rg=L(sr,sp);rc=qc.push(rg)
  rc.all_elim(pr,b.Imp(L(pr,sp),b.Not(forbidden(x,sp,sq,pr))),sr)
  rc.mp(rg,b.Not(forbidden(x,sp,sq,sr)))
  qc.intro(rg,b.Not(forbidden(x,sp,sq,sr)),rc);qc.all_intro(sr,b.Imp(rg,b.Not(forbidden(x,sp,sq,sr))))
  wc.intro(qg,nd.BALL(sr,sp,b.Not(forbidden(x,sp,sq,sr))),qc)
  wc.all_intro(sq,b.Imp(qg,nd.BALL(sr,sp,b.Not(forbidden(x,sp,sq,sr)))))
  pc.intro(pw,tail(x,sp),wc);c.intro(pg,body(x,sp),pc)
  c.all_intro(sp,b.Imp(pg,body(x,sp)))
  m.finish('z10-sparse-rename-bound-variables',root,prem,sparse(x),c,
   'Derived bound-variable renaming. Prove in an independent context before weakening into a context containing Sparse.')
 if proofs: sparse_alpha()
 def prove_sparse(ctx,x,fn):
  pg=L(pp,A(x,O));pc=ctx.push(pg);pw=m.power2(pp);wc=pc.push(pw)
  qg=L(pq,A(x,O));qc=wc.push(qg);rg=L(pr,pp);rc=qc.push(rg)
  eq=forbidden(x,pp,pq,pr);ec=rc.push(eq);bad=L(Z,Z)
  ec.put(bad,fn(ec,pp,pq,pr,eq,bad));ec.put(b.Not(bad),b.ax('O1',ec.g,t=Z))
  rc.put(b.Not(eq),a.not_intro(rc.g,eq,bad,ec.get(bad),ec.get(b.Not(bad))))
  qc.intro(rg,b.Not(eq),rc);qc.all_intro(pr,b.Imp(rg,b.Not(eq)))
  wc.intro(qg,nd.BALL(pr,pp,b.Not(eq)),qc)
  wc.all_intro(pq,b.Imp(qg,nd.BALL(pr,pp,b.Not(eq))))
  pc.intro(pw,fresh_tail(x,pp),wc);ctx.intro(pg,fresh_body(x,pp),pc)
  ctx.all_intro(pp,b.Imp(pg,fresh_body(x,pp)))
  return use(ctx,'z10-sparse-rename-bound-variables',{'t':x})
 def sparse_zero():
  root=nd.Ctx()
  def nofield(c,p,q,r,equation,bad):
   nd.unpack(c,list(m.power2(p)[1:]))
   def positive(cc,peq):
    m.bound(cc,Z,A(A(M(M(four,p),q),M(three,p)),r),A(A(M(M(four,p),q),A(M(three,gap),two)),r),[peq])
    m.rewrite(cc,L(Z,a.E),equation[2],Z,a.sym(Z,equation[2],cc.get(equation),cc.g))
    return cc.get(bad)
   return m.gap_elim(c,Z,p,gap,bad,positive)
  prove_sparse(root,Z,nofield)
  m.save('skelet17-ladder-skelet10-sparse-zero',root,sparse(Z),'Zero has no adjacent 1 bits. The Sparse predicate is Delta-0; no induction.')
 if proofs: sparse_zero()
 x,y,d=b.t,b.u,b.v
 def sparse_pop():
  fs=[sparse(x),Q(x,A(M(two,y),d)),L(d,two)]
  prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  def nofield(cc,p,q,r,equation,bad):
   nd.unpack(cc,list(m.power2(p)[1:]));use(cc,'skelet17-binary-power-double',{'t':p})
   low=A(M(two,r),d);scale=M(two,p)
   cc.both(L(r,p),L(d,two));use(cc,'skelet17-binary-field-range',{'t':r,'u':d,'v':two,'w':p})
   eq=forbidden(x,scale,q,low);m.eq(cc,*eq[1:],[fs[1],equation])
   return exclude_field(cc,x,scale,q,low,eq,bad)
  prove_sparse(c,y,nofield)
  m.finish('skelet17-ladder-skelet10-sparse-pop',root,prem,sparse(y),c,
   'Deleting the low bit preserves the absence of adjacent 1s. Reuses Pow2 doubling; no new induction.')
 if proofs: sparse_pop()
 def sparse_odd_tail():
  xx=A(M(two,x),O);prem=sparse(xx);goal=m.even(x)
  root=nd.Ctx();c=root.push(prem);m.bound(c,Z,two,O)
  use(c,'skelet17-bounded-division-exists',{'t':x,'u':two})
  def haveq(qc):
   def haver(rc):
    equation=Q(x,A(M(two,fq),fr));use(rc,'skelet17-binary-digit-cases',{'t':fr})
    def digit(dc,k):
     if k==0:
      m.eq(dc,x,M(two,fq),[equation,Q(fr,Z)])
      return m.bex_intro(dc,m.pz,A(x,O),Q(x,M(two,m.pz)),fq)
     use(dc,'skelet17-binary-power-one',{},False);m.bound(dc,Z,O,Z)
     eq=forbidden(xx,O,fq,Z);m.eq(dc,*eq[1:],[equation,Q(fr,O)])
     return exclude_field(dc,xx,O,fq,Z,eq,goal)
    return nd.cases(rc,[Q(fr,Z),Q(fr,O)],goal,digit)
   return m.bex_elim(qc,m.r,two,Q(x,A(M(two,fq),m.r)),fr,goal,haver)
  m.bex_elim(c,m.q,A(x,O),nd.BEX(m.r,two,Q(x,A(M(two,m.q),m.r))),fq,goal,haveq)
  m.finish('skelet17-ladder-skelet10-sparse-odd-tail',root,prem,goal,c,
   'A Sparse word beginning with 1 has a zero next bit, expressed by Even(tail). Uses existing bounded division only.')
 if proofs: sparse_odd_tail()
 # A small order fact makes the append proof independent of any division
 # algorithm implementation: a quotient of a value below 2y is below y.
 def double_window():
  x,y,d=b.t,b.u,b.v;prem=L(A(M(two,x),d),M(two,y));goal=L(x,y)
  root=nd.Ctx();c=root.push(prem);tri=[goal,Q(x,y),L(y,x)]
  c.put(nd.OR(tri),b.ax('O3',c.g,t=x,u=y))
  def order(cc,k):
   if k==0:return cc.get(goal)
   if k==1:
    old=A(M(two,x),d);right=M(two,y)
    m.eq(cc,old,A(d,M(two,y)),[Q(x,y)])
    m.rewrite(cc,L(a.E,right),old,A(d,right))
    m.eq(cc,right,A(Z,right));m.rewrite(cc,L(A(d,right),a.E),right,A(Z,right))
    use(cc,'skelet17-ladder-lt-add-cancel',{'t':d,'u':Z,'v':right})
    cc.put(b.Not(L(d,Z)),b.ax('O4',cc.g,t=d));return cc.explode(L(d,Z),goal)
   def larger(dc,eq):
    m.bound(dc,M(two,y),A(M(two,x),d),A(A(M(two,gap),d),O),[eq])
    m.translt(dc,M(two,y),A(M(two,x),d),M(two,y))
    bad=L(M(two,y),M(two,y));dc.put(b.Not(bad),b.ax('O1',dc.g,t=M(two,y)))
    return dc.explode(bad,goal)
   return m.gap_elim(cc,y,x,gap,goal,larger)
  nd.cases(c,tri,goal,order)
  m.finish('skelet17-ladder-skelet10-double-window-bound',root,prem,goal,c,
   'If 2x+d<2y then x<y, for arbitrary nonnegative d. No induction.')
 if proofs: double_window()
 half=m.declare('z10PlaceHalf')
 def sparse_push():
  x,d=b.t,b.u;new=A(M(two,x),d)
  condition=b.Or(Q(d,Z),m.even(x));fs=[sparse(x),L(d,two),condition]
  prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  def nofield(cc,p,q,r,equation,bad):
   use(cc,'skelet17-binary-power-halving',{'t':p})
   hb=b.And(Q(p,M(two,m.pz)),m.power2(m.pz))
   opts=[Q(p,O),nd.BEX(m.pz,A(p,O),hb)]
   def scale(dc,k):
    if k==0:
     m.rewrite(dc,L(r,a.E),p,O)
     m.eq(dc,O,A(Z,O));m.rewrite(dc,L(r,a.E),O,A(Z,O))
     use(dc,'skelet17-binary-below-successor',{'t':r,'u':Z})
     def remainder(ec,j):
      if j==0:
       ec.put(b.Not(L(r,Z)),b.ax('O4',ec.g,t=r));return ec.explode(L(r,Z),bad)
      eq=Q(new,A(M(two,A(M(two,q),O)),O))
      m.eq(ec,*eq[1:],[equation,Q(p,O),Q(r,Z)])
      m.bound(ec,O,two,Z);m.quotient_unique(ec,two,x,d,A(M(two,q),O),O)
      def guard(gc,t):
       if t==0:
        m.eq(gc,Z,O,[m.flip(gc,Q(d,Z)),Q(d,O)]);return m.false_zero_one(gc,bad)
       def evenword(hc):
        yEq=Q(x,M(two,evenfresh));m.eq(hc,A(M(two,evenfresh),Z),A(M(two,q),O),[m.flip(hc,yEq),Q(x,A(M(two,q),O))])
        m.bound(hc,Z,two,O);m.quotient_unique(hc,two,evenfresh,Z,q,O)
        return m.false_zero_one(hc,bad)
       return m.bex_elim(gc,m.pz,A(x,O),Q(x,M(two,m.pz)),evenfresh,bad,evenword)
      return nd.cases(ec,[Q(d,Z),m.even(x)],bad,guard)
     return nd.cases(dc,[L(r,Z),Q(r,Z)],bad,remainder)
    def havehalf(hc):
     peq=Q(p,M(two,half));nd.unpack(hc,[peq,m.power2(half)])
     m.bound(hc,Z,two,O);use(hc,'skelet17-bounded-division-exists',{'t':r,'u':two})
     def haveq(qc):
      def haver(rc):
       req=Q(r,A(M(two,fq),fr));m.rewrite(rc,L(r,a.E),p,M(two,half))
       m.rewrite(rc,L(a.E,M(two,half)),r,A(M(two,fq),fr),rc.get(req))
       use(rc,'skelet17-ladder-skelet10-double-window-bound',{'t':fq,'u':half,'v':fr})
       term=forbidden(x,half,q,fq)[2]
       m.eq(rc,new,A(M(two,term),fr),[equation,peq,req])
       m.quotient_unique(rc,two,x,d,term,fr)
       eq=forbidden(x,half,q,fq)
       return exclude_field(rc,x,half,q,fq,eq,bad)
      return m.bex_elim(qc,m.r,two,Q(r,A(M(two,fq),m.r)),fr,bad,haver)
     return m.bex_elim(hc,m.q,A(r,O),nd.BEX(m.r,two,Q(r,A(M(two,m.q),m.r))),fq,bad,haveq)
    return m.bex_elim(dc,m.pz,A(p,O),hb,half,bad,havehalf)
   return nd.cases(cc,opts,bad,scale)
  prove_sparse(c,new,nofield)
  m.finish('skelet17-ladder-skelet10-sparse-push',root,prem,sparse(new),c,
   'Prepending a bit d preserves Sparse if d=0 or the old low bit is zero. Reuses division and Pow2 halving; no new induction.')
 if proofs: sparse_push()
 def sparse_constructors():
  x=b.t;root=nd.Ctx();prem=sparse(x);c=root.push(prem)
  m.bound(c,Z,two,O);c.put(Q(Z,Z),b.refl(c.g,Z));nd.disj(c,[Q(Z,Z),m.even(x)],0)
  nd.conj(c,[sparse(x),L(Z,two),b.Or(Q(Z,Z),m.even(x))])
  use(c,'skelet17-ladder-skelet10-sparse-push',{'t':x,'u':Z})
  term=A(M(two,x),Z);m.eq(c,term,M(two,x));m.rewrite(c,sparse(a.E),term,M(two,x))
  m.finish('skelet17-ladder-skelet10-sparse-prefix-0',root,prem,sparse(M(two,x)),c,
   'The Zeckendorf syntax constructor 0w preserves Sparse. No new induction.')
  root=nd.Ctx();c=root.push(prem);use(c,'skelet17-ladder-skelet10-sparse-prefix-0',{'t':x})
  m.bound(c,x,A(M(two,x),O),x);c.put(Q(M(two,x),M(two,x)),b.refl(c.g,M(two,x)))
  m.bex_intro(c,m.pz,A(M(two,x),O),Q(M(two,x),M(two,m.pz)),x)
  m.bound(c,O,two,Z);nd.disj(c,[Q(O,Z),m.even(M(two,x))],1)
  nd.conj(c,[sparse(M(two,x)),L(O,two),b.Or(Q(O,Z),m.even(M(two,x)))])
  use(c,'skelet17-ladder-skelet10-sparse-push',{'t':M(two,x),'u':O})
  term=A(M(two,M(two,x)),O);target=A(M(four,x),O)
  m.eq(c,term,target);m.rewrite(c,sparse(a.E),term,target)
  m.finish('skelet17-ladder-skelet10-sparse-prefix-10',root,prem,sparse(target),c,
   'The Zeckendorf syntax constructor 10w preserves Sparse. Nearest tape bit is written first in 10w. No new induction.')
 if proofs: sparse_constructors()

 # Ordinary Skelet #10 transition relation; the only missing branch E0 is
 # completed by 1RZ, matching every other machine in this project.
 table=[(1,1,1),(0,1,0),(2,0,0),(0,1,1),(4,1,1),
        (3,0,1),(2,0,1),(3,0,0),(5,1,1),(1,1,0)]
 cf=[m.declare('z10Current'+s,'term') for s in ('Q','L','Bit','R')]
 nf=[m.declare('z10Next'+s,'term') for s in ('Q','L','Bit','R')]
 oddvar=m.declare('z10Odd');oddw=m.declare('z10OddWitness')
 def odd(l):return nd.BEX(oddvar,A(l,O),Q(l,A(M(two,oddvar),O)))
 def parts(c,n,j):
  q,l,bit,r=c;nq,nl,nb,nr=n;qs,direction,w=table[j]
  eqs=[Q(nl,A(M(two,l),num(w))),Q(r,A(M(two,nr),nb))] if direction else [Q(nr,A(M(two,r),num(w))),Q(l,A(M(two,nl),nb))]
  return [Q(q,num(j//2)),Q(bit,num(j%2)),Q(nq,num(qs)),*eqs,b.Or(Q(nb,Z),Q(nb,O))]
 def step(c,n):return nd.OR([nd.AND(parts(c,n,j)) for j in range(10)])
 def regions(c):
  q,l,bit,r=c
  return [[Q(q,Z),Q(bit,Z),sparse(r)],
          [Q(q,O),odd(l),sparse(A(M(two,r),bit))],
          [Q(q,two),Q(bit,O)]]
 def scan(c):return nd.OR([nd.AND(f) for f in regions(c)])
 def outcome(c):return b.Or(scan(c),Q(c[0],three))
 def neq(c,v,i,j,goal):
  proof=a.trans(num(i),v,num(j),a.sym(v,num(i),c.get(Q(v,num(i))),c.g),c.get(Q(v,num(j))),c.g)
  if i>j:proof=a.sym(num(i),num(j),proof,c.g)
  lo,hi=sorted((i,j));m.bound(c,num(lo),num(hi),num(hi-lo-1))
  m.rewrite(c,L(num(lo),a.E),num(hi),num(lo),a.sym(num(lo),num(hi),proof,c.g))
  bad=L(num(lo),num(lo));c.put(b.Not(bad),b.ax('O1',c.g,t=num(lo)));return c.explode(bad,goal)
 def bitbound(c,pf):
  def digit(dc,k):
   m.bound(dc,num(k),two,num(1-k))
   return m.rewrite(dc,L(a.E,two),num(k),nf[2],dc.get(m.flip(dc,Q(nf[2],num(k)))))
  return nd.cases(c,list(pf[-1][1:]),L(nf[2],two),digit)
 def makeodd(c,l,nl,eq):
  m.eq(c,nl,A(M(two,l),O),[eq]);m.bound(c,l,A(nl,O),A(l,O),[eq])
  return m.bex_intro(c,oddvar,A(nl,O),Q(nl,A(M(two,oddvar),O)),l)
 def pack(c,k):
  nd.conj(c,regions(nf)[k]);nd.disj(c,[nd.AND(f) for f in regions(nf)],k)
  return nd.disj(c,list(outcome(nf)[1:]),0)
 def local():
  prem=b.And(scan(cf),step(cf,nf));goal=outcome(nf);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]))
  def region(ec,k):
   nd.unpack(ec,regions(cf)[k])
   def instruction(sc,j):
    pf=parts(cf,nf,j);nd.unpack(sc,pf)
    if j//2!=k:return neq(sc,cf[0],k,j//2,goal)
    if k==0 and j==1:return neq(sc,cf[2],0,1,goal)
    if k==2:
     if j==4:return neq(sc,cf[2],1,0,goal)
     return nd.disj(sc,list(goal[1:]),1)
    if j==0:
     makeodd(sc,cf[1],nf[1],pf[3])
     m.rewrite(sc,sparse(a.E),cf[3],A(M(two,nf[3]),nf[2]),sc.get(pf[4]))
     return pack(sc,1)
    if j==2:
     def oddleft(dc):
      leq=Q(cf[1],A(M(two,oddw),O));m.eq(dc,A(M(two,nf[1]),nf[2]),A(M(two,oddw),O),[m.flip(dc,pf[4]),leq])
      bitbound(dc,pf);m.bound(dc,O,two,Z);m.quotient_unique(dc,two,nf[1],nf[2],oddw,O)
      return pack(dc,2)
     return m.bex_elim(sc,oddvar,A(cf[1],O),Q(cf[1],A(M(two,oddvar),O)),oddw,goal,oddleft)
    assert j==3
    m.rewrite(sc,sparse(A(M(two,cf[3]),a.E)),cf[2],O,sc.get(Q(cf[2],O)))
    use(sc,'skelet17-ladder-skelet10-sparse-odd-tail',{'t':cf[3]})
    def evenright(dc):
     req=Q(cf[3],M(two,evenfresh));m.eq(dc,A(M(two,nf[3]),nf[2]),A(M(two,evenfresh),Z),[m.flip(dc,pf[4]),req])
     bitbound(dc,pf);m.bound(dc,Z,two,O);m.quotient_unique(dc,two,nf[3],nf[2],evenfresh,Z)
     m.bound(dc,O,two,Z);m.eq(dc,A(M(two,cf[3]),O),A(M(two,cf[3]),O))
     nd.conj(dc,[sparse(A(M(two,cf[3]),O)),Q(A(M(two,cf[3]),O),A(M(two,cf[3]),O)),L(O,two)])
     use(dc,'skelet17-ladder-skelet10-sparse-pop',{'t':A(M(two,cf[3]),O),'u':cf[3],'v':O})
     nd.conj(dc,[sparse(cf[3]),pf[4],L(nf[2],two)])
     use(dc,'skelet17-ladder-skelet10-sparse-pop',{'t':cf[3],'u':nf[3],'v':nf[2]})
     return pack(dc,0)
    return m.bex_elim(sc,m.pz,A(cf[3],O),Q(cf[3],M(two,m.pz)),evenfresh,goal,evenright)
   return nd.cases(ec,[nd.AND(parts(cf,nf,j)) for j in range(10)],goal,instruction)
  nd.cases(ctx,[nd.AND(f) for f in regions(cf)],goal,region)
  m.finish('skelet17-ladder-skelet10-right-scan-to-D',root,prem,goal,ctx,
   'Ordinary right-counter step: preserves its arithmetic scan invariant or reaches state D. D is a stopping boundary, not asserted safe for further steps. Not whole-machine nonhalting.')
 if proofs: local()
 # The blank ordinary first step enters the right-counter scan domain.
 def entry():
  initial=[Z,Z,Z,Z];prem=step(initial,nf);goal=scan(nf);root=nd.Ctx();ctx=root.push(prem)
  def instruction(c,j):
   pf=parts(initial,nf,j);nd.unpack(c,pf)
   if j//2!=0:return neq(c,Z,0,j//2,goal)
   if j%2!=0:return neq(c,Z,0,1,goal)
   makeodd(c,Z,nf[1],pf[3]);bitbound(c,pf);m.bound(c,Z,two,O)
   m.eq(c,A(M(two,nf[3]),nf[2]),A(M(two,Z),Z),[m.flip(c,pf[4])])
   m.quotient_unique(c,two,nf[3],nf[2],Z,Z)
   use(c,'skelet17-ladder-skelet10-sparse-zero',{},False)
   eq=Q(A(M(two,nf[3]),nf[2]),Z);m.eq(c,*eq[1:],[Q(nf[3],Z),Q(nf[2],Z)])
   m.rewrite(c,sparse(a.E),Z,eq[1],a.sym(eq[1],Z,c.get(eq),c.g))
   nd.conj(c,regions(nf)[1]);return nd.disj(c,[nd.AND(f) for f in regions(nf)],1)
  ctx.put(Q(Z,Z),b.refl(ctx.g,Z))
  nd.cases(ctx,[nd.AND(parts(initial,nf,j)) for j in range(10)],goal,instruction)
  m.finish('skelet17-ladder-skelet10-blank-enters-right-scan',root,prem,goal,ctx,
   'Every ordinary first step from blank enters the right-counter scan invariant. No supplied tape annotation.')
 if proofs: entry()
 return {'sparse':sparse,'scan':scan,'step':step,'current':cf,'next':nf,'parts':parts,'neq':neq,'bitbound':bitbound,'regions':regions}
