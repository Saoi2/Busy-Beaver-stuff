from pathlib import Path
import json,os
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_skelet10_return import add_skelet10_return
m=r.m;P=Path(__file__).resolve().parent
if 'skelet17-ladder-skelet10-return-marker-step' in m.theorems:raise SystemExit('Input already contains return extension.')
m.nd.OUTPUT_PREFIX='ladder-z10-return-';m.a.OUTPUT_PREFIX='ladder-z10-return-';old=set(m.theorems)
add_skelet10_return(m,add_skelet10(m,proofs=False),stage=os.environ.get('RETURN_STAGE','all'))
with (P/'skelet10_return_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'skelet10_return_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Return extension generated.',flush=True)
