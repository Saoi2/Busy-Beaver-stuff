from pathlib import Path
import json
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_skelet10_spread import add_skelet10_spread
from ladder_skelet10_return import add_skelet10_return
from ladder_skelet10_right import add_skelet10_right
from ladder_skelet10_blocks import add_skelet10_blocks
from ladder_skelet10_clear import add_skelet10_clear
from ladder_skelet10_left import add_skelet10_left
from ladder_skelet10_full_left import add_skelet10_full_left
from ladder_history_tools import add_history_tools
from ladder_history_assembly import add_history_assembly
m=r.m;P=Path(__file__).resolve().parent;old=set(m.theorems)
m.nd.OUTPUT_PREFIX='ladder-history-assembly-';m.a.OUTPUT_PREFIX='ladder-history-assembly-'
api=add_skelet10(m,proofs=False);sp=add_skelet10_spread(m,proofs=False);ret=add_skelet10_return(m,api,proofs=False)
right=add_skelet10_right(m,api,ret,proofs=False);clear=add_skelet10_clear(m,api,sp,ret,proofs=False)
ins=add_skelet10_left(m,api,stage='contracts',proofs=False);blocks=add_skelet10_blocks(m,sp,proofs=False)
left=add_skelet10_full_left(m,api,sp,right,clear,ins,blocks,proofs=False)
h=add_history_tools(m,api,proofs=False);add_history_assembly(m,api,h,right,left)
with (P/'history_assembly_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'history_assembly_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Embedded history assembly generated.',flush=True)
