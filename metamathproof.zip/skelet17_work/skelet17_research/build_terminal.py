"""Extract the dangerous pattern from the end of a supplied beta history.

No scan guard or invariant is assumed. No induction is used by this theorem.
"""
import build_history as h
m,nd,b,a=h.m,h.nd,h.b,h.a
A,M,Q,L=h.A,h.M,h.Q,h.L
N,O,Z=h.N,h.O,h.Z
H,n=h.H,h.n
j=m.declare('s17terminalIndex')
rows=[[m.declare('s17end'+str(k)+s,'var') for s in ('q','l','b','r')] for k in range(3)]
last=m.NF
ix=[j]
for k in range(3):ix.append(A(ix[-1],O))
bind=[m.declare('s17bad'+s,'var') for s in ('q','l','b','r','tail')]

def PLAIN_STEPS():
    s=b.V('si');vs=h.SV
    return nd.BALL(s,n,nd.balls(vs,H,b.Imp(b.And(h.AT(s,vs[:4]),h.AT(A(s,O),vs[4:])),m.STEP(vs[:4],vs[4:]))))

def bad_body(vs):
    c=vs[:4];tail=vs[4]
    return nd.AND([h.AT(j,c),Q(c[0],O),Q(c[2],O),Q(c[3],A(M(a.num(4),tail),a.num(3)))])

def terminal():
    fields=[h.TOTAL(),PLAIN_STEPS(),Q(n,ix[3]),*[L(v,H) for v in last],h.AT(n,last),Q(last[0],a.num(5))]
    prem=nd.AND(fields);goal=nd.bexs(bind,H,bad_body(bind))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
    # The final row is already supplied, rather than constructed.
    ctx.put(h.AT(ix[3],last),a.replace(ctx.g,h.AT(a.E,last),n,ix[3],ctx.get(Q(n,ix[3])),ctx.get(h.AT(n,last))))
    for k in range(3):
        for upper,extra in ((n,2-k),(A(n,O),3-k)):
            rhs=A(A(ix[k],a.num(extra)),O)
            eq=a.constrained_equal(ctx.g,upper,rhs,[(n,ix[3],ctx.get(Q(n,ix[3])))])
            ctx.put(L(ix[k],upper),a.boundless_lt(ctx.g,ix[k],upper,a.num(extra),eq))
    def take_row(cc,k):
        if k==3:
            cs=[*rows,last]
            for z in range(3):
                s=ix[z];body=PLAIN_STEPS()[2]
                _,p=cc.all_elim(b.V('si'),body,s)
                inner,_=b.subst(body[2],b.V('si'),s,True)
                cc.mp(L(s,n),inner,p)
                stepbody=b.Imp(b.And(h.AT(s,h.SV[:4]),h.AT(A(s,O),h.SV[4:])),m.STEP(h.SV[:4],h.SV[4:]))
                _,p=nd.inst_balls(cc,h.SV,H,stepbody,cs[z]+cs[z+1])
                cc.both(h.AT(s,cs[z]),h.AT(A(s,O),cs[z+1]))
                cc.mp(b.And(h.AT(s,cs[z]),h.AT(A(s,O),cs[z+1])),m.STEP(cs[z],cs[z+1]),p)
            steps=[m.STEP(c,d) for c,d in zip(cs,cs[1:])];nd.conj(cc,steps)
            mapping={**{x[1]:v for x,v in zip(m.CF,cs[0])},**{x[1]:v for x,v in zip(m.NF,cs[3])}}
            mapping.update({('s17h'+str(k)+s):v for k,c in enumerate(cs[1:3],1) for s,v in zip(('q','l','b','r'),c)})
            m.use(cc,'skelet17-three-step-halting-characterization',mapping)
            danger=nd.AND([Q(cs[0][0],O),Q(cs[0][2],O),Q(cs[0][3],A(M(a.num(4),cs[2][3]),a.num(3)))])
            iff=b.Iff(Q(last[0],a.num(5)),danger)
            imp=b.Imp(iff[1],iff[2]);cc.put(imp,b.apply('nd-iff-left',{'ga':cc.g,'ph':iff[1],'ps':iff[2]},[cc.get(iff)]))
            cc.mp(imp[1],imp[2]);nd.unpack(cc,[Q(cs[0][0],O),Q(cs[0][2],O),danger[2][2]])
            values=cs[0]+[cs[2][3]]
            nd.conj(cc,[h.AT(j,cs[0]),Q(cs[0][0],O),Q(cs[0][2],O),danger[2][2]])
            # Introduce all five bounded witnesses from existing rows.
            def introduce(index):
                body=nd.bexs(bind[index+1:],H,bad_body(bind))
                for var,val in zip(bind[:index],values[:index]):body,_=b.subst(body,var,val,True)
                v=bind[index];actual,_=b.subst(body,v,values[index],True)
                if index==4:cc.get(actual)
                else:introduce(index+1)
                cc.both(L(values[index],H),actual)
                return cc.ex_intro(v,b.And(L(v,H),body),values[index])
            introduce(0);return cc.get(goal)
        ti=b.V('ti');_,p=cc.all_elim(ti,h.TOTAL()[2],ix[k])
        cc.mp(L(ix[k],A(n,O)),nd.bexs(h.TV,H,h.AT(ix[k],h.TV)),p)
        return h.bex_elim(cc,h.TV,H,h.AT(ix[k],h.TV),rows[k],goal,lambda child:take_row(child,k+1))
    take_row(ctx,0)
    m.finish('skelet17-history-terminal-danger',root,prem,goal,ctx,
             'Any supplied history ending in Z at n=j+3 contains B111 at j. No blank-start or scan assumptions. No induction.')
terminal()

if __name__=='__main__':m.write()
