"""Independently reconstruct complete right-counter statements and test phases."""
from pathlib import Path
import json
from check_skelet10_scope import parse,plus,times,eq,lt,implies,both,AND,OR,num,ALL,EX,power,sparse,even,step
from check_skelet10_left import norm,raw_step
from check_skelet10_spread import bounded
PTH=Path(__file__).resolve().parent
TWO,THREE,FOUR,FIVE,SIXTEEN=map(num,(2,3,4,5,16))
w,ell='rightInput','rightLeft';S=plus(times(THREE,w),TWO);W=plus(w,'1');K=times(SIXTEEN,W)
jp,js,ja=['rightCarry'+s for s in ('Scale','Suffix','Tail')];pp,ps=['rightPhase'+s for s in ('Scale','Suffix')]
def wr(c):return plus(times(TWO,c[3]),c[2])
def wl(c):return plus(times(TWO,c[1]),c[2])
def carry(x,v):
 p,s,a=jp,js,ja
 return EX(p,plus(times(THREE,x),TWO),EX(s,plus(x,'1'),EX(a,plus(x,'1'),AND([power(p),eq(p,plus(times(THREE,s),'1')),eq(x,plus(times(p,times(TWO,a)),s)),eq(v,times(p,plus(times(FOUR,a),'1')))]))))
def endpoint(c):return AND([eq(c[0],THREE),eq(wl(c),ell),carry(w,c[3]),sparse(c[3])])
def ranks(c,p):return [plus(plus(K,times(FOUR,wr(c))),TWO),plus(plus(K,times(SIXTEEN,c[3])),FIVE),plus(plus(K,times(FOUR,c[3])),'1'),times(FOUR,p)]
def phase(c,r,j,p,s):
 q,l,b,z=c;common=[power(p),eq(p,plus(times(THREE,s),'1'))]
 if j==0:return [eq(q,'1'),lt(b,TWO),*common,eq(plus(l,'1'),times(times(TWO,p),plus(ell,'1'))),eq(w,plus(times(p,wr(c)),s)),sparse(wr(c)),eq(r,ranks(c,p)[j])]
 if j==1:return [eq(q,'0'),eq(b,'0'),*common,eq(plus(l,'1'),times(times(FOUR,p),plus(ell,'1'))),eq(w,plus(times(times(FOUR,p),z),plus(times(FOUR,s),'1'))),sparse(z),eq(r,ranks(c,p)[j])]
 if j==2:return [eq(q,TWO),eq(b,'1'),*common,eq(plus(l,'1'),times(p,plus(ell,'1'))),eq(w,plus(times(p,z),s)),even(z),sparse(z),eq(r,ranks(c,p)[j])]
 return [eq(q,THREE),lt(b,TWO),power(p),eq(plus(wl(c),'1'),times(p,plus(ell,'1'))),carry(w,times(p,z)),sparse(z),eq(r,ranks(c,p)[j])]
def rank(c,r):
 clauses=[]
 for j in range(4):
  f=AND(phase(c,r,j,pp,ps))
  if j<3:f=EX(ps,W,f)
  clauses.append(EX(pp,S,f))
 return OR(clauses)
def entry(c):return AND([eq(c[0],'1'),eq(c[1],plus(times(TWO,ell),'1')),eq(wr(c),w),lt(c[2],TWO),sparse(w)])
R0=plus(plus(K,times(FOUR,w)),TWO)
def alls(vs,bound,body):
 for v in reversed(vs):body=ALL(v,bound,body)
 return body
def exs(vs,bound,body):
 for v in reversed(vs):body=EX(v,bound,body)
 return body
H,n,offset=['rightRun'+s for s in ('H','N','Offset')]
def at(index,row):
 q='rightRunBetaQuotient';out=[]
 for j,v in enumerate(row):
  mod=plus('1',times(plus(plus(offset,index),'1'),'rightRunC'+str(j)))
  out.append(EX(q,H,both(eq('rightRunB'+str(j),plus(times(q,mod),v)),lt(v,mod))))
 return AND(out)
TV=['rightRunTotalRow'+s for s in ('Q','L','Bit','R')];IV=['rightRunInitialRow'+s for s in ('Q','L','Bit','R')]
SV=['rightRunStepRow'+str(j)+s for j in (0,1) for s in ('Q','L','Bit','R')]
EV=['rightRunAvoidRow'+s for s in ('Q','L','Bit','R')];IP=['rightRunIndRow'+s for s in ('Q','L','Bit','R')]
HR=['rightRunHalt'+s for s in ('Q','L','Bit','R')];ER=['rightRunExitRow'+s for s in ('Q','L','Bit','R')]
ti,si,ai,i=['rightRun'+s for s in ('TotalIndex','StepIndex','AvoidIndex','Index')];rho='rightRunHistoryScale'
total=ALL(ti,plus(n,'1'),exs(TV,H,at(ti,TV)))
initial=alls(IV,H,implies(at('0',IV),entry(IV)))
steps=ALL(si,n,alls(SV,H,implies(both(at(si,SV[:4]),at(plus(si,'1'),SV[4:])),step(SV[:4],SV[4:]))))
avoid=ALL(ai,plus(n,'1'),alls(EV,H,implies(at(ai,EV),('-.',endpoint(EV)))))
def inv(index,row):return EX(rho,plus(R0,'1'),both(rank(row,rho),lt(plus(index,rho),plus(R0,'1'))))
invariant=ALL(i,plus(n,'1'),alls(IP,H,implies(at(i,IP),inv(i,IP))))
xi='rightRunExitIndex';exit_goal=EX(xi,plus(n,'1'),exs(ER,H,both(at(xi,ER),endpoint(ER))))
cf=['z10Current'+s for s in ('Q','L','Bit','R')];nf=['z10Next'+s for s in ('Q','L','Bit','R')];h='rightOutputRank'
expected={
 'right-counter-entry':implies(entry(cf),rank(cf,R0)),
 'right-counter-step':implies(AND([rank(cf,'t'),('-.',endpoint(cf)),step(cf,nf)]),EX(h,'t',rank(nf,h))),
 'right-window-invariant':implies(AND([total,initial,steps,avoid]),invariant),
 'right-window-bound':implies(AND([total,initial,steps,avoid]),lt(n,R0)),
 'right-window-exit':implies(AND([total,initial,steps,lt(R0,plus(n,'1'))]),exit_goal),
 'right-window-halting-barrier':implies(AND([total,initial,steps,*[lt(x,H) for x in HR],at(n,HR),eq(HR[0],num(5))]),exit_goal),
}
def sparse_num(x):return not x&(x>>1)
def power_num(p):return p>0 and not p&(p-1)
def jval(w):
 p=1;s=0;x=w
 while x%2:
  assert x%4==1;x//=4;p*=4;s=4*s+1
 return p*(2*x+1),p,s,x//2

def main():
 actual=json.loads((PTH/'skelet10_right_theorems.json').read_text());assert len(actual)==len(expected),(len(actual),len(expected))
 for name,f in expected.items():
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(f),label
  assert bounded(f),label
 for name in ('right-window-exit','right-window-halting-barrier'):
  text=actual['skelet17-ladder-skelet10-'+name]
  for forbidden in ('rightPhaseScale','rightPhaseSuffix','rightRunHistoryScale','rightFreshScale'):
   assert forbidden not in text,(name,forbidden)
 cases=0;count=0;examples=[]
 for w0 in range(512):
  if not sparse_num(w0):continue
  v,cp,cs,ca=jval(w0)
  assert cp==3*cs+1 and w0==cp*(2*ca)+cs and v==cp*(4*ca+1)
  assert cp<3*w0+2 and cs<=w0 and ca<=w0 and v<=3*w0+1 and sparse_num(v)
  for l0 in range(8):
   c=(1,2*l0+1,w0%2,w0//2);p=1;s=0;j=0;kk=16*(w0+1);t=0;trace=[];bound=20*w0+18
   while True:
    q,l,b,r=c;rr=2*r+b;ll=2*l+b
    assert p<3*w0+2 and power_num(p)
    if j<3:assert p==3*s+1 and s<=w0
    if j==0:assert q==1 and l+1==2*p*(l0+1) and w0==p*rr+s and sparse_num(rr)
    elif j==1:assert q==0 and b==0 and l+1==4*p*(l0+1) and w0==4*p*r+4*s+1 and sparse_num(r)
    elif j==2:assert q==2 and b==1 and l+1==p*(l0+1) and w0==p*r+s and r%2==0 and sparse_num(r)
    else:assert q==3 and ll+1==p*(l0+1) and p*r==v and sparse_num(r)
    rho=[kk+4*rr+2,kk+16*r+5,kk+4*r+1,4*p][j]
    assert rho>0 and t+rho<=bound
    trace.append({'step':t,'phase':['B','A','C','D'][j],'configuration':c,'rank':rho,'scale':p,'suffix':s})
    if q==3 and ll==l0 and r==v:break
    nxt=raw_step(c)
    if j==0:j=1 if b else 2
    elif j==1:p*=4;s=4*s+1;j=0
    elif j==2:j=3
    else:p//=2
    nq,nl,nb,nr=nxt;newrho=[kk+4*(2*nr+nb)+2,kk+16*nr+5,kk+4*nr+1,4*p][j]
    assert newrho<rho;c=nxt;t+=1;count+=1;assert t<=bound
   cases+=1
   if w0 in (0,1,5) and l0==2:examples.append({'input':w0,'left_target':l0,'output':v,'actual_steps':t,'bound':bound,'trace':trace})
 out={'statements_checked':len(expected),'independent_reconstruction_matches':True,'all_new_statements_delta0':True,
  'whole_right_counter_contract':True,'output_has_bounded_carry_graph_and_is_sparse':True,
  'ordinary_step_and_original_beta_format':True,'no_intermediate_annotations_in_exit_or_barrier':True,
  'finite_routine_cases':cases,'finite_ordinary_steps':count,'finite_tests_are_not_formal_proofs':True,
  'formal_carry_totality_or_uniqueness_claimed':False,'complete_two_counter_cycle':False,'whole_machine_nonhalting':False,'examples':examples}
 (PTH/'skelet10_right_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='examples'},indent=2))
if __name__=='__main__':main()
