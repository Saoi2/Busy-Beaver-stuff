Historical development plan; the complete routine is now documented in SKELET10_LEFT_ROUTINE.md.

# Remaining left-counter carry scan: proposed microphases

This is an unproved plan. The bounded block decompositions and the complete
A1 return are now formalized; read SKELET10_LEFT_RETURN.md. The following
D/C scan and exit phases have not yet been proved in Metamath.

## Fixed data and bounded witnesses

Fix original input word w, right tail r and the initial left relation
T(w,WholeLeft). The initial right half is R=4r+3. Put K=16*(w+1).
At a D search boundary use witnesses p<3w+2, s<w+1 and u<w+1 with

    Pow2(p), p=3s+1, w=p*u+s, Sparse(u),
    T(u,WholeLeft), R+1=4*p*p*(r+1), b<2.

The initial witnesses are p=1,s=0,u=w. The search rank is K+8u+8.
The already proved prefix-bounds helper bounds p and s after an update.
The bounded transformed tail t in a microphase can be bounded by its
actual L+1, since each displayed L is a positive affine multiple of t.
The actual transition and the new block-decoding theorems identify the
scanned and popped bits; they must not be added to Step as assumptions.

## Base and carry microphases

At a search boundary split the current Sparse input u. In the even case
u=2a, block decoding gives WholeLeft=4t and T(a,t). In the odd case
u=4a+1, it gives WholeLeft=16t+10 and T(a,t). Both cases force b=0.
Dividing the actual popped left word by 2 identifies the next row.
All phases below retain p,s,u,a,t, their bounds, w=p*u+s, p=3s+1,
Pow2(p), and the appropriate input split. Sparse(a) follows by deletion.

| Phase | State/read | L | R+1 | Rank |
|---|---|---|---|---|
| Base C | C0 | t | 8*p*p*(r+1) | K+8u+7 |
| Base E | E1 | 2t+1 | 4*p*p*(r+1) | K+8u+6 |
| Base B | B1 | 4t+2 | 2*p*p*(r+1) | K+8u+5 |
| Base A before last exit move | A1 | 8t+5 | p*p*(r+1) | K+8u+4 |
| Carry first C | C1 | 4t+2 | 8*p*p*(r+1) | K+8u+7 |
| Carry middle D | D0 | 2t+1 | 16*p*p*(r+1) | K+8u+6 |
| Carry last C | C1 | t | 32*p*p*(r+1) | K+8u+5 |

Each row retains T(a,t). The base phases use u=2a, the carry phases
u=4a+1. These are precisely the ordinary transitions already exhibited
by the finite left-counter contracts, now proposed as single-step phases.
The +1 equations on R make each popped right-side 1 explicit through
the existing arithmetic predecessor-of-even lemma.

From the carry's last C1 row, the ordinary left pop gives
WholeLeft_new=t, whatever syntactic expression is used for its two
coordinates. The next search witnesses are

    p'=4p, s'=4s+1, u'=a,
    R_new+1=64*p*p*(r+1)=4*p'*p'*(r+1).

No separate T-even theorem is needed just to show that this next row is
a search boundary: the search predicate has b<2 and T(a,WholeLeft),
so the next decoding step can derive the bit when it needs it.
The rank drops from K+8u+5 to K+8a+8 because u=4a+1>a.

## Entry to the verified A return

The base A1 row makes one ordinary move to left half 16t+10, with

    WholeRight+1=p*p*(r+1).

The transform constructor gives T(4a+1,16t+10), and Sparse(a) gives
Sparse(4a+1). Choose final represented output V=p*(4a+1). The carry
relation J(w,V) has witnesses p,s,a. Its output bound V<3w+2 should
follow without induction from V=2w+s+1 and s<=w.

The verified A-return relation can be instantiated with marker bound
P=3w+1, fixed output V and right tail r. Its current marker is p, not
necessarily the bound P. This use needs only the local return theorem;
that theorem does not assume Pow2(P), only Pow2 of its current marker.
The current return word is 4a+1 and its rank is 2p. The search offset K
leaves room for a strict rank decrease into this return phase.

A global left-counter rank relation could therefore add one branch

    exists V<3w+2, J(w,V) and ClearRank(P=3w+1,V,r,c,rho).

The desired left endpoint is A with WholeRight=r and some bounded V
satisfying J(w,V), T(V,L) and Sparse(V). Negating that global endpoint,
together with J(w,V), negates the instantiated return endpoint, so the
already verified return-step theorem applies directly. Its output keeps
the same V and a smaller rank.

## Remaining formal obligations

The phase initialization, preservation, witness bounds, rank comparisons,
J output bound and history lift above still require proofs. In particular
an actual history can stop between block boundaries, which is why the
single-step microphases are needed. A proposed initial rank is

    K+8w+8 = 24*(w+1).

This plan adds no axiom, alternate machine encoding, total carry function,
Pow2 product-totality principle or supplied intermediate annotation.
Full left-counter correctness and Skelet #10 nonhalting are not claimed.
