"""Append only new declarations/proofs from a checked dependency extraction.

Old assertions stay in the canonical file. Empty old dependency scopes are
removed; all DV conditions surrounding retained new proofs are preserved.
The resulting complete canonical file must be kernel-verified afterward.
"""
from pathlib import Path
import re,sys
from simplify_metamath import parse_intern
P=Path(__file__).resolve().parent
source=P/sys.argv[1];canonical=P/(sys.argv[2] if len(sys.argv)>2 else 'idelta0_machines.mm')
old=canonical.read_text();labels=set(re.findall(r'(?m)^(\S+) \$[faep] ',old))
variables=set(' '.join(re.findall(r'\$v ([^$]+)\$\.',old)).split())
s=source.read_text();records,_,_=parse_intern(s);stack=[([],False)];added=0
for r in records:
 k=r['kind'];items,live=stack[-1]
 if k=='{':stack.append(([],False));continue
 if k=='}':
  inner,used=stack.pop()
  if used:stack[-1][0].append('${\n'+''.join(inner)+'$}\n');stack[-1]=(stack[-1][0],True)
  continue
 if k=='c':continue
 if k=='v':
  vs=[v for v in r['expr'] if v not in variables]
  if vs:items.append('$v '+' '.join(vs)+' $.\n');variables.update(vs);stack[-1]=(items,True)
 elif k=='a':
  assert r['label'] in labels,'New trusted declarations are forbidden'
 elif k in ('f','e','p'):
  if r['label'] not in labels:items.append(s[r['start']:r['end']]+'\n');stack[-1]=(items,True);added+=k=='p'
 elif k=='d':items.append(s[r['start']:r['end']]+'\n')
assert len(stack)==1
with canonical.open('a') as out:out.write('\n$( Checked proof extension; no new axioms. $)\n');out.writelines(stack[0][0])
print({'appended_proofs':added,'appended_bytes':canonical.stat().st_size-len(old.encode())})
