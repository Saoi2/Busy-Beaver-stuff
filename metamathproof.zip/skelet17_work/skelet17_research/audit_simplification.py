"""Check exact public interfaces, trusted declarations, and verification."""
from pathlib import Path
import hashlib,json,re
from simplify_metamath import parse_intern,exact,public,digest_json
P=Path(__file__).resolve().parent
report=json.loads((P/'simplification_report.json').read_text())
path=P/'idelta0_machines.mm';source=path.read_text()
assert hashlib.sha256(source.encode()).hexdigest()==report['output_sha256']
records,rules,_=parse_intern(source)
axioms={r['label']:exact(r,rules) for r in records if r['kind']=='a'}
interfaces={k:exact(r,rules) for k,r in rules.items() if r['kind']=='p' and public(k)}
assert len(axioms)==93 and digest_json(axioms)==report['trusted_core_digest']
assert {k:digest_json(v) for k,v in interfaces.items()}==report['interface_digests']
assert {k:digest_json(v) for k,v in axioms.items()}==report['axiom_digests']
baseline_path=P/'simplification_baseline_report.json'
if baseline_path.is_file():
 baseline=json.loads(baseline_path.read_text())
 assert baseline['trusted_core_digest']==report['trusted_core_digest']
 for k,v in baseline['interface_digests'].items():assert report['interface_digests'][k]==v,k
 report['previous_checkpoint_interfaces_preserved']=len(baseline['interface_digests'])
prior_path=P/'preceding_checkpoint_report.json'
if prior_path.is_file():
 prior=json.loads(prior_path.read_text())
 assert prior['trusted_core_digest']==report['trusted_core_digest']
 for k,v in prior['interface_digests'].items():assert report['interface_digests'][k]==v,k
 report['preceding_checkpoint_interfaces_preserved']=len(prior['interface_digests'])
count=sum(r['kind']=='p' for r in records);assert count==report['output_proofs']
log=(P/'ladder_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log
assert 'All proofs in the database were verified' in log
assert int(re.search(r'93 are \$a and ([0-9]+) are \$p',log).group(1))==count
before=json.loads((P/'ladder_manifest.json').read_text())
if before['files']['idelta0_machines.mm']['sha256']==report['input_sha256']:
 report['input_matches_previous_verified_manifest']=True
report['exact_named_interfaces_preserved']=True
report['exact_trusted_declarations_preserved']=True
report['official_verification']='passed'
report['source_reduction_percent']=round(100*(1-report['output_bytes']/report['input_bytes']),2)
report['proof_count_reduction_percent']=round(100*(1-count/report['input_proofs']),2)
(P/'simplification_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('aliases','interface_digests','axiom_digests')},indent=2))
