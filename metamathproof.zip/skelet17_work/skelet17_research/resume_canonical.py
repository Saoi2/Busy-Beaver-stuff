"""Resume proof generation from the canonical database without adding axioms.

Use a separate input snapshot while developing an extension. Reproduction of
all results from the historical inputs is still build_ladder.py/rebuild_project.py.
"""
from pathlib import Path
import os
import build_binary as m
from simplify_metamath import parse_intern
P=Path(__file__).resolve().parent
source=Path(os.environ.get('IDELTA0_INPUT',P/'idelta0_machines.mm')).read_text()
records,rules,_=parse_intern(source)
b,nd=m.b,m.nd
b.lines[:]=[source];b.rules.clear()
# Clear the bootstrap metadata too: only active declarations in this database
# may be used. Optional bound variables are declared afresh below as needed.
b.metas.clear();b.floats.clear()
scope=[]
for rec in records:
 if rec['kind']=='{':scope.append((dict(b.metas),dict(b.floats)))
 elif rec['kind']=='}':
  metas,floats=scope.pop();b.metas.clear();b.metas.update(metas);b.floats.clear();b.floats.update(floats)
 elif rec['kind']=='f':
  typ,name=rec['expr'];b.metas[name]=typ;b.floats[name]=rec['label']
for rec in records:
 if rec['kind'] not in ('a','p'):continue
 hs=[h for h in rec['hyps'] if rules[h]['kind']=='e']
 mand=[rules[h]['expr'][1] for h in rec['hyps'] if rules[h]['kind']=='f']
 b.rules[rec['label']]=(' '.join(rec['expr']),[' '.join(rules[h]['expr']) for h in hs],mand,hs)
def expression(tokens):
 it=iter(tokens)
 def take():
  t=next(it)
  if t=='(':
   l=take();op=next(it);r=take();assert next(it)==')';return (op,l,r)
  if t in ('A.','E.'):return (t,take(),take())
  if t=='-.':return ('not',take())
  if t=='0':return b.Z
  if t=='1':return b.O
  if t=='[]':return b.NIL
  return (b.metas[t],t)
 out=take();assert next(it,None) is None;return out
m.theorems.clear()
for rec in records:
 if rec['kind']=='p' and (rec['label'].startswith(('skelet17-','z10-left-instruction-contract-','z10-spread-','z10-inverse-','z10-return-','z10-right-','z10-block-','z10-clear-','z10-full-left-','z10-align-','z10-compose-')) or rec['label']=='z10-sparse-rename-bound-variables') and rec['expr'][:3]==['|-','[]','=>']:
  m.theorems[rec['label']]=expression(rec['expr'][3:])
vs=[v for v,t in b.metas.items() if t=='var']
b.lines.append('$d '+' '.join(vs)+' $.')
b.lines.extend('$d '+v+' '+w+' $.' for v in vs for w,t in b.metas.items() if t!='var')
nd.cache.clear();nd.scache.clear();nd.OUTPUT_PREFIX='ladder-z10-';m.a.OUTPUT_PREFIX='ladder-z10-'
for fn in [m.a.associate,m.a.swap_at,m.a.sort_assoc,m.a.normalize]:fn.cache_clear()
m.a.proof_ast.clear()
# Helpers use these existing object variables, which might have been pruned
# if unused. Restore their syntax declarations, with ordinary DV conditions.
olddeclare=m.declare
def declare(name,typ='var'):
 if name in b.metas:
  assert b.metas[name]==typ;return (typ,name)
 return olddeclare(name,typ)
m.declare=declare
for name in ['e0','e1']:declare(name)
del records,rules,source
print('Resumed canonical database; all earlier proofs retained.',flush=True)
