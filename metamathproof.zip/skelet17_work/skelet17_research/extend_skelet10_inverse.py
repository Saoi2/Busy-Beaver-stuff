from pathlib import Path
import json,os
import resume_canonical as r
from ladder_skelet10_spread import add_skelet10_spread
from ladder_skelet10_inverse import add_skelet10_inverse
m=r.m;P=Path(__file__).resolve().parent
if 'skelet17-ladder-skelet10-spread-pop' in m.theorems:raise SystemExit('Input already contains this extension.')
m.nd.OUTPUT_PREFIX='ladder-z10-inverse-';m.a.OUTPUT_PREFIX='ladder-z10-inverse-'
old=set(m.theorems);api=add_skelet10_spread(m,proofs=False)
add_skelet10_inverse(m,api,stage=os.environ.get('INVERSE_STAGE','all'))
with (P/'skelet10_inverse_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'skelet10_inverse_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Inverse extension generated.',flush=True)
