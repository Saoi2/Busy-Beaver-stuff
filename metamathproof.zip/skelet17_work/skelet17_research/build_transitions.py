"""Proof-producing extension: actual Skelet17 transitions and scan invariants.

No oracle-produced assertion is an axiom. Run the original Metamath verifier.
"""
from pathlib import Path
import sys, json
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension/proof_tools'))
import build_scan as previous
nd,b,a=previous.nd,previous.b,previous.a
A,M,Q,L=b.Add,b.Mul,b.Eq,b.Lt
N,O,Z=b.NIL,b.O,b.Z
num=a.num

def declare(name,typ='term'):
    old=list(b.metas)
    b.lines.extend(['$v '+name+' $.','f-'+name+' $f '+typ+' '+name+' $.'])
    b.metas[name]=typ;b.floats[name]='f-'+name
    for other in old:
        if typ=='var' or b.metas[other]=='var':b.lines.append('$d '+name+' '+other+' $.')
    return (b.T if typ=='term' else b.V)(name)

CF=[declare('s17'+s) for s in ('q','l','b','r')]
NF=[declare('s17n'+s) for s in ('q','l','b','r')]
K=declare('s17K')
theorems={}
def finish(name,root,prem,goal,ctx,comment=''):
    root.intro(prem,goal,ctx);f=b.Imp(prem,goal)
    b.theorem(name,f,root.get(f),comment)
    theorems[name]=f
    print(name,flush=True)
    return f

def use(ctx,name,mapping={}):
    def subst(t):
        if t[0] in ('term','var','wff','ctx'):return mapping.get(t[1],t)
        return (t[0],*(subst(x) if isinstance(x,tuple) else x for x in t[1:]))
    f=subst(theorems[name]);ctx.theorem(f,b.apply(name,mapping))
    return ctx.mp(f[1],f[2])

def const_lt(x,y):
    xx,yy=num(x),num(y);gap=num(y-x-1)
    return a.boundless_lt(N,xx,yy,gap,a.equal(yy,A(A(xx,gap),O)))

def contradiction(ctx,field,x,y,goal):
    eq=a.trans(num(x),field,num(y),a.sym(field,num(x),ctx.get(Q(field,num(x))),ctx.g),ctx.get(Q(field,num(y))),ctx.g)
    if x<y:
        lo,hi=num(x),num(y);ceq=a.sym(lo,hi,eq,ctx.g)
    else:lo,hi=num(y),num(x);ceq=eq
    lt=ctx.theorem(L(lo,hi),const_lt(min(x,y),max(x,y)))
    bad=a.replace(ctx.g,L(lo,a.E),hi,lo,ceq,lt)
    return a.contradiction(ctx.g,L(lo,lo),goal,bad,b.ax('O1',ctx.g,t=lo))

# A1 is completed by 1RZ. No transition is provided from state Z=5.
TABLE=[(1,1,1),(5,1,1),(2,0,0),(4,1,1),(3,0,0),
       (2,0,1),(0,1,1),(1,0,1),(1,1,0),(0,1,0)]
def parts(c,d,index):
    q,l,bit,r=c;nq,nl,nb,nr=d
    state,read=divmod(index,2);newstate,direction,write=TABLE[index]
    eqs=([Q(nl,A(M(num(2),l),num(write))),Q(r,A(M(num(2),nr),nb))]
         if direction else
         [Q(nr,A(M(num(2),r),num(write))),Q(l,A(M(num(2),nl),nb))])
    return [Q(q,num(state)),Q(bit,num(read)),Q(nq,num(newstate)),*eqs,b.Or(Q(nb,Z),Q(nb,O))]
def STEP(c,d):return nd.OR([nd.AND(parts(c,d,j)) for j in range(10)])

def selector(index):
    state,read=divmod(index,2);p=nd.AND([STEP(CF,NF),Q(CF[0],num(state)),Q(CF[2],num(read))])
    goal=nd.AND(parts(CF,NF,index));root=nd.Ctx();ctx=root.push(p)
    nd.unpack(ctx,[STEP(CF,NF),Q(CF[0],num(state)),Q(CF[2],num(read))])
    branches=[nd.AND(parts(CF,NF,j)) for j in range(10)]
    def branch(c,j):
        nd.unpack(c,parts(CF,NF,j));sj,bj=divmod(j,2)
        if sj!=state:return contradiction(c,CF[0],state,sj,goal)
        if bj!=read:return contradiction(c,CF[2],read,bj,goal)
        return c.get(goal)
    nd.cases(ctx,branches,goal,branch)
    return finish('skelet17-select-'+str(index),root,p,goal,ctx)

for idx in (0,1,2,3,4,5,7,8,9):selector(idx)

def selected(ctx,c,d,index):
    p=nd.AND([STEP(c,d),Q(c[0],num(index//2)),Q(c[2],num(index%2))])
    nd.conj(ctx,[STEP(c,d),Q(c[0],num(index//2)),Q(c[2],num(index%2))])
    use(ctx,'skelet17-select-'+str(index),{**{x[1]:v for x,v in zip(CF,c)},**{x[1]:v for x,v in zip(NF,d)}})
    nd.unpack(ctx,parts(c,d,index))

def constraints(ctx,fs):return [(f[1],f[2],ctx.get(f)) for f in fs]

def transfer(ctx,fn,fo,gn,go,scale,pf,pg):
    # fn=scale*fo, go=scale*gn -> fn*gn=fo*go.
    v0=M(fn,gn);v1=M(M(scale,fo),gn);v2=M(M(fo,scale),gn);v3=M(fo,M(scale,gn));v4=M(fo,go)
    p0=a.cong2('*',fn,M(scale,fo),gn,gn,pf,b.refl(ctx.g,gn),ctx.g)
    p1=a.cong2('*',M(scale,fo),M(fo,scale),gn,gn,b.ax('A5',ctx.g,t=scale,u=fo),b.refl(ctx.g,gn),ctx.g)
    p2=b.ax('A4',ctx.g,t=fo,u=scale,v=gn)
    p3=a.cong2('*',fo,fo,M(scale,gn),go,b.refl(ctx.g,fo),a.sym(go,M(scale,gn),pg,ctx.g),ctx.g)
    p=a.trans(v0,v1,v2,p0,p1,ctx.g);p=a.trans(v0,v2,v3,p,p2,ctx.g)
    return a.trans(v0,v3,v4,p,p3,ctx.g)

def X(c):return A(c[2],M(num(2),c[3]))
def FB(c):return A(M(num(3),c[1]),num(2))
def GB(c):return A(M(num(3),X(c)),O)
def FE(c):return A(M(num(3),c[1]),O)
def GE(c):return A(M(num(3),X(c)),num(2))
def IB(c):return M(FB(c),GB(c))
def IE(c):return M(FE(c),GE(c))
def INV(c,k=K):return b.Or(b.And(Q(c[0],O),Q(IB(c),k)),b.And(Q(c[0],num(4)),Q(IE(c),k)))
def GO(c):return b.Or(b.And(Q(c[0],O),Q(c[2],O)),b.And(Q(c[0],num(4)),Q(c[2],Z)))

def right_one(index):
    fs=[STEP(CF,NF),Q(CF[0],num(index//2)),Q(CF[2],num(index%2))]
    prem=nd.AND(fs);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs);selected(ctx,CF,NF,index)
    cs=constraints(ctx,[parts(CF,NF,index)[1],*parts(CF,NF,index)[3:5]])
    if index==3:fn,fo,gn,go=FE(NF),FB(CF),GE(NF),GB(CF)
    else:fn,fo,gn,go=FB(NF),FE(CF),GB(NF),GE(CF)
    pf=a.constrained_equal(ctx.g,fn,M(num(2),fo),cs)
    pg=a.constrained_equal(ctx.g,go,M(num(2),gn),cs)
    goal=b.And(Q(NF[0],num(TABLE[index][0])),Q(M(fn,gn),M(fo,go)))
    ctx.put(goal[2],transfer(ctx,fn,fo,gn,go,num(2),pf,pg));ctx.both(*goal[1:])
    return finish('skelet17-right-step-'+str(index),root,prem,goal,ctx)

right_one(3);right_one(8)

def closure():
    fields=[INV(CF),STEP(CF,NF),GO(CF)];prem=nd.AND(fields);goal=INV(NF)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
    ip=list(INV(CF)[1:]);gp=list(GO(CF)[1:]);op=list(INV(NF)[1:])
    def icase(ic,ii):
        nd.unpack(ic,list(ip[ii][1:]));qstate=[1,4][ii]
        def gcase(gc,gi):
            nd.unpack(gc,list(gp[gi][1:]));gstate=[1,4][gi]
            if qstate!=gstate:return contradiction(gc,CF[0],qstate,gstate,goal)
            index=[3,8][ii];cp=nd.AND([STEP(CF,NF),Q(CF[0],num(qstate)),Q(CF[2],num(index%2))])
            nd.conj(gc,[STEP(CF,NF),Q(CF[0],num(qstate)),Q(CF[2],num(index%2))])
            use(gc,'skelet17-right-step-'+str(index));cf=theorems['skelet17-right-step-'+str(index)][2]
            nd.unpack(gc,list(cf[1:]));newprod=IE(NF) if ii==0 else IB(NF);oldprod=IB(CF) if ii==0 else IE(CF)
            gc.put(Q(newprod,K),a.trans(newprod,oldprod,K,gc.get(Q(newprod,oldprod)),gc.get(Q(oldprod,K)),gc.g))
            oi=1-ii;gc.both(*op[oi][1:]);return nd.disj(gc,op,oi)
        return nd.cases(ic,gp,goal,gcase)
    nd.cases(ctx,ip,goal,icase);return finish('skelet17-right-scan-local',root,prem,goal,ctx)
closure()

def Y(c):return A(c[2],M(num(2),c[1]))
def LF(c,phase):return A(M(num(3),c[3]),num(1+phase))
def LG(c,phase):return A(M(num(3),Y(c)),num(2-phase))
def IL(c,phase):return M(LF(c,phase),LG(c,phase))

def left_one(index):
    fs=[STEP(CF,NF),Q(CF[0],num(index//2)),Q(CF[2],num(index%2))]
    prem=nd.AND(fs);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs);selected(ctx,CF,NF,index)
    cs=constraints(ctx,[parts(CF,NF,index)[1],*parts(CF,NF,index)[3:5]])
    phase=index%2
    fn,fo,gn,go=LF(NF,1-phase),LF(CF,phase),LG(NF,1-phase),LG(CF,phase)
    pf=a.constrained_equal(ctx.g,fn,M(num(2),fo),cs)
    pg=a.constrained_equal(ctx.g,go,M(num(2),gn),cs)
    goal=b.And(Q(NF[0],num(TABLE[index][0])),Q(IL(NF,1-phase),IL(CF,phase)))
    ctx.put(goal[2],transfer(ctx,fn,fo,gn,go,num(2),pf,pg));ctx.both(*goal[1:])
    return finish('skelet17-left-step-'+str(index),root,prem,goal,ctx)

for idx in (4,7,2,5):left_one(idx)

def left_four():
    mids=[[declare('s17m'+str(i)+s) for s in ('q','l','b','r')] for i in range(1,4)]
    cs=[CF,*mids,NF];indices=[4,7,2,5]
    fields=[Q(CF[0],num(2)),*[Q(c[2],num(i%2)) for c,i in zip(cs,indices)],*[STEP(c,d) for c,d in zip(cs,cs[1:])]]
    prem=nd.AND(fields);goal=b.And(Q(NF[0],num(2)),Q(IL(NF,0),IL(CF,0)))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
    accumulated=b.refl(ctx.g,IL(CF,0))
    for j,(c,d,idx) in enumerate(zip(cs,cs[1:],indices)):
        nd.conj(ctx,[STEP(c,d),Q(c[0],num(idx//2)),Q(c[2],num(idx%2))])
        use(ctx,'skelet17-left-step-'+str(idx),{**{x[1]:v for x,v in zip(CF,c)},**{x[1]:v for x,v in zip(NF,d)}})
        pold,pnew=j%2,1-j%2
        result=b.And(Q(d[0],num(TABLE[idx][0])),Q(IL(d,pnew),IL(c,pold)))
        nd.unpack(ctx,list(result[1:]))
        accumulated=a.trans(IL(d,pnew),IL(c,pold),IL(CF,0),ctx.get(result[2]),accumulated,ctx.g)
    ctx.put(goal[2],accumulated);ctx.both(*goal[1:])
    finish('skelet17-left-four-scan-product',root,prem,goal,ctx,
           'Four actual left moves C0 D1 B0 C1; intermediate tuples are parameters, not extra machine data.')
left_four()

def halt_predecessor():
    fields=[STEP(CF,NF),Q(NF[0],num(5))];prem=nd.AND(fields);goal=b.And(Q(CF[0],Z),Q(CF[2],O))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
    def branch(c,j):
        nd.unpack(c,parts(CF,NF,j))
        if j!=1:return contradiction(c,NF[0],5,TABLE[j][0],goal)
        return c.both(*goal[1:])
    nd.cases(ctx,[nd.AND(parts(CF,NF,j)) for j in range(10)],goal,branch)
    finish('skelet17-halt-predecessor',root,prem,goal,ctx)
halt_predecessor()

def incoming(state):
    fields=[STEP(CF,NF),Q(NF[0],num(state))];prem=nd.AND(fields)
    choices=[i for i,t in enumerate(TABLE) if t[0]==state]
    goals=[nd.AND(parts(CF,NF,i)) for i in choices];goal=nd.OR(goals)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
    def branch(c,j):
        nd.unpack(c,parts(CF,NF,j))
        if TABLE[j][0]!=state:return contradiction(c,NF[0],state,TABLE[j][0],goal)
        return nd.disj(c,goals,choices.index(j))
    nd.cases(ctx,[nd.AND(parts(CF,NF,j)) for j in range(10)],goal,branch)
    finish('skelet17-incoming-'+str(state),root,prem,goal,ctx)
for state in (0,3,4):incoming(state)

def incoming_use(ctx,c,d,state):
    ctx.both(STEP(c,d),Q(d[0],num(state)))
    use(ctx,'skelet17-incoming-'+str(state),{**{x[1]:v for x,v in zip(CF,c)},**{x[1]:v for x,v in zip(NF,d)}})

def bit_bound(ctx,bit):
    alternatives=[Q(bit,Z),Q(bit,O)];goal=L(bit,num(2))
    def branch(c,j):
        p=c.theorem(L(num(j),num(2)),const_lt(j,2))
        return a.replace(c.g,L(a.E,num(2)),num(j),bit,a.sym(bit,num(j),c.get(alternatives[j]),c.g),p)
    return nd.cases(ctx,alternatives,goal,branch)

def quotient_unique(ctx,actual,rem,expected,want,equality):
    # The caller supplies equality of two base-2 decompositions.
    goal=b.And(Q(actual,expected),Q(rem,want))
    terms=[Q(A(M(num(2),actual),rem),A(M(num(2),expected),want)),L(rem,num(2)),L(want,num(2))]
    ctx.put(terms[0],equality);ctx.both(*terms[1:]);ctx.both(terms[0],b.And(*terms[1:]))
    f=b.Imp(b.And(terms[0],b.And(*terms[1:])),goal)
    ctx.theorem(f,b.apply('division-unique',{'t':num(2),'u':actual,'v':expected,'w':rem,'r':want}))
    ctx.mp(f[1],goal);nd.unpack(ctx,list(goal[1:]))

def halt_three():
    mid1=[declare('s17h1'+s) for s in ('q','l','b','r')]
    mid2=[declare('s17h2'+s) for s in ('q','l','b','r')]
    c0,c1,c2,c3=CF,mid1,mid2,NF
    steps=[STEP(c0,c1),STEP(c1,c2),STEP(c2,c3)];run=nd.AND(steps)
    hit=Q(c3[0],num(5));danger=nd.AND([Q(c0[0],O),Q(c0[2],O),Q(c0[3],A(M(num(4),c2[3]),num(3)))])
    root=nd.Ctx();ctx=root.push(run);nd.unpack(ctx,steps)
    # Backwards: the predecessor of Z is A1. Its predecessor is D0 or E1.
    hc=ctx.push(hit);hc.both(STEP(c2,c3),hit)
    use(hc,'skelet17-halt-predecessor',{**{x[1]:v for x,v in zip(CF,c2)},**{x[1]:v for x,v in zip(NF,c3)}})
    nd.unpack(hc,[Q(c2[0],Z),Q(c2[2],O)]);incoming_use(hc,c1,c2,0)
    options=[nd.AND(parts(c1,c2,j)) for j in (6,9)]
    def middle(mc,mi):
        idx=[6,9][mi];nd.unpack(mc,parts(c1,c2,idx))
        instate=3 if mi==0 else 4;firstidx=4 if mi==0 else 3
        incoming_use(mc,c0,c1,instate);nd.unpack(mc,parts(c0,c1,firstidx))
        if mi==0:
            # D0 can never be followed by A1 after a real C0->D move.
            # R1=2R0+0 and R1=2R2+1 contradict remainder uniqueness.
            vleft=A(M(num(2),c0[3]),Z);vright=A(M(num(2),c2[3]),O)
            cs=constraints(mc,[parts(c1,c2,6)[4],Q(c2[2],O)])
            ep=a.constrained_equal(mc.g,c1[3],vright,cs)
            left=a.sym(c1[3],vleft,mc.get(Q(c1[3],vleft)),mc.g)
            eq=a.trans(vleft,c1[3],vright,left,ep,mc.g)
            mc.theorem(L(Z,num(2)),const_lt(0,2));mc.theorem(L(O,num(2)),const_lt(1,2))
            quotient_unique(mc,c0[3],Z,c2[3],O,eq)
            mc.put(Q(Z,Z),b.refl(mc.g,Z))
            return contradiction(mc,Z,0,1,danger)
        cs=constraints(mc,[parts(c0,c1,3)[4],parts(c1,c2,9)[4],Q(c1[2],O),Q(c2[2],O)])
        mc.put(danger[2][2],a.constrained_equal(mc.g,danger[2][2][1],danger[2][2][2],cs))
        return nd.conj(mc,[Q(c0[0],O),Q(c0[2],O),danger[2][2]])
    nd.cases(hc,options,danger,middle);ctx.intro(hit,danger,hc)
    # Forwards: B111 has successive scanned bits 1,1,1, hence B->E->A->Z.
    dc=ctx.push(danger);nd.unpack(dc,[Q(c0[0],O),Q(c0[2],O),danger[2][2]])
    selected(dc,c0,c1,3);bit_bound(dc,c1[2]);dc.theorem(L(O,num(2)),const_lt(1,2))
    expect1=A(M(num(2),c2[3]),O)
    act1=A(M(num(2),c1[3]),c1[2]);tar1=A(M(num(2),expect1),O)
    original=dc.get(parts(c0,c1,3)[4]);cs=constraints(dc,[danger[2][2]])
    eq=a.trans(act1,c0[3],tar1,a.sym(c0[3],act1,original,dc.g),a.constrained_equal(dc.g,c0[3],tar1,cs),dc.g)
    quotient_unique(dc,c1[3],c1[2],expect1,O,eq)
    selected(dc,c1,c2,9);bit_bound(dc,c2[2])
    act2=A(M(num(2),c2[3]),c2[2]);tar2=A(M(num(2),c2[3]),O)
    eq=a.trans(act2,c1[3],tar2,a.sym(c1[3],act2,dc.get(parts(c1,c2,9)[4]),dc.g),dc.get(Q(c1[3],expect1)),dc.g)
    quotient_unique(dc,c2[3],c2[2],c2[3],O,eq)
    selected(dc,c2,c3,1);ctx.intro(danger,hit,dc)
    iff=b.Iff(hit,danger)
    ctx.put(iff,b.apply('nd-iff-intro',{'ga':ctx.g,'ph':hit,'ps':danger},[ctx.get(b.Imp(hit,danger)),ctx.get(b.Imp(danger,hit))]))
    finish('skelet17-three-step-halting-characterization',root,run,iff,ctx,
           'For any three actual transitions, the final state is Z iff the initial state is B scanning 111. The right-tail witness is the existing middle configuration R, not a newly encoded list.')
halt_three()

def write():
    (P/'transition_lemmas.mm').write_text('\n'.join(b.lines)+'\n')
    (P/'theorems.json').write_text(json.dumps({n:b.tok(f) for n,f in theorems.items()},indent=2)+'\n')
    print('Wrote',len(b.lines),'items',flush=True)

if __name__=='__main__':write()
