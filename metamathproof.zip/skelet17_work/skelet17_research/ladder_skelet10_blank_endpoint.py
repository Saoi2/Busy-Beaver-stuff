"""Connect the original all-zero initial tape to global boundary exclusion."""
def add_skelet10_blank_endpoint(m,api,sp,right,h,assembly,bd,cycles,maximum,exclusion,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;two=ar.num(2)
 H,N,o=[h[x] for x in ('H','n','offset')];AT=h['AT'];cf,nf=api['current'],api['next'];halt=assembly['halt']
 apply,unpack,collect,elim_rows,pack_rows,bounds=[assembly[x] for x in ('apply','unpack','collect','elim_rows','pack_rows','bounds')]
 av=[m.declare('blankBoundaryInitial'+s) for s in ('Q','L','Bit','R')]
 start=[m.declare('blankBoundaryStart'+s) for s in ('Q','L','Bit','R')]
 entry=[m.declare('blankBoundaryEntry'+s) for s in ('Q','L','Bit','R')]
 def cfg(row):return nd.AND([Q(x,Z) for x in row])
 blank=nd.balls(av,H,b.Imp(AT(o,Z,av),cfg(av)))
 fs=[h['total'](o,N),h['steps'](o,N),blank,*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5))]
 prem=nd.AND(fs);bad=L(Z,Z);T=sp['transform'];sparse=api['sparse']
 def wl(row):return A(M(two,row[1]),row[2])
 def prove():
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);m.bound(c,Z,A(N,O),N)
  c.all_elim(h['ti'],h['total'](o,N)[2],Z);c.mp(L(Z,A(N,O)),nd.bexs(h['TV'],H,AT(o,Z,h['TV'])))
  def have_start(dc):
   nd.inst_balls(dc,av,H,b.Imp(AT(o,Z,av),cfg(av)),start);dc.mp(AT(o,Z,start),cfg(start));unpack(dc,cfg(start))
   m.rewrite(dc,L(ar.E,H),start[0],Z)
   m.invoke(dc,'skelet17-ladder-skelet10-sparse-zero',{},False)
   m.rewrite(dc,sparse(ar.E),Z,start[3],ar.sym(start[3],Z,dc.get(Q(start[3],Z)),dc.g))
   def have_entry(ec):
    apply(ec,'skelet17-ladder-skelet10-a0-enters-right-counter',{**{x[1]:y for x,y in zip(cf,start)},**{x[1]:y for x,y in zip(nf,entry)}})
    m.rewrite(ec,m.sub(right['entry'](entry),{right['word'][1]:ar.E,right['ell'][1]:start[1]}),start[3],Z)
    m.rewrite(ec,m.sub(right['entry'](entry),{right['word'][1]:Z,right['ell'][1]:ar.E}),start[1],Z)
    def have_output(fc,i,row):
     m.invoke(fc,'skelet17-ladder-skelet10-transform-zero',{},False)
     m.rewrite(fc,T(Z,ar.E),Z,wl(row),ar.sym(wl(row),Z,fc.get(Q(wl(row),Z)),fc.g))
     apply(fc,'skelet17-ladder-skelet10-boundary-even-output',{'t':Z,**{x[1]:y for x,y in zip(cf,row)}})
     m.eq(fc,M(two,Z),Z);m.rewrite(fc,bd['boundary'](ar.E,row),M(two,Z),Z)
     prow,inp=maximum['row'],maximum['input'];fc.both(AT(o,i,row),bd['boundary'](Z,row))
     pack_rows(fc,prow,b.And(AT(o,i,prow),bd['boundary'](Z,prow)),row)
     m.bex_intro(fc,inp,H,nd.bexs(prow,H,b.And(AT(o,i,prow),bd['boundary'](inp,prow))),Z)
     m.bex_intro(fc,maximum['index'],A(N,O),maximum['P'](maximum['index']),i)
     collect(fc,exclusion['prem']);m.invoke(fc,'skelet17-ladder-skelet10-no-halting-history-with-boundary',{},False)
     return fc.explode(exclusion['prem'],bad)
    return cycles['run_counter'](ec,'right',entry,A(Z,O),{right['word'][1]:Z,right['ell'][1]:Z},bad,have_output)
   return cycles['advance'](dc,start,Z,0,entry,bad,have_entry)
  elim_rows(c,h['TV'],AT(o,Z,h['TV']),start,bad,have_start)
  c.put(b.Not(bad),b.ax('O1',c.g,t=Z));root.put(b.Not(prem),ar.not_intro(root.g,prem,bad,c.get(bad),c.get(b.Not(bad))))
  m.save('skelet17-ladder-skelet10-no-blank-halting-history',root,b.Not(prem),'No total bounded beta-coded ordinary Skelet #10 computation window starts with the all-zero tape and ends in halt. Original machine and history, no invariant or counter endpoint in the premises. Offset 0 is the ordinary blank-start instance.')
 if proofs:prove()
 return {'blank':blank,'prem':prem,'conclusion':b.Not(prem),'initial_row':av}
