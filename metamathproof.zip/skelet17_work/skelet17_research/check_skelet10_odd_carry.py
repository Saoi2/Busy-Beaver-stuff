"""Independent reconstruction of the recursive carry inverse statement."""
from pathlib import Path
import json
from check_skelet10_scope import implies,both,eq,plus,times,num,EX,parse
from check_skelet10_right import carry,jval,sparse_num
from check_skelet10_spread import bounded
from check_skelet10_left import norm
P=Path(__file__).resolve().parent
v='syncOddOutput'
expected=implies(carry(plus(times(num(4),'t'),'1'),'u'),EX(v,plus('u','1'),both(eq('u',times(num(4),v)),carry('t',v))))
def main():
 data=json.loads((P/'skelet10_odd_carry_theorems.json').read_text());label='skelet17-ladder-skelet10-carry-prefix-inverse'
 assert set(data)=={label};assert norm(parse(data[label]))==norm(expected);assert bounded(expected)
 cases=0
 for x in range(2048):
  if not sparse_num(x):continue
  y=jval(4*x+1)[0];z=jval(x)[0];assert y==4*z and z<y+1;cases+=1
 result={'statements_checked':1,'independent_reconstruction_matches':True,'all_new_statements_delta0':True,'finite_sparse_inputs':cases,'finite_tests_are_not_formal_proofs':True,'carry_uniqueness_formalized':False,'whole_machine_nonhalting':False}
 (P/'skelet10_odd_carry_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':main()
