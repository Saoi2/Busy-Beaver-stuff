from pathlib import Path
import json
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_skelet10_return import add_skelet10_return
from ladder_skelet10_right import add_skelet10_right
from ladder_skelet10_sync_inverse import add_skelet10_sync_inverse
m=r.m;P=Path(__file__).resolve().parent;old=set(m.theorems)
m.nd.OUTPUT_PREFIX='ladder-z10-inverse-carry-';m.a.OUTPUT_PREFIX='ladder-z10-inverse-carry-'
api=add_skelet10(m,proofs=False);ret=add_skelet10_return(m,api,proofs=False)
right=add_skelet10_right(m,api,ret,proofs=False)
add_skelet10_sync_inverse(m,right)
with (P/'skelet10_inverse_carry_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'skelet10_inverse_carry_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Synchronization extension generated.',flush=True)
