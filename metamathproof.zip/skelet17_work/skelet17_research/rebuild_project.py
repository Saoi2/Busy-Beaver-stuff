"""Reproduce the single cleaned project and its verification reports."""
from pathlib import Path
import argparse,shutil,subprocess,sys
P=Path(__file__).resolve().parent
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 fallback=P.parent.parent/'tmp/metamath_build/metamath'
 parser.add_argument('--metamath',default=shutil.which('metamath') or (str(fallback) if fallback.is_file() else None))
 args=parser.parse_args()
 if not args.metamath:parser.error('Pass --metamath /path/to/metamath')
 def python(script,*params,log):
  print(script,flush=True)
  with (P/log).open('w') as out:
   subprocess.run([sys.executable,str(P/script),*params],cwd=P,stdout=out,stderr=subprocess.STDOUT,check=True)
 python('build_ladder.py',log='ladder_build.log')
 python('prune.py','idelta0_machines_raw.mm','idelta0_machines.mm',log='ladder_prune.log')
 python('merge_previous_results.py',log='ladder_merge.log')
 python('simplify_metamath.py',log='simplification_build.log')
 with (P/'ladder_verification.log').open('w') as out:
  subprocess.run([args.metamath,'read "'+str(P/'idelta0_machines.mm')+'"','verify proof *','exit'],cwd=P,stdout=out,stderr=subprocess.STDOUT,check=True)
 python('audit_simplification.py',log='simplification_audit.log')
 python('audit_ladder.py',log='ladder_audit.log')
 print('Rebuild, verification, and audits completed.',flush=True)
if __name__=='__main__':main()
