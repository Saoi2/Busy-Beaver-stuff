"""Canonical boundary constructors and ordinary-step routine connections."""
def add_skelet10_boundaries(m,api,sp,right,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;O,Z=m.O,m.Z;use=m.invoke
 two,three,four,eight=map(ar.num,(2,3,4,8));J=right['carry'];T=sp['transform'];sparse=api['sparse'];cf,nf=api['current'],api['next'];step=api['step']
 ba,bt,bv=[m.declare('boundary'+s) for s in ('A','T','V')]
 fv=m.declare('boundaryFreshOutput')
 def wl(c):return A(M(two,c[1]),c[2])
 def wr(c):return A(M(two,c[3]),c[2])
 def even_fields(n,c,a):return [Q(n,M(two,a)),T(a,wl(c)),J(a,c[3])]
 def odd_fields(n,c,a,t,v):return [Q(n,A(M(four,a),O)),Q(wl(c),A(M(four,t),two)),T(a,t),Q(c[3],M(two,v)),J(a,v)]
 def even(n,c):return nd.BEX(ba,A(n,O),nd.AND(even_fields(n,c,ba)))
 def odd(n,c):return nd.BEX(ba,A(n,O),nd.BEX(bt,A(wl(c),O),nd.BEX(bv,A(c[3],O),nd.AND(odd_fields(n,c,ba,bt,bv)))))
 def boundary(n,c):return nd.AND([Q(c[0],three),L(c[2],two),sparse(n),sparse(c[3]),b.Or(even(n,c),odd(n,c))])
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+name,root,prem,goal,c,comment)
 a,t,v=b.t,b.u,b.v
 def even_input():
  fs=[Q(cf[0],three),L(cf[2],two),sparse(a),T(a,wl(cf)),J(a,cf[3]),sparse(cf[3])];prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);n=M(two,a)
  use(c,'skelet17-ladder-skelet10-sparse-prefix-0',{'t':a});m.bound(c,a,A(n,O),a);c.put(Q(n,n),b.refl(c.g,n));nd.conj(c,even_fields(n,cf,a))
  m.bex_intro(c,ba,A(n,O),nd.AND(even_fields(n,cf,ba)),a);nd.disj(c,[even(n,cf),odd(n,cf)],0);nd.conj(c,[Q(cf[0],three),L(cf[2],two),sparse(n),sparse(cf[3]),b.Or(even(n,cf),odd(n,cf))])
  finish('boundary-even-output',root,prem,boundary(n,cf),c,'A complete right-counter output of even canonical type. No new induction construction.')
 def odd_prem():return [Q(cf[0],three),L(cf[2],two),sparse(a),T(a,t),J(a,v),sparse(v),Q(wl(cf),A(M(four,t),two)),Q(cf[3],M(two,v))]
 def odd_input():
  fs=odd_prem();prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);n=A(M(four,a),O)
  use(c,'skelet17-ladder-skelet10-sparse-prefix-10',{'t':a});use(c,'skelet17-ladder-skelet10-sparse-prefix-0',{'t':v});m.rewrite(c,sparse(ar.E),M(two,v),cf[3],ar.sym(cf[3],M(two,v),c.get(fs[7]),c.g))
  m.bound(c,a,A(n,O),A(M(three,a),O));m.bound(c,t,A(wl(cf),O),A(M(three,t),two),[fs[6]]);m.bound(c,v,A(cf[3],O),v,[fs[7]])
  c.put(Q(n,n),b.refl(c.g,n));nd.conj(c,odd_fields(n,cf,a,t,v))
  m.bex_intro(c,bv,A(cf[3],O),nd.AND(odd_fields(n,cf,a,t,bv)),v)
  m.bex_intro(c,bt,A(wl(cf),O),nd.BEX(bv,A(cf[3],O),nd.AND(odd_fields(n,cf,a,bt,bv))),t)
  m.bex_intro(c,ba,A(n,O),nd.BEX(bt,A(wl(cf),O),nd.BEX(bv,A(cf[3],O),nd.AND(odd_fields(n,cf,ba,bt,bv)))),a)
  nd.disj(c,[even(n,cf),odd(n,cf)],1);nd.conj(c,[Q(cf[0],three),L(cf[2],two),sparse(n),sparse(cf[3]),b.Or(even(n,cf),odd(n,cf))])
  m.finish('z10-boundary-odd-pack',root,prem,boundary(n,cf),c,'Bounded constructor for the odd canonical boundary. Reuses Sparse prefix lemmas.')
 def enter_right():
  fs=[Q(cf[0],Z),Q(cf[2],Z),sparse(cf[3]),step(cf,nf)];prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  mp={right['ell'][1]:cf[1],right['word'][1]:cf[3]};goal=m.sub(right['entry'](nf),mp)
  def move(dc,j):
   pf=api['parts'](cf,nf,j);nd.unpack(dc,pf)
   if j//2!=0:return api['neq'](dc,cf[0],0,j//2,goal)
   if j!=0:return api['neq'](dc,cf[2],0,1,goal)
   api['bitbound'](dc,pf);m.flip(dc,pf[4])
   nd.conj(dc,[Q(nf[0],O),Q(nf[1],A(M(two,cf[1]),O)),Q(wr(nf),cf[3]),L(nf[2],two),sparse(cf[3])]);return dc.get(goal)
  nd.cases(c,[nd.AND(api['parts'](cf,nf,j)) for j in range(10)],goal,move)
  finish('a0-enters-right-counter',root,prem,goal,c,'One ordinary A0 step constructs the complete right-counter entry with input old R and left target old L. No induction.')
 def align_odd():
  five=ar.num(5);fs=[Q(cf[0],three),sparse(a),T(a,t),J(a,cf[3]),sparse(cf[3]),Q(wl(cf),A(M(eight,t),five)),step(cf,nf)]
  prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);goal=boundary(A(M(four,a),O),nf)
  def move(dc,j):
   pf=api['parts'](cf,nf,j);nd.unpack(dc,pf)
   if j//2!=3:return api['neq'](dc,cf[0],3,j//2,goal)
   known=A(M(four,t),two);m.bound(dc,ar.num(j%2),two,ar.num(1-j%2));m.rewrite(dc,L(ar.E,two),ar.num(j%2),cf[2],ar.sym(cf[2],ar.num(j%2),dc.get(pf[1]),dc.g))
   m.bound(dc,O,two,Z);m.eq(dc,wl(cf),A(M(two,known),O),[fs[5]]);m.quotient_unique(dc,two,cf[1],cf[2],known,O)
   if j==6:return api['neq'](dc,cf[2],0,1,goal)
   api['bitbound'](dc,pf);m.eq(dc,wl(nf),known,[m.flip(dc,pf[4]),Q(cf[1],known)]);m.eq(dc,nf[3],M(two,cf[3]),[pf[3]])
   mp={'v':cf[3],**{old[1]:new for old,new in zip(cf,nf)}}
   ant=m.sub(m.theorems['z10-boundary-odd-pack'],mp)[1]
   def collect(f):
    if f[0]=='/\\':collect(f[1]);collect(f[2]);dc.both(f[1],f[2])
    else:dc.get(f)
   collect(ant);use(dc,'z10-boundary-odd-pack',mp);return dc.get(goal)
  nd.cases(c,[nd.AND(api['parts'](cf,nf,j)) for j in range(10)],goal,move)
  finish('right-output-align-odd',root,prem,goal,c,'A right-counter D output with whole-left 8t+5 requires one ordinary D1 alignment before it is canonical. No new induction construction.')
 def identify_left():
  # Same bounded output search as the full-left endpoint, with explicit parameters.
  lv=m.declare('leftOutput');r=b.w;S=A(M(three,a),two)
  target=nd.AND([Q(cf[0],Z),Q(wr(cf),r),nd.BEX(lv,S,nd.AND([J(a,lv),T(lv,cf[1]),sparse(lv)]))])
  fs=[sparse(a),J(a,v),target];prem=nd.AND(fs);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  parts=[Q(cf[0],Z),Q(wr(cf),r),nd.BEX(lv,S,nd.AND([J(a,lv),T(lv,cf[1]),sparse(lv)]))];nd.unpack(c,parts)
  goal=nd.AND([Q(cf[0],Z),Q(wr(cf),r),T(v,cf[1]),sparse(v)])
  def found(dc):
   nd.unpack(dc,[J(a,fv),T(fv,cf[1]),sparse(fv)]);nd.conj(dc,[sparse(a),J(a,fv),J(a,v)]);use(dc,'skelet17-ladder-skelet10-carry-unique-sparse',{'t':a,'u':fv,'v':v})
   m.rewrite(dc,T(ar.E,cf[1]),fv,v);m.rewrite(dc,sparse(ar.E),fv,v);return nd.conj(dc,[Q(cf[0],Z),Q(wr(cf),r),T(v,cf[1]),sparse(v)])
  m.bex_elim(c,lv,S,nd.AND([J(a,lv),T(lv,cf[1]),sparse(lv)]),fv,goal,found)
  finish('left-output-identify',root,prem,goal,c,'Identify the left routine output with an existing carry witness using Sparse carry uniqueness. No new induction construction.')
 if proofs:even_input();odd_input();enter_right();align_odd();identify_left()
 return {'boundary':boundary,'even':even,'odd':odd,'ba':ba,'bt':bt,'bv':bv}
