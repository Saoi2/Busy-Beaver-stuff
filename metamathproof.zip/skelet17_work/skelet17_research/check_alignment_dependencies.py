from pathlib import Path
import sys,itertools
from collections import defaultdict
P=Path(__file__).parent;sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import rewrite
from simplify_metamath import parse_intern as parse
def public(k):return k in {'skelet17-ladder-skelet10-'+x for x in ('left-entry-two-step','return-clear-two-step','even-right-enters-counter')}
source=sys.argv[1] if len(sys.argv)>1 else 'scan_lemmas.mm'
destination=sys.argv[2] if len(sys.argv)>2 else 'scan_checked.mm'
s=(P/source).read_text();records,rules,vs=parse(s);seen=defaultdict(list);alias={}
for r in records:
 if r['kind']not in('a','p'):continue
 key=(tuple(r['expr']),tuple(tuple(rules[h]['expr'])for h in r['hyps']));old=next((q for q in seen[key]if rules[q]['dv']<=r['dv']),None)
 # Keep named interfaces even when a DAG node already has the same formula.
 # Their proof can be tiny, but the stable public label must remain usable.
 if old and r['kind']=='p' and not public(r['label']):alias[r['label']]=old
 else:seen[key].append(r['label'])
keep=set();rw={}
def need(k):
 k=alias.get(k,k)
 if k in keep:return
 keep.add(k);r=rules[k]
 if r['kind']=='p':
  rw[k],deps=rewrite(r,alias)
  for q in deps:need(q)
 for q in r.get('hyps',[]):need(q)
for r in records:
 if r['kind']=='a':need(r['label'])
for r in records:
 if r['kind']=='p' and public(r['label']):need(r['label'])
active=set();scopes=[];out=[]
for r in records:
 kind=r['kind']
 if kind=='{':scopes.append(active.copy())
 elif kind=='}':active=scopes.pop()
 elif kind=='d':active.update(tuple(sorted(p))for p in itertools.combinations(r['expr'],2));continue
 if kind=='p'and r['label']not in keep:continue
 if kind in ('a','p'):
  if kind=='a':dv=r['dv']
  else:
   pr=r['proof'];labs=pr[1:pr.index(')')]if pr[0]=='('else pr;used=set(r['expr'])&vs
   for lab in list(labs)+r['hyps']:
    if rules[lab]['kind']in('f','e'):used.update(set(rules[lab]['expr'])&vs)
   dv={tuple(sorted(pair)) for pair in itertools.combinations(used,2) if tuple(sorted(pair)) in active}
  out.append('${\n');out.extend('$d '+a+' '+b+' $.\n'for a,b in sorted(dv))
  out.append(r['label']+' $p '+' '.join(r['expr'])+' $=\n '+rw[r['label']]+' $.\n'if kind=='p'else s[r['start']:r['end']]+'\n');out.append('$}\n')
 else:out.append(s[r['start']:r['end']]+'\n')
with (P/destination).open('w') as stream:
 for piece in out:
  for pos in range(0,len(piece),1048576):stream.write(piece[pos:pos+1048576])
print('p',sum(rules[k]['kind']=='p'for k in keep),'aliases',len(alias),flush=True)
