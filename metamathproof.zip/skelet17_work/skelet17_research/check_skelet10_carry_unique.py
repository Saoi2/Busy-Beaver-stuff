"""Independent formula and finite witness checks for Sparse carry uniqueness."""
from pathlib import Path
import json
from check_skelet10_scope import implies,AND,eq,sparse,parse
from check_skelet10_right import carry,sparse_num
from check_skelet10_spread import bounded
from check_skelet10_left import norm
P=Path(__file__).resolve().parent
expected=implies(AND([sparse('t'),carry('t','u'),carry('t','v')]),eq('u','v'))
def main():
 data=json.loads((P/'skelet10_unique_carry_theorems.json').read_text());label='skelet17-ladder-skelet10-carry-unique-sparse'
 assert set(data)=={label};assert norm(parse(data[label]))==norm(expected);assert bounded(expected)
 cases=0
 for x in range(2048):
  if not sparse_num(x):continue
  outputs=[];p=1
  while p<3*x+2:
   if (p-1)%3==0:
    s=(p-1)//3
    if s<=x and (x-s)%(2*p)==0:
     a=(x-s)//(2*p)
     if a<=x:outputs.append(p*(4*a+1))
   p*=2
  assert len(set(outputs))==1,(x,outputs);cases+=1
 out={'statements_checked':1,'independent_reconstruction_matches':True,'all_new_statements_delta0':True,'finite_sparse_inputs':cases,'finite_tests_are_not_formal_proofs':True,'carry_uniqueness_on_sparse_inputs':True,'carry_totality_formalized':False,'transformed_word_uniqueness_assumed':False,'whole_machine_nonhalting':False}
 (P/'skelet10_unique_carry_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
