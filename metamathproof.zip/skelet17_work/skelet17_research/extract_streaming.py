"""Extract assertion dependencies using the same low-memory audit scanner.

All original metadata and scopes are retained. Extraction is untrusted;
the resulting database must pass the official Metamath verifier.
"""
from pathlib import Path
import sys,re,json
P=Path(__file__).resolve().parent
path=P/sys.argv[1];target=P/sys.argv[2];roots=json.loads((P/sys.argv[3]).read_text())
source=(P/'audit_streaming.py').read_text()
scanner=source[source.index('def tokens():'):source.index('assert not scopes and len(axioms)')]
namespace={'path':path,'sys':sys,'re':re,'expected':{},'prefixbytes':0}
exec(compile(scanner,'audit_streaming_scanner','exec'),namespace)
deps=namespace['deps'];axioms=namespace['axioms'];assert len(axioms)==93
assert all(key in deps or key in axioms for key in roots)
keep=set();todo=list(roots)
while todo:
 key=todo.pop()
 if key in keep:continue
 keep.add(key);todo.extend(deps.get(key,()))
skip=False;retained=0
with path.open() as inp,target.open('w') as out:
 for line in inp:
  match=re.match(r'^(\S+)\s+\$p\s',line)
  if match:
   assert not skip;skip=match.group(1) not in keep
   if not skip:retained+=1
  if skip:
   if '$.' in line:skip=False
   continue
  out.write(line)
assert not skip
print({'proofs_retained':retained,'bytes':target.stat().st_size,'peak_rss_kib':__import__('resource').getrusage(__import__('resource').RUSAGE_SELF).ru_maxrss},flush=True)
