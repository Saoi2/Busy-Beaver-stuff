"""Factored phases for Skelet #10's complete left-counter routine."""
def add_skelet10_full_left(m,api,sp,right,clear,instructions,blocks,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;use=m.invoke
 two,three,four,eight=map(ar.num,(2,3,4,8));T=sp['transform'];sparse=api['sparse'];carry=right['carry']
 word,rtail=[m.declare('left'+s,'term') for s in ('Input','RightTail')]
 S=A(M(three,word),two);W=A(word,O);PB=A(M(three,word),O);K=M(eight,S)
 cf,nf=api['current'],api['next'];step=api['step']
 p,s,u,a,t,v=[m.declare('left'+x) for x in ('Scale','Suffix','Word','Tail','Encoded','Output')]
 fp,fs,fu,fa,ft,fv=[m.declare('leftFresh'+x) for x in ('Scale','Suffix','Word','Tail','Encoded','Output')]
 dq,dd,eq=m.declare('leftDivisionQuotient'),m.declare('leftDivisionDigit'),m.declare('leftEvenQuotient')
 nrank=m.declare('leftOutputRank');gap=m.declare('leftGap')
 def push(x,d):return A(M(two,x),d)
 def double(x,n):
  for _ in range(n):x=M(two,x)
  return x
 def wl(c):return push(c[1],c[2])
 def wr(c):return push(c[3],c[2])
 def core(pv):return M(M(pv,pv),A(rtail,O))
 def common(pv,sv,uv):return [m.power2(pv),Q(pv,A(M(three,sv),O)),Q(word,A(M(pv,uv),sv)),sparse(uv)]
 def leftshape(j,tv):return {1:tv,2:push(tv,O),3:push(push(tv,O),Z),4:push(push(push(tv,O),Z),O),5:push(push(tv,O),Z),6:push(tv,O),7:tv}[j]
 states=[3,2,4,1,0,2,3,2];bits=[None,0,1,1,1,1,0,1];factors=[2,3,2,1,0,3,4,5];offsets=[8,7,6,5,4,7,6,5]
 def rho(j,uv):return A(A(K,M(eight,uv)),ar.num(offsets[j]))
 def body(c,r,j,pv,uv,tv):
  if j==0:return [Q(c[0],three),L(c[2],two),T(uv,wl(c)),Q(A(c[3],O),double(core(pv),2)),Q(r,rho(j,uv))]
  return [Q(c[0],ar.num(states[j])),Q(c[2],ar.num(bits[j])),Q(c[1],leftshape(j,tv)),Q(A(c[3],O),double(core(pv),factors[j])),Q(r,rho(j,uv))]
 def group(c,r,j,pv,uv,tv):return nd.OR([nd.AND(body(c,r,k,pv,uv,tv)) for k in (range(1,5) if j==0 else range(5,8))])
 def split(uv,av,j):return Q(uv,M(two,av)) if j==0 else Q(uv,A(M(four,av),O))
 def alternatives(c,r,pv,uv,av,tv):return b.Or(b.And(split(uv,av,0),group(c,r,0,pv,uv,tv)),b.And(split(uv,av,1),group(c,r,1,pv,uv,tv)))
 def micro(c,r,pv,uv):return nd.BEX(a,W,nd.BEX(t,A(c[1],O),nd.AND([sparse(a),T(a,t),alternatives(c,r,pv,uv,a,t)])))
 def scanbody(c,r,pv,sv,uv):return nd.AND([*common(pv,sv,uv),b.Or(nd.AND(body(c,r,0,pv,uv,t)),micro(c,r,pv,uv))])
 def scan(c,r):return nd.BEX(p,S,nd.BEX(s,W,nd.BEX(u,W,scanbody(c,r,p,s,u))))
 def cmap(value):return {clear['P'][1]:PB,clear['V'][1]:value,clear['tail'][1]:rtail}
 def clear_rank(c,r,value):return m.sub(clear['rank'](c,r),cmap(value))
 def returning(c,r):return nd.BEX(v,S,b.And(carry(word,v),clear_rank(c,r,v)))
 def rank(c,r):return b.Or(scan(c,r),returning(c,r))
 def endpoint(c):return nd.AND([Q(c[0],Z),Q(wr(c),rtail),nd.BEX(v,S,nd.AND([carry(word,v),T(v,c[1]),sparse(v)]))])
 def entry(c):return nd.AND([Q(c[0],three),L(c[2],two),sparse(word),T(word,wl(c)),Q(c[3],A(M(four,rtail),three))])
 initial_rank=rho(0,word)
 def finish(label,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+label,root,prem,goal,c,comment)
 def scan_cases(c,row,r,goal,fn):
  def pfound(pc):
   def sfound(sc):
    def ufound(uc):
     nd.unpack(uc,[*common(fp,fs,fu),b.Or(nd.AND(body(row,r,0,fp,fu,t)),micro(row,r,fp,fu))])
     def branch(ec,j):
      if j==0:nd.unpack(ec,body(row,r,0,fp,fu,t));return fn(ec,0,fp,fs,fu,Z,Z)
      def afound(ac):
       def tfound(tc):
        nd.unpack(tc,[sparse(fa),T(fa,ft),alternatives(row,r,fp,fu,fa,ft)])
        def kind(kc,k):
         kc.left(split(fu,fa,k),group(row,r,k,fp,fu,ft));kc.right(split(fu,fa,k),group(row,r,k,fp,fu,ft))
         js=list(range(1,5) if k==0 else range(5,8))
         def phase(ph,i):nd.unpack(ph,body(row,r,js[i],fp,fu,ft));return fn(ph,js[i],fp,fs,fu,fa,ft)
         return nd.cases(kc,[nd.AND(body(row,r,i,fp,fu,ft)) for i in js],goal,phase)
        return nd.cases(tc,list(alternatives(row,r,fp,fu,fa,ft)[1:]),goal,kind)
       return m.bex_elim(ac,t,A(row[1],O),nd.AND([sparse(fa),T(fa,t),alternatives(row,r,fp,fu,fa,t)]),ft,goal,tfound)
      return m.bex_elim(ec,a,W,nd.BEX(t,A(row[1],O),nd.AND([sparse(a),T(a,t),alternatives(row,r,fp,fu,a,t)])),fa,goal,afound)
     return nd.cases(uc,[nd.AND(body(row,r,0,fp,fu,t)),micro(row,r,fp,fu)],goal,branch)
    return m.bex_elim(sc,u,W,scanbody(row,r,fp,fs,u),fu,goal,ufound)
   return m.bex_elim(pc,s,W,nd.BEX(u,W,scanbody(row,r,fp,s,u)),fs,goal,sfound)
  return m.bex_elim(c,p,S,nd.BEX(s,W,nd.BEX(u,W,scanbody(row,r,p,s,u))),fp,goal,pfound)
 def return_cases(c,row,r,goal,fn):
  def found(cc):nd.unpack(cc,[carry(word,fv),clear_rank(row,r,fv)]);return fn(cc,fv)
  return m.bex_elim(c,v,S,b.And(carry(word,v),clear_rank(row,r,v)),fv,goal,found)
 def pack_scan(c,row,r,j,pv,sv,uv,av=Z,tv=Z):
  nd.conj(c,body(row,r,j,pv,uv,tv))
  if j==0:nd.disj(c,[nd.AND(body(row,r,0,pv,uv,t)),micro(row,r,pv,uv)],0)
  else:
   k=0 if j<5 else 1;js=list(range(1,5) if k==0 else range(5,8));nd.disj(c,[nd.AND(body(row,r,i,pv,uv,tv)) for i in js],js.index(j))
   c.both(split(uv,av,k),group(row,r,k,pv,uv,tv));nd.disj(c,list(alternatives(row,r,pv,uv,av,tv)[1:]),k)
   nd.conj(c,[sparse(av),T(av,tv),alternatives(row,r,pv,uv,av,tv)])
   m.bex_intro(c,t,A(row[1],O),nd.AND([sparse(av),T(av,t),alternatives(row,r,pv,uv,av,t)]),tv)
   m.bex_intro(c,a,W,nd.BEX(t,A(row[1],O),nd.AND([sparse(a),T(a,t),alternatives(row,r,pv,uv,a,t)])),av)
   nd.disj(c,[nd.AND(body(row,r,0,pv,uv,t)),micro(row,r,pv,uv)],1)
  nd.conj(c,[*common(pv,sv,uv),b.Or(nd.AND(body(row,r,0,pv,uv,t)),micro(row,r,pv,uv))])
  m.bex_intro(c,u,W,scanbody(row,r,pv,sv,u),uv);m.bex_intro(c,s,W,nd.BEX(u,W,scanbody(row,r,pv,s,u)),sv)
  m.bex_intro(c,p,S,nd.BEX(s,W,nd.BEX(u,W,scanbody(row,r,p,s,u))),pv);return nd.disj(c,[scan(row,r),returning(row,r)],0)
 def pack_return(c,row,r,value):
  c.both(carry(word,value),clear_rank(row,r,value));m.bex_intro(c,v,S,b.And(carry(word,v),clear_rank(row,r,v)),value)
  return nd.disj(c,[scan(row,r),returning(row,r)],1)
 def helpers():
  # Share the already proved bounded affine arithmetic and clearing facts.
  if 'z10-block-factor-bound' not in m.theorems:blocks['factor_bound']()
  clear['positive_safe']()
  x,y,z,r=b.t,b.u,b.v,b.w;root=nd.Ctx();prem=Q(r,A(x,A(y,O)));c=root.push(prem);goal=L(A(x,y),r)
  m.bound(c,A(x,y),r,Z,[prem]);m.finish('z10-full-left-unit-drop',root,prem,goal,c,'One unit of a factored rank is consumed. No induction.')
  # Symbolic coefficients avoid expanding eight copies of every summand.
  rk,rr=m.declare('leftRankOffset','term'),m.declare('leftRankValue','term')
  g2=m.declare('leftRankPositiveGap')
  root=nd.Ctx();fs0=[L(x,y),L(Z,r),Q(rr,A(A(rk,M(z,y)),r))];prem=nd.AND(fs0);c=root.push(prem);nd.unpack(c,fs0);goal=L(A(A(rk,M(z,x)),z),rr)
  def ygap(cc,ye):
   return m.gap_elim(cc,Z,r,g2,goal,lambda dc,re:m.bound(dc,A(A(rk,M(z,x)),z),rr,A(M(z,gap),g2),[fs0[2],ye,re]))
  m.gap_elim(c,x,y,gap,goal,ygap)
  m.finish('z10-full-left-carry-drop',root,prem,goal,c,'Symbolic-coefficient search rank comparison. No induction.')
  coef=A(two,z);root=nd.Ctx();fs0=[L(x,y),Q(rr,A(A(M(coef,y),M(coef,r)),four))];prem=b.And(*fs0);c=root.push(prem);nd.unpack(c,fs0);goal=L(M(two,x),rr)
  slack=A(A(A(M(z,x),M(coef,gap)),M(coef,r)),A(z,ar.num(5)))
  m.gap_elim(c,x,y,gap,goal,lambda cc,eq:m.bound(cc,M(two,x),rr,slack,[fs0[1],eq]))
  m.finish('z10-full-left-exit-drop',root,prem,goal,c,'Factored scan-to-return rank comparison. No induction.')
  root=nd.Ctx();f=Q(eight,A(two,ar.num(6)));m.eq(root,*f[1:]);m.save('z10-full-left-eight-split',root,f,'Constant coefficient split, without distributing over the tape parameters.')
  # A generic coefficient keeps nested doublings factored, avoiding 64-term expansion.
  coef,x,y=b.t,b.u,b.v
  def D(term,n):
   for _ in range(n):term=M(coef,term)
   return term
  root=nd.Ctx();lhs=D(M(M(D(x,2),D(x,2)),y),2);rhs=D(M(M(x,x),y),6);m.eq(root,lhs,rhs)
  m.save('z10-full-left-square-shift',root,Q(lhs,rhs),'Factored sixfold shift of a squared carry scale. No induction.')
  # Generic clearing-certificate constructor; no new machine rule.
  pv,uv=b.t,b.u;rr=M(two,pv);fs0=[L(pv,A(clear['P'],O)),L(uv,A(clear['V'],O)),*clear['fields'](cf,0,pv,uv,clear['t'])]
  root=nd.Ctx();prem=nd.AND(fs0);c=root.push(prem);nd.unpack(c,fs0);c.put(Q(rr,rr),b.refl(c.g,rr));clear['pack'](c,cf,rr,0,pv,uv)
  m.finish('z10-full-left-clear-pack',root,prem,clear['rank'](cf,rr),c,'Package a bounded main clearing certificate. Pure logic.')
 if proofs:
  if 'z10-right-prefix-bounds' not in m.theorems:right['prefix_bounds']()
  helpers()
 def tape_step(c,j,x,y,d):
  source,target,_=instructions['instruction'](j,x,y,d)
  for old,new in zip(cf,source):
   if old==new:c.put(Q(old,new),b.refl(c.g,old))
   c.get(Q(old,new))
  instructions['transport'](c,lambda row:step(row,nf),cf,source)
  formula=instructions['contract'](c,j,x,y,d,nf)
  eqs=nd.AND([Q(z,v0) for z,v0 in zip(nf,target)]);c.mp(step(source,nf),eqs);nd.unpack(c,[Q(z,v0) for z,v0 in zip(nf,target)])
  m.rewrite(c,L(ar.E,two),d,nf[2],ar.sym(nf[2],d,c.get(Q(nf[2],d)),c.g))
  return target
 def divides(c,x,goal,fn):
  m.bound(c,Z,two,O);use(c,'skelet17-bounded-division-exists',{'t':x,'u':two})
  return m.bex_elim(c,m.q,A(x,O),nd.BEX(m.r,two,Q(x,push(m.q,m.r))),dq,goal,lambda qc:m.bex_elim(qc,m.r,two,Q(x,push(dq,m.r)),dd,goal,lambda rc:fn(rc,dq,dd)))
 def right_plus(c,factor):
  eq0=Q(nf[3],push(cf[3],O));m.eq(c,A(nf[3],O),M(two,A(cf[3],O)),[eq0])
  return m.rewrite(c,Q(A(nf[3],O),M(two,ar.E)),A(cf[3],O),factor)
 def tail_bound(c,j,tv):
  coeff,offset={1:(1,0),2:(2,1),3:(4,2),4:(8,5),5:(4,2),6:(2,1),7:(1,0)}[j]
  lin=A(M(ar.num(coeff),tv),ar.num(offset));m.eq(c,nf[1],lin,[Q(nf[1],leftshape(j,tv))])
  m.bound(c,Z,ar.num(coeff),ar.num(coeff-1));c.both(L(Z,ar.num(coeff)),Q(nf[1],lin))
  return use(c,'z10-block-factor-bound',{'t':ar.num(coeff),'u':tv,'v':nf[1],'w':ar.num(offset)})
 def unit_drop(c,r,j,uv):
  old=Q(r,rho(j,uv));newrho=rho(j+1,uv)
  use(c,'z10-full-left-unit-drop',{'t':A(K,M(eight,uv)),'u':ar.num(offsets[j]-1),'v':Z,'w':r})
  return c.get(L(newrho,r))
 def carry_bound():
  x,y=b.t,b.u;root=nd.Ctx();prem=carry(x,y);c=root.push(prem);goal=L(y,A(M(three,x),two));jp,js,ja=right['jp'],right['js'],right['ja']
  ep,es,ea=[m.declare('leftCarryBound'+n) for n in ('P','S','A')]
  def cp(pv,sv,av):return [m.power2(pv),Q(pv,A(M(three,sv),O)),Q(x,A(M(pv,M(two,av)),sv)),Q(y,M(pv,A(M(four,av),O)))]
  def pfound(pc):
   def sfound(sc):
    def afound(ac):
     nd.unpack(ac,cp(ep,es,ea));linear=Q(y,A(A(M(two,x),es),O));m.eq(ac,*linear[1:],[cp(ep,es,ea)[3],cp(ep,es,ea)[2],cp(ep,es,ea)[1]])
     def gapfound(gc,geq):
      ant=Q(A(x,O),A(A(es,gap),O));m.eq(gc,*ant[1:],[geq]);out=Q(x,A(es,gap));gc.theorem(b.Imp(ant,out),b.apply('add-cancel',{'t':x,'u':A(es,gap),'v':O}));gc.mp(ant,out)
      return m.bound(gc,y,A(M(three,x),two),gap,[linear,out])
     return m.gap_elim(ac,es,A(x,O),gap,goal,gapfound)
    return m.bex_elim(sc,ja,A(x,O),nd.AND(cp(ep,es,ja)),ea,goal,afound)
   return m.bex_elim(pc,js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(ep,js,ja))),es,goal,sfound)
  m.bex_elim(c,jp,A(M(three,x),two),nd.BEX(js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(jp,js,ja)))),ep,goal,pfound)
  m.finish('z10-full-left-carry-output-bound',root,prem,goal,c,'The bounded carry graph has output at most 3w+1. No induction.')
 if proofs:carry_bound()
 def entry_proof():
  root=nd.Ctx();prem=entry(cf);c=root.push(prem);nd.unpack(c,[Q(cf[0],three),L(cf[2],two),sparse(word),T(word,wl(cf)),Q(cf[3],A(M(four,rtail),three))])
  use(c,'skelet17-binary-power-one',{},False);m.bound(c,O,S,M(three,word));m.bound(c,Z,W,word);m.successor(c,word)
  m.eq(c,O,A(M(three,Z),O));m.eq(c,word,A(M(O,word),Z))
  m.eq(c,A(cf[3],O),double(core(O),2),[Q(cf[3],A(M(four,rtail),three))]);c.put(Q(initial_rank,initial_rank),b.refl(c.g,initial_rank))
  pack_scan(c,cf,initial_rank,0,O,Z,word)
  finish('left-counter-entry',root,prem,rank(cf,initial_rank),c,'A proper D input has bounded scan witnesses and initial rank 32w+24. No induction.')
 if proofs:entry_proof()
 return {'rank':rank,'scan':scan,'returning':returning,'endpoint':endpoint,'entry':entry,'initial_rank':initial_rank,'word':word,'tail':rtail,'S':S,'W':W,'PB':PB,'K':K,'common':common,'body':body,'micro':micro,'scanbody':scanbody,'scan_cases':scan_cases,'return_cases':return_cases,'pack_scan':pack_scan,'pack_return':pack_return,'cmap':cmap,'clear_rank':clear_rank,'p':p,'s':s,'u':u,'a':a,'t':t,'v':v,'fp':fp,'fs':fs,'fu':fu,'fa':fa,'ft':ft,'fv':fv,'dq':dq,'dd':dd,'eq':eq,'nrank':nrank,'outscale':nrank,'push':push,'double':double,'wl':wl,'wr':wr,'core':core,'rho':rho,'leftshape':leftshape,'split':split,'tape_step':tape_step,'divides':divides,'right_plus':right_plus,'tail_bound':tail_bound}
