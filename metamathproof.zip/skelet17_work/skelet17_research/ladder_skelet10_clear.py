"""Two-phase A1 clearing return, preserving the encoded left word."""
def add_skelet10_clear(m,api,sp,ret,proofs=True):
 nd,b,a=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;two=a.num(2);four=a.num(4);use=m.invoke
 P,V,tail=[m.declare('clear'+s,'term') for s in ('InitialScale','OutputWord','RightTail')]
 cf,nf=api['current'],api['next'];step,parts=api['step'],api['parts'];T=sp['transform'];sparse=api['sparse']
 p,u,t=[m.declare('clear'+s) for s in ('Scale','Word','EncodedTail')]
 fp,fu,ft,fh=[m.declare('clearFresh'+s) for s in ('Scale','Word','EncodedTail','Half')]
 out=m.declare('clearOutputRank');gap=m.declare('clearPositiveGap')
 def wr(c):return A(M(two,c[3]),c[2])
 def rankvalue(j,p):return M(two,p) if j==0 else A(M(two,p),O)
 def fields(c,j,p,u,t):
  common=[Q(c[0],Z),L(c[2],two),m.power2(p),sparse(u)]
  if j==0:return [*common,T(u,c[1]),Q(M(p,u),V),Q(A(wr(c),O),M(M(p,p),A(tail,O)))]
  return [*common,T(u,t),Q(c[1],M(two,t)),Q(M(M(two,p),u),V),Q(A(wr(c),O),M(two,M(M(p,p),A(tail,O))))]
 def clause(c,r,j):
  body=nd.AND([*fields(c,j,p,u,t),Q(r,rankvalue(j,p))])
  if j:body=nd.BEX(t,A(c[1],O),body)
  return nd.BEX(p,A(P,O),nd.BEX(u,A(V,O),body))
 def rank(c,r):return b.Or(clause(c,r,0),clause(c,r,1))
 def entry(c):return nd.BEX(u,A(V,O),nd.AND(fields(c,0,P,u,t)))
 def endpoint(c):return nd.AND([Q(c[0],Z),Q(wr(c),tail),T(V,c[1]),sparse(V)])
 initial_rank=M(two,P)
 def finish(label,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+label,root,prem,goal,c,comment)
 def eliminate(c,row,r,j,goal,fn):
  def havep(pc):
   def haveu(uc):
    if j==0:nd.unpack(uc,[*fields(row,j,fp,fu,t),Q(r,rankvalue(j,fp))]);return fn(uc,fp,fu,Z)
    def havet(tc):nd.unpack(tc,[*fields(row,j,fp,fu,ft),Q(r,rankvalue(j,fp))]);return fn(tc,fp,fu,ft)
    return m.bex_elim(uc,t,A(row[1],O),nd.AND([*fields(row,j,fp,fu,t),Q(r,rankvalue(j,fp))]),ft,goal,havet)
   body=nd.AND([*fields(row,j,fp,u,t),Q(r,rankvalue(j,fp))]);body=nd.BEX(t,A(row[1],O),body) if j else body
   return m.bex_elim(pc,u,A(V,O),body,fu,goal,haveu)
  body=nd.AND([*fields(row,j,p,u,t),Q(r,rankvalue(j,p))]);body=nd.BEX(t,A(row[1],O),body) if j else body
  return m.bex_elim(c,p,A(P,O),nd.BEX(u,A(V,O),body),fp,goal,havep)
 def pack(c,row,r,j,pv,uv,tv=Z):
  fs=[*fields(row,j,pv,uv,tv),Q(r,rankvalue(j,pv))];nd.conj(c,fs)
  if j:m.bex_intro(c,t,A(row[1],O),nd.AND([*fields(row,j,pv,uv,t),Q(r,rankvalue(j,pv))]),tv)
  body=nd.AND([*fields(row,j,pv,u,t),Q(r,rankvalue(j,pv))]);body=nd.BEX(t,A(row[1],O),body) if j else body
  m.bex_intro(c,u,A(V,O),body,uv)
  body=nd.AND([*fields(row,j,p,u,t),Q(r,rankvalue(j,p))]);body=nd.BEX(t,A(row[1],O),body) if j else body
  m.bex_intro(c,p,A(P,O),nd.BEX(u,A(V,O),body),pv)
  return nd.disj(c,[clause(row,r,k) for k in (0,1)],j)
 def positive_safe():
  r=b.t;prem=rank(cf,r)
  if 'z10-clear-rank-positive' not in m.theorems:
   r=b.t;prem=rank(cf,r);root=nd.Ctx();c=root.push(prem);goal=L(Z,r)
   def branch(cc,j):
    def found(dc,pv,uv,tv):
     re=Q(r,rankvalue(j,pv))
     if j:return m.bound(dc,Z,r,M(two,pv),[re])
     nd.unpack(dc,list(m.power2(pv)[1:]));return m.gap_elim(dc,Z,pv,gap,goal,lambda ec,eq:m.bound(ec,Z,r,A(M(two,gap),O),[re,eq]))
    return eliminate(cc,cf,r,j,goal,found)
   nd.cases(c,[clause(cf,r,k) for k in (0,1)],goal,branch);m.finish('z10-clear-rank-positive',root,prem,goal,c,'Both clearing ranks are positive. No induction.')
  if 'z10-clear-rank-safe' not in m.theorems:
   root=nd.Ctx();c=root.push(prem);bad=Q(cf[0],a.num(5));bc=c.push(bad)
   def wrong(cc,j):return eliminate(cc,cf,r,j,L(Z,Z),lambda dc,pv,uv,tv:api['neq'](dc,cf[0],0,5,L(Z,Z)))
   nd.cases(bc,[clause(cf,r,k) for k in (0,1)],L(Z,Z),wrong);bc.put(b.Not(L(Z,Z)),b.ax('O1',bc.g,t=Z))
   c.put(b.Not(bad),a.not_intro(c.g,bad,L(Z,Z),bc.get(L(Z,Z)),bc.get(b.Not(L(Z,Z)))))
   m.finish('z10-clear-rank-safe',root,prem,b.Not(bad),c,'Both clearing phases are in A, hence exclude halt. No induction.')
 def entry_proof():
  root=nd.Ctx();prem=entry(cf);c=root.push(prem);goal=rank(cf,initial_rank)
  def found(cc):
   nd.unpack(cc,fields(cf,0,P,fu,t));m.successor(cc,P);cc.put(Q(initial_rank,initial_rank),b.refl(cc.g,initial_rank));return pack(cc,cf,initial_rank,0,P,fu)
  m.bex_elim(c,u,A(V,O),nd.AND(fields(cf,0,P,u,t)),fu,goal,found)
  finish('left-return-entry',root,prem,goal,c,'A proper A clearing entry has the bounded two-phase rank with initial value 2P. No induction.')
 def first_drop():
  h,r=b.t,b.u;prem=b.And(L(Z,h),Q(r,M(two,M(two,h))));goal=L(A(M(two,h),O),r);root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]))
  m.gap_elim(c,Z,h,gap,goal,lambda cc,eq:m.bound(cc,A(M(two,h),O),r,M(two,gap),[prem[2],eq]))
  m.finish('z10-clear-first-rank-drop',root,prem,goal,c,'The first half of a two-step clear decreases its rank. No induction.')
 if proofs:positive_safe();entry_proof();first_drop()
 def local():
  r=b.t;prem=nd.AND([rank(cf,r),b.Not(endpoint(cf)),step(cf,nf)]);goal=nd.BEX(out,r,rank(nf,out))
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,[rank(cf,r),b.Not(endpoint(cf)),step(cf,nf)])
  def finish_output(cc,j,pv,uv,tv=Z):
   rho=rankvalue(j,pv);cc.put(Q(rho,rho),b.refl(cc.g,rho));pack(cc,nf,rho,j,pv,uv,tv);return m.bex_intro(cc,out,r,rank(nf,out),rho)
  def region(cc,j):
   def found(dc,pv,uv,tv):
    if j==0:
     use(dc,'skelet17-binary-power-halving',{'t':pv});hb=b.And(Q(pv,M(two,m.pz)),m.power2(m.pz))
     opts=[Q(pv,O),nd.BEX(m.pz,A(pv,O),hb)]
     def scale_branch(ec,k):
      if k==0:
       m.eq(ec,A(wr(cf),O),A(tail,O),[fields(cf,0,pv,uv,tv)[-1],Q(pv,O)])
       ant=Q(A(wr(cf),O),A(tail,O));ee=Q(wr(cf),tail)
       ec.theorem(b.Imp(ant,ee),b.apply('add-cancel',{'t':wr(cf),'u':tail,'v':O}));ec.mp(ant,ee)
       m.rewrite(ec,Q(M(a.E,uv),V),pv,O);m.eq(ec,M(O,uv),uv);m.rewrite(ec,Q(a.E,V),M(O,uv),uv)
       m.rewrite(ec,T(a.E,cf[1]),uv,V);m.rewrite(ec,sparse(a.E),uv,V)
       nd.conj(ec,[Q(cf[0],Z),ee,T(V,cf[1]),sparse(V)]);return ec.explode(endpoint(cf),goal)
      def half_found(hc):
       heq=Q(pv,M(two,fh));nd.unpack(hc,[heq,m.power2(fh)]);nd.unpack(hc,list(m.power2(fh)[1:]))
       use(hc,'skelet17-binary-double-larger',{'t':fh});m.rewrite(hc,L(fh,a.E),M(two,fh),pv,a.sym(pv,M(two,fh),hc.get(heq),hc.g));m.translt(hc,fh,pv,A(P,O))
       rhs=M(two,M(M(fh,fh),A(tail,O)));peq=Q(A(wr(cf),O),M(two,rhs));m.eq(hc,*peq[1:],[fields(cf,0,pv,uv,tv)[-1],heq])
       m.eq(hc,wr(cf),A(M(two,cf[3]),cf[2]));nd.conj(hc,[peq,Q(wr(cf),A(M(two,cf[3]),cf[2])),L(cf[2],two)])
       use(hc,'z10-return-even-predecessor',{'t':wr(cf),'u':rhs,'v':cf[3],'w':cf[2]});nd.unpack(hc,[Q(cf[2],O),Q(A(cf[3],O),rhs)])
       def instruction(ic,k):
        pf=parts(cf,nf,k);nd.unpack(ic,pf)
        if k//2!=0:return api['neq'](ic,cf[0],0,k//2,goal)
        if k==0:return api['neq'](ic,cf[2],1,0,goal)
        api['bitbound'](ic,pf)
        m.eq(ic,nf[1],M(two,cf[1]),[pf[3]]);m.bound(ic,cf[1],A(nf[1],O),cf[1],[pf[3]])
        m.rewrite(ic,Q(M(a.E,uv),V),pv,M(two,fh),ic.get(heq))
        m.eq(ic,A(wr(nf),O),rhs,[m.flip(ic,pf[4]),Q(A(cf[3],O),rhs)])
        oldre=Q(r,M(two,pv));m.eq(ic,r,M(two,M(two,fh)),[oldre,heq]);ic.both(L(Z,fh),Q(r,M(two,M(two,fh))))
        use(ic,'z10-clear-first-rank-drop',{'t':fh,'u':r})
        return finish_output(ic,1,fh,uv,cf[1])
       return nd.cases(hc,[nd.AND(parts(cf,nf,k)) for k in range(10)],goal,instruction)
      return m.bex_elim(ec,m.pz,A(pv,O),hb,fh,goal,half_found)
     return nd.cases(dc,opts,goal,scale_branch)
    rhs=M(M(pv,pv),A(tail,O));peq=Q(A(wr(cf),O),M(two,rhs))
    m.eq(dc,wr(cf),A(M(two,cf[3]),cf[2]));nd.conj(dc,[peq,Q(wr(cf),A(M(two,cf[3]),cf[2])),L(cf[2],two)])
    use(dc,'z10-return-even-predecessor',{'t':wr(cf),'u':rhs,'v':cf[3],'w':cf[2]});nd.unpack(dc,[Q(cf[2],O),Q(A(cf[3],O),rhs)])
    def instruction(ic,k):
     pf=parts(cf,nf,k);nd.unpack(ic,pf)
     if k//2!=0:return api['neq'](ic,cf[0],0,k//2,goal)
     if k==0:return api['neq'](ic,cf[2],1,0,goal)
     api['bitbound'](ic,pf);m.eq(ic,nf[1],M(four,tv),[pf[3],Q(cf[1],M(two,tv))])
     use(ic,'skelet17-ladder-skelet10-transform-prefix-0',{'t':uv,'u':tv})
     m.rewrite(ic,T(M(two,uv),a.E),M(four,tv),nf[1],a.sym(nf[1],M(four,tv),ic.get(Q(nf[1],M(four,tv))),ic.g))
     use(ic,'skelet17-ladder-skelet10-sparse-prefix-0',{'t':uv})
     oldprod=M(M(two,pv),uv);newprod=M(pv,M(two,uv));m.eq(ic,oldprod,newprod);m.rewrite(ic,Q(a.E,V),oldprod,newprod)
     nd.unpack(ic,list(m.power2(pv)[1:]));use(ic,'skelet17-binary-factor-bound',{'t':M(two,uv),'u':pv})
     m.rewrite(ic,L(M(two,uv),A(a.E,O)),newprod,V)
     m.eq(ic,A(wr(nf),O),rhs,[m.flip(ic,pf[4]),Q(A(cf[3],O),rhs)])
     m.successor(ic,M(two,pv));m.rewrite(ic,L(M(two,pv),a.E),A(M(two,pv),O),r,a.sym(r,A(M(two,pv),O),ic.get(Q(r,A(M(two,pv),O))),ic.g))
     return finish_output(ic,0,pv,M(two,uv))
    return nd.cases(dc,[nd.AND(parts(cf,nf,k)) for k in range(10)],goal,instruction)
   return eliminate(cc,cf,r,j,goal,found)
  nd.cases(c,[clause(cf,r,j) for j in (0,1)],goal,region)
  finish('left-return-step',root,prem,goal,c,'A clearing step before the correct A endpoint preserves the transformed word and Sparse syntax with strictly smaller rank. Uses only the ordinary Step relation.')
 if proofs:
  if 'z10-return-even-predecessor' not in m.theorems:ret['predecessor']()
  local()
 return {'rank':rank,'endpoint':endpoint,'entry':entry,'initial_rank':initial_rank,'P':P,'V':V,'tail':tail,'cf':cf,'nf':nf,'outscale':out,'fields':fields,'clause':clause,'p':p,'u':u,'t':t,'pack':pack,'eliminate':eliminate,'rankvalue':rankvalue,'positive_safe':positive_safe}
