"""Bounded block-tail existence for the already fixed left-word graph."""
def add_skelet10_blocks(m,sp,proofs=True):
 nd,b,a=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 two,four,ten,sixteen=map(a.num,(2,4,10,16));use=m.invoke
 dil,T=sp['dil'],sp['transform'];zw=sp['zw'];push=sp['push']
 old,first,second,tail=[m.declare('block'+s) for s in ('Spread','First','Second','Tail')]
 dec=m.declare('inverseOutputTail');boundgap=m.declare('blockFactorGap')
 def factor_bound():
  p,x,z,d=b.t,b.u,b.v,b.w;fs=[L(Z,p),Q(z,A(M(p,x),d))];prem=b.And(*fs);goal=L(x,A(z,O));root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  m.gap_elim(c,Z,p,boundgap,goal,lambda cc,eq:m.bound(cc,x,A(z,O),A(M(boundgap,x),d),[fs[1],eq]))
  m.finish('z10-block-factor-bound',root,prem,goal,c,'A positive affine multiplier bounds its factor by the output. No induction.')
 def coefficients():
  # The earlier helper labels may have been safely inlined by cleanup.
  x,y,z=b.t,b.u,b.v
  if 'z10-spread-product-reorder' not in m.theorems:
   root=nd.Ctx();f=Q(M(x,M(y,z)),M(y,M(x,z)));m.eq(root,*f[1:]);m.save('z10-spread-product-reorder',root,f)
  if 'z10-spread-affine-scale' not in m.theorems:
   root=nd.Ctx();f=Q(A(M(x,M(y,z)),y),M(y,A(M(x,z),O)));m.eq(root,*f[1:]);m.save('z10-spread-affine-scale',root,f)
 if proofs:factor_bound();coefficients()
 def decoded(x,z,d):return nd.BEX(dec,A(z,O),b.And(Q(z,A(M(four,dec),d)),dil(x,dec)))
 def decode_use(c,x,z,d):
  m.bound(c,d,two,O if d==Z else Z);c.both(dil(push(x,d),z),L(d,two));return use(c,'skelet17-ladder-skelet10-spread-decompose',{'t':x,'u':z,'v':d})
 def decode_elim(c,x,z,d,fresh,goal,fn):
  body=b.And(Q(z,A(M(four,dec),d)),dil(x,dec))
  def found(cc):nd.unpack(cc,[Q(z,A(M(four,fresh),d)),dil(x,fresh)]);return fn(cc)
  return m.bex_elim(c,dec,A(z,O),body,fresh,goal,found)
 def theorem(digits,label):
  x,z=b.t,b.u;nx=M(two,x) if digits==1 else A(M(four,x),O);scale=four if digits==1 else sixteen;offset=Z if digits==1 else ten
  body=b.And(Q(z,A(M(scale,tail),offset)),T(x,tail));goal=nd.BEX(tail,A(z,O),body)
  root=nd.Ctx();prem=T(nx,z);c=root.push(prem)
  def found(cc):
   zeq=Q(z,M(ten,old));nd.unpack(cc,[zeq,dil(nx,old)])
   ix=x if digits==1 else M(two,x);d=Z if digits==1 else O
   m.eq(cc,nx,push(ix,d));m.rewrite(cc,dil(a.E,old),nx,push(ix,d));decode_use(cc,ix,old,d)
   def firstfound(dc):
    feq=Q(old,A(M(four,first),d))
    def conclude(ec,u,eq):
     inner=M(scale,u) if digits==1 else A(M(scale,u),O);value=M(ten,u)
     m.rewrite(ec,Q(z,M(ten,a.E)),old,inner,ec.get(eq))
     if digits==1:
      use(ec,'z10-spread-product-reorder',{'t':ten,'u':scale,'v':u},False)
      m.rewrite(ec,Q(z,a.E),M(ten,inner),M(scale,value))
      ec.put(Q(A(M(scale,value),Z),M(scale,value)),b.ax('A3',ec.g,t=M(scale,value)))
      m.rewrite(ec,Q(z,a.E),M(scale,value),A(M(scale,value),Z),a.sym(A(M(scale,value),Z),M(scale,value),ec.get(Q(A(M(scale,value),Z),M(scale,value))),ec.g))
     else:
      use(ec,'z10-spread-affine-scale',{'t':scale,'u':ten,'v':u},False);rhs=A(M(scale,value),ten)
      m.rewrite(ec,Q(z,a.E),M(ten,inner),rhs,a.sym(rhs,M(ten,inner),ec.get(Q(rhs,M(ten,inner))),ec.g))
     m.bound(ec,Z,scale,a.num(3 if digits==1 else 15));ec.both(L(Z,scale),Q(z,A(M(scale,value),offset)))
     use(ec,'z10-block-factor-bound',{'t':scale,'u':value,'v':z,'w':offset})
     m.bound(ec,Z,ten,a.num(9));use(ec,'skelet17-binary-factor-bound',{'t':u,'u':ten})
     ec.put(Q(value,M(ten,u)),b.refl(ec.g,value));sp['pack_transform'](ec,x,value,u)
     ec.both(Q(z,A(M(scale,value),offset)),T(x,value));return m.bex_intro(ec,tail,A(z,O),body,value)
    if digits==1:
     m.eq(dc,old,M(four,first),[feq]);return conclude(dc,first,Q(old,M(four,first)))
    m.eq(dc,M(two,x),push(x,Z));m.rewrite(dc,dil(a.E,first),M(two,x),push(x,Z));decode_use(dc,x,first,Z)
    def secondfound(ec):
     se=Q(first,A(M(four,second),Z));inner=A(M(sixteen,second),O)
     m.eq(ec,old,inner,[feq,se]);return conclude(ec,second,Q(old,inner))
    return decode_elim(dc,x,first,Z,second,goal,secondfound)
   return decode_elim(cc,ix,old,d,first,goal,firstfound)
  m.bex_elim(c,zw,A(z,O),b.And(Q(z,M(ten,zw)),dil(nx,zw)),old,goal,found)
  m.finish('skelet17-ladder-skelet10-'+label,root,prem,goal,c,'Every encoded grammar word has a bounded block tail with the exact output equation. Reuses spread decoding; no new induction or uniqueness premise.')
 if proofs:theorem(1,'transform-decompose-0');theorem(2,'transform-decompose-10')
 return {'tail':tail,'factor_bound':factor_bound}
