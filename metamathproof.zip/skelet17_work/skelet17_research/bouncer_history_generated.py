nd,b,a=m.nd,m.b,m.a
A,M,Q,L=b.Add,b.Mul,b.Eq,b.Lt
N,O,Z=b.NIL,b.O,b.Z
V,T=b.V,b.T
H=T('mh');n=T('mn');offset=m.declare('ladderBouncerOffset','term')
IV=V('iv');IP=[V(s) for s in ('oq','ol','ob','orr')]
CF=[V(s) for s in ('cq','cl','cb','cr')]
NF=[V(s) for s in ('vq','vl','vb','vr')]
TV=[V(s) for s in ('tq','tl','tb','tr')]
AV=[V(s) for s in ('iq','il','ib','ir')]
SV=[V(s) for s in ('sq','sl','sb','sr','nq','nl','nb','nr')]

def lt_cancel():
    t,u,v=b.t,b.u,b.v;root=nd.Ctx();prem=L(A(t,v),A(u,v));ctx=root.push(prem);goal=L(t,u)
    tri=[goal,Q(t,u),L(u,t)];ctx.put(nd.OR(tri),b.ax('O3',ctx.g,t=t,u=u))
    def branch(ch,i):
        if i==0:return ch.get(goal)
        if i==1:
            eq=a.cong2('+',t,u,v,v,ch.get(Q(t,u)),b.refl(ch.g,v),ch.g)
            bp=L(A(u,v),A(u,v));bad=a.replace(ch.g,L(a.E,A(u,v)),A(t,v),A(u,v),eq,ch.get(prem))
            return a.contradiction(ch.g,bp,goal,bad,b.ax('O1',ch.g,t=A(u,v)))
        rev=L(A(u,v),A(t,v));ch.put(rev,b.mp(ch.g,L(u,t),rev,b.ax('O5',ch.g,t=u,u=t,v=v),ch.get(L(u,t))))
        both=b.And(rev,prem);ch.both(rev,prem);bp=L(A(u,v),A(u,v))
        bad=b.mp(ch.g,both,bp,b.ax('O2',ch.g,t=A(u,v),u=A(t,v),v=A(u,v)),ch.get(both))
        return a.contradiction(ch.g,bp,goal,bad,b.ax('O1',ch.g,t=A(u,v)))
    nd.cases(ctx,tri,goal,branch);m.finish('skelet17-ladder-bouncer-lt-add-cancel',root,prem,goal,ctx)
lt_cancel()

def lt_succ(t):return a.boundless_lt(N,t,A(t,O),Z,a.equal(A(t,O),A(A(t,Z),O)))

def beta(index,value,j):
    quo=V('bu');mod=A(O,M(A(index,O),T('C'+str(j))))
    body=b.And(Q(T('B'+str(j)),A(M(quo,mod),value)),L(value,mod))
    return nd.BEX(quo,H,body)
def AT(i,c):return nd.AND([beta(A(offset,i),v,j) for j,v in enumerate(c)])
def TOTAL():return nd.BALL(V('ti'),A(n,O),nd.bexs(TV,H,AT(V('ti'),TV)))
def INITIAL():return nd.balls(AV,H,b.Imp(AT(Z,AV),m.INV(AV)))
def STEPS():
    s=V('si');return nd.BALL(s,n,nd.balls(SV,H,b.Imp(b.And(AT(s,SV[:4]),AT(A(s,O),SV[4:])),m.STEP(SV[:4],SV[4:]))))
def PHI(i):return b.Imp(L(i,A(n,O)),nd.balls(IP,H,b.Imp(AT(i,IP),m.INV(IP))))

def bforall(ctx,vs,bound,body,prove):
    if not vs:return ctx.put(body,prove(ctx))
    var=vs[0];child=ctx.push(L(var,bound));inner=nd.balls(vs[1:],bound,body)
    bforall(child,vs[1:],bound,body,prove);ctx.intro(L(var,bound),inner,child)
    return ctx.all_intro(var,b.Imp(L(var,bound),inner))

def bex_elim(ctx,vs,bound,body,freshs,goal,prove):
    if not vs:return ctx.put(goal,prove(ctx))
    var,fresh=vs[0],freshs[0];rest=nd.bexs(vs[1:],bound,body);fullbody=b.And(L(var,bound),rest)
    actual,_=b.subst(fullbody,var,fresh,True);child=ctx.push(actual);nd.unpack(child,list(actual[1:]))
    newbody,_=b.subst(body,var,fresh,True)
    bex_elim(child,vs[1:],bound,newbody,freshs[1:],goal,prove)
    return ctx.ex_elim(var,fullbody,fresh,goal,child)

def rename_block(ctx,sourcevars,targetvars,bodyfn):
    source=nd.balls(sourcevars,H,bodyfn(sourcevars));target=nd.balls(targetvars,H,bodyfn(targetvars))
    # Prove alpha-renaming with a small assumption context. Metamath's
    # distinct-variable condition is syntactic, including bound occurrences.
    root=nd.Ctx();child=root.push(source)
    def prove(cc):return nd.inst_balls(cc,sourcevars,H,bodyfn(sourcevars),targetvars)[1]
    bforall(child,targetvars,H,bodyfn(targetvars),prove);root.intro(source,target,child)
    ctx.theorem(b.Imp(source,target),root.get(b.Imp(source,target)))
    return ctx.mp(source,target)

def history_proof():
    fields=[TOTAL(),INITIAL(),STEPS()];prem=nd.AND(fields)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fields)
    ph=PHI(IV);base,s0=b.subst(ph,IV,Z,True);step,s1=b.subst(ph,IV,A(IV,O),True)
    # Base: the input hypothesis specifies the scan's initial product.
    baseguard=L(Z,A(n,O));bc=ctx.push(baseguard)
    def base_body(vs):return b.Imp(AT(Z,vs),m.INV(vs))
    rename_block(bc,AV,IP,base_body)
    ctx.intro(baseguard,nd.balls(IP,H,base_body(IP)),bc)
    # Successor: get the earlier row from totality; invoke the checked Step lemma.
    sc=ctx.push(ph);guard=L(A(IV,O),A(n,O));gc=sc.push(guard)
    m.use(gc,'skelet17-ladder-bouncer-lt-add-cancel',{'t':IV,'u':n,'v':O})
    gc.theorem(L(n,A(n,O)),lt_succ(n));gc.both(L(IV,n),L(n,A(n,O)))
    gc.put(L(IV,A(n,O)),b.mp(gc.g,b.And(L(IV,n),L(n,A(n,O))),L(IV,A(n,O)),b.ax('O2',gc.g,t=IV,u=n,v=A(n,O)),gc.get(b.And(L(IV,n),L(n,A(n,O))))))
    def successor_body(vs):return b.Imp(AT(A(IV,O),vs),m.INV(vs))
    def prove_successor(cc):
        atnext=AT(A(IV,O),NF);goal=m.INV(NF);ac=cc.push(atnext)
        tb=TOTAL()[2];_,tp=ac.all_elim(V('ti'),tb,IV)
        ac.mp(L(IV,A(n,O)),nd.bexs(TV,H,AT(IV,TV)),tp)
        def current(pc):
            acur=AT(IV,CF);icur=m.INV(CF)
            pc.mp(L(IV,A(n,O)),nd.balls(IP,H,b.Imp(AT(IV,IP),m.INV(IP))))
            _,pp=nd.inst_balls(pc,IP,H,b.Imp(AT(IV,IP),m.INV(IP)),CF);pc.mp(acur,icur,pp)
            sb=STEPS()[2];_,sp=pc.all_elim(V('si'),sb,IV)
            si,_=b.subst(sb[2],V('si'),IV,True);pc.mp(L(IV,n),si,sp)
            body=b.Imp(b.And(AT(IV,SV[:4]),AT(A(IV,O),SV[4:])),m.STEP(SV[:4],SV[4:]))
            _,pp=nd.inst_balls(pc,SV,H,body,CF+NF)
            pc.both(acur,atnext);res=m.STEP(CF,NF);pc.mp(b.And(acur,atnext),res,pp)
            nd.conj(pc,[icur,m.STEP(CF,NF)])
            return m.use(pc,'skelet17-ladder-bouncer-local',{**{t[1]:v for t,v in zip(m.CF,CF)},**{t[1]:v for t,v in zip(m.NF,NF)}})
        bex_elim(ac,TV,H,AT(IV,TV),CF,goal,current)
        cc.intro(atnext,goal,ac);return cc.get(b.Imp(atnext,goal))
    bforall(gc,NF,H,successor_body(NF),prove_successor)
    rename_block(gc,NF,IP,successor_body)
    sc.intro(guard,nd.balls(IP,H,successor_body(IP)),gc)
    ctx.intro(ph,step,sc);ctx.all_intro(IV,b.Imp(ph,step))
    indante=b.And(base,b.All(IV,b.Imp(ph,step)));ind=b.Imp(indante,b.All(IV,ph))
    ctx.put(ind,b.apply('ax-ind-bounded',{'ga':ctx.g,'x':IV,'ph':ph,'ps':base,'ch':step},[nd.classify(ph),s0,s1]))
    ctx.both(base,b.All(IV,b.Imp(ph,step)));ctx.mp(indante,b.All(IV,ph))
    # Output for every index, hence including a last row inside an unfinished scan.
    m.finish('skelet17-ladder-bouncer-history',root,prem,b.All(IV,ph),ctx,
             'Ordinary cycler supplied-history propagation. One bounded induction; no extra scan guard.')
history_proof()

