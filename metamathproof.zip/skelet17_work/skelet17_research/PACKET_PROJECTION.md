# Packed records and original parser emissions

This checkpoint's `packet_projection_checked.mm` extends the global base-32
record constructor. It connects those same records to the original partial
eight-control parser and its twelve emission rules. It does not prove the
Gray-counter interpretation, output compression, or Skelet #17 nonhalting.

## The issue resolved

The earlier global-record theorem produced one integer R, but its local
checks used a totalized 64-row recorder. A formal proof still had to exclude
the artificial transitions and identify its payload with the original
parser emissions. Agreement on standard simulation examples was insufficient.

The auxiliary record is

    c + 8 f + 16 v,   c<8, f<2, v<2.

Here c is the original parser control, f says whether a digit was emitted,
and v is that digit (zero when no digit was emitted). A control is
4*pending + 2*runParity + cumulativeXor. A previous emission payload is
ignored when interpreting the next step's old control.

The original control transition table, before partiality is imposed, is:

| Old control | Input 0 | Input 1 |
|---|---|---|
| 0 | invalid | 4 |
| 1 | invalid | 5 |
| 2 | invalid | 6 |
| 3 | invalid | 7 |
| 4 | 2 | 4 |
| 5 | 3 | 5 |
| 6 | 0 | 5 |
| 7 | 1 | 4 |

On input 1 from an old control 4 through 7, emit the low bit of the new
control. On every other valid transition emit nothing. This is exactly the
12-row relation used in the preceding local-emission development.

## First theorem: eliminate the artificial transitions

`LowerWord(x)` is the same bounded no-adjacent-00 condition used earlier.
For any binary place p for which 2p is also significant, it asserts that
the bit at p or the bit at 2p is 1. This is a formula about quotient and
remainder equations; no strings or indexed exponentials are added.

The proof treats a current input bit in two regions. At the leading place
it is 1. Elsewhere, LowerWord says that either it is 1, or its immediate
predecessor in the left-to-right reading is 1. Input 1 always leaves one of the six records 4, 5, 6, 7, 12, 29;
each has pending=1 in its low control. This stronger finite range fact
avoids enumerating other pending records that the table never produces. Shared-field uniqueness links that predecessor's
new record to the current step's old record. Thus input 0 can occur only
when its old low control is at least 4. The artificial four source cases,
repeated for the four possible old payloads, cannot occur.

The checked interface is

    LowerWord(x) and PacketRun(x,R) -> PartialPacketRun(x,R).

PartialPacketRun has the same fields and quantifier bounds, but its finite
table contains only the 48 rows whose old low control is at least 4 or
whose input bit is 1. This argument introduces no induction instance.
Its existing arithmetic dependency closure uses bounded division once.

## Second theorem: project the surviving rows

Write Field(z,p,B,w) for the existing bounded quotient/remainder predicate.
For each of the 48 surviving joint-recorder rows, the proof supplies
controls a,c<8 and bits f,v<2 satisfying

    Field(oldRecord,1,8,a),
    Field(newRecord,1,8,c),
    newRecord = (c + 8*f) + 16*v,
    OriginalEmit(a,inputBit,c,f,v).

OriginalEmit is the explicit disjunction of the twelve rules described
above. In particular, f and v must encode the actual next record; they
are not independent annotations chosen without relation to R. The proof
uses finite disjunction elimination, equality substitution, bounded
existential introduction, and previously proved quotient arithmetic.
There is no induction in the dependency closure of this local theorem.

The interface is `skelet17-packet-original-emission-projection`.
Lifting it under the same bounded input-place quantifier gives
`skelet17-packet-original-emission-run`.

## The resulting bounded global existence theorem

Define ProjectedRun exactly as PacketRun, retaining its bounded old record,
input bit, and new record and their three Field equations, but replacing
the table relation by the bounded projection formula immediately above.

`skelet17-packet-original-emission-certificate` states:

    LowerWord(x) and 0<x ->
      exists P<x+1 exists R<32*(x+1)^5
        (Pow2(P) and x<2P and R<32*P^5 and ProjectedRun(x,R)).

This is one global integer R, quantified before every input place. Its
five-bit records contain the original controls and sparse emission data.
It is not a construction of separate packed flag/value integers, nor a
compacted output with the non-emitting positions removed.

Every fifth power is a fixed multiplication term. The same original 93
trusted declarations are retained. The theorem reuses the two existing
bounded-induction constructions (including division); no new induction
construction is introduced by this bridge. The machine's configurations,
transition table, computation-history encoding, and halting formula are
unchanged.

## Verification and reproduction

The output Metamath database, rather than the proof generator, is what the
independent kernel checks. The standalone database parsed without errors
and all 21,109 proved statements passed the official verifier. The 93
trusted declarations are audited separately below. The audit compares all trusted declarations,
checks the clean verification log, and traverses actual proof dependencies
to count bounded-induction application nodes.

From the research directory:

    python3 build_packet_projection.py --resume
    python3 prune.py packet_projection_raw.mm packet_projection_checked.mm
    metamath 'read "packet_projection_checked.mm"' 'verify proof *' exit
    python3 audit_packet_projection.py

Capture the verifier output in `packet_projection_verification.log` before
running the audit. The finite-case helper derives the propositional theorem

    ((A -> G) and (B -> G)) -> ((A or B) -> G).

It proves each branch in the original context plus its own case assumption,
then combines the implications. This avoids copying unused disjunction-tail
assumptions into every arithmetic branch. Constant numerical inequalities
are also proved once in the empty context and reused. These optimizations
change proof presentation, not the logic or arithmetic axioms.

The resume option retains the complete existing checked
packet database, including all its proofs, as the output prefix. It only
reconstructs the generator's untrusted symbol table; it adds no axioms.
Omit --resume to regenerate the original constructor as well.

EOF had a separate local proof in the earlier base-8 development. This
checkpoint does not yet assemble that endpoint policy with the new global
record theorem. Emission counts, ranks, compacted output existence, the
Gray-counter interpretation, and the global invariant excluding B111
remain separate obligations. Whole-machine nonhalting remains unproved.
