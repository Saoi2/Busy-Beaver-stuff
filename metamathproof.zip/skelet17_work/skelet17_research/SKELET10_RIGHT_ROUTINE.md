# Skelet #10: the complete right-counter routine in I-Delta-0

The project now proves a correctness and termination contract for the
whole right-counter routine of `1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB`.
Its B/A/C carry scan and D1 marker return are handled by one bounded
rank invariant through ordinary quotient-and-remainder computation
histories. Intermediate phases, carry witnesses and ranks are constructed
inside the proof. They are not supplied as annotations on a computation.

All proofs remain in `idelta0_machines.mm` over the original 93 trusted
declarations. This completes the right-counter routine, but not the
left-counter routine, the complete two-counter cycle, or whole-machine
nonhalting.

## Input, output and the unchanged tape encoding

A configuration is c=(q,L,b,R). The scanned bit is b. The nearest bit in
each tape half is the low binary bit. Define two reading abbreviations:

    WholeRight(c) = 2R+b,       WholeLeft(c) = 2L+b.

Each includes the scanned cell, whereas L and R alone exclude it.
Right moves still satisfy L'=2L+write and R=2R'+b'. Left moves still
satisfy R'=2R+write and L=2L'+b'. The ordinary Step formula has all ten
instruction alternatives, including E0 completed by 1RZ.

Fix an input word w and left content ell. The routine starts at B with

    L=2ell+1,   WholeRight(c)=w,   b<2,   Sparse(w).

Thus L contains one nearest-cell 1 marker, followed by the older content
ell. In particular ell is not the initial L and is not the initial
WholeLeft. Sparse means that a binary word has no adjacent 1s; its
existing bounded arithmetic definition is unchanged.

The correct output is a D configuration with

    WholeLeft(c)=ell,   J(w,R),   Sparse(R).

The head has moved onto the older left content. Its whole left word is
ell, and the new right half contains the counter output. These are
conditions on the same ordinary configurations used throughout the project.

## The bounded carry relation

J is a reading abbreviation, fully expanded in the proofs:

    J(w,v) :=
      exists p<3w+2, exists s<w+1, exists a<w+1,
        Pow2(p) and p=3s+1 and
        w=p*(2a)+s and v=p*(4a+1).

The witnesses p and s describe the low 10 blocks consumed by the carry;
a is the remaining tail at its first even word. A word is read nearest
cell first when describing prefixes. The numerical recurrences motivating
this graph are

    J(2a,4a+1),
    J(a,v) -> J(4a+1,4v).

Their separate general formal proofs are not needed or claimed here.
Instead, the machine proof constructs the graph witnesses at its C1 exit.
No totality or uniqueness theorem for J is assumed.

Examples in ordinary natural numbers are:

| Input w | Output v | Consumed scale p | Remainder s | Tail a |
|---:|---:|---:|---:|---:|
| 0 | 1 | 1 | 0 | 0 |
| 1 | 4 | 4 | 1 | 0 |
| 2 | 5 | 1 | 0 | 1 |
| 4 | 9 | 1 | 0 | 2 |
| 5 | 16 | 16 | 5 | 0 |

For example 5=16*0+5, 16=3*5+1, and the output is 16*(0+1)=16.
J is the right-counter carry operation, not ordinary numerical successor
and not the least larger Sparse number. The proof therefore avoids a
least-Sparse-successor theorem and any Fibonacci function.

All graph witnesses are bounded by terms in the input w. Pow2 is the
existing bounded divisor predicate; no exponential function or new
function symbol is introduced.

## Four phases and one decreasing rank

Put K=16*(w+1). The rank rho is an auxiliary number used in the proof;
it is not a machine state, tape coordinate, or added history component.
The bounded relation Rank(c,rho) is a disjunction of four phases.
For the first three, p<3w+2 and s<w+1 are bounded existential witnesses
with Pow2(p) and p=3s+1.

| Phase | Tape conditions | Rank rho |
|---|---|---|
| B | L+1=2p*(ell+1); w=p*(2R+b)+s; b<2; Sparse(2R+b) | K+4*(2R+b)+2 |
| A | b=0; L+1=4p*(ell+1); w=4pR+4s+1; Sparse(R) | K+16R+5 |
| C | b=1; L+1=p*(ell+1); w=pR+s; Even(R); Sparse(R) | K+4R+1 |
| D | Some Pow2 h<3w+2 has WholeLeft+1=h*(ell+1); J(w,hR); b<2; Sparse(R) | 4h |

In the D phase h is the remaining return marker. It need not equal the
consumed-prefix scale p inside the independent existential graph J.
At the C-to-D transition h=p; subsequent D1 steps halve h, while the
carry graph continues to describe the same final output hR.

The entry witnesses are p=1 and s=0. Its rank is

    R0 = 16*(w+1)+4w+2 = 20w+18.

The proof checks the full ordinary Step disjunction in each phase:

* B1 reaches A0. Sparse(2R+1) forces R to be even, identifying the new
  scanned bit as 0. The rank drops by one.
* A0 reaches B. It updates the carry witnesses to p'=4p, s'=4s+1,
  and removes one low 10 block from the remaining input. The rank drops
  by 12R+3, where R is the old A-row right half.
* B0 reaches C1. The equation L+1=2p*(ell+1) forces the popped bit to be 1.
  The new right half is even and Sparse. The rank drops by one.
* C1 reaches D. Writing the even right half as 2a supplies the witnesses
  for J(w,pR_new). The existing Sparse append theorem proves that R_new
  is Sparse. The chosen offset K makes the transition strictly lower rank.
* Before the correct endpoint, a D row uses the previously verified D1
  marker-step theorem. It produces a smaller marker h, preserves the
  carry output, and strictly lowers 4h. Its actual right word stays Sparse
  because D1 prefixes a zero.

An important arithmetic helper derives the bounds p<3w+2 and s<w+1
from p=3s+1 and w=p*r+s. This justifies the updated existential witnesses
at each carry iteration. Every quantified phase witness stays bounded.

## An example of the entire routine

Take ell=2 and input w=5. The correct right output is 16. The table lists
the actual ordinary run and its constructed rank; it is not a macro run.

| Step | State | L | b | R | Rank |
|---:|---|---:|---:|---:|---:|
| 0 | B | 5 | 1 | 2 | 118 |
| 1 | A | 11 | 0 | 1 | 117 |
| 2 | B | 23 | 1 | 0 | 102 |
| 3 | A | 47 | 0 | 0 | 101 |
| 4 | B | 95 | 0 | 0 | 98 |
| 5 | C | 47 | 1 | 0 | 97 |
| 6 | D | 23 | 1 | 1 | 64 |
| 7 | D | 11 | 1 | 2 | 32 |
| 8 | D | 5 | 1 | 4 | 16 |
| 9 | D | 2 | 1 | 8 | 8 |
| 10 | D | 1 | 0 | 16 | 4 |

At the final row WholeLeft=2*1+0=ell and J(5,16) holds. The routine
contract ends there. The actual machine continues from that D row.
The coarse bound is 118 ordinary steps; this example needs only ten.
A sharp running-time formula is unnecessary for the bounded proof.

## The formal history theorem

Use the original four-coordinate beta format, with names prefixed
`rightRun` to keep these window parameters distinct from earlier windows:

    beta_j(k,x) := exists u<H,
      Bj=u*(1+(k+1)*Cj)+x and x<1+(k+1)*Cj.

Here n is the final row index, H bounds coordinates and beta quotients,
and Bj,Cj are arithmetic history-code parameters, not the machine states
B and C. At(i,c) uses the four beta predicates at offset+i.

TOTAL supplies a row below H at each i<n+1. STEPS supplies ordinary Step
between all adjacent supplied rows. INITIAL requires the stated B entry
of each supplied initial row. The main exit theorem assumes these three
conditions and R0<n+1. It concludes

    exists j<n+1, exists c<H,
      At(j,c) and CorrectOutput(c),

where CorrectOutput is precisely the D endpoint defined above. The tuple
quantifier means four bounded quantifiers. The separate halting-barrier
theorem obtains the same conclusion from an arbitrary supplied history
whose final row is halting, with no running-time lower-bound assumption.

Neither theorem assumes intermediate phase or rank annotations. Neither
asserts general totality of beta-history coding. These are statements
about every supplied ordinary history in the project's original encoding.

## Why bounded induction suffices

Assume temporarily that all supplied rows avoid CorrectOutput. Induct on

    Phi(i) := i<n+1 -> forall c<H,
      At(i,c) -> exists rho<R0+1,
        Rank(c,rho) and i+rho<R0+1.

This is Delta-0. All phase, graph, Sparse, Pow2, history and rank
quantifiers have explicit bounds. The base derives Rank from the B entry.
The step obtains the preceding row from TOTAL and its ordinary transition
from STEPS. The local theorem constructs a smaller positive rank, which
preserves i+rho<=R0 after advancing the index.

At the last row, positivity gives n<R0. This contradicts n>=R0 in the
exit theorem. In the halting-barrier theorem, the last ranked phase instead
contradicts its halting state. Classical first-order logic then gives the
bounded existential correct output. The universally closed statements
are Pi-1, since every output witness is bounded.

## Public statements and verification

Every label starts `skelet17-ladder-skelet10-`.

| Label suffix | Content | Induction constructions in its dependency closure |
|---|---|---:|
| `right-counter-entry` | Derive the bounded phase and initial rank from an ordinary B entry. | 0 |
| `right-counter-step` | Every unfinished ordinary step preserves the phase with smaller rank. | 1 |
| `right-window-invariant` | Construct bounded phases, graph witnesses and the rank clock in a target-avoiding history. | 2 |
| `right-window-bound` | A target-avoiding history has n<20w+18. | 2 |
| `right-window-exit` | A sufficiently long supplied history visits a correct D output. | 2 |
| `right-window-halting-barrier` | Any supplied history ending at halt has visited a correct D output. | 2 |

The two dependencies of a history theorem are the earlier bounded division
construction and one new bounded history induction. These are counts for
the actual proofs, not minimal-theory lower bounds. No induction proving
Fibonacci totality, a general carry function, or arbitrary sequence
existence is used. The D1 local theorem is reused directly.

The rank arithmetic keeps common offsets and coefficients factored.
This avoids thousands of unnecessary expansions of unary numerals and
repeated common summands. The final Metamath verifier checks the expanded
proofs, and the preservation audit checks all earlier public interfaces
and the unchanged 93 trusted declarations.

`check_skelet10_right.py` independently reconstructs all six formulas,
checks their bounded syntax and absence of supplied intermediate
annotations in the exit/barrier statements, and tests 712 complete
standard routines comprising 3,184 ordinary steps. Simulation supplements
the formal verification. The generators are `ladder_skelet10_right.py`
and `ladder_skelet10_right_history.py`; the full rebuild includes both.

## Remaining work

The whole right-counter contract is now proved. The next major task is
the complete left-counter carry routine and its relation to the bounded
left-word transform T. The current proofs do not yet synchronize the two
counters through a full global cycle, exclude every blank-start halting
history of Skelet #10, prove J total or unique, or establish a Busy Beaver
value. Earlier complete nonhalting examples remain unchanged.
