"""Finite left-counter contracts for Skelet #10, in ordinary Step.

Each public theorem gives an explicit path and the unique endpoint of any
ordinary path of the same fixed length. No recursive counter theorem or
whole-machine nonhalting result is asserted here.
"""
def add_skelet10_left(m,api,stage="all",proofs=True):
 nd,b,a=m.nd,m.b,m.a
 A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;two=a.num(2)
 step,parts=api['step'],api['parts'];nf=api['next']
 def push(x,d):return A(M(two,x),d)
 def equal(c,d):return nd.AND([Q(v,w) for v,w in zip(c,d)])
 def instruction(j,t,u,v):
  q,read=divmod(j,2)
  # The same independently documented standard table, with 1RZ at E0.
  table=[(1,1,1),(0,1,0),(2,0,0),(0,1,1),(4,1,1),
         (3,0,1),(2,0,1),(3,0,0),(5,1,1),(1,1,0)]
  nq,right,w=table[j]
  c=[a.num(q),u,a.num(read),push(t,v)] if right else [a.num(q),push(t,v),a.num(read),u]
  n=[a.num(nq),push(u,a.num(w)),v,t] if right else [a.num(nq),t,v,push(u,a.num(w))]
  return c,n,right
 def contracts():
  t,u,v=b.t,b.u,b.v
  for j in (1,3,4,5,6,9):
   if "z10-left-instruction-contract-"+str(j) in m.theorems:continue
   c,n,right=instruction(j,t,u,v);prem=L(v,two)
   root=nd.Ctx();ctx=root.push(prem)
   pf=parts(c,n,j)
   for eq in pf[:-1]:m.eq(ctx,*eq[1:])
   m.invoke(ctx,'skelet17-binary-digit-cases',{'t':v})
   nd.cases(ctx,[Q(v,Z),Q(v,O)],pf[-1],lambda dc,k:nd.disj(dc,list(pf[-1][1:]),k))
   nd.conj(ctx,pf);nd.disj(ctx,[nd.AND(parts(c,n,k)) for k in range(10)],j)
   raw=step(c,nf);goal=equal(nf,n);sc=ctx.push(raw)
   sc.put(Q(c[0],c[0]),b.refl(sc.g,c[0]));sc.put(Q(c[2],c[2]),b.refl(sc.g,c[2]))
   def branch(dc,k):
    fields=parts(c,nf,k);nd.unpack(dc,fields)
    if k//2!=j//2:return api['neq'](dc,c[0],j//2,k//2,goal)
    if k%2!=j%2:return api['neq'](dc,c[2],j%2,k%2,goal)
    quotient=nf[3] if right else nf[1]
    m.eq(dc,push(quotient,nf[2]),push(t,v),[m.flip(dc,fields[4])])
    api['bitbound'](dc,fields)
    m.quotient_unique(dc,two,quotient,nf[2],t,v)
    pushed=nf[1] if right else nf[3];want=n[1] if right else n[3]
    m.eq(dc,pushed,want,[fields[3]])
    return nd.conj(dc,[Q(x,y) for x,y in zip(nf,n)])
   nd.cases(sc,[nd.AND(parts(c,nf,k)) for k in range(10)],goal,branch)
   ctx.intro(raw,goal,sc)
   final=b.And(step(c,n),b.Imp(raw,goal));ctx.both(*final[1:])
   m.finish('z10-left-instruction-contract-'+str(j),root,prem,final,ctx,
    'Derived ordinary instruction instance plus unique successor, with an arbitrary bounded binary popped digit. No induction.')
 if proofs:contracts()
 def contract(ctx,j,t,u,v,actual):
  mapp={'t':t,'u':u,'v':v,**{n[1]:x for n,x in zip(nf,actual)}}
  label='z10-left-instruction-contract-'+str(j)
  m.invoke(ctx,label,mapp);formula=m.sub(m.theorems[label],mapp)[2]
  nd.unpack(ctx,list(formula[1:]));return formula
 def transport(ctx,predicate,old,new):
  """Replace only the four coordinate slots, not constants in Step."""
  row=list(old)
  for i,(x,y) in enumerate(zip(old,new)):
   templ=list(row);templ[i]=a.E
   m.rewrite(ctx,predicate(templ),x,y,ctx.get(Q(x,y)));row[i]=y
  return ctx.get(predicate(new))
 if stage=='contracts':return {'contract':contract,'instruction':instruction,'transport':transport}
 def macro(name,rows,updates,prem,scan_end=False):
  # Actual run rows are independent term parameters, never annotations
  # incorporated in the machine's Step or beta-history encoding.
  actual=[[m.declare('z10'+name+'Row'+str(i)+c,'term') for c in ('Q','L','Bit','R')]
          for i in range(1,len(rows))]
  actual=[rows[0],*actual]
  canonical=[step(c,d) for c,d in zip(rows,rows[1:])]
  given=[step(c,d) for c,d in zip(actual,actual[1:])]
  root=nd.Ctx();ctx=root.push(prem)
  for i,(j,t,u,v) in enumerate(updates):
   if v in (Z,O):m.bound(ctx,v,two,O if v==Z else Z)
   formula=contract(ctx,j,t,u,v,actual[i+1])
   c,n,_=instruction(j,t,u,v)
   assert c==rows[i] and n==rows[i+1],(name,i)
   assert formula[1]==canonical[i]
  path=nd.AND(canonical);nd.conj(ctx,canonical)
  if scan_end:
   q,l,bit,r=rows[-1]
   ctx.put(Q(q,Z),b.refl(ctx.g,Z));ctx.put(Q(bit,Z),b.refl(ctx.g,Z))
   nd.conj(ctx,api['regions'](rows[-1])[0]);nd.disj(ctx,[nd.AND(f) for f in api['regions'](rows[-1])],0)
  run=nd.AND(given);rc=ctx.push(run);nd.unpack(rc,given)
  for i,(j,t,u,v) in enumerate(updates):
   if i:
    transport(rc,lambda row:step(row,actual[i+1]),actual[i],rows[i])
   c,n,_=instruction(j,t,u,v)
   rc.mp(step(c,actual[i+1]),equal(actual[i+1],n))
   nd.unpack(rc,[Q(x,y) for x,y in zip(actual[i+1],n)])
  endpoint=equal(actual[-1],rows[-1])
  if scan_end:
   # Equality symmetry transports the proved canonical Scan to the actual
   # final row, through the same coordinate-only templates.
   for x,y in zip(actual[-1],rows[-1]):m.flip(rc,Q(x,y))
   transport(rc,api['scan'],rows[-1],actual[-1])
   endpoint=b.And(endpoint,api['scan'](actual[-1]));rc.both(*endpoint[1:])
  ctx.intro(run,endpoint,rc)
  goal=b.And(path,b.Imp(run,endpoint));ctx.both(*goal[1:])
  m.finish('skelet17-ladder-skelet10-'+name,root,prem,goal,ctx,
   'Explicit finite ordinary trace and unique endpoint for any ordinary run of the same length. No new axiom, history-code totality, recursive macro assumption, or induction.')
  return {'rows':rows,'actual':actual,'steps':len(rows)-1,'instructions':[x[0] for x in updates],'scan_end':scan_end}
 x,y,d=b.t,b.u,b.v
 D,C,E,B,AA=map(a.num,(3,2,4,1,0))
 # Left exit: 00 <D 11r -> updated-left A> r, in five steps.
 r=push(push(push(y,d),O),O);l0=push(x,Z);l1=push(x,O)
 l2=push(l1,Z);l3=push(l2,O);l4=push(l3,Z)
 rows=[[D,l0,Z,r],[C,x,Z,push(r,O)],[E,l1,O,r],
       [B,l2,O,push(push(y,d),O)],[AA,l3,O,push(y,d)],[AA,l4,d,y]]
 updates=[(6,x,r,Z),(4,r,x,O),(9,push(push(y,d),O),l1,O),
          (3,push(y,d),l2,O),(1,y,l3,d)]
 output={'left-exit-five-step':macro('left-exit-five-step',rows,updates,L(d,two))}
 # Four left-moving steps strip one encoded 1010 block and push four 1s.
 p0=push(x,d);p1=push(p0,O);p2=push(p1,Z);p3=push(p2,O)
 r1=push(y,O);r2=push(r1,O);r3=push(r2,O);r4=push(r3,O)
 rows=[[D,p3,Z,y],[C,p2,O,r1],[D,p1,Z,r2],[C,p0,O,r3],[D,x,d,r4]]
 updates=[(6,p2,y,O),(5,p1,r1,Z),(6,p0,r2,O),(5,x,r3,d)]
 output['left-carry-four-step']=macro('left-carry-four-step',rows,updates,L(d,two))
 # Four A1 moves clear four pending 1s on the return.
 r0=push(push(push(push(y,d),O),O),O)
 rr=[r0,push(push(push(y,d),O),O),push(push(y,d),O),push(y,d),y]
 ll=[x]
 for i in range(4):ll.append(push(ll[-1],Z))
 rows=[[AA,ll[i],O if i<4 else d,rr[i]] for i in range(5)]
 updates=[(1,rr[i+1],ll[i],O if i<3 else d) for i in range(4)]
 output['return-clear-four-step']=macro('return-clear-four-step',rows,updates,L(d,two))
 # The synchronized 00/10 boundary case enters the earlier right-scan
 # invariant after four ordinary moves, despite its intermediate even L.
 r=push(push(y,Z),O)
 rows=[[D,l0,Z,r],[C,x,Z,push(r,O)],[E,l1,O,r],
       [B,l2,O,push(y,Z)],[AA,l3,Z,y]]
 updates=[(6,x,r,Z),(4,r,x,O),(9,push(y,Z),l1,O),(3,y,l2,Z)]
 output['left-zero-return-to-scan']=macro('left-zero-return-to-scan',rows,updates,api['sparse'](y),True)
 return output
