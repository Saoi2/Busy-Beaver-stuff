"""Audit emission and terminal-decision proofs against the original core."""
from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse,rewrite
orr,old,_=parse((P/'scan_checked.mm').read_text())
rr,rules,_=parse((P/'emissions_checked.mm').read_text())
def trusted(rs,ds):return {r['label']:(r['expr'],[ds[h]['expr'] for h in r['hyps']],sorted(r['dv'])) for r in rs if r['kind']=='a'}
assert trusted(orr,old)==trusted(rr,rules) and len(trusted(rr,rules))==93
log=(P/'emission_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
deps={r['label']:rewrite(r,{})[1] for r in rr if r['kind']=='p'}
def closure(root):
    seen=set();todo=[root]
    while todo:
        k=todo.pop()
        if k in seen:continue
        seen.add(k);todo.extend(deps.get(k,()))
    return seen
metrics={}
for r in rr:
    k=r.get('label','')
    if r['kind']!='p' or not k.startswith('skelet17-emission-'):continue
    ids=sorted(v for v in closure(k) if 'ax-ind-bounded' in deps.get(v,set()))
    metrics[k]={'bounded_induction_application_nodes':ids,'induction_application_count':len(ids)}
for k,v in metrics.items():assert v['induction_application_count']==(2 if k=='skelet17-emission-local-and-eof-certificate' else 0)
files=['build_emissions.py','emissions_checked.mm','emission_theorems.json','emission_verification.log','EMISSION_EOF.md','audit_emissions.py','check_emissions.py','emission_checks.json']
out={'local_emission_decisions_total_and_unique':True,'terminal_decision_total_and_unique':True,
    'pointwise_emission_and_terminal_certificate_existence_proved':True,
    'terminal_flag_input_parity_proved':True,'packed_emission_stream_existence_proved':False,
    'emission_count_existence_proved':False,'compressed_Gray_decoder_totality_proved':False,'whole_machine_nonhalting_proved':False,
    'trusted_declarations_unchanged':True,'trusted_count':93,'verifier_log_clean':True,
    'proved_statement_count':sum(r['kind']=='p' for r in rr),'public_interfaces':metrics,
    'files':{s:{'bytes':(P/s).stat().st_size,'sha256':hashlib.sha256((P/s).read_bytes()).hexdigest()} for s in files}}
(P/'emission_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('files','public_interfaces')},indent=2))
