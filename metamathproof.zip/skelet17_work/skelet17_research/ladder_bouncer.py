"""Product-and-residue invariant for 1RB0LC_0LC1RA_---1LA."""
TABLES['bouncer']=[(1,1,1),(2,0,0),(2,0,0),(0,1,1),(5,1,1),(0,0,1)]
def STEP(c,d,kind='bouncer',previous=STEP):return previous(c,d,kind)
exec(compile((p/'bouncer_arithmetic.py').read_text(),'bouncer_arithmetic.py','exec'),globals())
def PROD(c,k):return M(A(c[1],O),A(M(three,c[3]),O if k<2 else two))
STATES=[0,0,1,1,2];BITS=[0,1,0,1,1];RESIDUES=[1,2,1,1,2]
def bounce_fields(c,k):
 fs=[Q(c[0],num(STATES[k])),Q(c[2],num(BITS[k])),m.power2(PROD(c,k)),RES(PROD(c,k),RESIDUES[k])]
 if k==2:fs.append(Q(c[3],Z))
 return fs
def clauses(c):return [nd.AND(bounce_fields(c,k)) for k in range(5)]
def INV(c):return nd.OR(clauses(c))
def unpack_clause(ctx,c,k):nd.unpack(ctx,bounce_fields(c,k));return bounce_fields(c,k)
def bouncer_closure():
 prem=b.And(INV(CF),STEP(CF,NF));goal=INV(NF);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]))
 def region(ec,k):
  unpack_clause(ec,CF,k);old=PROD(CF,k)
  def move(sc,j):
   pf=parts(TABLES['bouncer'],CF,NF,j);nd.unpack(sc,pf)
   if j//2!=STATES[k]:return contradiction(sc,CF[0],STATES[k],j//2,goal)
   if j%2!=BITS[k]:return contradiction(sc,CF[2],BITS[k],j%2,goal)
   factor_pow(sc,A(CF[1],O),A(M(three,CF[3]),O if k<2 else two))
   def bitcase(dc,nb):
    fs=[pf[3],pf[4],Q(NF[2],num(nb))]
    if k==2:fs.append(Q(CF[3],Z))
    if j in (1,2,5) and nb==0:
     odd_zero(dc,A(CF[1],O),NF[1],[pf[4],Q(NF[2],Z)])
     m.eq(dc,CF[1],Z,[pf[4],Q(NF[2],Z),Q(NF[1],Z)])
     fs.extend([Q(CF[1],Z),Q(NF[1],Z)])
     if j==1:return res_bad(dc,old,2,CF[3],1,goal,[Q(CF[1],Z)])
     if j==2:return res_bad(dc,old,1,Z,2,goal,[Q(CF[1],Z),Q(CF[3],Z)])
    if j==0 and nb==0:
     odd_zero(dc,A(M(three,CF[3]),O),M(three,NF[3]),[pf[4],Q(NF[2],Z)])
     m.eq(dc,A(M(three,NF[3]),Z),A(M(three,Z),Z),[Q(M(three,NF[3]),Z)])
     m.bound(dc,Z,three,two);m.quotient_unique(dc,three,NF[3],Z,Z,Z)
     m.eq(dc,CF[3],Z,[pf[4],Q(NF[2],Z),Q(NF[3],Z)])
     fs.extend([Q(CF[3],Z),Q(NF[3],Z)])
    if j==3 and nb==1:
     val=A(M(three,NF[3]),two)
     odd_zero(dc,A(M(three,CF[3]),two),val,[pf[4],Q(NF[2],O)])
     m.bound(dc,Z,val,A(M(three,NF[3]),O));m.rewrite(dc,L(Z,a.E),val,Z)
     dc.put(b.Not(L(Z,Z)),b.ax('O1',dc.g,t=Z));return dc.explode(L(Z,Z),goal)
    target,mode=({(0,0):(2,'quad'),(0,1):(3,'same'),(1,1):(4,'same'),(2,1):(4,'half'),(3,0):(0,'same'),(5,0):(0,'double'),(5,1):(1,'same')})[(j,nb)]
    new=PROD(NF,target)
    relation=Q(old,M(two,new)) if mode=='half' else Q(new,old if mode=='same' else M(two if mode=='double' else four,old))
    m.eq(dc,*relation[1:],fs)
    rc=scale_safe(dc,old,new,RESIDUES[k],mode,relation);assert rc==RESIDUES[target]
    nd.conj(dc,bounce_fields(NF,target));return nd.disj(dc,clauses(NF),target)
   return nd.cases(sc,list(pf[-1][1:]),goal,bitcase)
  return nd.cases(ec,[nd.AND(parts(TABLES['bouncer'],CF,NF,j)) for j in range(6)],goal,move)
 nd.cases(ctx,clauses(CF),goal,region)
 finish('skelet17-ladder-bouncer-local',root,prem,goal,ctx,'A bounded power-of-two product and residue invariant for the original bouncer. Arithmetic dependencies are audited; no new axioms.')
bouncer_closure()
bs=cs.replace('skelet17-ladder-counter-','skelet17-ladder-bouncer-').replace("'ladderCounterOffset'","'ladderBouncerOffset'")
shim=types.SimpleNamespace(nd=nd,b=b,a=a,declare=m.declare,finish=finish,use=use,CF=CF,NF=NF,INV=INV,STEP=STEP)
h={'m':shim};exec(compile(bs,'bouncer_history_generated.py','exec'),h)
(p/'bouncer_history_generated.py').write_text(bs)
bep=(p/'ladder_endpoint.py').read_text().replace('ladderInitial','bouncerInitial').replace('skelet17-ladder-cycler-','skelet17-ladder-bouncer-')
initial='''nd.unpack(ac,[Q(v,Z) for v in fresh])
 eqs=[Q(v,Z) for v in fresh];pv=PROD(fresh,0)
 use(ac,'skelet17-binary-power-one',{},False);m.eq(ac,pv,O,eqs)
 m.rewrite(ac,m.power2(a.E),O,pv,a.sym(pv,O,ac.get(Q(pv,O)),ac.g))
 res_intro(ac,pv,1,Z,eqs)
 nd.conj(ac,bounce_fields(fresh,0));nd.disj(ac,clauses(fresh),0)'''
bep=bep.replace('nd.disj(ac,[cfg(fresh,v) for v in CYCLE],0)',initial)
bep=bep.replace('nd.unpack(ec,[Q(v,num(z)) for v,z in zip(NF,CYCLE[k])])\n return contradiction(ec,NF[0],CYCLE[k][0],5,bad)','unpack_clause(ec,NF,k)\n return contradiction(ec,NF[0],STATES[k],5,bad)')
bep=bep.replace('nd.cases(ctx,[cfg(NF,v) for v in CYCLE],bad,exclude)','nd.cases(ctx,clauses(NF),bad,exclude)')
bep=bep.replace('One bounded induction in its dependency closure.','One new history induction plus existing arithmetic induction dependencies.')
exec(compile(bep,'bouncer_endpoint_generated.py','exec'),globals());(p/'bouncer_endpoint_generated.py').write_text(bep)
