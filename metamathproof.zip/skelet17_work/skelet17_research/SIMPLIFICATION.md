# Proof library size, structure and checking

The active file remains idelta0_machines.mm. It contains all retained
results over the same original 93 trusted declarations.

| Measure | First cleanup | Current checkpoint |
|---|---:|---:|
| Source bytes | 176,637,743 | 1,031,962,351 |
| Proved assertions | 40,271 | 150,764 |
| Named interfaces | 186 | 270 |
| Trusted declarations | 93 | 93 |

The latest assembly adds four public theorems, preserving
all 266 preceding interfaces exactly. The private-node total includes
syntax construction, equality and natural deduction in expanded history
formulas; it is not the number of mathematical decider results.

Earlier cleanup shared schema-equivalent proofs, inlined eligible
single-use private helpers, removed unreachable assertions and packed DV
declarations without changing their pair graph. Its per-pass statistics
are historical. Current size, hash and interface counts are recorded in
simplification_report.json. Recent extensions are appended after checked
dependency extraction; no fresh whole-file proof-DAG cleanup was run.

In the earlier n=4b extension, ordinary-Step source equality transport
was proved once and reused. Together with dependency
pruning, this reduced the candidate dependency file from 24,136 to 22,718
proved assertions. The difference includes pruning effects and earlier
dependencies. The mathematical conclusion is unchanged. The n=8b+2 extension reuses
that same transport and finite-prefix construction; no second transport
theorem or duplicate numerical case is added. Only its dependencies are
retained before merging. The canonical file is appended, preserving all
earlier interfaces; no whole-file minimality claim is made.

## Inspection

Load the canonical file in the official Metamath verifier and use:

    verify proof *
    show statement skelet17-ladder-skelet10-no-blank-halting-history / full
    show proof skelet17-ladder-skelet10-no-blank-halting-history / depth 4

The full-statement command includes hypotheses and mandatory DV conditions.
The deeper natural-deduction proof may be inspected with / lemmon / renumber.

## Audit scope

The current append-only workflow uses a streaming exact-interface refresh
and a streaming actual-dependency audit. They avoid retaining every expanded
proof formula in memory. The former was checked against all full-parser
signatures of the previous file before use on this extension. The latter
decodes used compressed proof indices, including mandatory hypothesis
offsets. The official kernel independently verifies every proof.
Read AUDIT_WORKFLOW.md and streaming_audit_report.json.

A byte-for-byte old prefix preserves every old proof and interface. The
streaming refresh additionally checks all old mandatory hypotheses, DV
pairs and the exact 93-axiom core, and computes the new interface from the
actual canonical file. This append-only workflow rejects a rewritten old
prefix. A later whole-library cleanup requires its corresponding exact
interface and kernel checks, not an unchecked prefix assumption.

All three numerical cases, their general combination, the bounded maximum
argument and the blank-start nonhalting endpoint are now proved. The new
global generation resumes from streamed theorem interfaces and scopes only
new reachable proof nodes. The canonical old byte prefix is preserved.
A full fresh rebuild or whole-file simplification is not claimed.
