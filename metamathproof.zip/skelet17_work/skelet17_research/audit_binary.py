"""Audit the arithmetic extension against the unchanged trusted core."""
from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse,rewrite
old=(P/'scan_checked.mm').read_text();new=(P/'binary_checked.mm').read_text()
orr,orules,_=parse(old);nrr,nrules,_=parse(new)
def trusted(records,rules):
    return {r['label']:{'expression':r['expr'],'hypotheses':[rules[h]['expr'] for h in r['hyps']],
        'disjoint':sorted(r['dv'])} for r in records if r['kind']=='a'}
assert trusted(orr,orules)==trusted(nrr,nrules)
assert len(trusted(nrr,nrules))==93
log=(P/'binary_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
deps={r['label']:rewrite(r,{})[1] for r in nrr if r['kind']=='p'}
def closure(root):
    seen=set();todo=[root]
    while todo:
        k=todo.pop()
        if k in seen:continue
        seen.add(k);todo.extend(deps.get(k,()))
    return seen
roots=[r['label'] for r in nrr if r['kind']=='p' and r['label'].startswith('skelet17-')]
metrics={}
for root in roots:
    reach=closure(root);instances=sorted(k for k in reach if 'ax-ind-bounded' in deps.get(k,set()))
    metrics[root]={'bounded_induction_application_nodes':instances,'induction_application_count':len(instances)}
assert metrics['skelet17-bounded-division-exists']['induction_application_count']==1
assert metrics['skelet17-bounded-field-exists']['induction_application_count']==1
assert metrics['skelet17-bounded-field-unique']['induction_application_count']==0
assert metrics['skelet17-bounded-leading-power']['induction_application_count']==2
for name in ['skelet17-binary-bit-exclusive','skelet17-binary-power-divisor','skelet17-binary-power-halving','skelet17-binary-field-shift']:
    assert metrics[name]['induction_application_count']==0
files=['binary_checked.mm','binary_verification.log','binary_theorems.json','build_binary.py','audit_binary.py','BINARY_ARITHMETIC.md']
out={'whole_machine_nonhalting_proved':False,'decoder_totality_proved':False,
    'trusted_declarations_unchanged':True,'trusted_count':93,'verifier_log_clean':True,
    'proved_statement_count':sum(r['kind']=='p' for r in nrr),'public_interfaces':metrics,
    'files':{s:{'bytes':(P/s).stat().st_size,'sha256':hashlib.sha256((P/s).read_bytes()).hexdigest()} for s in files}}
(P/'binary_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('files','public_interfaces')},indent=2))
