"""Independent formula checks for synchronization arithmetic."""
from pathlib import Path
import json
from check_skelet10_right import carry,jval,sparse_num
from check_skelet10_scope import implies,lt,times,plus,num,parse
from check_skelet10_left import norm
from check_skelet10_spread import bounded
P=Path(__file__).resolve().parent
expected={
 'carry-strict-growth':implies(carry('t','u'),lt('t','u')),
 'carry-base':carry(times(num(2),'t'),plus(times(num(4),'t'),'1')),
 'carry-prefix':implies(carry('t','u'),carry(plus(times(num(4),'t'),'1'),times(num(4),'u'))),
}
def main():
 actual=json.loads((P/'skelet10_sync_theorems.json').read_text());assert len(actual)==len(expected)
 for name,f in expected.items():
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(f),label
  assert bounded(f),label
 for x in range(1024):
  assert jval(2*x)[0]==4*x+1
  if sparse_num(x):
   y=jval(x)[0];assert x<y and jval(4*x+1)[0]==4*y
 out={'statements_checked':len(expected),'independent_reconstruction_matches':True,'all_new_statements_delta0':True,'finite_inputs_checked':1024,'finite_tests_are_not_formal_proofs':True,'carry_uniqueness_formalized':False,'whole_machine_nonhalting':False}
 (P/'skelet10_sync_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
