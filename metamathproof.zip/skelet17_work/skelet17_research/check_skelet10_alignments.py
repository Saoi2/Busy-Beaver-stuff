"""Independent formulas and numerical checks for finite routine alignments."""
from pathlib import Path
import json
from check_skelet10_scope import AND,eq,lt,plus,times,num,implies,parse,sparse,step
from check_skelet10_left import norm,raw_step
from check_skelet10_right import sparse_num
from check_skelet10_spread import bounded
P=Path(__file__).resolve().parent;two,three,four=map(num,(2,3,4))
c=['z10Current'+s for s in ('Q','L','Bit','R')]
d=['z10Next'+s for s in ('Q','L','Bit','R')]
h=['z10AlignMiddle'+s for s in ('Q','L','Bit','R')]
def wl(x):return plus(times(two,x[1]),x[2])
def wr(x):return plus(times(two,x[3]),x[2])
expected={
 'left-entry-two-step':implies(AND([eq(c[0],three),eq(wl(c),plus(times(four,'t'),two)),step(c,h),step(h,d)]),AND([eq(d[0],three),eq(wl(d),'t'),eq(d[3],plus(times(four,c[3]),three)),lt(d[2],two)])),
 'return-clear-two-step':implies(AND([eq(c[0],'0'),eq(wr(c),plus(times(four,'t'),three)),step(c,h),step(h,d)]),AND([eq(d[0],'0'),eq(d[1],times(four,c[1])),eq(wr(d),'t'),lt(d[2],two)])),
 'even-right-enters-counter':implies(AND([eq(c[0],'0'),eq(wr(c),times(two,'t')),sparse('t'),step(c,d)]),AND([eq(d[0],'1'),eq(d[1],plus(times(two,c[1]),'1')),eq(wr(d),'t'),lt(d[2],two),sparse('t')])),
}
def main():
 data=json.loads((P/'skelet10_alignments_theorems.json').read_text());assert len(data)==3
 for name,f in expected.items():
  label='skelet17-ladder-skelet10-'+name;assert norm(parse(data[label]))==norm(f),label;assert bounded(f),label
 counts=[0,0,0]
 for t in range(128):
  for r in range(32):
   old=(3,2*t+1,0,r);middle=raw_step(old);new=raw_step(middle)
   assert middle[0]==2 and 2*middle[1]+middle[2]==2*t+1 and middle[3]==2*r+1
   assert new[0]==3 and 2*new[1]+new[2]==t and new[3]==4*r+3 and new[2]<2;counts[0]+=1
  for l in range(32):
   old=(0,l,1,2*t+1);middle=raw_step(old);new=raw_step(middle)
   assert middle[0]==0 and middle[1]==2*l and 2*middle[3]+middle[2]==2*t+1
   assert new[0]==0 and new[1]==4*l and 2*new[3]+new[2]==t and new[2]<2;counts[1]+=1
   if sparse_num(t):
    old=(0,l,0,t);new=raw_step(old)
    assert new[0]==1 and new[1]==2*l+1 and 2*new[3]+new[2]==t and new[2]<2;counts[2]+=1
 out={'statements_checked':3,'independent_reconstruction_matches':True,'all_new_statements_delta0':True,'ordinary_machine_encoding_unchanged':True,'finite_D0_C1_paths':counts[0],'finite_A1_A1_paths':counts[1],'finite_even_A_entries':counts[2],'finite_tests_are_not_formal_proofs':True,'no_new_induction_constructions':True,'complete_boundary_compositions':False,'whole_machine_nonhalting':False}
 (P/'skelet10_alignments_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
