from pathlib import Path
import json,os
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_skelet10_spread import add_skelet10_spread
from ladder_skelet10_return import add_skelet10_return
from ladder_skelet10_right import add_skelet10_right
from ladder_skelet10_blocks import add_skelet10_blocks
from ladder_skelet10_clear import add_skelet10_clear
from ladder_skelet10_left import add_skelet10_left
from ladder_skelet10_full_left import add_skelet10_full_left
m=r.m;P=Path(__file__).resolve().parent
m.nd.OUTPUT_PREFIX='ladder-z10-full-left-';m.a.OUTPUT_PREFIX='ladder-z10-full-left-';old=set(m.theorems)
api=add_skelet10(m,proofs=False);sp=add_skelet10_spread(m,proofs=False);ret=add_skelet10_return(m,api,proofs=False)
right=add_skelet10_right(m,api,ret,proofs=False);clear=add_skelet10_clear(m,api,sp,ret,proofs=False)
ins=add_skelet10_left(m,api,stage='contracts');blocks=add_skelet10_blocks(m,sp,proofs=False)
full=add_skelet10_full_left(m,api,sp,right,clear,ins,blocks)
if os.environ.get('FULL_LEFT_STAGE','all')!='entry':
 from ladder_skelet10_full_left_steps import add_skelet10_full_left_steps
 add_skelet10_full_left_steps(m,api,sp,right,clear,full)
if os.environ.get('FULL_LEFT_STAGE','all')=='all':
 from ladder_skelet10_full_left_history import add_skelet10_full_left_history
 add_skelet10_full_left_history(m,api,full,ret)
with (P/'skelet10_full_left_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'skelet10_full_left_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Full left-counter extension generated.',flush=True)
