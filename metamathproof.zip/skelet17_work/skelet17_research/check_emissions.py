"""Check source interpretation and output order, independently of the kernel."""
from itertools import product
from pathlib import Path
import json
from gray_transducer import transition,decode,word,source_value
T=[[0,4],[0,5],[0,6],[0,7],[2,4],[3,5],[0,5],[1,4]]
def event(i,j):
    f=int(i>=4 and j==1);return f,T[i][j]%2 if f else 0
def end(i):return (1,((i//2)%2)^(i%2)) if i>=4 else (0,0)
if __name__=='__main__':
    regular=0
    for i in range(8):
        for j in range(2):
            if i<4 and j==0:continue
            state,emitted=transition((i//4,(i//2)%2,i%2),j)
            assert 4*state[0]+2*state[1]+state[2]==T[i][j]
            assert event(i,j)==(int(emitted is not None),emitted if emitted is not None else 0)
            regular+=1
    cases=0;ends=set();examples=[]
    for size in range(1,8):
        for xs in product(range(4),repeat=size):
            w=word(xs);x=int(w,2) if w else 0;S=state=0
            for ch in w:state=T[state][int(ch)];S=8*S+state
            p=1<<(len(w)-1) if w else 0;bits=[]
            while p:
                before=S//((2*p)**3)%8;current=S//(p**3)%8;bit=x//p%2
                assert T[before][bit]==current
                f,v=event(before,bit)
                if f:bits.append(v)
                p//=2
            terminal=S%8;ends.add(terminal);f,v=end(terminal)
            if f:bits.append(v)
            N=0
            for v in bits:N=2*N+v
            assert (N,bits)==decode(w)
            assert N==source_value(xs)
            cases+=1
    for w in ['', '1','10','11','1101']:
        N,bits=decode(w);examples.append({'input_word':w,'emitted_digits':bits,'integer':N})
    report={'status':'Regression checks, not formal counting or Gray-counter correctness proofs.',
        'ordinary_table_rows_checked':regular,'valid_list_inputs_checked':cases,
        'terminal_controls_observed':sorted(ends),'examples':examples}
    Path(__file__).with_name('emission_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report)
