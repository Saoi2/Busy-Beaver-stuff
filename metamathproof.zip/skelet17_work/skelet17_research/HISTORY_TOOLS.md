# Shared raw-history uniqueness and suffix tools

Four theorems provide arithmetic infrastructure for assembling the
Skelet #10 routine proofs into a global proof. They are deductions in the
same canonical file over the unchanged 93 trusted declarations. None
uses induction, CRT, exponentiation, a totality axiom for coding, or a
certificate added to the definition of a history.

## Exact representation

Fix a coordinate bound H and four pairs of code parameters B_j,C_j.
For an absolute index k, let

    m_j(k)=1+(k+1)C_j,
    beta_j(k,x) := exists u<H:
        B_j=u*m_j(k)+x and x<m_j(k).

The quotient is bounded by H as in the existing routine histories.
No existence claim is part of a beta definition. For a window offset o,

    At_o(i,c) := conjunction over j=0,1,2,3 of beta_j(o+i,c_j).

For a length N the supplied-history premises are

    TOTAL(o,N) := forall i<N+1 exists c_0<H ... exists c_3<H At_o(i,c),

    STEPS(o,N) := forall i<N forall c_0<H ... forall d_3<H:
        (At_o(i,c) and At_o(i+1,d)) -> Step(c,d).

The STEPS theorem here is instantiated with the original Skelet #10
Step table. The coordinate/row uniqueness facts do not depend on any
machine table. They also do not require TOTAL or STEPS as premises.
All displayed abbreviations expand to first-order Delta-0 formulas.

## 1. A beta value is unique

`skelet17-ladder-history-beta-value-unique` proves

    beta(B,C,k,x) and beta(B,C,k,y) -> x=y.

Eliminate both bounded quotient witnesses, calling them u and v.
Their equations imply m*u+x=m*v+y. Their remainder bounds give
x<m and y<m. The existing quotient/remainder uniqueness theorem
therefore gives x=y (as well as u=v, which the interface does not need).
The quotient bounds are preserved and discharged when the witnesses
are eliminated. The proof never presumes that the remainders exist for
arbitrary input codes.

## 2. A history row is unique

`skelet17-ladder-history-row-unique` proves

    At_o(i,c) and At_o(i,d)
    -> c_0=d_0 and c_1=d_1 and c_2=d_2 and c_3=d_3.

Unpack the four coordinate assertions and apply the first theorem once
to each. This is the fact needed when a routine theorem universally
quantifies over all initial decoded rows: a known initial row and every
other decoded row at that index must have the same quadruple.

It is now used to exclude a nonhalting current row at the final halt
index and to embed both counter routines from a known row; read
HISTORY_ASSEMBLY.md. This theorem by itself is not a nonhalting result.

## 3. Every row exists in a suffix

`skelet17-ladder-history-total-suffix` proves

    TOTAL(o,N) and k+n=N -> TOTAL(o+k,n).

For an arbitrary i<n+1, addition preserves order, so k+i<N+1.
Instantiate the original TOTAL at k+i. It supplies a decoded quadruple
with each coordinate below the SAME H. Associativity identifies

    o+(k+i)=(o+k)+i.

Rewrite the absolute index in the four beta assertions. The quadruple
is now a witness for TOTAL(o+k,n). Introduce the bounded universal
quantifier on i. No induction is used, and no code is reconstructed.

## 4. Every transition condition holds in a suffix

`skelet17-ladder-history-steps-suffix` proves

    STEPS(o,N) and k+n=N -> STEPS(o+k,n).

For arbitrary i<n and arbitrary bounded rows c,d, assume their two
suffix At assertions. We have k+i<N. Addition associativity identifies
their absolute indices with

    o+(k+i) and o+((k+i)+1).

Instantiate the old STEPS at k+i and those same rows, then apply it to
the rewritten At assertions. It yields the unchanged ordinary
Step(c,d). Discharge the row and index premises by natural deduction.

The suffix formulas use fresh bound-variable names so universal
introduction meets the kernel's syntactic variable-independence rules.
These names do not change the mathematics or add history information.

## Verification and remaining assembly

The source is ladder_history_tools.py; check_history_tools.py separately
reconstructs the four formulas and checks that they are Delta-0. Its
16,384 remainder examples and 45,760 suffix-index examples are only
supplementary checks. Metamath verifies the universal proof deductions.
The dependency audit checks zero bounded-induction nodes for all four.

These results finish the arithmetic uniqueness and TOTAL/STEPS suffix
obligations listed in the global plan. Subsequent work in
HISTORY_ASSEMBLY.md proves known-row-to-universal entry conversion for
both routines, original-index exit transport, strict progress and endpoint
bit bounds. It also supplies a shared advancement lemma for finite-prefix
assembly. The three complete boundary compositions, global remaining-length
induction and blank-start connection remain unfinished.
