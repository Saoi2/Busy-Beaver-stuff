# Recursive carry inversion

The new interface is
`skelet17-ladder-skelet10-carry-prefix-inverse`:

    J(4x+1,y) implies exists v<y+1, y=4v and J(x,v).

Here J is the same bounded relation used in the complete counter routine
contracts. No machine instruction or computation-history definition changes.
All active results belong to idelta0_machines.mm; odd_carry_check.mm is a
temporary dependency extraction used during verification.

## Recovering the smaller witnesses

Eliminate J's witnesses p,s,a, which satisfy

    Pow2(p), p=3s+1, 4x+1=p(2a)+s, y=p(4a+1).

The existing Pow2-halving theorem splits p into p=1 or a bounded positive
Pow2 half. If p=1, quotient uniqueness in p=3s+1 gives s=0; the input
would then be both odd and even. If the half is 1, p=2, which is
incompatible with p=3s+1 by remainder uniqueness modulo 3. Halve again
in the remaining case, obtaining p=4h and Pow2(h).

Bounded division gives s=4q+d, d<4. There are four explicit cases for d;
this is a finite natural-deduction case split, not an induction schema.
The equation 4h=12q+3d+1 has remainder 0 modulo 4 only for d=1.
For d=0,2,3, quotient uniqueness gives 0=1, 0=3, 0=2, respectively.
For d=1 it gives

    h=3q+1, s=4q+1.

Substitution into the input equation and quotient uniqueness at modulus 4
then give x=h(2a)+q. Set v=h(4a+1). The output equation gives y=4v.
Consequently h,q,a are exactly the desired witnesses for J(x,v).

## Bounds and logic

The already proved prefix-bound lemma supplies h<3x+2, q<x+1 and
2a<x+1 from the recovered equations. Elementary order reasoning gives
a<x+1. These bounds are proved before introducing the three bounded
existentials in J(x,v). The equation y=4v gives v<y+1 with explicit
gap 3v. Thus the theorem's output witness is bounded as well.

The proof reuses bounded division, Pow2 halving, ordinary equality
substitution, quotient/remainder uniqueness, and natural deduction.
It adds no induction construction. The actual dependency audit checks
that its only induction dependency is the earlier bounded division proof.
This is an upper bound for this implementation, not a claim that induction
is necessary for this particular statement.

The independent checker reconstructs the exact quantified formula and
checks its Delta-0 syntax. It also checks 233 numerical Sparse inputs as
supplementary examples; these finite tests do not establish the theorem.
The official Metamath verifier checks the universal formal proof.

## Remaining task

Together with the even-input inverse, this supplies the arithmetic
recursion for a bounded strong-induction proof of output uniqueness on
Sparse inputs. If the input is even, the even inverse fixes its output.
If it is odd and Sparse, it has shape 4x+1; the new inverse reduces both
outputs to outputs for the strictly smaller Sparse input x. Equality at
that smaller input then implies equality of the original outputs.

That uniqueness proof is not yet formalized. It must explicitly bound
its two output variables and recover smaller Sparse inputs using the
existing pop lemmas. The global routine synchronization and blank-start
nonhalting proof are also still unfinished.
