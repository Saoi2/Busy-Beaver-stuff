"""Independent scope reconstruction for raw-history routine embedding."""
from pathlib import Path
import json
import check_history_tools as ht
from check_skelet10_scope import AND,both,eq,lt,plus,num,implies,parse,EX,step
from check_skelet10_left import norm,raw_step
from check_skelet10_spread import bounded
from check_skelet10_right import entry as right_entry,endpoint as right_endpoint
from check_skelet10_full_left import entry as left_entry,endpoint as left_endpoint
P=Path(__file__).resolve().parent
H,N,o,k,n,idx=ht.H,ht.N,ht.o,ht.k,ht.n,ht.idx
c,d=ht.c,ht.d;halt=['assemblyHalt'+s for s in ('Q','L','Bit','R')]
def bounds(row):return [lt(x,H) for x in row]
tot=ht.total(o,N,ht.ti);moves=ht.steps(o,N,ht.si,ht.SV)
after=ht.bexs(ht.TV,both(ht.at(o,plus(idx,'1'),ht.TV),step(c,ht.TV)))
expected={
 'history-advance-before-halt':implies(AND([tot,moves,*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5)),*bounds(c),lt(idx,plus(N,'1')),ht.at(o,idx,c),('-.',eq(c[0],num(5)))]),both(lt(idx,N),after)),
 'history-positive-row-bit':implies(AND([tot,moves,lt(idx,N),*bounds(d),ht.at(o,plus(idx,'1'),d)]),lt(d[2],num(2))),
}
for kind,entry,endpoint in [('right',right_entry,right_endpoint),('left',left_entry,left_endpoint)]:
 ei='embedded'+kind.title()+'AbsoluteIndex'
 er=['embedded'+kind.title()+'OutputRow'+s for s in ('Q','L','Bit','R')]
 prem=AND([tot,moves,eq(plus(k,n),N),*bounds(c),ht.at(o,k,c),entry(c),*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5))])
 result=AND([lt(k,ei),ht.at(o,ei,er),endpoint(er),lt(er[2],num(2))])
 expected['skelet10-'+kind+'-embedded-halting-barrier']=implies(prem,EX(ei,plus(N,'1'),ht.bexs(er,result)))
def main():
 data=json.loads((P/'history_assembly_theorems.json').read_text());assert len(data)==4
 for name,f in expected.items():
  label='skelet17-ladder-'+name;assert norm(parse(data[label]))==norm(f),label;assert bounded(f),label
 histories=advanced=binary=0
 for q in range(5):
  for l in range(12):
   for bit in range(2):
    for r in range(12):
     row=(q,l,bit,r);trace=[row]
     for _ in range(128):
      if row[0]==5:break
      row=raw_step(row);trace.append(row)
     if row[0]!=5:continue
     histories+=1
     for i,row in enumerate(trace):
      if row[0]!=5:assert i<len(trace)-1 and raw_step(row)==trace[i+1];advanced+=1
      if i>0:assert row[2]<2;binary+=1
 out={'statements_checked':4,'independent_reconstruction_matches':True,'all_new_statements_delta0':True,'ordinary_history_and_machine_unchanged':True,'entry_at_known_supplied_row':True,'output_at_strictly_later_original_index':True,'endpoint_bit_bound_derived_from_history':True,'finite_halting_histories':histories,'finite_advance_cases':advanced,'finite_positive_bit_cases':binary,'finite_tests_are_not_formal_proofs':True,'full_boundary_compositions':False,'whole_machine_nonhalting':False}
 (P/'history_assembly_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
