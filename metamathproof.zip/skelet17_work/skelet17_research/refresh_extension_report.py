"""Record an appended, kernel-verified extension without claiming a new cleanup."""
from pathlib import Path
import json,hashlib,re
from simplify_metamath import parse_intern,exact,public,digest_json
P=Path(__file__).resolve().parent
r=json.loads((P/'simplification_report.json').read_text());prior=json.loads((P/'preceding_checkpoint_report.json').read_text())
s=(P/'idelta0_machines.mm').read_text();records,rules,_=parse_intern(s)
a={q['label']:exact(q,rules) for q in records if q['kind']=='a'}
assert len(a)==93 and digest_json(a)==r['trusted_core_digest']
i={k:digest_json(exact(v,rules)) for k,v in rules.items() if v['kind']=='p' and public(k)}
for k,v in prior['interface_digests'].items():assert i[k]==v,k
for k,v in r['interface_digests'].items():assert i[k]==v,k
log=(P/'ladder_verification.log').read_text();assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
count=sum(q['kind']=='p' for q in records);assert count==int(re.search(r'93 are \$a and ([0-9]+) are \$p',log).group(1))
r.update(output_bytes=len(s.encode()),output_sha256=hashlib.sha256(s.encode()).hexdigest(),output_proofs=count,named_interfaces=len(i),interface_digests=i,official_verification='passed',preceding_checkpoint_interfaces_preserved=len(prior['interface_digests']),incremental_append_after_last_simplification=True)
(P/'simplification_report.json').write_text(json.dumps(r,indent=2)+'\n')
print({k:r[k] for k in ('output_bytes','output_proofs','named_interfaces','preceding_checkpoint_interfaces_preserved','output_sha256')},flush=True)
