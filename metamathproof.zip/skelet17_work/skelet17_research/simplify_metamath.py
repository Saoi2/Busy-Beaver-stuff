"""Untrusted proof-preserving cleanup. Official verification is mandatory.

Reuse an earlier assertion only when ordered mandatory hypotheses and
conclusion agree up to renaming of their mandatory variables, and its
mandatory distinct-variable constraints are no stronger. Preserve every
named Skelet17/ladder interface, including its original exact statement.
Pack $d declarations only into cliques of the *existing* pair graph.
"""
from pathlib import Path
from collections import defaultdict,Counter
from functools import lru_cache
import hashlib,itertools,json,re,sys,textwrap,time
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import rewrite,numbers,encode

def used_labels(text,mandatory):
 tokens=text.split()
 if not tokens or tokens[0]!='(':return Counter(tokens)
 j=tokens.index(')');labels=[*mandatory,*tokens[1:j]];out=Counter()
 for x in numbers(tokens[j+1:]):
  if x!='Z' and x<=len(labels):out[labels[x-1]]+=1
 return out

def inline_single_use(keep,rules,rewritten,deps,proof):
 """Eliminate a single-use private proof only if it has no private inputs.

All floating-hypothesis leaves must be mandatory hypotheses. Thus proof
substitution needs no fresh variables and no extra $d conditions. Original
caller declarations suffice; the official verifier independently checks it.
"""
 refs=Counter()
 for k in keep:
  if rules[k]['kind']=='p':refs.update(used_labels(proof(k),rules[k]['hyps']))
 selected={k for k in keep if rules[k]['kind']=='p' and not public(k) and refs[k]==1
           and all(rules[h]['kind']!='f' or h in rules[k]['hyps'] for h in deps[k])}
 print('Single-use private proofs without private inputs:',len(selected),flush=True)
 if not selected:return 0
 sys.setrecursionlimit(max(sys.getrecursionlimit(),20000))
 arity={k:len(r.get('hyps',[])) for k,r in rules.items()}
 for label in sorted(keep-selected,key=lambda k:rules[k]['start']):
  if rules[label]['kind']!='p':continue
  if not any(k in selected for k in deps[label]):continue
  nodes=[];intern={}
  def node(lab,children=()):
   key=(lab,tuple(children))
   if key not in intern:intern[key]=len(nodes);nodes.append(key)
   return intern[key]
  def evaluate(lab,env):
   tokens=proof(lab).split();stack=[];saved=[]
   def apply(op):
    if op in env:stack.append(env[op]);return
    n=arity[op];assert len(stack)>=n,(lab,op)
    children=stack[-n:] if n else []
    if n:del stack[-n:]
    if op in selected:
     assert len(children)==len(rules[op]['hyps'])
     stack.append(evaluate(op,dict(zip(rules[op]['hyps'],children))))
    else:stack.append(node(op,children))
   if tokens[0]=='(':
    j=tokens.index(')');labels=[*rules[lab]['hyps'],*tokens[1:j]];base=len(labels)
    for x in numbers(tokens[j+1:]):
     if x=='Z':assert stack;saved.append(stack[-1])
     elif x<=base:apply(labels[x-1])
     else:stack.append(saved[x-base-1])
   else:
    for op in tokens:apply(op)
   assert len(stack)==1,(lab,len(stack));return stack[0]
  root=evaluate(label,{})
  reachable=set();todo=[root];counts=Counter({root:1})
  while todo:
   k=todo.pop()
   if k in reachable:continue
   reachable.add(k)
   for child in nodes[k][1]:counts[child]+=1;todo.append(child)
  mandatory=rules[label]['hyps'];indices={x:i+1 for i,x in enumerate(mandatory)};explicit=[]
  for k in sorted(reachable):
   lab=nodes[k][0]
   if lab not in indices:indices[lab]=len(mandatory)+len(explicit)+1;explicit.append(lab)
  base=len(mandatory)+len(explicit);saved={};code=[];work=[(root,False)]
  while work:
   k,ready=work.pop()
   if k in saved:code.append(encode(base+saved[k]+1));continue
   lab,children=nodes[k]
   if not ready:
    work.append((k,True));work.extend((c,False) for c in reversed(children));continue
   code.append(encode(indices[lab]))
   if counts[k]>1 and children:saved[k]=len(saved);code.append('Z')
  text=''.join(code)
  rewritten[label]='( '+' '.join(explicit)+' )\n  '+'\n  '.join(text[i:i+100] for i in range(0,len(text),100))
  deps[label]=set(mandatory)|{nodes[k][0] for k in reachable}
  assert not (deps[label]&selected)
 # Recompute closure: discarded proof arguments can make other nodes dead.
 roots=[k for k in keep if rules[k]['kind']=='a' or (rules[k]['kind']=='p' and public(k))]
 live=set();todo=list(roots)
 while todo:
  k=todo.pop()
  if k in live:continue
  live.add(k);r=rules[k]
  if r['kind']=='p':todo.extend(deps[k])
  todo.extend(r.get('hyps',[]))
 assert not (live&selected)
 keep.clear();keep.update(live)
 return len(selected)

@lru_cache(maxsize=10000)
def pack_dv(pairs):
 if not pairs:return ''
 adj=defaultdict(set)
 for x,y in pairs:adj[x].add(y);adj[y].add(x)
 # Arithmetic generators frequently produce a complete split graph: all
 # object variables are mutually distinct, and each term parameter is
 # distinct from every object variable. Pack that case directly instead
 # of repeatedly searching its large, nearly identical cliques.
 vertices=set(adj);universal={v for v in vertices if len(adj[v])==len(vertices)-1}
 rest=vertices-universal
 if universal and all(adj[v]==universal for v in rest):
  cliques=[tuple(sorted(universal|{v})) for v in sorted(rest)] if rest else [tuple(sorted(universal))]
  assert set(itertools.chain.from_iterable(itertools.combinations(c,2) for c in cliques))==set(pairs)
  return ''.join('$d '+' '.join(c)+' $.\n' for c in cliques)
 remaining=set(pairs);cliques=[]
 while remaining:
  degree=Counter(v for e in remaining for v in e)
  start=max(degree,key=lambda v:(degree[v],v));clique=[start];candidates=set(adj[start])
  while candidates:
   def score(v):return sum(tuple(sorted((v,w))) in remaining for w in clique),degree[v],v
   v=max(candidates,key=score)
   if score(v)[0]==0:break
   clique.append(v);candidates.intersection_update(adj[v]);candidates.difference_update(clique)
  assert len(clique)>1
  clique=tuple(sorted(clique));cliques.append(clique)
  remaining.difference_update(itertools.combinations(clique,2))
 assert set(itertools.chain.from_iterable(itertools.combinations(c,2) for c in cliques))==set(pairs)
 return ''.join('$d '+' '.join(c)+' $.\n' for c in cliques)

def compact_layout(src,dst):
 pending=set();stats=Counter();digest=hashlib.sha256()
 with src.open() as inp,dst.open('w') as out:
  def flush():
   if pending:
    text=pack_dv(tuple(sorted(pending)));out.write(text);stats['packed_dv_statements']+=text.count('$.');pending.clear()
  for line in inp:
   digest.update(line.encode());stats['input_bytes']+=len(line.encode())
   if line.startswith('$d ') and line.rstrip().endswith('$.'):
    words=line.split()[1:-1];pending.update(tuple(sorted(e)) for e in itertools.combinations(words,2));stats['original_dv_statements']+=1
   else:flush();out.write(line)
  flush()
 stats['layout_bytes']=dst.stat().st_size;stats['input_sha256']=digest.hexdigest()
 print('Packed declaration layout:',dict(stats),flush=True)
 return dict(stats)

def parse_intern(source):
 """Same record format as minimize_library.parse, with interned tokens."""
 records=[];rules={};variables=set();floats=[];essential=[];adj=defaultdict(set);scopes=[]
 iterator=iter(m for m in re.finditer(r'\$\([\s\S]*?\$\)|\S+',source) if not m.group().startswith('$('))
 token=lambda m:sys.intern(m.group())
 for match in iterator:
  t=token(match);start=match.start()
  if t=='${':
   scopes.append((len(floats),len(essential),[]));records.append({'kind':'{','start':start,'end':match.end()});continue
  if t=='$}':
   nf,ne,added=scopes.pop();floats=floats[:nf];essential=essential[:ne]
   for x,y in added:adj[x].remove(y);adj[y].remove(x)
   records.append({'kind':'}','start':start,'end':match.end()});continue
  if t in ('$c','$v','$d'):
   fields=[]
   for end in iterator:
    v=token(end)
    if v=='$.':break
    fields.append(v)
   kind=t[1:];records.append({'kind':kind,'expr':fields,'start':start,'end':end.end()})
   if kind=='v':variables.update(fields)
   if kind=='d':
    assert len(fields)==len(set(fields))
    for x,y in itertools.combinations(fields,2):
     if y in adj[x]:continue
     adj[x].add(y);adj[y].add(x)
     if scopes:scopes[-1][2].append((x,y))
   continue
  label=t;assert label not in rules
  kind=token(next(iterator));expr=[];proof=None
  for end in iterator:
   v=token(end)
   if v in ('$.','$='):break
   expr.append(v)
  if kind=='$p':
   assert v=='$=';proof=[]
   for end in iterator:
    v=token(end)
    if v=='$.':break
    proof.append(v)
  else:assert v=='$.'
  r={'label':label,'kind':kind[1:],'expr':expr,'proof':proof,'start':start,'end':end.end()}
  if kind=='$f':floats.append(label)
  if kind=='$e':essential.append(label)
  if kind in ('$p','$a'):
   used=set(expr)&variables
   for e in essential:used.update(set(rules[e]['expr'])&variables)
   r['hyps']=[f for f in floats if rules[f]['expr'][1] in used]+essential.copy()
   r['dv']=frozenset((x,y) for x in used for y in adj[x]&used if x<y)
  records.append(r);rules[label]=r
 assert not scopes
 return records,rules,variables

def public(label):return label.startswith('skelet17-') or '-skelet17-' in label
def signature(r,rules):
 vs=[rules[h]['expr'][1] for h in r['hyps'] if rules[h]['kind']=='f'];vm={v:i for i,v in enumerate(vs)}
 def norm(xs):return ' '.join('@'+str(vm[x]) if x in vm else ':'+x for x in xs)
 data='\n'.join([*(rules[h]['kind']+' '+norm(rules[h]['expr']) for h in r['hyps']),'conclusion '+norm(r['expr'])])
 mask=0;n=len(vs)
 for x,y in r['dv']:
  i,j=sorted((vm[x],vm[y]));mask|=1<<(i*n+j)
 return data,mask
def exact(r,rules):
 return {'expr':r['expr'],'hypotheses':[(rules[h]['kind'],rules[h]['expr']) for h in r['hyps']],
         'dv':sorted(r['dv'])}
def digest_json(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

HEADER=r'''$(
I-DELTA-0 MACHINE PROOFS -- READING GUIDE AND RESULT INDEX
=======================================================

This is the single standalone project file. Its trusted declarations are
the original syntax rules, classical natural-deduction rules, discrete
ordered-semiring arithmetic axioms, and bounded-induction schema. All
other assertions are proved statements. There are no new machine axioms.

PUBLIC RESULTS (search for the full label)
-----------------------------------------
Finite ordinary traces, not exhaustive Busy Beaver classifications:
  skelet17-ladder-bb1-halting-trace                 one step
  skelet17-ladder-bb2-halting-trace                 six steps

Individual blank-start nonhalting theorems:
  skelet17-ladder-cycler-no-blank-halting-history
    1RB0RB_0LA---
  skelet17-ladder-translated-no-blank-halting-history
    1RB1RA_1LA---
  skelet17-ladder-counter-no-blank-halting-history
    1RB---_1LC1RB_0RA0LC
  skelet17-ladder-bouncer-no-blank-halting-history
    1RB0LC_0LC1RA_---1LA
  skelet17-ladder-fractal-no-blank-halting-history
    1RB0LA_1RC---_0RD0RC_1LD0LA
  skelet17-ladder-finned3-no-blank-halting-history
    1RB1RE_1LC1RB_0RA0LD_1LB1LD_---0RA

For each machine, the corresponding -local theorem proves preservation
of its invariant; -history propagates it along a supplied history.
Finned #3 uses parameters bounded by 16*(H+1); their existence is derived.
Skelet #10 right-counter fragment (not whole-machine nonhalting):
  skelet17-ladder-skelet10-sparse-zero / -sparse-pop / -sparse-push
  skelet17-ladder-skelet10-sparse-prefix-0 / -sparse-prefix-10
  skelet17-ladder-skelet10-sparse-odd-tail / -double-window-bound
  skelet17-ladder-skelet10-right-scan-to-D
  skelet17-ladder-skelet10-blank-enters-right-scan
Four finite left-counter contracts are also proved:
  skelet17-ladder-skelet10-left-exit-five-step
  skelet17-ladder-skelet10-left-carry-four-step
  skelet17-ladder-skelet10-return-clear-four-step
  skelet17-ladder-skelet10-left-zero-return-to-scan
They include explicit ordinary paths and forced endpoints of arbitrary
runs of the same fixed length. See SKELET10_LEFT_COUNTER.md.
Bounded word-transform arithmetic is also established:
  skelet17-ladder-skelet10-spread-zero / -spread-push
  skelet17-ladder-skelet10-spread-exists-quadratic
  skelet17-ladder-skelet10-transform-zero
  skelet17-ladder-skelet10-transform-prefix-0 / -transform-prefix-10
  skelet17-ladder-skelet10-transform-exists-quadratic
These prove a total bounded graph, not yet uniqueness or synchronization.
See SKELET10_SPREAD.md for the explicit Delta-0 definition and induction.
Exact bounded decoding and both inverse grammar rules are now proved:
  skelet17-ladder-skelet10-spread-low-digit / -spread-second-bit-zero
  skelet17-ladder-skelet10-spread-pop / -spread-decompose
  skelet17-ladder-skelet10-transform-pop-0 / -transform-pop-10
See SKELET10_DECODING.md. These add no induction construction.
The full D1 return phase has a supplied-history termination contract:
  skelet17-ladder-skelet10-return-marker-step
  skelet17-ladder-skelet10-return-window-invariant / -return-window-bound
  skelet17-ladder-skelet10-return-window-exit
  skelet17-ladder-skelet10-return-window-halting-barrier
Intermediate markers are constructed by one bounded history induction.
See SKELET10_RETURN.md. The complete counter cycle is still unfinished.
The complete right-counter routine now has a ranked history contract:
  skelet17-ladder-skelet10-right-counter-entry / -right-counter-step
  skelet17-ladder-skelet10-right-window-invariant / -right-window-bound
  skelet17-ladder-skelet10-right-window-exit
  skelet17-ladder-skelet10-right-window-halting-barrier
Its endpoint is D with the original whole left word restored and a
Sparse right output satisfying the bounded carry graph J. The coarse
rank bound is 20*w+18. Intermediate phases and ranks are constructed.
See SKELET10_RIGHT_ROUTINE.md. Full two-counter synchronization is open.
The bounded left-word graph now supplies its block tails directly:
  skelet17-ladder-skelet10-transform-decompose-0 / -transform-decompose-10
The complete A1 clearing return also has a ranked history contract:
  skelet17-ladder-skelet10-left-return-entry / -left-return-step
  skelet17-ladder-skelet10-left-return-window-invariant
  skelet17-ladder-skelet10-left-return-window-bound
  skelet17-ladder-skelet10-left-return-window-exit
  skelet17-ladder-skelet10-left-return-window-halting-barrier
The word encoding, Sparse property and right tail are preserved. A rank
bound 2P suffices. See SKELET10_LEFT_RETURN.md. This clearing phase is
reused in the complete left routine below. Whole-machine nonhalting is open.
The complete left-counter routine now has a ranked history contract:
  skelet17-ladder-skelet10-left-counter-entry / -left-counter-step
  skelet17-ladder-skelet10-left-window-invariant / -left-window-bound
  skelet17-ladder-skelet10-left-window-exit
  skelet17-ladder-skelet10-left-window-halting-barrier
Starting at D with T(w,2L+b), Sparse(w) and R=4r+3, a sufficiently long
supplied ordinary history visits A with whole right word r and a bounded
output V satisfying J(w,V), T(V,L) and Sparse(V). The coarse time bound
is 32w+24. History induction constructs all scan and return witnesses.
The two complete routine contracts are not yet a global cycle theorem.
Three synchronization arithmetic interfaces additionally prove strict
carry growth, the base carry J(2x,4x+1), and closure J(x,y) -> J(4x+1,4y).
See SKELET10_SYNCHRONIZATION.md. Inversion, uniqueness and the global
history argument are still unfinished.

The right-scan theorem preserves its invariant OR reaches D. It does not
assert that an arbitrary D configuration is safe. Synchronization is open.
Skelet #10 and #17 nonhalting and full BB classifications remain unfinished.
The older Skelet17 parser, recorder and emission results are partial
infrastructure. Historical labels are retained as stable interfaces.

ENCODING AND ABBREVIATIONS USED IN THE COMMENTS
---------------------------------------------
A configuration is (q,L,b,R). A=0, B=1, C=2, D=3, E=4, halt Z=5.
The scanned bit is b. L and R hold the two tape halves, excluding b;
the nearest cell is their least significant binary bit.
Right, writing w: L'=2L+w and R=2R'+b'.
Left, writing w: R'=2R+w and L=2L'+b'.
Every ordinary step explicitly includes b'=0 or b'=1. Undefined
instructions are completed by 1RZ, recording the final write and move.

H (the term parameter mh) bounds supplied history coordinates and beta
quotients; n (mn) is the final index. Bj,Cj are history-code parameters,
not the state B or a tape bit. A coordinate value v at index k satisfies
  beta_j(k,v): exists u<H,
      Bj=u*(1+(k+1)*Cj)+v and v<1+(k+1)*Cj.
At(i,c) conjoins the four coordinate relations at offset+i. TOTAL gives
a tuple below H at each i<n+1. STEPS requires ordinary Step between
adjacent supplied tuples. BLANK requires the initial tuple to be zero.
Each nonhalting theorem negates TOTAL, STEPS, BLANK, the final coordinate
bounds, At(n,final), and final.q=5, conjoined. It does not assume an
auxiliary invariant or a theorem asserting totality of history coding.

Even(x) abbreviates exists z<x+1, x=2z. Div(d,p) abbreviates
exists e<p+1, d*e=p. Pow2(p) is the bounded divisor predicate
  0<p and forall d<p+1, Div(d,p) -> (d=1 or Even(d)).
These are reading abbreviations; the actual statements expand them.
No total exponentiation function is added to the language.

METAMATH NOTATION AND PROOF LAYERS
--------------------------------
$c introduces fixed symbols; $v substitution variables; $f their syntax
types. Object-language quantifiers are A. and E.; -> is implication,
/\ conjunction, \/ disjunction, and -. negation. Typical mathematical
assertions have form |- [] => Phi: Phi follows from the empty assumption
context. A var is an object-variable name; term and wff are syntax types.
The bnd/open judgments certify a formula's syntactic class. They are not
additional arithmetic predicates. Bounded induction requires bnd evidence.

$a is a trusted declaration; $p is a proved assertion. $e supplies a local
essential hypothesis. ${ ... $} delimits scope. $d specifies syntactic
variable independence/capture conditions, not numerical inequality.
The cleanup packs only already present distinct-variable pairs.

Generated arith-, dag- and syn- labels are shared equality, deduction and
syntax steps. Their count is not the number of independent mathematical
results or decider algorithms. Named interfaces above are the main entry
points. The skelet17-ladder prefix is a historical project namespace;
it also names proofs about other machines.

The cleanup reuses schema-equivalent earlier proofs and discards private
nodes outside the named results' dependency closure. Every named theorem
keeps its exact conclusion, mandatory hypotheses and distinct-variable
conditions. See simplification_report.json and SIMPLIFICATION.md.
$)

'''

NOTES={
'skelet17-ladder-skelet10-left-counter-entry':'LEFT-COUNTER ENTRY: Sparse transformed input at D with R=4r+3 has a factored phase certificate and initial rank 32w+24. No induction.',
'skelet17-ladder-skelet10-left-counter-step':'LEFT-COUNTER LOCAL: every ordinary step before correct output preserves the bounded scan-or-clearing invariant with strictly decreasing rank. Reuses the instruction contracts, exact block decompositions and clearing step.',
'skelet17-ladder-skelet10-left-window-invariant':'LEFT-COUNTER HISTORY: bounded induction constructs phase witnesses and decreasing rank in every supplied target-avoiding raw beta history. No intermediate annotations are premises.',
'skelet17-ladder-skelet10-left-window-bound':'LEFT-COUNTER TIME BOUND: a target-avoiding ordinary history has n<32w+24.',
'skelet17-ladder-skelet10-left-window-exit':'LEFT-COUNTER CORRECTNESS: a sufficiently long supplied ordinary history visits A with restored whole right tail r and bounded transformed Sparse output V satisfying J(w,V).',
'skelet17-ladder-skelet10-left-window-halting-barrier':'LEFT-COUNTER SAFETY: a supplied ordinary history from the D entry to halt has already visited its correct A output. Not whole-machine nonhalting.',

'skelet17-ladder-skelet10-transform-decompose-0':'BOUNDED BLOCK DECODING: T(2x,z) gives a tail t<=z with z=4t and T(x,t). No uniqueness premise or new induction.',
'skelet17-ladder-skelet10-transform-decompose-10':'BOUNDED BLOCK DECODING: T(4x+1,z) gives a tail t<=z with z=16t+10 and T(x,t). No uniqueness premise or new induction.',
'skelet17-ladder-skelet10-left-return-entry':'A CLEARING ENTRY: a proper encoded-word return has the two-phase rank with initial value 2P. No induction.',
'skelet17-ladder-skelet10-left-return-step':'A CLEARING STEP: before the specified A output, an ordinary step preserves bounded phase witnesses, the transformed word and Sparse syntax with strictly smaller rank.',
'skelet17-ladder-skelet10-left-return-window-invariant':'CONSTRUCTED CLEARING PHASES: bounded history induction derives intermediate words, encoding tails and ranks from ordinary unannotated histories.',
'skelet17-ladder-skelet10-left-return-window-bound':'A CLEARING TIME BOUND: any supplied target-avoiding return history has final index n<2P.',
'skelet17-ladder-skelet10-left-return-window-exit':'A CLEARING CORRECTNESS: any sufficiently long supplied ordinary return history visits A with the specified right tail and correct Sparse transformed output word.',
'skelet17-ladder-skelet10-left-return-window-halting-barrier':'A CLEARING SAFETY: any supplied return history ending at halt has already visited the specified A output. Not full left-counter correctness or whole-machine nonhalting.',
'skelet17-ladder-skelet10-right-counter-entry':'RIGHT-COUNTER ENTRY: a B row with left half 2ell+1 and Sparse whole-right word w has a bounded phase and rank 20w+18. No induction.',
'skelet17-ladder-skelet10-right-counter-step':'RANKED ROUTINE: any ordinary step before the correct D endpoint preserves one of four bounded phases with a smaller rank. Reuses the D1 return lemma. No annotated Step.',
'skelet17-ladder-skelet10-right-window-invariant':'CONSTRUCTED PHASES: a target-avoiding ordinary history has bounded carry witnesses and rank at each row, with elapsed index plus rank at most 20w+18. One new history induction.',
'skelet17-ladder-skelet10-right-window-bound':'RIGHT-COUNTER TIME BOUND: a target-avoiding ordinary supplied history has final index n<20w+18.',
'skelet17-ladder-skelet10-right-window-exit':'RIGHT-COUNTER CORRECTNESS: a supplied ordinary history of length at least 20w+18 visits D with whole left word ell restored, Sparse right output and a bounded carry-graph witness. No supplied intermediate annotations.',
'skelet17-ladder-skelet10-right-window-halting-barrier':'RIGHT-COUNTER SAFETY: a supplied ordinary history from the B entry to halt has already visited its correct D output. Not full-machine nonhalting.',
'skelet17-ladder-skelet10-return-marker-step':'RETURN PHASE: an ordinary step before the specified endpoint strictly decreases its positive Pow2 marker. Original Step, no induction.',
'skelet17-ladder-skelet10-return-window-invariant':'CONSTRUCTED CERTIFICATES: a target-avoiding ordinary beta history has a bounded marker s with i+s<=P at each row. One bounded history induction.',
'skelet17-ladder-skelet10-return-window-bound':'TARGET-AVOIDANCE BOUND: any ordinary return window avoiding its endpoint has final index n<P. Reuses the history invariant.',
'skelet17-ladder-skelet10-return-window-exit':'PHASE TERMINATION: any supplied ordinary window of length at least P visits its specified D endpoint. No annotated intermediate history.',
'skelet17-ladder-skelet10-return-window-halting-barrier':'PHASE SAFETY: any supplied ordinary return window ending at halt has already visited the specified D endpoint. Reuses the same history induction; not whole-machine nonhalting.',
'skelet17-ladder-skelet10-spread-low-digit':'A spread pair has the same low input and output bit. No induction.',
'skelet17-ladder-skelet10-spread-second-bit-zero':'Every spread output has a zero in binary place 2. No Pow2 square is 2.',
'skelet17-ladder-skelet10-spread-pop':'MATCHED DECODING: Dil(2x+d,4z+d) and d<2 imply Dil(x,z). Both support clauses are recovered.',
'skelet17-ladder-skelet10-spread-decompose':'BOUNDED DECODING: Dil(2x+d,z) and d<2 imply some u<z+1 with z=4u+d and Dil(x,u). No graph uniqueness premise.',
'skelet17-ladder-skelet10-transform-pop-0':'INVERSE GRAMMAR: T(2x,4t) implies T(x,t). No new induction.',
'skelet17-ladder-skelet10-transform-pop-10':'INVERSE GRAMMAR: T(4x+1,16t+10) implies T(x,t). No new induction.',
'skelet17-ladder-skelet10-bit-support-bound':'A one-bit place lies below the input plus one. No induction.',
'skelet17-ladder-skelet10-zero-has-no-one-bit':'Zero has no one bit at a positive place. No induction.',
'skelet17-ladder-skelet10-bit-push-forward':'Pushing a binary digit shifts every old one bit to twice its place. No induction.',
'skelet17-ladder-skelet10-bit-push-back':'Deleting a pushed bit recovers any higher one bit. Reuses existing bounded division.',
'skelet17-ladder-skelet10-bit-low-digit':'The low one-bit predicate for 2x+d is equivalent to d=1 when d<2. No induction.',
'skelet17-ladder-skelet10-spread-zero':'BASE: the bounded two-sided bit-spread graph contains (0,0). No induction.',
'skelet17-ladder-skelet10-spread-push':'CONSTRUCTOR: Dil(x,z) and d<2 imply Dil(2x+d,4z+d). No new function symbol or exponential totality axiom.',
'skelet17-ladder-skelet10-spread-exists-quadratic':'TOTAL GRAPH: every x has a bit-spread witness z<=x*x. One new bounded strong-induction construction; uniqueness and machine synchronization are not claimed.',
'skelet17-ladder-skelet10-transform-zero':'The bounded left-word transform graph contains (0,0). No induction.',
'skelet17-ladder-skelet10-transform-prefix-0':'T(x,t) implies T(2x,4t), using the bounded bit-spread graph.',
'skelet17-ladder-skelet10-transform-prefix-10':'T(x,t) implies T(4x+1,16t+10), using the bounded bit-spread graph.',
'skelet17-ladder-skelet10-transform-exists-quadratic':'Every x has a left-transform witness t<=10*x*x. Reuses bounded spread existence; not a machine nonhalting theorem.',
'skelet17-ladder-skelet10-left-exit-five-step':'PARTIAL LEFT-COUNTER CONTRACT: five explicit ordinary steps and the unique final row for any five-step ordinary run from the displayed source. No induction.',
'skelet17-ladder-skelet10-left-carry-four-step':'PARTIAL LEFT-COUNTER CONTRACT: four ordinary steps remove one encoded 1010 block on the left and push four 1s on the right. The theorem also forces the endpoint of every such four-step run. No induction.',
'skelet17-ladder-skelet10-return-clear-four-step':'PARTIAL LEFT-COUNTER CONTRACT: four A1 steps clear four pending 1s, multiply the left half by 16, and force the displayed endpoint. No induction.',
'skelet17-ladder-skelet10-left-zero-return-to-scan':'Synchronized 00/10 boundary case: an explicit four-step trace, and every matching four-step ordinary run ends in the previously proved right-scan invariant. This is not whole-machine nonhalting. No induction.',
'skelet17-ladder-skelet10-sparse-zero':'Zero satisfies the bounded no-adjacent-1 predicate Sparse.',
'skelet17-ladder-skelet10-sparse-pop':'Deleting the nearest binary digit preserves Sparse. Existing arithmetic induction is reused.',
'skelet17-ladder-skelet10-sparse-odd-tail':'Sparse(2x+1) implies Even(x): a leading 1 must have a following 0.',
'skelet17-ladder-skelet10-double-window-bound':'Elementary quotient bound: 2x+d<2y implies x<y. No induction.',
'skelet17-ladder-skelet10-sparse-push':'Pushing a digit preserves Sparse if the new digit is 0 or the old low bit is 0.',
'skelet17-ladder-skelet10-sparse-prefix-0':'The nearest-first word constructor 0w corresponds to 2x.',
'skelet17-ladder-skelet10-sparse-prefix-10':'The nearest-first word constructor 10w corresponds to 4x+1.',
'skelet17-ladder-skelet10-right-scan-to-D':'PARTIAL MACHINE RESULT. Ordinary Skelet #10 steps preserve Scan or reach D. This says nothing about continuing from an arbitrary D configuration, and is not whole-machine nonhalting.',
'skelet17-ladder-skelet10-blank-enters-right-scan':'Every ordinary first step of Skelet #10 from blank enters the right-scan invariant. No annotation is supplied in the computation definition.',
'skelet17-ladder-cycler-local':'Four exact configurations form an ordinary-step invariant. No induction is needed for this local theorem.',
'skelet17-ladder-translated-local':'Safety invariant: A has R=0 or (b=1,R=1); B has b=0,R=0 and odd L.',
'skelet17-ladder-counter-local':'Safety invariant: A scans 0; B has odd L; C scans 1 or has even R.',
'skelet17-ladder-bouncer-local':'The bouncer product and its residue modulo 3 exclude C0. Products and bounded Pow2 replace exponential tape-length notation.',
'skelet17-ladder-fractal-local':'The fractal needs only: A has even R; B scans 0; C and D are unrestricted.',
'skelet17-ladder-finned3-local':'Preserve one bounded existential invariant through an ordinary step. The only extra premises are the target tape bounds already supplied by a raw history.',
'skelet17-ladder-finned3-history':'One bounded history induction constructs bounded phase witnesses at every supplied row. It does not assume an annotated computation.',
'skelet17-ladder-finned3-power-product':'Pow2 multiplication closure by one bounded strong-induction construction, with earlier arithmetic reused.',
}
MACHINES={'cycler':'1RB0RB_0LA---','translated':'1RB1RA_1LA---','counter':'1RB---_1LC1RB_0RA0LC',
 'bouncer':'1RB0LC_0LC1RA_---1LA','fractal':'1RB0LA_1RC---_0RD0RC_1LD0LA',
 'finned3':'1RB1RE_1LC1RB_0RA0LD_1LB1LD_---0RA'}
for name,machine in MACHINES.items():
 NOTES['skelet17-ladder-'+name+'-no-blank-halting-history']='NONHALTING: '+machine+'. Excludes every supplied ordinary blank-start halting history in the original beta format. No invariant is supplied in this statement.'

def main():
 began=time.time();path=P/'idelta0_machines.mm';layout=P/'idelta0_compact_raw.mm'
 stats=compact_layout(path,layout)
 source=layout.read_text();records,rules,variables=parse_intern(source)
 print('Parsed',len(rules),'labelled statements.',flush=True)
 axioms={r['label']:exact(r,rules) for r in records if r['kind']=='a'}
 roots=[k for k,r in rules.items() if r['kind']=='p' and public(k)]
 interfaces={k:exact(rules[k],rules) for k in roots}
 groups=defaultdict(list);alias={}
 for r in records:
  if r['kind'] not in ('a','p'):continue
  data,mask=signature(r,rules);key=hashlib.sha256(data.encode()).digest();match=None
  for label,oldmask in groups[key]:
   if oldmask&~mask:continue
   if signature(rules[label],rules)[0]==data:match=label;break
  if match is not None and r['kind']=='p':alias[r['label']]=match
  else:groups[key].append((r['label'],mask))
 print('Schema-equivalent proofs:',len(alias),flush=True)
 rewritten={};deps={}
 def proof(label):
  if label not in rewritten:
   r=rules[label]
   if label in alias:
    labels=[*r['hyps'],alias[label]];rewritten[label]=' '.join(labels);deps[label]=set(labels)
   else:rewritten[label],deps[label]=rewrite(r,alias)
  return rewritten[label]
 keep=set();todo=[*roots,*axioms]
 while todo:
  label=todo.pop()
  if label in keep:continue
  keep.add(label);r=rules[label]
  if r['kind']=='p':proof(label);todo.extend(deps[label])
  todo.extend(r.get('hyps',[]))
 inlined=inline_single_use(keep,rules,rewritten,deps,proof)
 live=set()
 for label in keep:live.update(set(rules[label]['expr'])&variables)
 # Preserve original scope structure first; remove only transparent or empty
 # wrappers afterward. Labelled assertions are globally available in Metamath.
 tree=[];stack=[tree]
 for r in records:
  k=r['kind'];label=r.get('label')
  if k=='{':child=[];stack[-1].append(child);stack.append(child);continue
  if k=='}':stack.pop();continue
  if k in ('a','p','f','e') and label not in keep:continue
  if k=='v':
   fields=[x for x in r['expr'] if x in live]
   if fields:stack[-1].append({**r,'expr':fields})
  elif k=='d':
   fields=[x for x in r['expr'] if x in live]
   if len(fields)>1:stack[-1].append({**r,'expr':fields})
  else:stack[-1].append(r)
 assert len(stack)==1
 removed_scopes=0
 def clean(xs,root=False):
  nonlocal removed_scopes
  out=[]
  for x in xs:
   if isinstance(x,list):out.extend(clean(x))
   else:out.append(x)
  material=any(isinstance(x,list) or x['kind']!='d' for x in out)
  if not root and not material:removed_scopes+=1;return []
  if not root and not any(not isinstance(x,list) and x['kind'] in ('c','v','f','e','d') for x in out):
   removed_scopes+=1;return out
  while True:
   children=[i for i,x in enumerate(out) if isinstance(x,list)]
   if len(children)!=1 or any(not isinstance(x,list) and x['kind']!='d' for x in out):break
   i=children[0];out=out[:i]+out[i]+out[i+1:];removed_scopes+=1
  return out if root else [out]
 tree=clean(tree,True);temp=path.with_suffix('.simplified.mm')
 milestones=set();declstats=Counter()
 def comment(out,text):out.write('$(\n'+textwrap.fill(text,96)+'\n$)\n')
 def emit(items,out):
  pending=set()
  def flush():
   if pending:
    text=pack_dv(tuple(sorted(pending)));out.write(text);declstats['output_dv_statements']+=text.count('$.');pending.clear()
  for r in items:
   if isinstance(r,list):flush();out.write('${\n');emit(r,out);out.write('$}\n');continue
   k=r['kind'];label=r.get('label')
   if k=='d':pending.update(tuple(sorted(e)) for e in itertools.combinations(r['expr'],2));continue
   flush()
   if k=='v':
    for prefix,file in [('oldmachine-','transitions_checked.mm'),('oldemission-','emissions_checked.mm'),('oldsyntax-','gray_syntax_checked.mm')]:
     if any(x.startswith(prefix) for x in r['expr']) and prefix not in milestones:
      milestones.add(prefix);out.write('$( Preserved results from '+file+'; shared proofs reused. $)\n')
    for name,title in [('ladderCq','INDIVIDUAL MACHINE LADDER'),('finnedHalf','FINNED #3: LOCAL PHASE PROOFS'),('finnedBoundGap','FINNED #3: UNIFORM WITNESS BOUNDS'),('finnedBoundParameter0','FINNED #3: BOUNDED INVARIANT AND HISTORY')]:
     if name in r['expr'] and name not in milestones:milestones.add(name);comment(out,title)
   if label in NOTES:comment(out,NOTES[label])
   if k=='p':
    out.write(label+' $p '+r['expr'][0]+'\n')
    out.write(textwrap.fill(' '.join(r['expr'][1:]),width=100,initial_indent='  ',subsequent_indent='  ',break_long_words=False,break_on_hyphens=False)+'\n$=\n')
    pr=proof(label)
    if pr.startswith('('):out.write('  '+pr+'\n')
    else:out.write(textwrap.fill(pr,width=100,initial_indent='  ',subsequent_indent='  ',break_long_words=False,break_on_hyphens=False)+'\n')
    out.write('$.\n\n')
   elif k in ('a','f','e'):out.write(label+' $'+k+' '+' '.join(r['expr'])+' $.\n')
   else:out.write('$'+k+' '+' '.join(r['expr'])+' $.\n')
  flush()
 with temp.open('w') as out:out.write(HEADER);emit(tree,out)
 # Exact public/core metadata is recorded for a fresh, post-write parse and
 # official verification. No old theorem is accepted as a new axiom.
 report={**stats,'output_bytes':temp.stat().st_size,'input_proofs':sum(r['kind']=='p' for r in records),
  'output_proofs':sum(rules[k]['kind']=='p' for k in keep),'named_interfaces':len(roots),
  'schema_equivalent_assertions':len(alias),'removed_transparent_or_empty_scopes':removed_scopes,
  'inlined_single_use_private_proofs':inlined,
  'discarded_private_proofs':sum(r['kind']=='p' and r['label'] not in keep for r in records),
  'retained_public_aliases':sum(k in alias for k in roots),'output_dv_statements':declstats['output_dv_statements'],
  'trusted_core_digest':digest_json(axioms),'interface_digests':{k:digest_json(v) for k,v in interfaces.items()},
  'axiom_digests':{k:digest_json(v) for k,v in axioms.items()},'aliases':alias,
  'elapsed_seconds':time.time()-began,'official_verification':'pending'}
 temp.replace(path)
 report['output_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 (P/'simplification_report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k not in ('aliases','interface_digests','axiom_digests')},indent=2),flush=True)

if __name__=='__main__':main()
