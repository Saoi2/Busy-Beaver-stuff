from pathlib import Path
import sys,json,hashlib,re
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse,rewrite
log=(P/'ladder_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
from simplify_metamath import parse_intern
prefix=(P/'idelta0_machines.mm').read_text()
rr,rules,_=parse_intern(prefix)
verified_count=int(re.search(r'93 are \$a and ([0-9]+) are \$p',log).group(1))
assert len(re.findall(r'(?m)^\S+ \$a ',prefix))==93
old,core,_=parse((P/'scan_checked.mm').read_text())
def axioms(rs,ds):return {r['label']:(r['expr'],[ds[h]['expr'] for h in r['hyps']],sorted(r['dv'])) for r in rs if r['kind']=='a'}
assert axioms(rr,rules)==axioms(old,core) and len(axioms(rr,rules))==93
cache={}
def deps(k):
 if k not in cache:cache[k]=rewrite(rules[k],{})[1] if rules[k]['kind']=='p' else set()
 return cache[k]
def closure(k):
 seen=set();todo=[k]
 while todo:
  j=todo.pop()
  if j in seen:continue
  seen.add(j);todo.extend(deps(j))
 return seen
metrics={}
for name,want in [('bb1-halting-trace',0),('bb2-halting-trace',0),('cycler-local',0),('cycler-history',1),('cycler-no-blank-halting-history',1),('translated-local',0),('translated-history',1),('translated-no-blank-halting-history',1),('counter-local',0),('counter-history',1),('counter-no-blank-halting-history',1),('bouncer-power-factors',0),('bouncer-odd-power',0),('bouncer-local',1),('bouncer-history',2),('bouncer-no-blank-halting-history',2),('fractal-local',0),('fractal-history',1),('fractal-no-blank-halting-history',1),('finned3-a0-to-b',1),('finned3-a1-to-e1',1),('finned3-e1-to-a',0),('finned3-b1-scan',1),('finned3-b0-work-to-c1',0),('finned3-b0-final-to-c0',0),('finned3-c0-final-to-a1',0),('finned3-d1-scan',1),('finned3-d0-to-b',1),('finned3-power-product',2),('finned3-c1-to-d',2),('finned3-tape-linear-bound',0),('finned3-left-scale-bound',0),('finned3-square-scale-bound',0),('finned3-right-scales-bound',0),('finned3-local',2),('finned3-history',3),('finned3-no-blank-halting-history',3),('skelet10-sparse-zero',0),('skelet10-sparse-pop',1),('skelet10-sparse-odd-tail',1),('skelet10-double-window-bound',0),('skelet10-sparse-push',1),('skelet10-sparse-prefix-0',1),('skelet10-sparse-prefix-10',1),('skelet10-right-scan-to-D',1),('skelet10-blank-enters-right-scan',0),('skelet10-left-exit-five-step',0),('skelet10-left-carry-four-step',0),('skelet10-return-clear-four-step',0),('skelet10-left-zero-return-to-scan',0),('skelet10-bit-support-bound',0),('skelet10-zero-has-no-one-bit',0),('skelet10-bit-push-forward',0),('skelet10-bit-push-back',1),('skelet10-bit-low-digit',0),('skelet10-spread-zero',0),('skelet10-spread-push',1),('skelet10-spread-exists-quadratic',2),('skelet10-transform-zero',0),('skelet10-transform-prefix-0',1),('skelet10-transform-prefix-10',1),('skelet10-transform-exists-quadratic',2),('skelet10-spread-low-digit',0),('skelet10-spread-second-bit-zero',1),('skelet10-spread-pop',1),('skelet10-spread-decompose',1),('skelet10-transform-pop-0',1),('skelet10-transform-pop-10',1),('skelet10-return-marker-step',0),('skelet10-return-window-invariant',1),('skelet10-return-window-bound',1),('skelet10-return-window-exit',1),('skelet10-return-window-halting-barrier',1),('skelet10-right-counter-entry',0),('skelet10-right-counter-step',1),('skelet10-right-window-invariant',2),('skelet10-right-window-bound',2),('skelet10-right-window-exit',2),('skelet10-right-window-halting-barrier',2),('skelet10-transform-decompose-0',1),('skelet10-transform-decompose-10',1),('skelet10-left-return-entry',0),('skelet10-left-return-step',1),('skelet10-left-return-window-invariant',2),('skelet10-left-return-window-bound',2),('skelet10-left-return-window-exit',2),('skelet10-left-return-window-halting-barrier',2),('skelet10-left-counter-entry',0),('skelet10-left-counter-step',1),('skelet10-left-window-invariant',2),('skelet10-left-window-bound',2),('skelet10-left-window-exit',2),('skelet10-left-window-halting-barrier',2),('skelet10-carry-strict-growth',0),('skelet10-carry-base',0),('skelet10-carry-prefix',1),('skelet10-carry-base-inverse',1),('skelet10-carry-prefix-inverse',1),('skelet10-carry-unique-sparse',2),('skelet10-boundary-even-output',1),('skelet10-a0-enters-right-counter',0),('skelet10-right-output-align-odd',1),('skelet10-left-output-identify',2),('skelet10-left-entry-two-step',0),('skelet10-return-clear-two-step',0),('skelet10-even-right-enters-counter',0),('history-beta-value-unique',0),('history-row-unique',0),('history-total-suffix',0),('history-steps-suffix',0),('history-advance-before-halt',0),('history-positive-row-bit',0),('skelet10-right-embedded-halting-barrier',2),('skelet10-left-embedded-halting-barrier',2),('skelet10-odd-boundary-cycle',4),('skelet10-even-zero-boundary-cycle',2),('skelet10-even-one-boundary-cycle',4),('skelet10-boundary-progress',4),('skelet10-boundary-index-maximum',1),('skelet10-no-halting-history-with-boundary',5),('skelet10-no-blank-halting-history',5)]:
 key='skelet17-ladder-'+name
 nodes=sorted(j for j in closure(key) if 'ax-ind-bounded' in deps(j))
 assert len(nodes)==want,(key,nodes)
 metrics[key]={'bounded_induction_nodes':nodes,'count':len(nodes)}
statements=json.loads((P/'ladder_theorems.json').read_text())
endpoint='skelet17-ladder-finned3-no-blank-halting-history'
assert rules[endpoint]['expr']==['|-','[]','=>',*statements[endpoint].split()]
import subprocess
subprocess.run([sys.executable,str(P/'check_finned3_endpoint_scope.py')],check=True,capture_output=True)
endpoint_scope=json.loads((P/'finned3_endpoint_scope.json').read_text())
assert endpoint_scope['matches_independent_raw_history_formula'] and not endpoint_scope['auxiliary_certificates_in_statement']
z10statements=json.loads((P/'skelet10_theorems.json').read_text())
for label,formula in z10statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_scope.py')],check=True,capture_output=True)
left_statements=json.loads((P/'skelet10_left_theorems.json').read_text())
for label,formula in left_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_left.py')],check=True,capture_output=True)
spread_statements=json.loads((P/'skelet10_spread_theorems.json').read_text())
for label,formula in spread_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_spread.py')],check=True,capture_output=True)
inverse_statements=json.loads((P/'skelet10_inverse_theorems.json').read_text())
for label,formula in inverse_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_inverse.py')],check=True,capture_output=True)
return_statements=json.loads((P/'skelet10_return_theorems.json').read_text())
for label,formula in return_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_return.py')],check=True,capture_output=True)
right_statements=json.loads((P/'skelet10_right_theorems.json').read_text())
for label,formula in right_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_right.py')],check=True,capture_output=True)
clear_statements=json.loads((P/'skelet10_clear_theorems.json').read_text())
for label,formula in clear_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_clear.py')],check=True,capture_output=True)
full_left_statements=json.loads((P/'skelet10_full_left_theorems.json').read_text())
for label,formula in full_left_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_full_left.py')],check=True,capture_output=True)
sync_statements=json.loads((P/'skelet10_sync_theorems.json').read_text())
for label,formula in sync_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_sync.py')],check=True,capture_output=True)
inverse_carry_statements=json.loads((P/'skelet10_inverse_carry_theorems.json').read_text())
for label,formula in inverse_carry_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_sync_inverse.py')],check=True,capture_output=True)
odd_carry_statements=json.loads((P/'skelet10_odd_carry_theorems.json').read_text())
for label,formula in odd_carry_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_odd_carry.py')],check=True,capture_output=True)
unique_carry_statements=json.loads((P/'skelet10_unique_carry_theorems.json').read_text())
for label,formula in unique_carry_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_carry_unique.py')],check=True,capture_output=True)
boundary_statements=json.loads((P/'skelet10_boundaries_theorems.json').read_text())
for label,formula in boundary_statements.items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
subprocess.run([sys.executable,str(P/'check_skelet10_boundaries.py')],check=True,capture_output=True)
for export,checker in [('skelet10_alignments_theorems.json','check_skelet10_alignments.py'),('history_tools_theorems.json','check_history_tools.py'),('history_assembly_theorems.json','check_history_assembly.py'),('skelet10_odd_cycle_theorems.json','check_skelet10_odd_cycle.py'),('skelet10_even_zero_theorems.json','check_skelet10_even_zero_cycle.py'),('skelet10_even_one_theorems.json','check_skelet10_even_one_cycle.py'),('skelet10_progress_theorems.json','check_skelet10_progress.py'),('skelet10_maximum_theorems.json','check_skelet10_maximum.py'),('skelet10_global_theorems.json','check_skelet10_global.py')]:
 for label,formula in json.loads((P/export).read_text()).items():assert rules[label]['expr']==['|-','[]','=>',*formula.split()]
 subprocess.run([sys.executable,str(P/checker)],check=True,capture_output=True)
wanted={'oldmachine-skelet17-','oldemission-skelet17-','oldsyntax-skelet17-'}
with (P/'idelta0_machines.mm').open() as stream:
 for line in stream:
  for key in list(wanted):
   if line.startswith(key) and ' $p ' in line:wanted.remove(key)
  if not wanted:break
assert not wanted
files=['ladder_skelet10_boundary_progress.py','ladder_skelet10_boundary_maximum.py','ladder_skelet10_boundary_exclusion.py','ladder_skelet10_blank_endpoint.py','extend_skelet10_progress.py','extend_skelet10_maximum.py','extend_skelet10_global.py','check_skelet10_progress.py','check_skelet10_maximum.py','check_skelet10_global.py','skelet10_progress_theorems.json','skelet10_maximum_theorems.json','skelet10_global_theorems.json','skelet10_progress_checks.json','skelet10_maximum_checks.json','skelet10_global_checks.json','SKELET10_NONHALTING.md','resume_streaming.py','scope_new_extension.py','ladder_skelet10_even_one_cycle.py','extend_skelet10_even_one_cycle.py','check_skelet10_even_one_cycle.py','skelet10_even_one_theorems.json','skelet10_even_one_checks.json','SKELET10_EVEN_ONE_CYCLE.md','ladder_skelet10_even_zero_cycle.py','extend_skelet10_even_zero_cycle.py','check_skelet10_even_zero_cycle.py','skelet10_even_zero_theorems.json','skelet10_even_zero_checks.json','SKELET10_EVEN_ZERO_CYCLE.md','ladder_skelet10_odd_cycle.py','extend_skelet10_odd_cycle.py','check_skelet10_odd_cycle.py','skelet10_odd_cycle_theorems.json','skelet10_odd_cycle_checks.json','SKELET10_ODD_BOUNDARY_CYCLE.md','repack_declarations.py','declaration_repack_report.json','ladder_history_assembly.py','extend_history_assembly.py','check_history_assembly.py','history_assembly_theorems.json','history_assembly_checks.json','HISTORY_ASSEMBLY.md','ladder_skelet10_alignments.py','extend_skelet10_alignments.py','check_skelet10_alignments.py','skelet10_alignments_theorems.json','skelet10_alignments_checks.json','SKELET10_FINITE_ALIGNMENTS.md','ladder_history_tools.py','extend_history_tools.py','check_history_tools.py','history_tools_theorems.json','history_tools_checks.json','HISTORY_TOOLS.md','ladder_skelet10_boundaries.py','extend_skelet10_boundaries.py','check_skelet10_boundaries.py','skelet10_boundaries_theorems.json','skelet10_boundaries_checks.json','SKELET10_BOUNDARY_CONNECTIONS.md','ladder_skelet10_carry_unique.py','extend_skelet10_carry_unique.py','check_skelet10_carry_unique.py','skelet10_unique_carry_theorems.json','skelet10_unique_carry_checks.json','SKELET10_CARRY_UNIQUENESS.md','SKELET10_UNIQUENESS_PLAN.md','refresh_extension_report.py','ladder_skelet10_carry_odd_inverse.py','extend_skelet10_carry_odd_inverse.py','check_skelet10_odd_carry.py','skelet10_odd_carry_theorems.json','skelet10_odd_carry_checks.json','SKELET10_ODD_INVERSE.md','merge_checked_extension.py','ladder_skelet10_sync_inverse.py','extend_skelet10_sync_inverse.py','check_skelet10_sync_inverse.py','skelet10_inverse_carry_theorems.json','skelet10_inverse_carry_checks.json','SKELET10_BASE_INVERSE.md','ladder_skelet10_sync.py','extend_skelet10_sync.py','check_skelet10_sync.py','skelet10_sync_theorems.json','skelet10_sync_checks.json','SKELET10_SYNCHRONIZATION.md','SKELET10_GLOBAL_PLAN.md','explore_skelet10_cycle.py','skelet10_cycle_experiment.json','ladder_skelet10_full_left.py','ladder_skelet10_full_left_steps.py','ladder_skelet10_full_left_history.py','extend_skelet10_full_left.py','check_skelet10_full_left.py','skelet10_full_left_theorems.json','skelet10_full_left_checks.json','SKELET10_LEFT_ROUTINE.md','explore_skelet10_left_scan.py','skelet10_left_scan_experiment.json','ladder_skelet10_blocks.py','ladder_skelet10_clear.py','ladder_skelet10_clear_history.py','extend_skelet10_clear.py','skelet10_clear_theorems.json','check_skelet10_clear.py','skelet10_clear_checks.json','SKELET10_LEFT_RETURN.md','SKELET10_LEFT_SCAN_PLAN.md','ladder_skelet10_right.py','ladder_skelet10_right_history.py','extend_skelet10_right.py','skelet10_right_theorems.json','check_skelet10_right.py','skelet10_right_checks.json','SKELET10_RIGHT_ROUTINE.md','SKELET10_LEFT_PLAN.md','ladder_skelet10_return.py','extend_skelet10_return.py','skelet10_return_theorems.json','check_skelet10_return.py','skelet10_return_checks.json','SKELET10_RETURN.md','SKELET10_RIGHT_PLAN.md','ladder_skelet10_inverse.py','extend_skelet10_inverse.py','skelet10_inverse_theorems.json','check_skelet10_inverse.py','skelet10_inverse_checks.json','SKELET10_DECODING.md','ladder_skelet10_spread.py','extend_skelet10_spread.py','skelet10_spread_theorems.json','check_skelet10_spread.py','skelet10_spread_checks.json','SKELET10_SPREAD.md','explore_skelet10_boundaries.py','skelet10_boundary_experiment.json','ladder_skelet10_left.py','extend_skelet10_left.py','skelet10_left_theorems.json','check_skelet10_left.py','skelet10_left_checks.json','SKELET10_LEFT_COUNTER.md','preceding_checkpoint_report.json','ladder_skelet10.py','resume_canonical.py','extend_skelet10.py','skelet10_theorems.json','check_skelet10_scope.py','skelet10_scope.json','check_skelet10_fragment.py','skelet10_fragment_checks.json','SKELET10_RIGHT_COUNTER.md','simplification_baseline_report.json','prune.py','simplify_metamath.py','audit_simplification.py','simplification_report.json','SIMPLIFICATION.md','rebuild_project.py','idelta0_machines.mm','build_ladder.py','ladder_endpoint.py','ladder_translated.py','ladder_counter.py','translated_history_generated.py','translated_endpoint_generated.py','counter_history_generated.py','counter_endpoint_generated.py','bouncer_arithmetic.py','ladder_bouncer.py','bouncer_history_generated.py','bouncer_endpoint_generated.py','check_bouncer_invariant.py','bouncer_invariant_checks.json','ladder_fractal.py','fractal_history_generated.py','fractal_endpoint_generated.py','check_fractal_invariant.py','fractal_invariant_checks.json','FRACTAL_SAFETY.md','ladder_finned3_sweeps.py','check_finned3_certificate.py','finned3_certificate_checks.json','FINNED3_INVARIANT.md','FINNED3_NEXT_STEPS.md','finned3_bounds.py','ladder_finned3_global.py','ladder_finned3_history.py','finned3_history_generated.py','finned3_endpoint_generated.py','check_finned3_endpoint_scope.py','finned3_endpoint_scope.json','ladder_history_generated.py','resume_project.py','merge_previous_results.py','ladder_verification.log','ladder_traces.json','LADDER_PROGRESS.md','audit_ladder.py']
def file_hash(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
out={'canonical_project_file':'idelta0_machines.mm','trusted_declarations':93,'trusted_core_unchanged':True,
 'skelet10_carry_even_inverse_kernel_verified':True,'skelet10_canonical_boundary_connections':True,'skelet10_two_step_alignments':True,'shared_history_row_uniqueness':True,'shared_history_suffix_transport':True,'skelet10_routines_embedded_in_original_history':True,'history_finite_prefix_advance':True,'history_positive_row_bit_bound':True,'skelet10_complete_boundary_compositions':True,'skelet10_odd_boundary_composition':True,'skelet10_even_zero_boundary_composition':True,'skelet10_even_one_boundary_composition':True,'skelet10_proved_boundary_cases':3,'skelet10_remaining_boundary_cases':0,'skelet10_carry_uniqueness_on_sparse_inputs':True,'skelet10_carry_odd_inverse_kernel_verified':True,'inverse_dependency_audit_pending':False,'proofs_verified':True,'proved_statement_count':verified_count,'new_results':metrics,
 'cycler_nonhalting_in_original_beta_history_format':True,'full_BB1_value_assembled':False,'full_BB2_value_assembled':False,
 'translated_cycler_ladder_rung_added_this_checkpoint':True,'counter_nonhalting_in_original_beta_history_format':True,'bouncer_nonhalting_in_original_beta_history_format':True,'fractal_nonhalting_in_original_beta_history_format':True,'finned3_phase_preservation_interfaces':10,'finned3_full_nonhalting':True,'finned3_auxiliary_bounds_formalized':True,'finned3_history_lift_assembled':True,'finned3_endpoint_matches_independent_raw_history_formula':True,'skelet10_bounded_transform_block_tails':True,'skelet10_whole_A_clearing_return':True,'skelet10_complete_left_counter':True,'skelet10_whole_right_counter_contract':True,'skelet10_right_output_carry_and_sparse':True,'skelet10_D_return_phase_completed':True,'skelet10_return_phase_bounded_history':True,'skelet10_return_phase_no_premature_halt':True,'skelet10_complete_counter_cycle':True,'skelet10_spread_exact_digit_decoding':True,'skelet10_left_grammar_both_directions':True,'skelet10_bounded_spread_totality':True,'skelet10_bounded_transform_totality':True,'skelet10_spread_uniqueness_formalized':False,'skelet10_left_finite_contracts':4,'skelet10_zero_boundary_returns_to_scan':True,'skelet10_right_scan_fragment':True,'skelet10_whole_nonhalting':True,'skelet17_nonhalting':False,
 'files':{f:{'bytes':(P/f).stat().st_size,'sha256':file_hash(P/f)} for f in files}}
(P/'ladder_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='files'},indent=2))
