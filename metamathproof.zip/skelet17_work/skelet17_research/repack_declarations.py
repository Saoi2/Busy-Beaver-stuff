"""Pack consecutive DV declarations, preserving exactly the same pair graph.

No assertion, proof or axiom is simplified by this pass. compact_layout
asserts exact equality of the represented pair sets in every packed block.
The old canonical bytes are retained as a reproducible raw backup until
the independently invoked full kernel check and audits pass.
"""
from pathlib import Path
import json,os
from simplify_metamath import compact_layout
P=Path(__file__).resolve().parent
canonical=P/'idelta0_machines.mm';packed=P/'idelta0_declarations_packed_raw.mm'
backup=P/'idelta0_before_repack_raw.mm'
assert not backup.exists()
stats=dict(compact_layout(canonical,packed))
stats.update(kind='declaration-layout-only',assertions_and_proofs_changed=False,output_bytes=packed.stat().st_size)
assert stats['output_bytes']<=stats['input_bytes']
os.replace(canonical,backup);os.replace(packed,canonical)
(P/'declaration_repack_report.json').write_text(json.dumps(stats,indent=2)+'\n')
print(stats,flush=True)
