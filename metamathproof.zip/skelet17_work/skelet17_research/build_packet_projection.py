"""Project globally packed joint records to the original partial emissions.

All arithmetic formulas expand in the original first-order language.  No
new axioms, machine encoding, induction instance, or compressed output is used.
"""
import json
import build_packet_parser as r
n,m,nd,b,a=r.n,r.m,r.nd,r.b,r.a
A,M,Q,L,O,Z,N=n.A,n.M,n.Q,n.L,n.O,n.Z,n.N
two,base=n.two,n.eight
eight=a.num(8);sixteen=a.num(16)
eq,rewrite,bound,invoke,finish,save,flip=n.eq,n.rewrite,n.bound,n.invoke,n.finish,n.save,n.flip
old,bit,new=[m.declare('projection'+s,'term') for s in ('Old','Input','New')]
lo,hi,flag,value=[m.declare('projection'+s) for s in ('Before','After','Flag','Value')]
CONTROL=[[0,4],[0,5],[0,6],[0,7],[2,4],[3,5],[0,5],[1,4]]
ORIGINAL=[(i,j) for i in range(8) for j in range(2) if i>=4 or j==1]
def event(i,j):
    f=int(i>=4 and j==1)
    return f,CONTROL[i][j]%2 if f else 0
def emission_row(av,bv,cv,f,v,i,j):
    fi,vi=event(i,j)
    return nd.AND([Q(av,a.num(i)),Q(bv,a.num(j)),Q(cv,a.num(CONTROL[i][j])),Q(f,a.num(fi)),Q(v,a.num(vi))])
def EMIT(av,bv,cv,f,v):
    return nd.OR([emission_row(av,bv,cv,f,v,i,j) for i,j in ORIGINAL])
def parts(old,bit,new,av,cv,f,v):
    return [n.FIELD(old,O,eight,av),n.FIELD(new,O,eight,cv),
            Q(new,A(A(cv,M(eight,f)),M(sixteen,v))),EMIT(av,bit,cv,f,v)]
def PROJECT(old,bit,new):
    return nd.BEX(lo,eight,nd.BEX(hi,eight,nd.BEX(flag,two,nd.BEX(value,two,nd.AND(parts(old,bit,new,lo,hi,flag,value))))))
def low_field(ctx,record,control):
    payload=record//8;cv=a.num(control)
    bound(ctx,Z,eight,a.num(7));bound(ctx,cv,eight,a.num(7-control))
    eq(ctx,a.num(record),A(M(eight,a.num(payload)),cv))
    fs=[L(Z,eight),Q(a.num(record),A(M(eight,a.num(payload)),cv)),L(cv,eight)]
    nd.conj(ctx,fs)
    invoke(ctx,'skelet17-packet-low-field',{'annInput':a.num(record),'annPrefix':a.num(payload),'annBase':eight,'annValue':cv})
def local_projection():
    prem=r.PARTIAL(old,bit,new);goal=PROJECT(old,bit,new)
    root=nd.Ctx();ctx=root.push(prem)
    def row(ec,k):
        i,j=r.VALID[k];c=n.TABLE[i][j];ci=i%8;co=CONTROL[ci][j];f,v=event(ci,j)
        assert c==co+8*f+16*v
        nd.unpack(ec,[Q(old,a.num(i)),Q(bit,a.num(j)),Q(new,a.num(c))])
        low_field(ec,i,ci)
        rewrite(ec,n.FIELD(a.E,O,eight,a.num(ci)),a.num(i),old,ec.get(flip(ec,Q(old,a.num(i)))))
        low_field(ec,c,co)
        rewrite(ec,n.FIELD(a.E,O,eight,a.num(co)),a.num(c),new,ec.get(flip(ec,Q(new,a.num(c)))))
        eq(ec,new,A(A(a.num(co),M(eight,a.num(f))),M(sixteen,a.num(v))),[Q(new,a.num(c))])
        for const in [ci,co,f,v]:ec.put(Q(a.num(const),a.num(const)),b.refl(ec.g,a.num(const)))
        fields=[Q(a.num(ci),a.num(ci)),Q(bit,a.num(j)),Q(a.num(co),a.num(co)),Q(a.num(f),a.num(f)),Q(a.num(v),a.num(v))]
        nd.conj(ec,fields)
        nd.disj(ec,[emission_row(a.num(ci),bit,a.num(co),a.num(f),a.num(v),u,w) for u,w in ORIGINAL],ORIGINAL.index((ci,j)))
        for const,upper in [(ci,eight),(co,eight),(f,two),(v,two)]:bound(ec,a.num(const),upper,a.num((8 if upper==eight else 2)-const-1))
        nd.conj(ec,parts(old,bit,new,a.num(ci),a.num(co),a.num(f),a.num(v)))
        m.bex_intro(ec,value,two,nd.AND(parts(old,bit,new,a.num(ci),a.num(co),a.num(f),value)),a.num(v))
        m.bex_intro(ec,flag,two,nd.BEX(value,two,nd.AND(parts(old,bit,new,a.num(ci),a.num(co),flag,value))),a.num(f))
        m.bex_intro(ec,hi,eight,nd.BEX(flag,two,nd.BEX(value,two,nd.AND(parts(old,bit,new,a.num(ci),hi,flag,value)))),a.num(co))
        return m.bex_intro(ec,lo,eight,nd.BEX(hi,eight,nd.BEX(flag,two,nd.BEX(value,two,nd.AND(parts(old,bit,new,lo,hi,flag,value))))),a.num(ci))
    nd.cases(ctx,[r.clause(old,bit,new,i,j) for i,j in r.VALID],goal,row)
    finish('skelet17-packet-original-emission-projection',root,prem,goal,ctx,
           'Each of the 48 surviving joint-recorder rows projects to one of the original 12 partial emission rules. The emission flag and value are encoded in the actual next record, not freely supplied pointwise annotations. No induction.')
local_projection()
def PBODY(x,R,p,av,bv,cv):
    return nd.AND(n.list_body(x,R,p,av,bv,cv)[:3]+[PROJECT(av,bv,cv)])
def PLOCAL(x,R,p):
    return nd.BEX(n.av,base,nd.BEX(n.bv,two,nd.BEX(n.cv,base,PBODY(x,R,p,n.av,n.bv,n.cv))))
def PRUN(x,R):
    return nd.BALL(n.place,A(x,O),b.Imp(m.power2(n.place),PLOCAL(x,R,n.place)))
def lift():
    prem=r.ORUN(n.x,n.s);root=nd.Ctx();ctx=root.push(prem)
    p=n.pf;guard=L(p,A(n.x,O));gc=ctx.push(guard);pc=gc.push(m.power2(p));goal=PLOCAL(n.x,n.s,p)
    _,ip=pc.all_elim(n.place,prem[2],p)
    pc.mp(guard,b.Imp(m.power2(p),r.OLOCAL(n.x,n.s,p)),ip);pc.mp(m.power2(p),r.OLOCAL(n.x,n.s,p))
    def first(ac):
        def second(bc):
            def third(cc):
                nd.unpack(cc,n.list_body(n.x,n.s,p,n.af,n.bf,n.cf)[:3]+[r.PARTIAL(n.af,n.bf,n.cf)])
                invoke(cc,'skelet17-packet-original-emission-projection',{'projectionOld':n.af,'projectionInput':n.bf,'projectionNew':n.cf})
                nd.conj(cc,n.list_body(n.x,n.s,p,n.af,n.bf,n.cf)[:3]+[PROJECT(n.af,n.bf,n.cf)])
                m.bex_intro(cc,n.cv,base,PBODY(n.x,n.s,p,n.af,n.bf,n.cv),n.cf)
                m.bex_intro(cc,n.bv,two,nd.BEX(n.cv,base,PBODY(n.x,n.s,p,n.af,n.bv,n.cv)),n.bf)
                return m.bex_intro(cc,n.av,base,nd.BEX(n.bv,two,nd.BEX(n.cv,base,PBODY(n.x,n.s,p,n.av,n.bv,n.cv))),n.af)
            return m.bex_elim(bc,n.cv,base,r.OBODY(n.x,n.s,p,n.af,n.bf,n.cv),n.cf,goal,third)
        return m.bex_elim(ac,n.bv,two,nd.BEX(n.cv,base,r.OBODY(n.x,n.s,p,n.af,n.bv,n.cv)),n.bf,goal,second)
    m.bex_elim(pc,n.av,base,nd.BEX(n.bv,two,nd.BEX(n.cv,base,r.OBODY(n.x,n.s,p,n.av,n.bv,n.cv))),n.af,goal,first)
    gc.intro(m.power2(p),goal,pc);ctx.intro(guard,b.Imp(m.power2(p),goal),gc)
    ctx.all_intro(p,b.Imp(guard,b.Imp(m.power2(p),goal)))
    m.rename_all(ctx,p,n.place,lambda q:b.Imp(L(q,A(n.x,O)),b.Imp(m.power2(q),PLOCAL(n.x,n.s,q))))
    finish('skelet17-packet-original-emission-run',root,prem,PRUN(n.x,n.s),ctx,
           'The same global packed integer realizes the original parser emissions at every significant input place. No output compression or emission count is asserted. No new induction.')
lift()
def CERT_BODY(x,p,R):
    return nd.AND([m.power2(p),L(x,M(two,p)),L(R,M(base,n.power5(p))),PRUN(x,R)])
def exists():
    fs=[r.WORD(n.x),L(Z,n.x)];prem=b.And(*fs)
    goal=nd.BEX(n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),CERT_BODY(n.x,n.lead,n.codevar)))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    invoke(ctx,'skelet17-packet-parser-original-certificate-exists')
    def place(pc):
        def code(sc):
            nd.unpack(sc,[m.power2(n.lp),L(n.x,M(two,n.lp)),L(n.st,M(base,n.power5(n.lp))),r.ORUN(n.x,n.st)])
            invoke(sc,'skelet17-packet-original-emission-run',{'annStates':n.st})
            nd.conj(sc,[m.power2(n.lp),L(n.x,M(two,n.lp)),L(n.st,M(base,n.power5(n.lp))),PRUN(n.x,n.st)])
            m.bex_intro(sc,n.codevar,n.K(n.x),CERT_BODY(n.x,n.lp,n.codevar),n.st)
            return m.bex_intro(sc,n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),CERT_BODY(n.x,n.lead,n.codevar)),n.lp)
        return m.bex_elim(pc,n.codevar,n.K(n.x),r.OCERT_BODY(n.x,n.lp,n.codevar),n.st,goal,code)
    m.bex_elim(ctx,n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),r.OCERT_BODY(n.x,n.lead,n.codevar)),n.lp,goal,place)
    finish('skelet17-packet-original-emission-certificate',root,prem,goal,ctx,
           'Every positive valid input has one polynomially bounded joint-record integer whose fields project to original parser controls and original emission flags and values. Reuses exactly the two existing bounded induction constructions. EOF and compressed output are separate obligations.')
exists()
for name,formula in [('projection',PROJECT(old,bit,new)),('run',PRUN(n.x,n.s))]:
    syntax=nd.classify(formula)
    b.lines.append('skelet17-packet-original-emission-'+name+'-bounded $p bnd '+b.tok(formula)+' $= '+' '.join(syntax.labels)+' $.')
def write():
    (m.P/'packet_projection_raw.mm').write_text('\n'.join(b.lines)+'\n')
    (m.P/'packet_projection_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if 'packet-original-emission-' in k},indent=2)+'\n')
if __name__=='__main__':write()
