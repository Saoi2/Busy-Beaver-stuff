Status update: the complete left-counter routine is now formalized; see SKELET10_LEFT_ROUTINE.md. Global synchronization and nonhalting are still open in this project. The proposal below is retained as development history.

# Next target: the complete left-counter routine

This was the proposed route to the left-counter proof. The two bounded
transform block-tail interfaces and the entire A1 return phase are now
proved; read SKELET10_LEFT_RETURN.md. The D/C carry scan and connection to
the complete left-counter endpoint are still unfinished. The proposal
below is retained as design context; SKELET10_LEFT_SCAN_PLAN.md gives the
updated proposed microphases.

## Desired interface

Write T(w,t) for the existing bounded left-word transform graph, and use
the same bounded carry relation J as in the new right-counter theorem.
The expected left routine starts with

    q=D,  WholeLeft=t,  T(w,t),  Sparse(w),  R=4r+3.

It should reach A with

    WholeRight=r,  T(v,L),  J(w,v),  Sparse(v).

The output whole right word includes its scanned bit; the output left
half L does not. This is an interface for the same ordinary Step, not a
proposed macro instruction or annotated history definition.

## First missing arithmetic interfaces

The existing inverse rules assume the output's block shape already:

    T(2a,4t) -> T(a,t),
    T(4a+1,16t+10) -> T(a,t).

For a machine phase that only knows T(w,t), it is more convenient to
recover a bounded block tail:

    T(2a,z) -> exists t<z+1, z=4t and T(a,t),
    T(4a+1,z) -> exists t<z+1, z=16t+10 and T(a,t).

These should follow directly from the proved spread-decomposition theorem
and the definition T=10*Dil. Neither graph uniqueness nor a new induction
looks necessary. Keep numerical coefficients factored when deriving the
scaled output equations and bounds.

## How the fixed contracts fit together

For an even input w=2a, let the decoded left output be t with T(a,t).
Then the initial whole left word is 4t, so L=2t and b=0. The existing
five-step exit contract, with r=2y+d, gives an A row with

    L=16t+10,   b=d,   R=y.

Thus its whole right word is r, its left half satisfies T(4a+1,L), and
the carry graph's base output is v=4a+1. This is the base of the routine.

For w=4a+1, the decoded whole left word is 16t+10 with T(a,t). The
four-step carry contract removes that low 1010 block, leaving whole left
t and replacing the right half y by 16y+15. When y=4r+3, this equals

    16*(4r+3)+15 = 4*(16r+15)+3.

So the smaller left problem has tail parameter r'=16r+15. If that smaller
problem returns an A row with T(v0,L) and whole right r', the four A1
clearing steps return to whole right r and left half 16L. The two zero
constructors give T(4v0,16L), matching the carry operation's recursive
output. A proof must implement this reasoning on actual ordinary rows,
including safety inside the fixed blocks.

## Candidate invariants and bounds

After k consumed 10 blocks, let p=4^k and s=(p-1)/3 as in the right-side
carry graph. Exponent notation here is only an explanation; the proposed
formulas use Pow2(p), p=3s+1 and arithmetic equations. The current input
u and original input w should satisfy

    w=p*u+s.

Removing each transformed block divides the whole left word by 16 and
prefixes four 1s to the right. If the original transformed whole left is
t0, current whole left is t and original right half is R0, the corresponding
numerical identities are

    3*t0+2 = p*p*(3*t+2),
    R+1 = p*p*(R0+1).

For example t0=T(5)=170: after one block t=10 and p=4, and
3*170+2=16*(3*10+2). After another block t=0 and p=16, giving 512=256*2.
These equations are exploratory invariants; their bounded witnesses,
initialization and preservation have not yet been formalized.

During the A return, one can track a current output word v0 with T(v0,L)
and a fixed final output v=p*v0. Four clearing steps multiply v0 by 4
and L by 16 while dividing the remaining carry scale by 4. At scale 1,
the current word is the desired output v. This may avoid proving a general
multiplicative closure theorem for T before tackling the machine.

A potentially simpler return proof uses two A1 steps at a time rather
than four. With current return scale p=2h, the equation
WholeRight+1=p*p*(r+1) becomes 4h*h*(r+1), forcing two pending 1 bits.
Two clearing steps multiply L by 4; the already proved constructor gives
T(2v0,4L). Update the current output to 2v0 and the remaining scale to h.
Then h*(2v0)=p*v0 preserves the final carry output. This uses only Pow2
halving, not a proof that the current return scale stays a power of 4 or
that arbitrary Pow2 products are total. One intermediate return microphase
would describe the first of the two clearing steps. This is a proposed
optimization, not a verified theorem.

A complete proof still needs microphases or bounded-history reasoning
for the four- and five-step contracts. An arbitrary history can end in
the middle of a block, so block-boundary preservation alone is inadequate.
It also needs explicit bounds on every current word, scale, transformed
word and rank. The displayed equations suggest polynomial bounds in the
initial encoded tape words and right tail. No such full left-phase rank
or history theorem is currently claimed.
