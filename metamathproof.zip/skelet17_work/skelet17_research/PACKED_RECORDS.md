# A global joint-record construction

The new standalone packets_checked.mm proves a polynomially bounded
global code for a specified joint recorder. This replaces pointwise
existence by a global packed witness for that recorder. The formal
projection to the preceding original-parser emission certificate is
still unproved. Do not interpret this checkpoint as a completed theorem
about the original parser's packed emission stream.

No Skelet #17 configuration, instruction or halting definition changes.
This is an auxiliary certificate layout. No trusted axioms are added.

## Record layout and transition table

Each record is one base-32 digit

    record = control + 8*flag + 16*digit,
    control<8, flag<2, digit<2.

The low three bits store the parser's control. The next bit says whether
a digit is emitted; the last bit stores that digit. When nothing is
emitted, the digit is conventionally zero. An emitted zero therefore has
a different record from no emission.

The recorder's previous record r has control r mod 8. For input bit b,
the next control c is the preceding totalized eight-control table entry.
Set f=1 exactly when that old control has a pending 1 and b=1. If f=1,
set v=c mod 2; otherwise set v=0. The next record is c+8f+16v.
The resulting table has 32 possible old records and two input bits.
The four invalid source-parser cases, for each possible old payload,
retain the earlier explicit totalization. The full table is packet_table.json.

For example, source word 1101 has successive records 4,12,2,6:
the second record stores control 4, emission flag 1, and emitted digit 0.
The other records have emission flag 0. The source EOF policy would then
emit 1 from final control 6. EOF is still handled separately, rather than
as an additional record in this packed code.

## Exact theorem

Use the same bounded Pow2 predicate and quotient/remainder Field predicate
as before. Let DeltaPacket be the explicit disjunction of the 64 joint
table entries. Define

    PacketRun(x,R) := forall p<x+1 (Pow2(p) ->
      exists a<32 exists b<2 exists c<32
        (Field(R,(2*p)^5,32,a) and Field(x,p,2,b) and
         Field(R,p^5,32,c) and DeltaPacket(a,b,c))).

All fifth powers are abbreviations for multiplication of five terms.
No indexed exponentiation symbol is used. The checked theorem
`skelet17-packet-positive-certificate` is

    0<x -> exists P<x+1 exists R<32*(x+1)^5
      (Pow2(P) and x<2*P and R<32*P^5 and PacketRun(x,R)).

The quantified R precedes the universal input-place quantifier. Thus it
is one global record code, not separate local record choices. The bound
R<32*P^5 forces record 0 before the leading place because (2P)^5=32P^5.
The empty case separately has PacketRun(0,0).

The input bit at binary weight p corresponds to a record at weight p^5.
Appending an input bit sends x to 2x+b; appending a record sends R to
32R+c. The relation (2p)^5=32p^5 preserves all existing local fields.

## Proof construction and verification

build_packets.py instantiates the preceding annotation constructor for
32 record states and five-bit fields. It writes the actual instantiated
Python source as build_packets_generated.py for inspection. The output
Metamath proof remains the object checked by the independent verifier;
neither Python transformations nor arithmetic simplification are axioms.

A reusable derived theorem proves (2p)^5=32p^5 once. Weight comparisons
then use equality substitution and congruence, avoiding repeated expansion
of products of fixed coefficients into thousands of unary summands.
This is a proof-size optimization, not a change of theory.

The existence proof uses the same bounded strong-induction construction
as the control-only proof, now with bound 32*(x+1)^5. The dependency closure
has two bounded-induction constructions, including bounded division.
The trusted core is exactly the original 93 declarations.

check_packets.py checks all binary inputs below 16384 and all 21,844 prior
valid-list cases. For valid words, extracting the control, flag and digit
from each record agrees with the source transition function; adding the
source EOF digit reproduces the complete emitted-digit list. These tests
are interpretation evidence, not the missing formal source projection.

## Remaining gap

The original-parser correctness and emission theorems were proved for the
earlier base-8 control code. The new base-32 joint code needs its own
formal projection to those control/emission relations and elimination of
its invalid source transitions on LowerWord inputs. Their agreement on
the finite source table and standard valid-word tests is not a substitute
for the weak-theory bridge theorem. That bridge is the next obligation.

Even after that bridge, emission counts, output ranks, deletion of
non-emitting positions, and identification of the compressed output with
the source Gray counter remain unproved. Skelet #17 nonhalting and
independence remain unproved.

To regenerate:

    python3 skelet17_research/build_packets.py
    python3 skelet17_research/prune.py packets_raw.mm packets_checked.mm
    metamath 'read "skelet17_research/packets_checked.mm"' 'verify proof *' exit
    python3 skelet17_research/check_packets.py
    python3 skelet17_research/audit_packets.py

Capture the clean verifier output in packet_verification.log before auditing.
