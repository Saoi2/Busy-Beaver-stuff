"""Shared uniqueness and suffix facts for the original bounded beta histories.

These are purely arithmetic/first-order consequences. There is no induction,
coding-totality assumption, modified Step, or annotation in a history row.
"""
def add_history_tools(m,api,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;use=m.invoke
 H,N,offset,start,length,index,second=[m.declare('sharedHistory'+s,'term') for s in ('H','N','Offset','Start','Length','CompareIndex','SecondValue')]
 Bj=[m.declare('sharedHistoryB'+str(j),'term') for j in range(4)]
 Cj=[m.declare('sharedHistoryC'+str(j),'term') for j in range(4)]
 quo,qa,qb=[m.declare('sharedHistory'+s) for s in ('BetaQuotient','FirstQuotient','SecondQuotient')]
 ti,si,sti,ssi=[m.declare('sharedHistory'+s) for s in ('TotalIndex','StepIndex','SuffixTotalIndex','SuffixStepIndex')]
 TV=[m.declare('sharedHistoryTotalRow'+s) for s in ('Q','L','Bit','R')]
 SV=[m.declare('sharedHistoryStepRow'+str(j)+s) for j in (0,1) for s in ('Q','L','Bit','R')]
 SSV=[m.declare('sharedHistorySuffixRow'+str(j)+s) for j in (0,1) for s in ('Q','L','Bit','R')]
 cf,nf=api['current'],api['next'];step=api['step']
 def beta(B,C,i,x):
  mod=A(O,M(A(i,O),C));return nd.BEX(quo,H,b.And(Q(B,A(M(quo,mod),x)),L(x,mod)))
 def absolute(i,row):return nd.AND([beta(Bj[j],Cj[j],i,v) for j,v in enumerate(row)])
 def AT(o,i,row):return absolute(A(o,i),row)
 def total(o,n,iv=ti):return nd.BALL(iv,A(n,O),nd.bexs(TV,H,AT(o,iv,TV)))
 def steps(o,n,iv=si,rows=SV):return nd.BALL(iv,n,nd.balls(rows,H,b.Imp(b.And(AT(o,iv,rows[:4]),AT(o,A(iv,O),rows[4:])),step(rows[:4],rows[4:]))))
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-history-'+name,root,prem,goal,c,comment)
 def value_unique():
  B,C,i,x=b.t,b.u,b.v,b.w;y=second;mod=A(O,M(A(i,O),C))
  fs=[beta(B,C,i,x),beta(B,C,i,y)];prem=b.And(*fs);goal=Q(x,y)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  bodyx=b.And(Q(B,A(M(quo,mod),x)),L(x,mod));bodyy=b.And(Q(B,A(M(quo,mod),y)),L(y,mod))
  def first(cc):
   eqx=Q(B,A(M(qa,mod),x));nd.unpack(cc,[eqx,L(x,mod)])
   def other(dc):
    eqy=Q(B,A(M(qb,mod),y));nd.unpack(dc,[eqy,L(y,mod)])
    lhs=A(M(mod,qa),x);coded=A(M(qa,mod),x)
    m.eq(dc,lhs,coded);back=m.flip(dc,eqx)
    dc.put(Q(lhs,B),ar.trans(lhs,coded,B,dc.get(Q(lhs,coded)),dc.get(back),dc.g))
    m.eq(dc,A(M(mod,qa),x),A(M(mod,qb),y),[Q(A(M(mod,qa),x),B),eqy])
    m.quotient_unique(dc,mod,qa,x,qb,y);return dc.get(goal)
   return m.bex_elim(cc,quo,H,bodyy,qb,goal,other)
  m.bex_elim(c,quo,H,bodyx,qa,goal,first)
  finish('beta-value-unique',root,prem,goal,c,'Two bounded quotient-and-remainder decodings of one coordinate at the same index have the same remainder. Reuses division uniqueness; no induction.')
 def row_unique():
  fs=[AT(offset,index,cf),AT(offset,index,nf)];prem=b.And(*fs);out=[Q(x,y) for x,y in zip(cf,nf)];goal=nd.AND(out)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  nd.unpack(c,[beta(Bj[j],Cj[j],A(offset,index),v) for j,v in enumerate(cf)])
  nd.unpack(c,[beta(Bj[j],Cj[j],A(offset,index),v) for j,v in enumerate(nf)])
  for j,(x,y) in enumerate(zip(cf,nf)):
   mp={'t':Bj[j],'u':Cj[j],'v':A(offset,index),'w':x,second[1]:y}
   f=m.sub(m.theorems['skelet17-ladder-history-beta-value-unique'],mp)
   c.both(*f[1][1:]);use(c,'skelet17-ladder-history-beta-value-unique',mp)
  nd.conj(c,out);finish('row-unique',root,prem,goal,c,'A raw beta history has at most one decoded quadruple at an index. Four uses of coordinate uniqueness; no induction.')
 def translate_bound(c,i,upper,out,eq):
  m.ltadd(c,i,upper,start)
  m.eq(c,A(i,start),A(start,i));m.rewrite(c,L(ar.E,A(upper,start)),A(i,start),A(start,i))
  m.eq(c,A(upper,start),out,[m.flip(c,eq)]);m.rewrite(c,L(A(start,i),ar.E),A(upper,start),out)
 def total_suffix():
  fs=[total(offset,N),Q(A(start,length),N)];prem=b.And(*fs);goal=total(A(offset,start),length,sti)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);guard=L(sti,A(length,O));ic=c.push(guard)
  translate_bound(ic,sti,A(length,O),A(N,O),fs[1])
  ic.all_elim(ti,total(offset,N)[2],A(start,sti))
  body=nd.bexs(TV,H,AT(offset,A(start,sti),TV));ic.mp(L(A(start,sti),A(N,O)),body)
  old=A(offset,A(start,sti));new=A(A(offset,start),sti);m.eq(ic,old,new)
  m.rewrite(ic,nd.bexs(TV,H,absolute(ar.E,TV)),old,new)
  out=nd.bexs(TV,H,AT(A(offset,start),sti,TV));c.intro(guard,out,ic);c.all_intro(sti,b.Imp(guard,out))
  finish('total-suffix',root,prem,goal,c,'The same four beta codes supply every row of a suffix when start+length=N. Only the offset and window length change. No induction or recoding.')
 def bforall(c,vs,body,fn):
  if not vs:return c.put(body,fn(c))
  v=vs[0];guard=L(v,H);ch=c.push(guard);inner=nd.balls(vs[1:],H,body)
  bforall(ch,vs[1:],body,fn);c.intro(guard,inner,ch);return c.all_intro(v,b.Imp(guard,inner))
 def steps_suffix():
  fs=[steps(offset,N),Q(A(start,length),N)];prem=b.And(*fs);goal=steps(A(offset,start),length,ssi,SSV)
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs);guard=L(ssi,length);ic=c.push(guard)
  translate_bound(ic,ssi,length,N,fs[1])
  oldrows=SV;rows=SSV;oldidx=A(start,ssi)
  original=b.Imp(b.And(AT(offset,oldidx,oldrows[:4]),AT(offset,A(oldidx,O),oldrows[4:])),step(oldrows[:4],oldrows[4:]))
  ic.all_elim(si,steps(offset,N)[2],oldidx);ic.mp(L(oldidx,N),nd.balls(oldrows,H,original))
  at=b.And(AT(A(offset,start),ssi,rows[:4]),AT(A(offset,start),A(ssi,O),rows[4:]));conclusion=step(rows[:4],rows[4:]);inner=b.Imp(at,conclusion)
  def prove_row(rc):
   ac=rc.push(at)
   first=A(A(offset,start),ssi);firstnew=A(offset,oldidx)
   last=A(A(offset,start),A(ssi,O));lastnew=A(offset,A(oldidx,O))
   m.eq(ac,first,firstnew);m.rewrite(ac,b.And(absolute(ar.E,rows[:4]),absolute(last,rows[4:])),first,firstnew)
   m.eq(ac,last,lastnew);m.rewrite(ac,b.And(absolute(firstnew,rows[:4]),absolute(ar.E,rows[4:])),last,lastnew)
   nd.inst_balls(ac,oldrows,H,original,rows)
   given=b.And(AT(offset,oldidx,rows[:4]),AT(offset,A(oldidx,O),rows[4:]));ac.mp(given,conclusion)
   rc.intro(at,conclusion,ac);return rc.get(inner)
  bforall(ic,rows,inner,prove_row)
  c.intro(guard,nd.balls(rows,H,inner),ic);c.all_intro(ssi,b.Imp(guard,nd.balls(rows,H,inner)))
  finish('steps-suffix',root,prem,goal,c,'Every ordinary transition condition is inherited by a suffix with the same beta codes. Explicit addition/index transport; no induction or recoding.')
 if proofs:value_unique();row_unique();total_suffix();steps_suffix()
 return {'H':H,'n':N,'offset':offset,'start':start,'length':length,'index':index,'Bj':Bj,'Cj':Cj,'quo':quo,'AT':AT,'beta':beta,'absolute':absolute,'total':total,'steps':steps,'ti':ti,'si':si,'sti':sti,'ssi':ssi,'TV':TV,'SV':SV,'SSV':SSV}
