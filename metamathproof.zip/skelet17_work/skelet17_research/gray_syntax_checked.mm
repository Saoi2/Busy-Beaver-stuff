$c var term wff ctx open bnd subt subf |- => [] ; 0 1 + * = < ( ) -. /\ \/ -> <-> A. E. $.
$v x y z k t u v w ph ps ch th ga $.
f-x $f var x $.
f-y $f var y $.
f-z $f var z $.
f-k $f var k $.
f-t $f term t $.
f-u $f term u $.
f-v $f term v $.
f-w $f term w $.
f-ph $f wff ph $.
f-ps $f wff ps $.
f-ch $f wff ch $.
f-th $f wff th $.
f-ga $f ctx ga $.
${
term-zero $a term 0 $.
$}
${
term-one $a term 1 $.
$}
${
term-var $a term x $.
$}
${
term-add $a term ( t + u ) $.
$}
${
term-mul $a term ( t * u ) $.
$}
${
w-eq $a wff ( t = u ) $.
$}
${
w-lt $a wff ( t < u ) $.
$}
${
w-not $a wff -. ph $.
$}
${
w-and $a wff ( ph /\ ps ) $.
$}
${
w-or $a wff ( ph \/ ps ) $.
$}
${
w-imp $a wff ( ph -> ps ) $.
$}
${
w-iff $a wff ( ph <-> ps ) $.
$}
${
w-all $a wff A. x ph $.
$}
${
w-ex $a wff E. x ph $.
$}
${
ctx-empty $a ctx [] $.
$}
${
ctx-cons $a ctx ( ga ; ph ) $.
$}
${
st-same $a subt x x t t $.
$}
${
${
$d t x $.
st-fresh $a subt t x u t $.
$}
$}
${
${
$d x y $.
st-other $a subt y x t y $.
$}
$}
${
st-zero $a subt 0 x t 0 $.
$}
${
st-one $a subt 1 x t 1 $.
$}
$v r $.
f-r $f term r $.
${
st-add-general.h1 $e subt u x t w $.
st-add-general.h2 $e subt v x t r $.
${
st-add-general $a subt ( u + v ) x t ( w + r ) $.
$}
$}
${
st-mul-general.h1 $e subt u x t w $.
st-mul-general.h2 $e subt v x t r $.
${
st-mul-general $a subt ( u * v ) x t ( w * r ) $.
$}
$}
${
sf-eq.h1 $e subt u x t w $.
sf-eq.h2 $e subt v x t r $.
${
sf-eq $a subf ( u = v ) x t ( w = r ) $.
$}
$}
${
sf-lt.h1 $e subt u x t w $.
sf-lt.h2 $e subt v x t r $.
${
sf-lt $a subf ( u < v ) x t ( w < r ) $.
$}
$}
${
sf-not.h1 $e subf ph x t ps $.
${
sf-not $a subf -. ph x t -. ps $.
$}
$}
${
sf-and.h1 $e subf ph x t ch $.
sf-and.h2 $e subf ps x t th $.
${
sf-and $a subf ( ph /\ ps ) x t ( ch /\ th ) $.
$}
$}
${
sf-or.h1 $e subf ph x t ch $.
sf-or.h2 $e subf ps x t th $.
${
sf-or $a subf ( ph \/ ps ) x t ( ch \/ th ) $.
$}
$}
${
sf-imp.h1 $e subf ph x t ch $.
sf-imp.h2 $e subf ps x t th $.
${
sf-imp $a subf ( ph -> ps ) x t ( ch -> th ) $.
$}
$}
${
sf-iff.h1 $e subf ph x t ch $.
sf-iff.h2 $e subf ps x t th $.
${
sf-iff $a subf ( ph <-> ps ) x t ( ch <-> th ) $.
$}
$}
${
sf-all-same $a subf A. x ph x t A. x ph $.
$}
${
sf-all-other.h1 $e subf ph x t ps $.
${
$d t y $.
$d x y $.
sf-all-other $a subf A. y ph x t A. y ps $.
$}
$}
${
sf-ex-same $a subf E. x ph x t E. x ph $.
$}
${
sf-ex-other.h1 $e subf ph x t ps $.
${
$d t y $.
$d x y $.
sf-ex-other $a subf E. y ph x t E. y ps $.
$}
$}
${
open-eq $a open ( t = u ) $.
$}
${
open-lt $a open ( t < u ) $.
$}
${
open-not.h1 $e open ph $.
${
open-not $a open -. ph $.
$}
$}
${
open-and.h1 $e open ph $.
open-and.h2 $e open ps $.
${
open-and $a open ( ph /\ ps ) $.
$}
$}
${
open-or.h1 $e open ph $.
open-or.h2 $e open ps $.
${
open-or $a open ( ph \/ ps ) $.
$}
$}
${
open-imp.h1 $e open ph $.
open-imp.h2 $e open ps $.
${
open-imp $a open ( ph -> ps ) $.
$}
$}
${
open-iff.h1 $e open ph $.
open-iff.h2 $e open ps $.
${
open-iff $a open ( ph <-> ps ) $.
$}
$}
${
bnd-open.h1 $e open ph $.
${
bnd-open $a bnd ph $.
$}
$}
${
bnd-not.h1 $e bnd ph $.
${
bnd-not $a bnd -. ph $.
$}
$}
${
bnd-and.h1 $e bnd ph $.
bnd-and.h2 $e bnd ps $.
${
bnd-and $a bnd ( ph /\ ps ) $.
$}
$}
${
bnd-or.h1 $e bnd ph $.
bnd-or.h2 $e bnd ps $.
${
bnd-or $a bnd ( ph \/ ps ) $.
$}
$}
${
bnd-imp.h1 $e bnd ph $.
bnd-imp.h2 $e bnd ps $.
${
bnd-imp $a bnd ( ph -> ps ) $.
$}
$}
${
bnd-iff.h1 $e bnd ph $.
bnd-iff.h2 $e bnd ps $.
${
bnd-iff $a bnd ( ph <-> ps ) $.
$}
$}
${
bnd-ex.h1 $e bnd ph $.
${
$d t x $.
bnd-ex $a bnd E. x ( ( x < t ) /\ ph ) $.
$}
$}
${
bnd-all.h1 $e bnd ph $.
${
$d t x $.
bnd-all $a bnd A. x ( ( x < t ) -> ph ) $.
$}
$}
${
nd-assume $a |- ( ga ; ph ) => ph $.
$}
${
nd-weaken.h1 $e |- ga => ph $.
${
nd-weaken $a |- ( ga ; ps ) => ph $.
$}
$}
${
nd-empty-weaken.h1 $e |- [] => ph $.
${
nd-empty-weaken $a |- ga => ph $.
$}
$}
${
nd-imp-intro.h1 $e |- ( ga ; ph ) => ps $.
${
nd-imp-intro $a |- ga => ( ph -> ps ) $.
$}
$}
${
nd-mp.h1 $e |- ga => ( ph -> ps ) $.
nd-mp.h2 $e |- ga => ph $.
${
nd-mp $a |- ga => ps $.
$}
$}
${
nd-and-intro.h1 $e |- ga => ph $.
nd-and-intro.h2 $e |- ga => ps $.
${
nd-and-intro $a |- ga => ( ph /\ ps ) $.
$}
$}
${
nd-and-left.h1 $e |- ga => ( ph /\ ps ) $.
${
nd-and-left $a |- ga => ph $.
$}
$}
${
nd-and-right.h1 $e |- ga => ( ph /\ ps ) $.
${
nd-and-right $a |- ga => ps $.
$}
$}
${
nd-or-left.h1 $e |- ga => ph $.
${
nd-or-left $a |- ga => ( ph \/ ps ) $.
$}
$}
${
nd-or-right.h1 $e |- ga => ps $.
${
nd-or-right $a |- ga => ( ph \/ ps ) $.
$}
$}
${
nd-or-elim.h1 $e |- ga => ( ph \/ ps ) $.
nd-or-elim.h2 $e |- ( ga ; ph ) => ch $.
nd-or-elim.h3 $e |- ( ga ; ps ) => ch $.
${
nd-or-elim $a |- ga => ch $.
$}
$}
${
nd-all-intro.h1 $e |- ga => ph $.
${
$d ga x $.
nd-all-intro $a |- ga => A. x ph $.
$}
$}
${
nd-all-elim.h1 $e |- ga => A. x ph $.
nd-all-elim.h2 $e subf ph x t ps $.
${
nd-all-elim $a |- ga => ps $.
$}
$}
${
nd-ex-intro.h1 $e subf ph x t ps $.
nd-ex-intro.h2 $e |- ga => ps $.
${
nd-ex-intro $a |- ga => E. x ph $.
$}
$}
${
nd-ex-elim.h1 $e |- ga => E. x ph $.
nd-ex-elim.h2 $e subf ph x y ps $.
nd-ex-elim.h3 $e |- ( ga ; ps ) => ch $.
${
$d ch y $.
$d ga y $.
$d ph y $.
$d x y $.
nd-ex-elim $a |- ga => ch $.
$}
$}
${
nd-iff-left.h1 $e |- ga => ( ph <-> ps ) $.
${
nd-iff-left $a |- ga => ( ph -> ps ) $.
$}
$}
${
nd-iff-right.h1 $e |- ga => ( ph <-> ps ) $.
${
nd-iff-right $a |- ga => ( ps -> ph ) $.
$}
$}
${
nd-iff-intro.h1 $e |- ga => ( ph -> ps ) $.
nd-iff-intro.h2 $e |- ga => ( ps -> ph ) $.
${
nd-iff-intro $a |- ga => ( ph <-> ps ) $.
$}
$}
${
nd-excluded-middle $a |- ga => ( ph \/ -. ph ) $.
$}
${
nd-explosion.h1 $e |- ga => ph $.
nd-explosion.h2 $e |- ga => -. ph $.
${
nd-explosion $a |- ga => ps $.
$}
$}
${
nd-not-intro.h1 $e |- ( ga ; ph ) => ps $.
nd-not-intro.h2 $e |- ( ga ; ph ) => -. ps $.
${
nd-not-intro $a |- ga => -. ph $.
$}
$}
${
nd-dne.h1 $e |- ga => -. -. ph $.
${
nd-dne $a |- ga => ph $.
$}
$}
${
eq-refl $a |- ga => ( t = t ) $.
$}
${
eq-sym.h1 $e |- ga => ( t = u ) $.
${
eq-sym $a |- ga => ( u = t ) $.
$}
$}
${
eq-trans.h1 $e |- ga => ( t = u ) $.
eq-trans.h2 $e |- ga => ( u = v ) $.
${
eq-trans $a |- ga => ( t = v ) $.
$}
$}
${
eq-add-cong.h1 $e |- ga => ( t = u ) $.
eq-add-cong.h2 $e |- ga => ( v = w ) $.
${
eq-add-cong $a |- ga => ( ( t + v ) = ( u + w ) ) $.
$}
$}
${
eq-mul-cong.h1 $e |- ga => ( t = u ) $.
eq-mul-cong.h2 $e |- ga => ( v = w ) $.
${
eq-mul-cong $a |- ga => ( ( t * v ) = ( u * w ) ) $.
$}
$}
${
eq-replace.h1 $e |- ga => ( t = u ) $.
eq-replace.h2 $e subf ph x t ps $.
eq-replace.h3 $e subf ph x u ch $.
eq-replace.h4 $e |- ga => ps $.
${
eq-replace $a |- ga => ch $.
$}
$}
${
ax-A1 $a |- ga => ( ( ( t + u ) + v ) = ( t + ( u + v ) ) ) $.
$}
${
ax-A2 $a |- ga => ( ( t + u ) = ( u + t ) ) $.
$}
${
ax-A3 $a |- ga => ( ( t + 0 ) = t ) $.
$}
${
ax-A4 $a |- ga => ( ( ( t * u ) * v ) = ( t * ( u * v ) ) ) $.
$}
${
ax-A5 $a |- ga => ( ( t * u ) = ( u * t ) ) $.
$}
${
ax-A6 $a |- ga => ( ( t * 1 ) = t ) $.
$}
${
ax-A7 $a |- ga => ( ( t * 0 ) = 0 ) $.
$}
${
ax-A8 $a |- ga => ( ( t * ( u + v ) ) = ( ( t * u ) + ( t * v ) ) ) $.
$}
${
ax-O1 $a |- ga => -. ( t < t ) $.
$}
${
ax-O2 $a |- ga => ( ( ( t < u ) /\ ( u < v ) ) -> ( t < v ) ) $.
$}
${
ax-O3 $a |- ga => ( ( t < u ) \/ ( ( t = u ) \/ ( u < t ) ) ) $.
$}
${
ax-O4 $a |- ga => -. ( t < 0 ) $.
$}
${
ax-O5 $a |- ga => ( ( t < u ) -> ( ( t + v ) < ( u + v ) ) ) $.
$}
${
ax-O6 $a |- ga => ( ( ( t < u ) /\ ( 0 < v ) ) -> ( ( t * v ) < ( u * v ) ) ) $.
$}
${
${
$d t x $.
$d u x $.
ax-O7 $a |- ga => ( ( t < u ) <-> E. x ( u = ( ( t + x ) + 1 ) ) ) $.
$}
$}
${
ax-ind-bounded.h1 $e bnd ph $.
ax-ind-bounded.h2 $e subf ph x 0 ps $.
ax-ind-bounded.h3 $e subf ph x ( x + 1 ) ch $.
${
ax-ind-bounded $a |- ga => ( ( ps /\ A. x ( ph -> ch ) ) -> A. x ph ) $.
$}
$}
${
ind-open.h1 $e open ph $.
ind-open.h2 $e subf ph x 0 ps $.
ind-open.h3 $e subf ph x ( x + 1 ) ch $.
$}
$v e0 $.
f-e0 $f var e0 $.
$v e1 $.
f-e1 $f var e1 $.
$v e2 $.
f-e2 $f var e2 $.
$v e3 $.
f-e3 $f var e3 $.
$v i $.
f-i $f var i $.
$v j $.
f-j $f var j $.
$v n $.
f-n $f var n $.
$v h $.
f-h $f var h $.
$v q $.
f-q $f var q $.
$v ll $.
f-ll $f var ll $.
$v rr $.
f-rr $f var rr $.
$v bit $.
f-bit $f var bit $.
$v bb0 $.
f-bb0 $f var bb0 $.
$v cc0 $.
f-cc0 $f var cc0 $.
$v bb1 $.
f-bb1 $f var bb1 $.
$v cc1 $.
f-cc1 $f var cc1 $.
$v bb2 $.
f-bb2 $f var bb2 $.
$v cc2 $.
f-cc2 $f var cc2 $.
$v bb3 $.
f-bb3 $f var bb3 $.
$v cc3 $.
f-cc3 $f var cc3 $.
$v aa $.
f-aa $f var aa $.
$v dd $.
f-dd $f var dd $.
$v mn $.
f-mn $f term mn $.
$v mh $.
f-mh $f term mh $.
$v d0 $.
f-d0 $f term d0 $.
$v d1 $.
f-d1 $f term d1 $.
$v d2 $.
f-d2 $f term d2 $.
$v d3 $.
f-d3 $f term d3 $.
$v d4 $.
f-d4 $f term d4 $.
$v d5 $.
f-d5 $f term d5 $.
$v B0 $.
f-B0 $f term B0 $.
$v C0 $.
f-C0 $f term C0 $.
$v B1 $.
f-B1 $f term B1 $.
$v C1 $.
f-C1 $f term C1 $.
$v B2 $.
f-B2 $f term B2 $.
$v C2 $.
f-C2 $f term C2 $.
$v B3 $.
f-B3 $f term B3 $.
$v C3 $.
f-C3 $f term C3 $.
$v ti $.
f-ti $f var ti $.
$v tq $.
f-tq $f var tq $.
$v tl $.
f-tl $f var tl $.
$v tb $.
f-tb $f var tb $.
$v tr $.
f-tr $f var tr $.
$v iq $.
f-iq $f var iq $.
$v il $.
f-il $f var il $.
$v ib $.
f-ib $f var ib $.
$v ir $.
f-ir $f var ir $.
$v si $.
f-si $f var si $.
$v sq $.
f-sq $f var sq $.
$v sl $.
f-sl $f var sl $.
$v sb $.
f-sb $f var sb $.
$v sr $.
f-sr $f var sr $.
$v nq $.
f-nq $f var nq $.
$v nl $.
f-nl $f var nl $.
$v nb $.
f-nb $f var nb $.
$v nr $.
f-nr $f var nr $.
$v fq $.
f-fq $f var fq $.
$v fl $.
f-fl $f var fl $.
$v fb $.
f-fb $f var fb $.
$v fr $.
f-fr $f var fr $.
$v iv $.
f-iv $f var iv $.
$v pq $.
f-pq $f var pq $.
$v pl $.
f-pl $f var pl $.
$v pb $.
f-pb $f var pb $.
$v pr $.
f-pr $f var pr $.
$v oq $.
f-oq $f var oq $.
$v ol $.
f-ol $f var ol $.
$v ob $.
f-ob $f var ob $.
$v orr $.
f-orr $f var orr $.
$v cq $.
f-cq $f var cq $.
$v cl $.
f-cl $f var cl $.
$v cb $.
f-cb $f var cb $.
$v cr $.
f-cr $f var cr $.
$v vq $.
f-vq $f var vq $.
$v vl $.
f-vl $f var vl $.
$v vb $.
f-vb $f var vb $.
$v vr $.
f-vr $f var vr $.
$v bu $.
f-bu $f var bu $.
$v iu $.
f-iu $f var iu $.
$v ju $.
f-ju $f var ju $.
$v evl $.
f-evl $f var evl $.
$v evr $.
f-evr $f var evr $.
$v pv $.
f-pv $f var pv $.
$v pd $.
f-pd $f var pd $.
$v clu $.
f-clu $f var clu $.
$v cru $.
f-cru $f var cru $.
$v nlq $.
f-nlq $f var nlq $.
$v nrq $.
f-nrq $f var nrq $.
$v code0 $.
f-code0 $f var code0 $.
$v code1 $.
f-code1 $f var code1 $.
$v code2 $.
f-code2 $f var code2 $.
$v code3 $.
f-code3 $f var code3 $.
$v hn $.
f-hn $f var hn $.
$v hh $.
f-hh $f var hh $.
$v hB0 $.
f-hB0 $f var hB0 $.
$v hC0 $.
f-hC0 $f var hC0 $.
$v hB1 $.
f-hB1 $f var hB1 $.
$v hC1 $.
f-hC1 $f var hC1 $.
$v hB2 $.
f-hB2 $f var hB2 $.
$v hC2 $.
f-hC2 $f var hC2 $.
$v hB3 $.
f-hB3 $f var hB3 $.
$v hC3 $.
f-hC3 $f var hC3 $.
$v grayWeight $.
f-grayWeight $f var grayWeight $.
$v grayDivisor $.
f-grayDivisor $f var grayDivisor $.
$v grayQuotient $.
f-grayQuotient $f var grayQuotient $.
$v grayHalf $.
f-grayHalf $f var grayHalf $.
$v grayBitQ $.
f-grayBitQ $f var grayBitQ $.
$v grayBitR $.
f-grayBitR $f var grayBitR $.
${
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayQuotient grayWeight $.
syn-0 $p wff ( ( grayDivisor * grayQuotient ) = grayWeight ) $=
 f-grayDivisor term-var f-grayQuotient term-var term-mul f-grayWeight term-var w-eq $.
$}
${
$d grayDivisor grayHalf $.
syn-1 $p wff ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) $=
 f-grayDivisor term-var term-one term-one term-add f-grayHalf term-var term-mul w-eq $.
$}
${
$d grayDivisor grayHalf $.
syn-2 $p wff ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) $=
 f-grayHalf term-var f-grayDivisor term-var term-one term-add w-lt f-grayDivisor f-grayHalf syn-1 w-and $.
$}
${
$d grayDivisor grayHalf $.
syn-3 $p wff E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) $=
 f-grayHalf f-grayDivisor f-grayHalf syn-2 w-ex $.
$}
${
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayQuotient grayWeight $.
syn-4 $p wff ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) $=
 f-grayQuotient term-var f-grayWeight term-var term-one term-add w-lt f-grayWeight f-grayDivisor f-grayQuotient syn-0 w-and $.
$}
${
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayQuotient grayWeight $.
syn-5 $p wff E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) $=
 f-grayQuotient f-grayWeight f-grayDivisor f-grayQuotient syn-4 w-ex $.
$}
${
$d grayDivisor grayHalf $.
syn-6 $p wff ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) $=
 f-grayDivisor term-var term-one w-eq f-grayDivisor f-grayHalf syn-3 w-or $.
$}
${
$d grayDivisor grayHalf $.
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayHalf grayQuotient $.
$d grayHalf grayWeight $.
$d grayQuotient grayWeight $.
syn-7 $p wff ( E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) -> ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) ) $=
 f-grayWeight f-grayDivisor f-grayQuotient syn-5 f-grayDivisor f-grayHalf syn-6 w-imp $.
$}
${
$d grayDivisor grayHalf $.
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayHalf grayQuotient $.
$d grayHalf grayWeight $.
$d grayQuotient grayWeight $.
syn-8 $p wff ( ( grayDivisor < ( grayWeight + 1 ) ) -> ( E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) -> ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) ) ) $=
 f-grayDivisor term-var f-grayWeight term-var term-one term-add w-lt f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-7 w-imp $.
$}
${
$d grayDivisor grayHalf $.
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayHalf grayQuotient $.
$d grayHalf grayWeight $.
$d grayQuotient grayWeight $.
syn-9 $p wff A. grayDivisor ( ( grayDivisor < ( grayWeight + 1 ) ) -> ( E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) -> ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) ) ) $=
 f-grayDivisor f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-8 w-all $.
$}
${
$d grayWeight t $.
syn-10 $p wff ( ( ( 1 + 1 ) * grayWeight ) < ( t + 1 ) ) $=
 term-one term-one term-add f-grayWeight term-var term-mul f-t term-one term-add w-lt $.
$}
${
$d grayDivisor grayHalf $.
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayHalf grayQuotient $.
$d grayHalf grayWeight $.
$d grayQuotient grayWeight $.
syn-11 $p wff ( ( 0 < grayWeight ) /\ A. grayDivisor ( ( grayDivisor < ( grayWeight + 1 ) ) -> ( E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) -> ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) ) ) ) $=
 term-zero f-grayWeight term-var w-lt f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-9 w-and $.
$}
${
$d grayBitQ grayWeight $.
syn-12 $p term ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) $=
 f-grayBitQ term-var term-one term-one term-add f-grayWeight term-var term-mul term-mul $.
$}
${
$d grayBitQ grayWeight $.
syn-13 $p term ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) $=
 f-grayWeight f-grayBitQ syn-12 f-grayWeight term-var term-add $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitR grayWeight $.
syn-14 $p term ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) $=
 f-grayWeight f-grayBitQ syn-13 f-grayBitR term-var term-add $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-15 $p wff ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) $=
 f-t f-grayWeight f-grayBitQ f-grayBitR syn-14 w-eq $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-16 $p wff ( ( grayBitR < grayWeight ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) ) $=
 f-grayBitR term-var f-grayWeight term-var w-lt f-t f-grayWeight f-grayBitQ f-grayBitR syn-15 w-and $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-17 $p wff E. grayBitR ( ( grayBitR < grayWeight ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) ) $=
 f-grayBitR f-t f-grayWeight f-grayBitQ f-grayBitR syn-16 w-ex $.
$}
${
syn-18 $p term ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) $=
 term-one term-one term-add term-one term-one term-add f-grayWeight term-var term-mul term-mul $.
$}
${
$d grayBitQ grayWeight $.
syn-19 $p term ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) $=
 f-grayBitQ term-var f-grayWeight syn-18 term-mul $.
$}
${
$d grayBitQ grayWeight $.
syn-20 $p term ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) $=
 f-grayWeight f-grayBitQ syn-19 term-one term-one term-add f-grayWeight term-var term-mul term-add $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitR grayWeight $.
syn-21 $p term ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) $=
 f-grayWeight f-grayBitQ syn-20 f-grayBitR term-var term-add $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-22 $p wff ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) $=
 f-t f-grayWeight f-grayBitQ f-grayBitR syn-21 w-eq $.
$}
${
$d grayBitR grayWeight $.
syn-23 $p wff ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) $=
 f-grayBitR term-var term-one term-one term-add f-grayWeight term-var term-mul w-lt $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-24 $p wff ( ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) ) $=
 f-grayWeight f-grayBitR syn-23 f-t f-grayWeight f-grayBitQ f-grayBitR syn-22 w-and $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-25 $p wff E. grayBitR ( ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) ) $=
 f-grayBitR f-t f-grayWeight f-grayBitQ f-grayBitR syn-24 w-ex $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-26 $p wff ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < grayWeight ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) ) ) $=
 f-grayBitQ term-var f-t term-one term-add w-lt f-t f-grayWeight f-grayBitQ f-grayBitR syn-17 w-and $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-27 $p wff E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < grayWeight ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) ) ) $=
 f-grayBitQ f-t f-grayWeight f-grayBitQ f-grayBitR syn-26 w-ex $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-28 $p wff ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) ) ) $=
 f-grayBitQ term-var f-t term-one term-add w-lt f-t f-grayWeight f-grayBitQ f-grayBitR syn-25 w-and $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-29 $p wff E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) ) ) $=
 f-grayBitQ f-t f-grayWeight f-grayBitQ f-grayBitR syn-28 w-ex $.
$}
${
$d grayDivisor grayHalf $.
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayDivisor t $.
$d grayHalf grayQuotient $.
$d grayHalf grayWeight $.
$d grayHalf t $.
$d grayQuotient grayWeight $.
$d grayQuotient t $.
$d grayWeight t $.
syn-30 $p wff ( ( ( 0 < grayWeight ) /\ A. grayDivisor ( ( grayDivisor < ( grayWeight + 1 ) ) -> ( E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) -> ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) ) ) ) /\ ( ( ( 1 + 1 ) * grayWeight ) < ( t + 1 ) ) ) $=
 f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-11 f-t f-grayWeight syn-10 w-and $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayWeight t $.
syn-31 $p wff ( E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < grayWeight ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) ) ) \/ E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) ) ) ) $=
 f-t f-grayWeight f-grayBitQ f-grayBitR syn-27 f-t f-grayWeight f-grayBitQ f-grayBitR syn-29 w-or $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayDivisor $.
$d grayBitQ grayHalf $.
$d grayBitQ grayQuotient $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayDivisor $.
$d grayBitR grayHalf $.
$d grayBitR grayQuotient $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayDivisor grayHalf $.
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayDivisor t $.
$d grayHalf grayQuotient $.
$d grayHalf grayWeight $.
$d grayHalf t $.
$d grayQuotient grayWeight $.
$d grayQuotient t $.
$d grayWeight t $.
syn-32 $p wff ( ( ( ( 0 < grayWeight ) /\ A. grayDivisor ( ( grayDivisor < ( grayWeight + 1 ) ) -> ( E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) -> ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) ) ) ) /\ ( ( ( 1 + 1 ) * grayWeight ) < ( t + 1 ) ) ) -> ( E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < grayWeight ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) ) ) \/ E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) ) ) ) ) $=
 f-t f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-30 f-t f-grayWeight f-grayBitQ f-grayBitR syn-31 w-imp $.
$}
${
$d grayBitQ grayBitR $.
$d grayBitQ grayDivisor $.
$d grayBitQ grayHalf $.
$d grayBitQ grayQuotient $.
$d grayBitQ grayWeight $.
$d grayBitQ t $.
$d grayBitR grayDivisor $.
$d grayBitR grayHalf $.
$d grayBitR grayQuotient $.
$d grayBitR grayWeight $.
$d grayBitR t $.
$d grayDivisor grayHalf $.
$d grayDivisor grayQuotient $.
$d grayDivisor grayWeight $.
$d grayDivisor t $.
$d grayHalf grayQuotient $.
$d grayHalf grayWeight $.
$d grayHalf t $.
$d grayQuotient grayWeight $.
$d grayQuotient t $.
$d grayWeight t $.
skelet17-lower-word-bounded $p bnd A. grayWeight ( ( grayWeight < ( t + 1 ) ) -> ( ( ( ( 0 < grayWeight ) /\ A. grayDivisor ( ( grayDivisor < ( grayWeight + 1 ) ) -> ( E. grayQuotient ( ( grayQuotient < ( grayWeight + 1 ) ) /\ ( ( grayDivisor * grayQuotient ) = grayWeight ) ) -> ( ( grayDivisor = 1 ) \/ E. grayHalf ( ( grayHalf < ( grayDivisor + 1 ) ) /\ ( grayDivisor = ( ( 1 + 1 ) * grayHalf ) ) ) ) ) ) ) /\ ( ( ( 1 + 1 ) * grayWeight ) < ( t + 1 ) ) ) -> ( E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < grayWeight ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * grayWeight ) ) + grayWeight ) + grayBitR ) ) ) ) \/ E. grayBitQ ( ( grayBitQ < ( t + 1 ) ) /\ E. grayBitR ( ( grayBitR < ( ( 1 + 1 ) * grayWeight ) ) /\ ( t = ( ( ( grayBitQ * ( ( 1 + 1 ) * ( ( 1 + 1 ) * grayWeight ) ) ) + ( ( 1 + 1 ) * grayWeight ) ) + grayBitR ) ) ) ) ) ) ) $=
 f-grayWeight f-t term-one term-add f-t f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf f-grayBitQ f-grayBitR syn-32 f-t f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-30 f-t f-grayWeight f-grayBitQ f-grayBitR syn-31 f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-11 f-t f-grayWeight syn-10 term-zero f-grayWeight term-var w-lt f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-9 term-zero f-grayWeight term-var w-lt term-zero f-grayWeight term-var open-lt bnd-open f-grayDivisor f-grayWeight term-var term-one term-add f-grayWeight f-grayDivisor f-grayQuotient f-grayHalf syn-7 f-grayWeight f-grayDivisor f-grayQuotient syn-5 f-grayDivisor f-grayHalf syn-6 f-grayQuotient f-grayWeight term-var term-one term-add f-grayWeight f-grayDivisor f-grayQuotient syn-0 f-grayWeight f-grayDivisor f-grayQuotient syn-0 f-grayDivisor term-var f-grayQuotient term-var term-mul f-grayWeight term-var open-eq bnd-open bnd-ex f-grayDivisor term-var term-one w-eq f-grayDivisor f-grayHalf syn-3 f-grayDivisor term-var term-one w-eq f-grayDivisor term-var term-one open-eq bnd-open f-grayHalf f-grayDivisor term-var term-one term-add f-grayDivisor f-grayHalf syn-1 f-grayDivisor f-grayHalf syn-1 f-grayDivisor term-var term-one term-one term-add f-grayHalf term-var term-mul open-eq bnd-open bnd-ex bnd-or bnd-imp bnd-all bnd-and f-t f-grayWeight syn-10 term-one term-one term-add f-grayWeight term-var term-mul f-t term-one term-add open-lt bnd-open bnd-and f-t f-grayWeight f-grayBitQ f-grayBitR syn-27 f-t f-grayWeight f-grayBitQ f-grayBitR syn-29 f-grayBitQ f-t term-one term-add f-t f-grayWeight f-grayBitQ f-grayBitR syn-17 f-grayBitR f-grayWeight term-var f-t f-grayWeight f-grayBitQ f-grayBitR syn-15 f-t f-grayWeight f-grayBitQ f-grayBitR syn-15 f-t f-grayWeight f-grayBitQ f-grayBitR syn-14 open-eq bnd-open bnd-ex bnd-ex f-grayBitQ f-t term-one term-add f-t f-grayWeight f-grayBitQ f-grayBitR syn-25 f-grayBitR term-one term-one term-add f-grayWeight term-var term-mul f-t f-grayWeight f-grayBitQ f-grayBitR syn-22 f-t f-grayWeight f-grayBitQ f-grayBitR syn-22 f-t f-grayWeight f-grayBitQ f-grayBitR syn-21 open-eq bnd-open bnd-ex bnd-ex bnd-or bnd-imp bnd-all $.
$}
