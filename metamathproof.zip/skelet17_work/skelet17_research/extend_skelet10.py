"""Incremental development driver. All generated statements must be verified."""
from pathlib import Path
import json
import resume_canonical as r
from ladder_skelet10 import add_skelet10
m=r.m
if any('-skelet10-' in k for k in m.theorems):
 raise SystemExit('Input already includes the Skelet #10 extension. Use the full rebuild, or set IDELTA0_INPUT to a previous verified snapshot.')
add_skelet10(m)
P=Path(__file__).resolve().parent
with (P/'skelet10_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for start in range(0,len(line),1048576):out.write(line[start:start+1048576])
  out.write('\n')
(P/'skelet10_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if '-skelet10-' in k},indent=2)+'\n')
print('Skelet #10 extension written.',flush=True)
