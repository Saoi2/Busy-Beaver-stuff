"""Bounded local emission and end-of-input witnesses. No compressed output yet."""
import json
import build_parser as r
n,m,nd,b,a=r.n,r.m,r.nd,r.b,r.a
A,M,Q,L,O,Z,N=n.A,n.M,n.Q,n.L,n.O,n.Z,n.N
two,eight=n.two,n.eight
eq,rewrite,bound,invoke,finish,save,flip=n.eq,n.rewrite,n.bound,n.invoke,n.finish,n.save,n.flip
aa,bb,cc,ff,vv,gg,ww=[m.declare('emit'+s,'term') for s in ('A','B','C','Flag','Value','OtherFlag','OtherValue')]
lf,lv=[m.declare('emitLocal'+s) for s in ('Flag','Value')]
ef,ev=[m.declare('emitFresh'+s) for s in ('Flag','Value')]
endstate,endflag,endvalue=[m.declare('emitEnd'+s) for s in ('State','Flag','Value')]
zs,zf,zv=[m.declare('emitFinalFresh'+s) for s in ('State','Flag','Value')]
def event(i,j):
    flag=int(i>=4 and j==1)
    return flag,n.TABLE[i][j]%2 if flag else 0
def terminal(i):return (1,((i//2)%2)^(i%2)) if i>=4 else (0,0)
def erow(aa,bb,cc,f,v,i,j):
    flag,bit=event(i,j)
    return nd.AND([Q(aa,a.num(i)),Q(bb,a.num(j)),Q(cc,a.num(n.TABLE[i][j])),Q(f,a.num(flag)),Q(v,a.num(bit))])
def EMIT(aa,bb,cc,f,v):return nd.OR([erow(aa,bb,cc,f,v,i,j) for i,j in r.VALID])
def endrow(c,f,v,i):
    flag,bit=terminal(i);return nd.AND([Q(c,a.num(i)),Q(f,a.num(flag)),Q(v,a.num(bit))])
def END(c,f,v):return nd.OR([endrow(c,f,v,i) for i in range(8)])
def choose(ctx,f,v,relation,fi,vi):
    fv,vv0=a.num(fi),a.num(vi);bound(ctx,fv,two,a.num(1-fi));bound(ctx,vv0,two,a.num(1-vi))
    m.bex_intro(ctx,v,two,relation(fv,v),vv0)
    return m.bex_intro(ctx,f,two,nd.BEX(v,two,relation(f,v)),fv)
def emission_total():
    prem=r.PARTIAL(aa,bb,cc);goal=nd.BEX(lf,two,nd.BEX(lv,two,EMIT(aa,bb,cc,lf,lv)))
    root=nd.Ctx();ctx=root.push(prem)
    def branch(ec,k):
        i,j=r.VALID[k];nd.unpack(ec,[Q(aa,a.num(i)),Q(bb,a.num(j)),Q(cc,a.num(n.TABLE[i][j]))]);f,v=event(i,j)
        for t in [a.num(f),a.num(v)]:ec.put(Q(t,t),b.refl(ec.g,t))
        nd.conj(ec,[Q(aa,a.num(i)),Q(bb,a.num(j)),Q(cc,a.num(n.TABLE[i][j])),Q(a.num(f),a.num(f)),Q(a.num(v),a.num(v))])
        nd.disj(ec,[erow(aa,bb,cc,a.num(f),a.num(v),u,w) for u,w in r.VALID],k)
        return choose(ec,lf,lv,lambda f,v:EMIT(aa,bb,cc,f,v),f,v)
    nd.cases(ctx,[r.clause(aa,bb,cc,i,j) for i,j in r.VALID],goal,branch)
    finish('skelet17-emission-local-total',root,prem,goal,ctx)
emission_total()
def eof_total():
    prem=L(cc,eight);goal=nd.BEX(lf,two,nd.BEX(lv,two,END(cc,lf,lv)))
    root=nd.Ctx();ctx=root.push(prem)
    def branch(ec,i):
        f,v=terminal(i)
        for t in [a.num(f),a.num(v)]:ec.put(Q(t,t),b.refl(ec.g,t))
        nd.conj(ec,[Q(cc,a.num(i)),Q(a.num(f),a.num(f)),Q(a.num(v),a.num(v))])
        nd.disj(ec,[endrow(cc,a.num(f),a.num(v),j) for j in range(8)],i)
        return choose(ec,lf,lv,lambda f,v:END(cc,f,v),f,v)
    n.finite_cases(ctx,cc,8,goal,branch)
    finish('skelet17-emission-eof-total',root,prem,goal,ctx)
eof_total()
def unique(is_end):
    rel=(lambda f,v:END(cc,f,v)) if is_end else (lambda f,v:EMIT(aa,bb,cc,f,v))
    indices=list(range(8)) if is_end else r.VALID
    def parts(f,v,k):
        if is_end:
            z,w=terminal(k);return [Q(cc,a.num(k)),Q(f,a.num(z)),Q(v,a.num(w))]
        i,j=k;z,w=event(i,j)
        return [Q(aa,a.num(i)),Q(bb,a.num(j)),Q(cc,a.num(n.TABLE[i][j])),Q(f,a.num(z)),Q(v,a.num(w))]
    fs=[rel(ff,vv),rel(gg,ww)];prem=b.And(*fs);goal=b.And(Q(ff,gg),Q(vv,ww));root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    def first(ec,k):
        key=indices[k];nd.unpack(ec,parts(ff,vv,key))
        def second(hc,j):
            other=indices[j];nd.unpack(hc,parts(gg,ww,other))
            if is_end and key!=other:return r.conflict(hc,cc,key,other,goal)
            if not is_end and key[0]!=other[0]:return r.conflict(hc,aa,key[0],other[0],goal)
            if not is_end and key[1]!=other[1]:return r.conflict(hc,bb,key[1],other[1],goal)
            f,v=terminal(key) if is_end else event(*key)
            for left,right,constant in [(ff,gg,f),(vv,ww,v)]:
                hc.put(Q(left,right),a.trans(left,a.num(constant),right,hc.get(Q(left,a.num(constant))),a.sym(right,a.num(constant),hc.get(Q(right,a.num(constant))),hc.g),hc.g))
            return hc.both(*goal[1:])
        return nd.cases(ec,[nd.AND(parts(gg,ww,k)) for k in indices],goal,second)
    nd.cases(ctx,[nd.AND(parts(ff,vv,k)) for k in indices],goal,first)
    finish('skelet17-emission-'+('eof' if is_end else 'local')+'-unique',root,prem,goal,ctx)
unique(False);unique(True)

def EBODY(x,S,p,av,bv,cv,f,v):return nd.AND(n.list_body(x,S,p,av,bv,cv)[:3]+[EMIT(av,bv,cv,f,v)])
def ELOCAL(x,S,p):return nd.BEX(n.av,eight,nd.BEX(n.bv,two,nd.BEX(n.cv,eight,nd.BEX(lf,two,nd.BEX(lv,two,EBODY(x,S,p,n.av,n.bv,n.cv,lf,lv))))))
def ERUN(x,S):return nd.BALL(n.place,A(x,O),b.Imp(m.power2(n.place),ELOCAL(x,S,n.place)))
def lift_emissions():
    prem=r.ORUN(n.x,n.s);root=nd.Ctx();ctx=root.push(prem);p=n.pf;guard=L(p,A(n.x,O));gc=ctx.push(guard);pc=gc.push(m.power2(p));goal=ELOCAL(n.x,n.s,p)
    _,ip=pc.all_elim(n.place,prem[2],p);pc.mp(guard,b.Imp(m.power2(p),r.OLOCAL(n.x,n.s,p)),ip);pc.mp(m.power2(p),r.OLOCAL(n.x,n.s,p))
    def first(ac):
        def second(bc):
            def third(cc0):
                fields=n.list_body(n.x,n.s,p,n.af,n.bf,n.cf)[:3]+[r.PARTIAL(n.af,n.bf,n.cf)];nd.unpack(cc0,fields)
                invoke(cc0,'skelet17-emission-local-total',{'emitA':n.af,'emitB':n.bf,'emitC':n.cf})
                def flag(fc):
                    def value(vc):
                        nd.conj(vc,fields[:3]+[EMIT(n.af,n.bf,n.cf,ef,ev)])
                        m.bex_intro(vc,lv,two,EBODY(n.x,n.s,p,n.af,n.bf,n.cf,ef,lv),ev)
                        m.bex_intro(vc,lf,two,nd.BEX(lv,two,EBODY(n.x,n.s,p,n.af,n.bf,n.cf,lf,lv)),ef)
                        m.bex_intro(vc,n.cv,eight,nd.BEX(lf,two,nd.BEX(lv,two,EBODY(n.x,n.s,p,n.af,n.bf,n.cv,lf,lv))),n.cf)
                        m.bex_intro(vc,n.bv,two,nd.BEX(n.cv,eight,nd.BEX(lf,two,nd.BEX(lv,two,EBODY(n.x,n.s,p,n.af,n.bv,n.cv,lf,lv)))),n.bf)
                        return m.bex_intro(vc,n.av,eight,nd.BEX(n.bv,two,nd.BEX(n.cv,eight,nd.BEX(lf,two,nd.BEX(lv,two,EBODY(n.x,n.s,p,n.av,n.bv,n.cv,lf,lv))))),n.af)
                    return m.bex_elim(fc,lv,two,EMIT(n.af,n.bf,n.cf,ef,lv),ev,goal,value)
                return m.bex_elim(cc0,lf,two,nd.BEX(lv,two,EMIT(n.af,n.bf,n.cf,lf,lv)),ef,goal,flag)
            return m.bex_elim(bc,n.cv,eight,r.OBODY(n.x,n.s,p,n.af,n.bf,n.cv),n.cf,goal,third)
        return m.bex_elim(ac,n.bv,two,nd.BEX(n.cv,eight,r.OBODY(n.x,n.s,p,n.af,n.bv,n.cv)),n.bf,goal,second)
    m.bex_elim(pc,n.av,eight,nd.BEX(n.bv,two,nd.BEX(n.cv,eight,r.OBODY(n.x,n.s,p,n.av,n.bv,n.cv))),n.af,goal,first)
    gc.intro(m.power2(p),goal,pc);ctx.intro(guard,b.Imp(m.power2(p),goal),gc);ctx.all_intro(p,b.Imp(guard,b.Imp(m.power2(p),goal)))
    m.rename_all(ctx,p,n.place,lambda q:b.Imp(L(q,A(n.x,O)),b.Imp(m.power2(q),ELOCAL(n.x,n.s,q))))
    finish('skelet17-emission-pointwise-run',root,prem,ERUN(n.x,n.s),ctx,
           'Every original control annotation supports bounded local emission flags and values at every input place. No packed output or emission-count existence is claimed.')
lift_emissions()

def COMPLETE(x,P,S,c,f,v):return nd.AND([m.power2(P),L(x,M(two,P)),L(S,M(eight,n.cube(P))),ERUN(x,S),n.FIELD(S,O,eight,c),END(c,f,v)])
def tail(x,P,S):return nd.BEX(endstate,eight,nd.BEX(endflag,two,nd.BEX(endvalue,two,COMPLETE(x,P,S,endstate,endflag,endvalue))))
def complete_exists():
    fs=[r.WORD(n.x),L(Z,n.x)];prem=b.And(*fs);goal=nd.BEX(n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),tail(n.x,n.lead,n.codevar)))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs);invoke(ctx,'skelet17-parser-original-certificate-exists')
    def place(pc):
        def code(sc):
            nd.unpack(sc,[m.power2(n.lp),L(n.x,M(two,n.lp)),L(n.st,M(eight,n.cube(n.lp))),r.ORUN(n.x,n.st)])
            invoke(sc,'skelet17-emission-pointwise-run',{'annStates':n.st})
            bound(sc,Z,O,Z);bound(sc,Z,eight,a.num(7));sc.both(L(Z,O),L(Z,eight))
            invoke(sc,'skelet17-annotation-field-total',{'annInput':n.st,'annScale':O,'annBase':eight})
            def final_control(fc):
                invoke(fc,'skelet17-emission-eof-total',{'emitC':zs})
                def flag(hc):
                    def value(vc):
                        nd.conj(vc,[m.power2(n.lp),L(n.x,M(two,n.lp)),L(n.st,M(eight,n.cube(n.lp))),ERUN(n.x,n.st),n.FIELD(n.st,O,eight,zs),END(zs,zf,zv)])
                        m.bex_intro(vc,endvalue,two,COMPLETE(n.x,n.lp,n.st,zs,zf,endvalue),zv)
                        m.bex_intro(vc,endflag,two,nd.BEX(endvalue,two,COMPLETE(n.x,n.lp,n.st,zs,endflag,endvalue)),zf)
                        m.bex_intro(vc,endstate,eight,nd.BEX(endflag,two,nd.BEX(endvalue,two,COMPLETE(n.x,n.lp,n.st,endstate,endflag,endvalue))),zs)
                        m.bex_intro(vc,n.codevar,n.K(n.x),tail(n.x,n.lp,n.codevar),n.st)
                        return m.bex_intro(vc,n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),tail(n.x,n.lead,n.codevar)),n.lp)
                    return m.bex_elim(hc,lv,two,END(zs,zf,lv),zv,goal,value)
                return m.bex_elim(fc,lf,two,nd.BEX(lv,two,END(zs,lf,lv)),zf,goal,flag)
            return m.bex_elim(sc,n.av,eight,n.FIELD(n.st,O,eight,n.av),zs,goal,final_control)
        return m.bex_elim(pc,n.codevar,n.K(n.x),r.OCERT_BODY(n.x,n.lp,n.codevar),n.st,goal,code)
    m.bex_elim(ctx,n.lead,A(n.x,O),nd.BEX(n.codevar,n.K(n.x),r.OCERT_BODY(n.x,n.lead,n.codevar)),n.lp,goal,place)
    finish('skelet17-emission-local-and-eof-certificate',root,prem,goal,ctx,
           'Every positive valid input has a bounded control certificate with pointwise emission witnesses and a bounded terminal-state EOF decision. No counting or compressed-output theorem.')
complete_exists()
def eof_flag_last_bit():
    fs=[r.PARTIAL(aa,bb,cc),END(cc,ff,vv)];prem=b.And(*fs);goal=Q(ff,bb)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    def first(ec,k):
        i,j=r.VALID[k];out=n.TABLE[i][j]
        nd.unpack(ec,[Q(aa,a.num(i)),Q(bb,a.num(j)),Q(cc,a.num(out))])
        def second(hc,l):
            f,v=terminal(l);nd.unpack(hc,[Q(cc,a.num(l)),Q(ff,a.num(f)),Q(vv,a.num(v))])
            if out!=l:return r.conflict(hc,cc,out,l,goal)
            assert f==j
            return hc.put(goal,a.trans(ff,a.num(j),bb,hc.get(Q(ff,a.num(j))),a.sym(bb,a.num(j),hc.get(Q(bb,a.num(j))),hc.g),hc.g))
        return nd.cases(ec,[endrow(cc,ff,vv,l) for l in range(8)],goal,second)
    nd.cases(ctx,[r.clause(aa,bb,cc,i,j) for i,j in r.VALID],goal,first)
    finish('skelet17-emission-eof-flag-last-bit',root,prem,goal,ctx)
eof_flag_last_bit()
def eof_flag_field():
    fs=[L(Z,n.x),r.ORUN(n.x,n.s),L(cc,eight),n.FIELD(n.s,O,eight,cc),END(cc,ff,vv)]
    prem=nd.AND(fs);goal=n.FIELD(n.x,O,two,ff);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    m.ltadd(ctx,Z,n.x,O);eq(ctx,A(Z,O),O);rewrite(ctx,L(a.E,A(n.x,O)),A(Z,O),O)
    invoke(ctx,'skelet17-binary-power-one',{},False)
    _,ip=ctx.all_elim(n.place,r.ORUN(n.x,n.s)[2],O)
    ctx.mp(L(O,A(n.x,O)),b.Imp(m.power2(O),r.OLOCAL(n.x,n.s,O)),ip);ctx.mp(m.power2(O),r.OLOCAL(n.x,n.s,O))
    def first(ac):
        def second(bc):
            def third(hc):
                nd.unpack(hc,n.list_body(n.x,n.s,O,n.af,n.bf,n.cf)[:3]+[r.PARTIAL(n.af,n.bf,n.cf)])
                n.scale_field(hc,n.s,n.cube(O),O,eight,n.cf)
                r.value_unique(hc,n.s,O,eight,n.cf,cc)
                rewrite(hc,END(a.E,ff,vv),cc,n.cf,hc.get(flip(hc,Q(n.cf,cc))))
                hc.both(r.PARTIAL(n.af,n.bf,n.cf),END(n.cf,ff,vv))
                invoke(hc,'skelet17-emission-eof-flag-last-bit',{'emitA':n.af,'emitB':n.bf,'emitC':n.cf})
                return rewrite(hc,n.FIELD(n.x,O,two,a.E),n.bf,ff,hc.get(flip(hc,Q(ff,n.bf))))
            return m.bex_elim(bc,n.cv,eight,r.OBODY(n.x,n.s,O,n.af,n.bf,n.cv),n.cf,goal,third)
        return m.bex_elim(ac,n.bv,two,nd.BEX(n.cv,eight,r.OBODY(n.x,n.s,O,n.af,n.bv,n.cv)),n.bf,goal,second)
    m.bex_elim(ctx,n.av,eight,nd.BEX(n.bv,two,nd.BEX(n.cv,eight,r.OBODY(n.x,n.s,O,n.av,n.bv,n.cv))),n.af,goal,first)
    finish('skelet17-emission-eof-flag-input-parity',root,prem,goal,ctx,
           'For a positive annotated input, the terminal emission flag is its least significant input bit. No induction.')
eof_flag_field()
def write():
    (m.P/'emissions_raw.mm').write_text('\n'.join(b.lines)+'\n')
    (m.P/'emission_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if 'emission-' in k},indent=2)+'\n')
if __name__=='__main__':write()
