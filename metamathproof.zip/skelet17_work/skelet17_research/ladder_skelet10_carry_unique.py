"""Bounded strong induction proving carry uniqueness on Sparse inputs."""
def add_skelet10_carry_unique(m,right,api):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;O,Z=m.O,m.Z;use=m.invoke
 two,three,four=map(ar.num,(2,3,4));J=right['carry'];sparse=api['sparse']
 H=m.declare('uniqueOutputBound','term')
 i,tx,tf,uy,uz,fy,fz,q,d,a,v,w=[m.declare('unique'+n) for n in ('Index','Word','FreshWord','First','Second','FreshFirst','FreshSecond','Half','Digit','Quarter','SmallFirst','SmallSecond')]
 ov=m.declare('syncOddOutput')
 def prem(x,y,z):return nd.AND([sparse(x),J(x,y),J(x,z)])
 def body(x,y,z):return b.Imp(prem(x,y,z),Q(y,z))
 def U(x):return nd.BALL(uy,H,nd.BALL(uz,H,body(x,uy,uz)))
 def phi(k):return nd.BALL(tx,A(k,O),U(tx))
 def equality(c,y,z,value):
  return c.put(Q(y,z),ar.trans(y,value,z,c.get(Q(y,value)),ar.sym(z,value,c.get(Q(z,value)),c.g),c.g))
 def build_outputs(parent,x,fn):
  cy=parent.push(L(fy,H));cz=cy.push(L(fz,H));cc=cz.push(prem(x,fy,fz));nd.unpack(cc,[sparse(x),J(x,fy),J(x,fz)])
  cc.put(Q(fy,fz),fn(cc,fy,fz));cz.intro(prem(x,fy,fz),Q(fy,fz),cc)
  cy.intro(L(fz,H),body(x,fy,fz),cz);cy.all_intro(fz,b.Imp(L(fz,H),body(x,fy,fz)))
  m.rename_all(cy,fz,uz,lambda z:b.Imp(L(z,H),body(x,fy,z)))
  parent.intro(L(fy,H),nd.BALL(uz,H,body(x,fy,uz)),cy);parent.all_intro(fy,b.Imp(L(fy,H),nd.BALL(uz,H,body(x,fy,uz))))
  return m.rename_all(parent,fy,uy,lambda y:b.Imp(L(y,H),nd.BALL(uz,H,body(x,y,uz))))
 root=nd.Ctx()
 def zero(c,y,z):
  m.eq(c,Z,M(two,Z))
  for out in (y,z):
   m.rewrite(c,J(ar.E,out),Z,M(two,Z));use(c,'skelet17-ladder-skelet10-carry-base-inverse',{'t':Z,'u':out})
  return equality(c,y,z,A(M(four,Z),O))
 build_outputs(root,Z,zero)
 def build_words(parent,k,fn):
  guard=L(tf,A(k,O));gc=parent.push(guard);gc.put(U(tf),fn(gc));parent.intro(guard,U(tf),gc);parent.all_intro(tf,b.Imp(guard,U(tf)))
  return m.rename_all(parent,tf,tx,lambda x:b.Imp(L(x,A(k,O)),U(x)))
 def base(c):
  use(c,'skelet17-binary-below-successor',{'t':tf,'u':Z})
  def case(dc,k):
   if k==0:
    dc.put(b.Not(L(tf,Z)),b.ax('O4',dc.g,t=tf));return dc.explode(L(tf,Z),U(tf))
   return m.rewrite(dc,U(ar.E),Z,tf,ar.sym(tf,Z,dc.get(Q(tf,Z)),dc.g))
  return nd.cases(c,[L(tf,Z),Q(tf,Z)],U(tf),case)
 build_words(root,Z,base);sc=root.push(phi(i))
 def ih(c,x):
  c.all_elim(tx,b.Imp(L(tx,A(i,O)),U(tx)),x);return c.mp(L(x,A(i,O)),U(x))
 def successor(c):
  use(c,'skelet17-binary-below-successor',{'t':tf,'u':A(i,O)})
  def case(dc,k):
   if k==0:return ih(dc,tf)
   def prove(cc,y,z):
    goal=Q(y,z);m.bound(cc,Z,two,O);use(cc,'skelet17-bounded-division-exists',{'t':tf,'u':two})
    def half(qc):
     def digit(rc):
      e=Q(tf,A(M(two,q),d));nd.conj(rc,[sparse(tf),e,L(d,two)]);use(rc,'skelet17-ladder-skelet10-sparse-pop',{'t':tf,'u':q,'v':d})
      use(rc,'skelet17-binary-digit-cases',{'t':d})
      def bit(bc,j):
       if j==0:
        ee=Q(tf,M(two,q));m.eq(bc,*ee[1:],[e,Q(d,Z)])
        for out in (y,z):
         m.rewrite(bc,J(ar.E,out),tf,M(two,q));use(bc,'skelet17-ladder-skelet10-carry-base-inverse',{'t':q,'u':out})
        return equality(bc,y,z,A(M(four,q),O))
       odd=A(M(two,q),O);m.eq(bc,tf,odd,[e,Q(d,O)]);m.rewrite(bc,sparse(ar.E),tf,odd)
       use(bc,'skelet17-ladder-skelet10-sparse-odd-tail',{'t':q})
       def quarter(ac):
        ae=Q(q,M(two,a));ee=Q(tf,A(M(four,a),O));m.eq(ac,*ee[1:],[e,Q(d,O),ae])
        m.eq(ac,q,A(M(two,a),Z),[ae]);m.bound(ac,Z,two,O);nd.conj(ac,[sparse(q),Q(q,A(M(two,a),Z)),L(Z,two)])
        use(ac,'skelet17-ladder-skelet10-sparse-pop',{'t':q,'u':a,'v':Z})
        m.bound(ac,a,tf,M(three,a),[ee]);m.rewrite(ac,L(a,ar.E),tf,A(i,O));ih(ac,a)
        def inverse_body(out,small):return b.And(Q(out,M(four,small)),J(a,small))
        for out in (y,z):
         m.rewrite(ac,J(ar.E,out),tf,A(M(four,a),O));use(ac,'skelet17-ladder-skelet10-carry-prefix-inverse',{'t':a,'u':out})
        def first(vc):
         nd.unpack(vc,[Q(y,M(four,v)),J(a,v)]);vc.both(L(v,A(y,O)),L(y,H));use(vc,'skelet17-binary-le-lt-trans',{'t':v,'u':y,'v':H})
         def second(wc):
          nd.unpack(wc,[Q(z,M(four,w)),J(a,w)]);wc.both(L(w,A(z,O)),L(z,H));use(wc,'skelet17-binary-le-lt-trans',{'t':w,'u':z,'v':H})
          nd.inst_balls(wc,[uy,uz],H,body(a,uy,uz),[v,w]);nd.conj(wc,[sparse(a),J(a,v),J(a,w)]);wc.mp(prem(a,v,w),Q(v,w))
          return m.eq(wc,y,z,[Q(y,M(four,v)),Q(z,M(four,w)),Q(v,w)])
         return m.bex_elim(vc,ov,A(z,O),inverse_body(z,ov),w,goal,second)
        return m.bex_elim(ac,ov,A(y,O),inverse_body(y,ov),v,goal,first)
       return m.bex_elim(bc,m.pz,A(q,O),Q(q,M(two,m.pz)),a,goal,quarter)
      return nd.cases(rc,[Q(d,Z),Q(d,O)],goal,bit)
     return m.bex_elim(qc,m.r,two,Q(tf,A(M(two,q),m.r)),d,goal,digit)
    return m.bex_elim(cc,m.q,A(tf,O),nd.BEX(m.r,two,Q(tf,A(M(two,m.q),m.r))),q,goal,half)
   return build_outputs(dc,tf,prove)
  return nd.cases(c,[L(tf,A(i,O)),Q(tf,A(i,O))],U(tf),case)
 build_words(sc,A(i,O),successor);root.intro(phi(i),phi(A(i,O)),sc);root.all_intro(i,b.Imp(phi(i),phi(A(i,O))))
 m.induction(root,i,phi(i),phi(Z),b.All(i,b.Imp(phi(i),phi(A(i,O)))))
 root.all_elim(i,phi(i),b.t);m.successor(root,b.t);root.all_elim(tx,b.Imp(L(tx,A(b.t,O)),U(tx)),b.t);root.mp(L(b.t,A(b.t,O)),U(b.t))
 m.save('z10-carry-unique-bounded',root,U(b.t),'One bounded strong-induction construction, with a fixed output bound as a parameter.')
 x,y,z=b.t,b.u,b.v;limit=A(A(y,z),O);rr=nd.Ctx();ant=prem(x,y,z);cc=rr.push(ant);nd.unpack(cc,[sparse(x),J(x,y),J(x,z)])
 use(cc,'z10-carry-unique-bounded',{H[1]:limit},False)
 m.bound(cc,y,limit,z);m.bound(cc,z,limit,y);nd.inst_balls(cc,[uy,uz],limit,body(x,uy,uz),[y,z]);cc.mp(ant,Q(y,z))
 m.finish('skelet17-ladder-skelet10-carry-unique-sparse',rr,ant,Q(y,z),cc,'The bounded carry graph is functional on Sparse inputs. No totality or transformed-word uniqueness assumption.')
