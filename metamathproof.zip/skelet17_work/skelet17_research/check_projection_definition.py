"""Check definitional identity with the preceding 12-row EMIT relation.

This is a source-definition check, not an additional arithmetic axiom or a
replacement for the verified bridge proof. Only selected definitions run.
"""
from pathlib import Path
from types import SimpleNamespace
import ast,json
P=Path(__file__).resolve().parent
def binary(op):return lambda a,b:(op,a,b)
def fold(op,items):
    if len(items)==1:return items[0]
    return (op,items[0],fold(op,items[1:]))
def num(n):return ('zero',) if n==0 else ('one',) if n==1 else ('+',num(n-1),('one',))
common={'Q':binary('='),'nd':SimpleNamespace(AND=lambda xs:fold('/\\',xs),OR=lambda xs:fold('\\/',xs)),
        'a':SimpleNamespace(num=num)}
def selected(file,names,env):
    tree=ast.parse((P/file).read_text());nodes=[]
    for node in tree.body:
        if isinstance(node,ast.FunctionDef) and node.name in names:nodes.append(node)
        elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in node.targets):nodes.append(node)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),file,'exec'),env)
    return env
control=selected('build_annotations.py',{'TABLE'},{} )['TABLE']
valid=selected('build_parser.py',{'ROWS','VALID'},{} )['VALID']
old=selected('build_emissions.py',{'event','erow','EMIT'},dict(common,n=SimpleNamespace(TABLE=control),r=SimpleNamespace(VALID=valid)))
new=selected('build_packet_projection.py',{'CONTROL','ORIGINAL','event','emission_row','EMIT'},dict(common))
args=[('term',x) for x in ['a','b','c','f','v']]
assert old['EMIT'](*args)==new['EMIT'](*args)
out={'original_emission_definition_identical':True,'original_valid_rows':len(valid),
     'method':'exact equality of expanded first-order formula trees with common parameter names',
     'scope':'definition check only; soundness is established by the separately verified Metamath proof'}
(P/'projection_definition_check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
