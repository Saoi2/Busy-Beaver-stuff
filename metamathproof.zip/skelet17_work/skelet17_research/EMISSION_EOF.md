# Checked emission decisions and end-of-input handling

This checkpoint extends the original-parser control certificates with
local emitted-digit decisions and a terminal decision. All proofs use
the unchanged original 93 trusted declarations. The machine and its
history encoding are unchanged.

The whole compressed Gray decoder is still unproved, as is Skelet #17
nonhalting. The new result does not count emitted digits or construct
a packed output stream. It proves bounded local decisions and connects
the terminal decision to the final control and last input bit.

## Why an emission flag is necessary

Use the parser control encoding 4*pending+2*parity+xor from
CONTROL_ANNOTATIONS.md. An ordinary input-reading transition emits a digit
exactly when a pending 1 is followed by another 1. The earlier 1 is then a
separator terminating a run of 10 pairs. Its parity is XORed into the
cumulative parity, and that new cumulative bit is emitted.

| Old control | Input | New control | Emitted digit |
| --- | --- | --- | --- |
| 4 | 1 | 4 | 0 |
| 5 | 1 | 5 | 1 |
| 6 | 1 | 5 | 1 |
| 7 | 1 | 4 | 0 |

The other eight original transitions emit nothing. Represent a decision
by two bits (f,v): f=1 means emit v; f=0 means emit nothing. In the latter
case v is conventionally 0. This distinguishes an emitted 0 from no output.

Emit(a,b,c,f,v) is the disjunction of the twelve original transition rows,
each extended by equalities for the flag and value. The checked theorems
`skelet17-emission-local-total` and `skelet17-emission-local-unique` prove

    DeltaOriginal(a,b,c) -> exists f<2 exists v<2 Emit(a,b,c,f,v),
    Emit(a,b,c,f,v) and Emit(a,b,c,g,w) -> (f=g and v=w).

These are explicit finite natural-deduction case proofs, with no induction.

## The end-of-input decision

After the last input bit there may still be a pending 1. It is a separator
before an empty final run a_0; the source decoder emits the XOR of current
run parity and cumulative parity. If no 1 is pending, the current run is
a_0 and contributes no output.

Define End(c,f,v) by this eight-row table:

| Final control c | Flag f | Value v |
| --- | --- | --- |
| 0,1,2,3 | 0 | 0 |
| 4 | 1 | 0 |
| 5 | 1 | 1 |
| 6 | 1 | 1 |
| 7 | 1 | 0 |

The grouped first row abbreviates four separate clauses. The checked
`skelet17-emission-eof-total` proves c<8 implies a bounded (f,v) decision.
`skelet17-emission-eof-unique` proves the decision is unique. Neither proof
uses induction. These theorems establish the explicit terminal policy;
they do not yet identify a compressed output with the source Gray-counter
definition on lists.

There is also a checked connection to the input itself. The finite table
proves that if an original transition reads b and ends in c, then any
End(c,f,v) has f=b. Instantiating an annotated run at input place 1 and
using packed-field uniqueness proves

    0<x and RunOriginal(x,S) and c<8 and Field(S,1,8,c)
      and End(c,f,v) -> Field(x,1,2,f).

This is `skelet17-emission-eof-flag-input-parity`. With the flag's bit bound,
it says the terminal emission flag is the least significant input bit.
Thus a final 1 triggers a terminal emission and a final 0 does not. This
connection needs no induction and uses the existing packed control code.

For example, input word 1 has no ordinary emission but emits 0 at EOF.
Input 10 emits nothing, including at EOF. Input 11 emits 0 while reading
the second 1 and another 0 at EOF. All three have integer output zero,
but their output lengths differ. A proof about the decoded integer alone
would lose information needed to distinguish these cases. For input 1101
the ordinary emitted digit is 0 and the terminal digit is 1, yielding 01.

## The combined bounded certificate

Let ERun be RunOriginal with two more bounded witnesses f,v at each
significant input place, and replace its local table condition by Emit.
The theorem `skelet17-emission-pointwise-run` proves

    RunOriginal(x,S) -> ERun(x,S).

It retains the same three existing input/control fields at every place
and supplies their emission decisions. No induction is used for this lift.

The theorem `skelet17-emission-local-and-eof-certificate` proves, assuming
LowerWord(x) and x>0, the existence of bounded witnesses

    P<x+1, S<8*(x+1)^3, c<8, f<2, v<2

satisfying

    Pow2(P), x<2*P, S<8*P^3, ERun(x,S),
    Field(S,1,8,c), End(c,f,v).

The low base-8 digit of S is the control after the final input bit. The
proof reads that existing field by bounded division, applies terminal
decision totality, and introduces the bounded witnesses. The dependency
closure has the same two bounded-induction constructions as the preceding
control certificate. It introduces no further induction construction.

## Quantifier order and remaining work

Inside ERun the quantifiers have the form

    forall input place p, exists local flag f and value v ...

The result does not interchange these quantifiers to assert existence of
packed global flag/value codes. In particular, no comprehension or counting
principle has silently been added. The control code S is globally packed;
the emission decisions at its positions are currently pointwise witnesses.

Still needed are proofs constructing and verifying emission counts and
output ranks, a compressed output word, and its equality with the source
Gray-counter value. The balanced-tree design remains a proposal for those
steps. The global invariant excluding the machine pattern B111 is another
separate unfinished proof.

## Verification

The official verifier checks emissions_checked.mm. audit_emissions.py
compares all trusted expressions, hypotheses and distinct-variable
conditions against scan_checked.mm and audits induction dependencies.
Its findings and hashes are in emission_manifest.json.

check_emissions.py independently compares all twelve ordinary emission
rows with the source Python transition function. On all 21,844 previous
valid-list test cases it reconstructs the output digits directly from
packed control fields, adds the EOF digit, and checks the complete digit
list and integer against the executable decoder and source Gray value.
All eight terminal controls occur among these tests. These checks validate
the interpretation; they are not formal counting or Gray-counter proofs.

From the archive root:

    python3 skelet17_research/build_emissions.py
    python3 skelet17_research/prune.py emissions_raw.mm emissions_checked.mm
    metamath 'read "skelet17_research/emissions_checked.mm"' 'verify proof *' exit
    python3 skelet17_research/check_emissions.py
    python3 skelet17_research/audit_emissions.py

Save the clean verifier output as emission_verification.log before auditing.
