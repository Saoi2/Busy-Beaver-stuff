"""Independent statement reconstruction for the complete left-counter routine.

No imports from the full-left proof generators: the ordinary instruction
relation and the arithmetic word graphs come from the earlier independent
checkers. Numerical traces supplement, and do not replace, kernel checking.
"""
from pathlib import Path
import json
from check_skelet10_scope import parse,plus,times,eq,lt,implies,both,AND,OR,num,EX,sparse,power,step
from check_skelet10_left import norm
from check_skelet10_spread import transform,bounded
from check_skelet10_right import carry
from check_skelet10_clear import rank as clear_rank
from check_skelet10_right import alls,exs
PTH=Path(__file__).resolve().parent
TWO,THREE,FOUR,EIGHT=map(num,(2,3,4,8))
w,tail='leftInput','leftRightTail'
S=plus(times(THREE,w),TWO);W=plus(w,'1');PB=plus(times(THREE,w),'1');K=times(EIGHT,S)
p,s,u,a,t,v=['left'+x for x in ('Scale','Suffix','Word','Tail','Encoded','Output')]
def subst(f,m):
 if isinstance(f,str):return m.get(f,f)
 return tuple(subst(x,m) for x in f)
def wr(c):return plus(times(TWO,c[3]),c[2])
def wl(c):return plus(times(TWO,c[1]),c[2])
def push(x,d):return plus(times(TWO,x),d)
def double(x,k):
 for _ in range(k):x=times(TWO,x)
 return x
def core(p):return times(times(p,p),plus(tail,'1'))
def rho(j,u):return plus(plus(K,times(EIGHT,u)),num([8,7,6,5,4,7,6,5][j]))
def fields(c,r,j,p,u,t):
 if j==0:return [eq(c[0],THREE),lt(c[2],TWO),transform(u,wl(c)),eq(plus(c[3],'1'),double(core(p),2)),eq(r,rho(j,u))]
 shape={1:t,2:push(t,'1'),3:push(push(t,'1'),'0'),4:push(push(push(t,'1'),'0'),'1'),5:push(push(t,'1'),'0'),6:push(t,'1'),7:t}
 return [eq(c[0],num([3,2,4,1,0,2,3,2][j])),eq(c[2],num([0,0,1,1,1,1,0,1][j])),eq(c[1],shape[j]),eq(plus(c[3],'1'),double(core(p),[2,3,2,1,0,3,4,5][j])),eq(r,rho(j,u))]
def scan(c,r):
 base=both(eq(u,times(TWO,a)),OR([AND(fields(c,r,j,p,u,t)) for j in range(1,5)]))
 carryphase=both(eq(u,plus(times(FOUR,a),'1')),OR([AND(fields(c,r,j,p,u,t)) for j in range(5,8)]))
 micro=EX(a,W,EX(t,plus(c[1],'1'),AND([sparse(a),transform(a,t),both_or(base,carryphase)])))
 common=[power(p),eq(p,plus(times(THREE,s),'1')),eq(w,plus(times(p,u),s)),sparse(u)]
 return EX(p,S,EX(s,W,EX(u,W,AND([*common,both_or(AND(fields(c,r,0,p,u,t)),micro)]))))
def both_or(x,y):return ('\\/',x,y)
def returning(c,r):return EX(v,S,both(carry(w,v),subst(clear_rank(c,r),{'clearInitialScale':PB,'clearOutputWord':v,'clearRightTail':tail})))
def rank(c,r):return both_or(scan(c,r),returning(c,r))
def entry(c):return AND([eq(c[0],THREE),lt(c[2],TWO),sparse(w),transform(w,wl(c)),eq(c[3],plus(times(FOUR,tail),THREE))])
def endpoint(c):return AND([eq(c[0],'0'),eq(wr(c),tail),EX(v,S,AND([carry(w,v),transform(v,c[1]),sparse(v)]))])
R0=rho(0,w)
# Reconstruct the same raw beta-history shape with the leftRun namespace.
from check_skelet10_right import ALL
H,n,offset=['leftRun'+s for s in ('H','N','Offset')]
def at(index,row):
 out=[];q='leftRunBetaQuotient'
 for j,x in enumerate(row):
  mod=plus('1',times(plus(plus(offset,index),'1'),'leftRunC'+str(j)))
  out.append(EX(q,H,both(eq('leftRunB'+str(j),plus(times(q,mod),x)),lt(x,mod))))
 return AND(out)
TV=['leftRunTotalRow'+x for x in ('Q','L','Bit','R')];IV=['leftRunInitialRow'+x for x in ('Q','L','Bit','R')]
SV=['leftRunStepRow'+str(j)+x for j in (0,1) for x in ('Q','L','Bit','R')]
EV=['leftRunAvoidRow'+x for x in ('Q','L','Bit','R')];IP=['leftRunIndRow'+x for x in ('Q','L','Bit','R')]
HR=['leftRunHalt'+x for x in ('Q','L','Bit','R')];ER=['leftRunExitRow'+x for x in ('Q','L','Bit','R')]
ti,si,ai,i=['leftRun'+x for x in ('TotalIndex','StepIndex','AvoidIndex','Index')];hr='leftRunHistoryScale'
total=ALL(ti,plus(n,'1'),exs(TV,H,at(ti,TV)))
initial=alls(IV,H,implies(at('0',IV),entry(IV)))
steps=ALL(si,n,alls(SV,H,implies(both(at(si,SV[:4]),at(plus(si,'1'),SV[4:])),step(SV[:4],SV[4:]))))
avoid=ALL(ai,plus(n,'1'),alls(EV,H,implies(at(ai,EV),('-.',endpoint(EV)))))
def inv(index,row):return EX(hr,plus(R0,'1'),both(rank(row,hr),lt(plus(index,hr),plus(R0,'1'))))
invariant=ALL(i,plus(n,'1'),alls(IP,H,implies(at(i,IP),inv(i,IP))))
xi='leftRunExitIndex';exit_goal=EX(xi,plus(n,'1'),exs(ER,H,both(at(xi,ER),endpoint(ER))))
cf=['z10Current'+x for x in ('Q','L','Bit','R')];nf=['z10Next'+x for x in ('Q','L','Bit','R')]
expected={
 'left-counter-entry':implies(entry(cf),rank(cf,R0)),
 'left-counter-step':implies(AND([rank(cf,'t'),('-.',endpoint(cf)),step(cf,nf)]),EX('leftOutputRank','t',rank(nf,'leftOutputRank'))),
 'left-window-invariant':implies(AND([total,initial,steps,avoid]),invariant),
 'left-window-bound':implies(AND([total,initial,steps,avoid]),lt(n,R0)),
 'left-window-exit':implies(AND([total,initial,steps,lt(R0,plus(n,'1'))]),exit_goal),
 'left-window-halting-barrier':implies(AND([total,initial,steps,*[lt(x,H) for x in HR],at(n,HR),eq(HR[0],num(5))]),exit_goal),
}
def main():
 actual=json.loads((PTH/'skelet10_full_left_theorems.json').read_text());assert len(actual)==6
 for name,f in expected.items():
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(f),label
  assert bounded(f),label
 for name in ('left-window-exit','left-window-halting-barrier'):
  text=actual['skelet17-ladder-skelet10-'+name]
  for forbidden in ('leftScale','leftSuffix','leftWord','leftTail','leftEncoded','leftRunHistoryScale','clearScale','clearWord','clearEncodedTail'):
   assert forbidden not in text,(name,forbidden)
 from explore_skelet10_left_scan import main as traces
 traces();numeric=json.loads((PTH/'skelet10_left_scan_experiment.json').read_text())
 out={'statements_checked':6,'independent_reconstruction_matches':True,'all_new_statements_delta0':True,
  'complete_left_counter':True,'ordinary_step_and_original_beta_format':True,
  'no_intermediate_annotations_in_exit_or_barrier':True,'right_tail_restored':True,
  'output_has_bounded_carry_graph_transform_and_sparse':True,'coarse_time_bound':'32*w+24',
  'finite_routine_cases':numeric['cases'],'finite_ordinary_steps':numeric['ordinary_steps'],
  'finite_tests_are_not_formal_proofs':True,'complete_two_counter_cycle':False,'whole_machine_nonhalting':False}
 (PTH/'skelet10_full_left_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
