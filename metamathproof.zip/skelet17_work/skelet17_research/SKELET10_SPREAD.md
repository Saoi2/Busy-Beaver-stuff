# Skelet #10: a bounded word-transform relation in I-Delta-0

The project now formalizes the arithmetic relation needed to describe the
left counter's word transformation. It proves a quadratic bound on its
witnesses and existence for every input, together with its two word
constructors. This develops the word encoding beyond the preceding
finite step contracts. Machine synchronization and whole-machine
nonhalting remain unfinished.

All statements are expanded formulas in the original language
0,1,+,*,<. The machine, ordinary Step relation and beta-history predicates
are unchanged. No new function symbol or defining axiom is introduced.

## The intended operation

Write an input in binary. Keep its digits but replace binary place values
1,2,4,8,... by 1,4,16,64,... . In effect, insert a zero between consecutive
binary digits. Examples are:

| x | Binary input | Spread(x) | Binary output | 10*Spread(x) |
|---:|---|---:|---|---:|
| 0 | 0 | 0 | 0 | 0 |
| 1 | 1 | 1 | 1 | 10 |
| 2 | 10 | 4 | 100 | 40 |
| 5 | 101 | 17 | 10001 | 170 |
| 10 | 1010 | 68 | 1000100 | 680 |

Thus a digit at place p moves to place p*p. There is no need to give
an exponentiation function to the arithmetic language.

The formal results establish base, constructor and bounded-existence
properties of a relation describing this operation. A separate formal
uniqueness theorem has not yet been added. We therefore use the relation
directly, rather than introducing Spread as a total function symbol.

## Exact bounded definitions

Use the already existing bounded divisor predicate Pow2(p). It says:

    0<p and forall d<p+1,
      (exists e<p+1, d*e=p) ->
      (d=1 or exists h<d+1, d=2h).

The existing one-bit predicate is

    One(x,p) := exists q<x+1, exists r<p,
        x = q*(2p) + p + r.

For a binary place p, this says the bit at p is 1. The q part contains
higher bits, and r contains lower bits. For example, One(13,4) holds
with q=1 and r=1, since 13=1*8+4+1.

Define Dil(x,z) as the conjunction of:

    forall p<x+1,
      (Pow2(p) and One(x,p)) -> One(z,p*p),

    forall q<z+1,
      (Pow2(q) and One(z,q)) ->
        exists p<x+1,
          Pow2(p) and q=p*p and One(x,p).

The first clause moves every input 1 to its squared place. The second
clause accounts for every output 1. Keeping both clauses is essential:
the first alone would allow unwanted additional output digits.

Every quantifier has an explicit bound made from arithmetic terms.
In particular, the inner remainder bound p*p is permitted in a Delta-0
formula. No quantified exponent, sequence-totality principle or tape
annotation is hidden in these definitions. Because its existential output
is bounded, the universally closed witness-existence statement is Pi-1.

## The main proved statements

All labels start `skelet17-ladder-skelet10-`.

| Label suffix | Statement |
|---|---|
| `spread-zero` | Dil(0,0). |
| `spread-push` | Dil(x,z) and d<2 imply Dil(2x+d,4z+d). |
| `spread-exists-quadratic` | For every x, there exists z<x*x+1 with Dil(x,z). |

The constructor reads the next input digit in base 2 and the corresponding
output digit in base 4. Since d<2, that output digit is always 0 or 1.

Five supporting one-bit lemmas prove the support bound, absence of a one
bit in zero, forward and backward digit shifts, and the characterization
of the low bit. These use the existing quotient-and-remainder predicates.
The backward shift reuses the earlier bounded division theorem.

## Why the constructor holds

For the forward clause, consider an input one-bit place p. The existing
Pow2 halving theorem gives either p=1 or p=2h with Pow2(h).
At p=1 the bit is just the newly appended digit. At p=2h the old input
bit was at h, and the old output bit was at h*h. Multiplying the output
by 4 moves this to 4*h*h=(2h)*(2h), as required.

For the reverse clause, similarly inspect an output place q. Place 1
again represents the appended digit. Place 2 cannot contain a 1, because
the constructor inserts a zero there. At a larger possible output place,
two halvings give q=4k. The old reverse clause supplies an input place p
with k=p*p. The new input place 2p then satisfies q=(2p)*(2p).

All quotient witnesses and their bounds are proved explicitly. This
argument reuses bounded division and Pow2 halving/doubling; it adds no
new induction construction.

## The bounded induction proving existence

The useful witness bound is z<=x*x. Suppose z<=u*u and d is 0 or 1.
The constructor produces 4z+d for input 2u+d. The bound is preserved:

    4z+d <= (2u+d)*(2u+d).

The formal proof avoids subtraction. It writes u*u=z+g using the
bounded inequality, then gives explicit nonnegative slack:

* For d=0 the slack is 4g.
* For d=1 the slack is 4g+4u.

Define

    E(x) := exists z<x*x+1, Dil(x,z),
    Phi(i) := forall x<i+1, E(x).

Phi is Delta-0, so its induction is an allowed instance of the existing
bounded-induction schema.

For Phi(0), any x<1 is zero, and Dil(0,0) supplies its witness. For the
successor step, an x<i+2 either already satisfies x<i+1, or equals i+1.
In the latter case x is positive. Bounded division gives x=2u+d with
d<2 and u<x=i+1. The induction hypothesis therefore supplies a witness
z<=u*u. The digit constructor and the slack calculation supply E(x).

Finally instantiate Phi at i=x and use x<x+1. This proves bounded
existence for an arbitrary input.

The proof uses one new bounded strong-induction construction. Its complete
dependency closure contains two induction constructions: this one and the
previously proved bounded division construction. These counts describe
this proof, rather than a lower bound on the strength required.

## The left-word relation

The intended left-counter transformation is 10*Spread(x). Present it as
another bounded relation:

    T(x,t) := exists z<t+1, t=10z and Dil(x,z).

The project proves:

| Label suffix | Statement |
|---|---|
| `transform-zero` | T(0,0). |
| `transform-prefix-0` | T(x,t) implies T(2x,4t). |
| `transform-prefix-10` | T(x,t) implies T(4x+1,16t+10). |
| `transform-exists-quadratic` | For every x, some t<10*x*x+1 satisfies T(x,t). |

The prefix strings are read nearest cell first. On Sparse inputs the constructors match
the left-word grammar used by the carry contracts: a 0 contributes a
00 block; a 10 contributes a 1010 block on the oppositely displayed left
side. These are graph implications with explicit bounded witnesses.

Scaling proofs keep 10 and 16 factored through reusable semiring
identities. They do not expand large products of successor numerals
into long, repeated arithmetic derivations.

## Connection to the remaining machine proof

The preceding checkpoint proposed a D-boundary relation involving a
word w, the least larger Sparse word R, and the left quotient
T(w)=4*(2L+b)+e with e<4. The new results supply an explicit Delta-0
relation for T and prove that a bounded output exists for each w.

Further work must show that the ordinary machine preserves the required
counter relationship through arbitrarily long carries and returns. The
right counter's exact successor behavior and the final raw-history safety
invariant also remain to be assembled. The new existence theorem alone
does not prove that a machine row has the required synchronized word.

## Verification and reproduction

All proofs remain in `idelta0_machines.mm` over the original 93 trusted
declarations. The independent Metamath verifier checks their derivations.
The dependency audit checks the induction counts and preservation of all
previous named theorem interfaces.

`check_skelet10_spread.py` independently reconstructs the twelve new
public statements, including both graph clauses and the exact existential
bounds. Supplementary tests compare the relation with numerical bit
spreading on a 12,288-pair grid and check 128 quadratic-bound examples.
Finite uniqueness on that grid is not a formal uniqueness theorem.

Use `rebuild_project.py --metamath /path/to/metamath` to regenerate, prune,
simplify, verify and audit the project. The new proof generator is
`ladder_skelet10_spread.py`.

For the earlier machine contracts, read SKELET10_LEFT_COUNTER.md and
SKELET10_RIGHT_COUNTER.md. The structural motivation is the left-word
grammar in [BusyCoq/Skelet10.v](https://github.com/ccz181078/Coq-BB5/blob/main/BusyCoq/Skelet10.v).
No Rocq theorem is imported as an arithmetic axiom.

## Subsequent decoding checkpoint

SKELET10_DECODING.md records six further verified results. The graph can
now be decoded with a bounded witness: Dil(2x+d,z) and d<2 give some
u<z+1 with z=4u+d and Dil(x,u). Both T constructors also have proved
reverse implications. These results require no new induction construction
or uniqueness premise. Whole-machine synchronization remains unfinished.
