# A checked bounded construction of control annotations

The new result is a uniform existence theorem in IDelta0 for locally
verified control-state annotations. It uses no additional trusted axioms.
It is not a theorem that the compressed Gray decoder is total or correct,
and it does not prove Skelet #17 nonhalting.

## Which states these are

These are the eight states of the auxiliary parser in `gray_transducer.py`,
not Skelet #17's working states A through E. The machine configurations
(q,L,b,R), machine instructions, and beta-coded histories are unchanged.
Only an auxiliary certificate field is being developed here.

Encode the parser tuple (pending,parity,xor) as 4*pending+2*parity+xor.
For a 1 with nothing pending, set pending. For a pending 1 followed by 0,
complete a 10 pair and toggle run parity. For two successive 1s, the first
is a separator: XOR the completed run's parity into the cumulative XOR.
Emission digits and the final end-of-input action are NOT part of this
new control-only predicate.

The table used in the theorem is explicitly total:

| Old control | Input 0: next control | Input 1: next control |
| --- | --- | --- |
| 0 | 0* | 4 |
| 1 | 0* | 5 |
| 2 | 0* | 6 |
| 3 | 0* | 7 |
| 4 | 2 | 4 |
| 5 | 3 | 5 |
| 6 | 0 | 5 |
| 7 | 1 | 4 |

The four starred entries were invalid transitions of the original partial
parser. We explicitly fill them with 0 for this auxiliary construction.
This permits an existence theorem for every input number. Correspondence
with the original partial parser must be proved under a valid-word
condition. The new kernel proofs do not yet establish that correspondence
from the bounded LowerWord predicate. Nothing in Skelet #17 is totalized
or modified by this choice.

## Where the control digits are stored

Let x be an input number and read its significant binary digits from most
to least significant. Concatenate the control AFTER each input digit as a
base-8 digit to form S. The control BEFORE the first input digit is 0.

The input digit at weight p=2^j corresponds to the base-8 digit of S at
weight p^3=8^j. This uses a fixed polynomial term p*p*p, not a function
whose exponent is a variable. Appending an input bit sends x to 2*x+b;
appending the next control sends S to 8*S+c. Cubing doubles the place
weight by the required factor 8.

This is a different layout for the auxiliary control field from the
earlier certificate prototype with an explicit end marker and padding.
It annotates exactly the significant input bits. A conversion to the
older padded layout has not been proved or needed for this theorem.

Example: x=13 has input word 1101. Its successive controls are 4,4,2,6,
so S is the octal number 4426, or decimal 2326.

| Input weight p | Input bit | Control before | Control after | Control weight p^3 |
| --- | --- | --- | --- | --- |
| 8 | 1 | 0 | 4 | 512 |
| 4 | 1 | 4 | 4 | 64 |
| 2 | 0 | 4 | 2 | 8 |
| 1 | 1 | 2 | 6 | 1 |

Here P=8 is a leading-place witness and S<8*P^3=4096.

## Exact bounded predicates

All the following abbreviations expand to the original first-order
language 0,1,+,*,=,< with ordinary guarded quantifiers. Define

    Field(z,p,B,v) := exists q<z+1 exists r<p
      (z=(B*p)*q+p*v+r).

The value bound v<B is supplied separately where required. The earlier
checked bounded predicate Pow2(p) is

    0<p and forall d<p+1
      ((exists e<p+1 (d*e=p)) ->
        (d=1 or exists h<d+1 (d=2*h))).

Write Delta(a,b,c) for the disjunction of the table's sixteen rows, each
expanded as a conjunction of three equalities to numerals. Then

    Run(x,S) := forall p<x+1 (Pow2(p) ->
      exists a<8 exists b<2 exists c<8
        (Field(S,(2*p)^3,8,a) and Field(x,p,2,b) and
         Field(S,p^3,8,c) and Delta(a,b,c))).

Every occurrence of a cube means multiplication of three terms. This is
a bounded formula. Its named syntax certificate is checked by Metamath;
its use in induction also carries explicit substitution certificates.

## The uniform existence theorem

Put K(x)=8*(x+1)^3. `skelet17-annotation-positive-certificate` proves

    0<x -> exists P<x+1 exists S<K(x)
      (Pow2(P) and x<2*P and S<8*P^3 and Run(x,S)).

The companion `skelet17-annotation-certificate-exists` includes the x=0
case as a disjunction. `skelet17-annotation-empty` separately proves
Run(0,0).

The bound S<8*P^3 is stronger than a generic polynomial bound. It forces
the control before the leading input place to be zero, since
(2*P)^3=8*P^3. This is proved internally by
`skelet17-annotation-leading-control-zero`:

    S<8*P^3 -> Field(S,(2*P)^3,8,0).

The result constructs witnesses in the weak theory; it is more than a
metatheoretic estimate on the size of a standard finite trace.

## Proof structure

The append theorem proves that all local conditions survive the change
x=2*y+b and S=8*T+c, given Run(y,T), b<2, c<8, the old low control a,
and Delta(a,b,c). It needs no induction.

For p=1 the new local condition is precisely the supplied transition.
For every other Pow2(p), the earlier halving theorem supplies p=2*h with
Pow2(h). The order lemma shows h<=y. Instantiate the old local condition
at h, then shift its input field by 2 and its control fields by 8. All
quotient, remainder and state witnesses retain explicit bounds. The
uniform field-shift theorem is reused for all three fields.

The finite table's totality is proved by sixteen explicit cases, not by
induction. Bounded division extracts the old low control and yields

    Run(y,T) and x=2*y+b and b<2 ->
      exists c<8 Run(x,8*T+c).

For global existence, define Cert(x) as x=0 or the bounded existential
conclusion in the displayed positive-certificate theorem. Use ordinary
bounded induction on i with the formula

    Phi(i) := forall z<i+1 Cert(z).

This is a bounded formula, including the quantifiers inside Run and Pow2.
The proof handles input 1 explicitly. To construct the certificate at
X=i+1, divide X by 2: X=2*y+b, b<2. Positivity gives y<X, so Phi(i)
supplies Cert(y). The case y=0 reduces to input 1. Otherwise, from the
old leading place P and code T, choose the next control c and set

    new leading place = 2*P,
    new code = 8*T+c.

The existing field-range theorem proves x<4*P and new code<64*P^3.
These are exactly the required bounds at leading place 2*P. Elementary
ordered multiplication bounds the new code by K(X). The append theorem
supplies the local conditions. This proves the successor step of Phi.

The dependency closure of the existence theorem contains two bounded
induction constructions: the earlier bounded division proof and this
Phi proof. Total exponentiation, sequence comprehension and trace
existence are not additional axioms.

## Verification and limits

The official Metamath verifier checks `annotations_checked.mm`.
`audit_annotations.py` checks the clean log, compares all 93 trusted
declarations exactly with the original baseline, and audits induction
dependencies. The source generator is `build_annotations.py`.

`check_annotations.py` also checks the interpretation on 16,384 binary
inputs, including invalid parser words, and compares the controls with
the original partial parser on all 21,844 previous valid-list test cases.
These tests are regression checks, not the formal existence proof.

Still unproved: correspondence with the original parser from LowerWord;
the end-of-input action; existence and correctness of emission-count,
rank and compressed-output witnesses; and the global Skelet #17 invariant
excluding B111. This theorem alone gives no new nonhalting conclusion.

From the archive root, regenerate and check with

    python3 skelet17_research/build_annotations.py
    python3 skelet17_research/prune.py annotations_raw.mm annotations_checked.mm
    metamath 'read "skelet17_research/annotations_checked.mm"' 'verify proof *' exit
    python3 skelet17_research/check_annotations.py
    python3 skelet17_research/audit_annotations.py

Capture the verifier output in `annotation_verification.log` before
running the audit. Require both a clean parse and complete verification.

## Subsequent correspondence theorem

The valid-word input-reading table gap described above is now closed in
parser_checked.mm. See PARSER_CORRESPONDENCE.md and parser_manifest.json.
This does not yet establish EOF handling or Gray-output correctness.
