"""Independent reconstruction of general boundary progress."""
from pathlib import Path
import json
import check_history_tools as ht
from check_skelet10_scope import AND,eq,lt,plus,num,implies,parse,EX
from check_skelet10_boundaries import boundary
from check_skelet10_spread import bounded
from check_skelet10_left import norm
P=Path(__file__).resolve().parent;H,N,o,k=ht.H,ht.N,ht.o,ht.k;c=ht.c;n='cycleInput'
halt=['assemblyHalt'+s for s in ('Q','L','Bit','R')];ei='cycleOutputIndex';er=['cycleOutput'+s for s in ('Q','L','Bit','R')]
def bounds(row):return [lt(x,H) for x in row]
prem=AND([ht.total(o,N,ht.ti),ht.steps(o,N,ht.si,ht.SV),*bounds(halt),ht.at(o,N,halt),eq(halt[0],num(5)),*bounds(c),lt(k,plus(N,'1')),ht.at(o,k,c),boundary(n,c)])
expected=implies(prem,EX(ei,plus(N,'1'),ht.bexs(er,AND([lt(k,ei),ht.at(o,ei,er),boundary(c[3],er)]))))
def main():
 data=json.loads((P/'skelet10_progress_theorems.json').read_text());label='skelet17-ladder-skelet10-boundary-progress'
 assert set(data)=={label} and norm(parse(data[label]))==norm(expected) and bounded(expected)
 result={'statements_checked':1,'independent_reconstruction_matches':True,'statement_delta0':True,'original_history_unchanged':True,'all_boundary_cases_covered':True,'numerical_case_or_intermediate_endpoint_not_an_extra_premise':True,'strict_progress_and_old_R_input':True,'no_new_induction_construction':True,'whole_machine_nonhalting':False}
 (P/'skelet10_progress_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':main()
