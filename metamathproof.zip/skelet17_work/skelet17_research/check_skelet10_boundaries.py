"""Independent reconstruction of canonical-boundary connection statements."""
from pathlib import Path
import json
from check_skelet10_scope import implies,AND,OR,both,eq,lt,plus,times,num,EX,parse,sparse,step
from check_skelet10_right import carry,sparse_num,jval
from check_skelet10_spread import transform,bounded,spread
from check_skelet10_left import norm,raw_step
P=Path(__file__).resolve().parent;two,three,four,eight,five=map(num,(2,3,4,8,5))
cf=['z10Current'+s for s in ('Q','L','Bit','R')];nf=['z10Next'+s for s in ('Q','L','Bit','R')]
a,t,v='t','u','v';ba,bt,bv='boundaryA','boundaryT','boundaryV'
def wl(c):return plus(times(two,c[1]),c[2])
def wr(c):return plus(times(two,c[3]),c[2])
def boundary(n,c):
 even=EX(ba,plus(n,'1'),AND([eq(n,times(two,ba)),transform(ba,wl(c)),carry(ba,c[3])]))
 odd=EX(ba,plus(n,'1'),EX(bt,plus(wl(c),'1'),EX(bv,plus(c[3],'1'),AND([eq(n,plus(times(four,ba),'1')),eq(wl(c),plus(times(four,bt),two)),transform(ba,bt),eq(c[3],times(two,bv)),carry(ba,bv)]))))
 return AND([eq(c[0],three),lt(c[2],two),sparse(n),sparse(c[3]),OR([even,odd])])
r='w';lv='leftOutput';S=plus(times(three,a),two)
left_target=AND([eq(cf[0],'0'),eq(wr(cf),r),EX(lv,S,AND([carry(a,lv),transform(lv,cf[1]),sparse(lv)]))])
expected={
 'boundary-even-output':implies(AND([eq(cf[0],three),lt(cf[2],two),sparse(a),transform(a,wl(cf)),carry(a,cf[3]),sparse(cf[3])]),boundary(times(two,a),cf)),
 'a0-enters-right-counter':implies(AND([eq(cf[0],'0'),eq(cf[2],'0'),sparse(cf[3]),step(cf,nf)]),AND([eq(nf[0],'1'),eq(nf[1],plus(times(two,cf[1]),'1')),eq(wr(nf),cf[3]),lt(nf[2],two),sparse(cf[3])])),
 'right-output-align-odd':implies(AND([eq(cf[0],three),sparse(a),transform(a,t),carry(a,cf[3]),sparse(cf[3]),eq(wl(cf),plus(times(eight,t),five)),step(cf,nf)]),boundary(plus(times(four,a),'1'),nf)),
 'left-output-identify':implies(AND([sparse(a),carry(a,v),left_target]),AND([eq(cf[0],'0'),eq(wr(cf),r),transform(v,cf[1]),sparse(v)])),
}
def main():
 data=json.loads((P/'skelet10_boundaries_theorems.json').read_text());assert len(data)==4
 for name,f in expected.items():
  label='skelet17-ladder-skelet10-'+name;assert norm(parse(data[label]))==norm(f),label;assert bounded(f),label
 a0=align=0
 for l in range(32):
  for rr in range(128):
   if not sparse_num(rr):continue
   old=(0,l,0,rr);new=raw_step(old);assert new[0]==1 and new[1]==2*l+1 and 2*new[3]+new[2]==rr;a0+=1
 for x in range(512):
  if not sparse_num(x):continue
  t0=10*spread(x);r0=jval(x)[0];old=(3,4*t0+2,1,r0);new=raw_step(old)
  assert new[0]==3 and 2*new[1]+new[2]==4*t0+2 and new[3]==2*r0
  assert sparse_num(4*x+1) and sparse_num(new[3]);align+=1
 out={'statements_checked':4,'independent_reconstruction_matches':True,'all_new_statements_delta0':True,'canonical_boundary_uses_original_configuration':True,'finite_A0_cases':a0,'finite_D1_alignment_cases':align,'finite_tests_are_not_formal_proofs':True,'complete_boundary_to_boundary_compositions':False,'global_history_proof':False,'whole_machine_nonhalting':False}
 (P/'skelet10_boundaries_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
