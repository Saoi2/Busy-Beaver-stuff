"""Synchronization arithmetic over the unchanged bounded carry graph."""
def add_skelet10_sync(m,right):
 nd,b=m.nd,m.b;A,M,Q,L=m.A,m.M,m.Q,m.L;O=m.O;Z=m.Z;use=m.invoke
 two,three,four=map(m.a.num,(2,3,4));carry=right['carry']
 def growth():
  x,y=b.t,b.u;root=nd.Ctx();prem=carry(x,y);c=root.push(prem);goal=L(x,y);jp,js,ja=right['jp'],right['js'],right['ja']
  ep,es,ea=[m.declare('leftCarryBound'+n) for n in ('P','S','A')]
  def cp(pv,sv,av):return [m.power2(pv),Q(pv,A(M(three,sv),O)),Q(x,A(M(pv,M(two,av)),sv)),Q(y,M(pv,A(M(four,av),O)))]
  def pfound(pc):
   def sfound(sc):
    def afound(ac):
     nd.unpack(ac,cp(ep,es,ea));linear=Q(y,A(A(M(two,x),es),O));m.eq(ac,*linear[1:],[cp(ep,es,ea)[3],cp(ep,es,ea)[2],cp(ep,es,ea)[1]])
     return m.bound(ac,x,y,A(x,es),[linear])
    return m.bex_elim(sc,ja,A(x,O),nd.AND(cp(ep,es,ja)),ea,goal,afound)
   return m.bex_elim(pc,js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(ep,js,ja))),es,goal,sfound)
  m.bex_elim(c,jp,A(M(three,x),two),nd.BEX(js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(jp,js,ja)))),ep,goal,pfound)
  m.finish('skelet17-ladder-skelet10-carry-strict-growth',root,prem,goal,c,'The bounded carry graph output strictly exceeds its input. No induction.')
 growth()

 def constructors():
  if 'z10-right-prefix-bounds' not in m.theorems:right['prefix_bounds']()
  jp,js,ja=right['jp'],right['js'],right['ja']
  def cp(x,y,p,s,a):return [m.power2(p),Q(p,A(M(three,s),O)),Q(x,A(M(p,M(two,a)),s)),Q(y,M(p,A(M(four,a),O)))]
  def pack(c,x,y,p,s,a):
   c.both(Q(p,A(M(three,s),O)),Q(x,A(M(p,M(two,a)),s)));use(c,'z10-right-prefix-bounds',{'t':p,'u':s,'v':x,'w':M(two,a)})
   nd.unpack(c,[L(p,A(M(three,x),two)),L(s,A(x,O)),L(M(two,a),A(x,O))])
   m.bound(c,a,A(M(two,a),O),a);c.both(L(a,A(M(two,a),O)),L(M(two,a),A(x,O)));use(c,'skelet17-binary-le-lt-trans',{'t':a,'u':M(two,a),'v':A(x,O)})
   nd.conj(c,cp(x,y,p,s,a));m.bex_intro(c,ja,A(x,O),nd.AND(cp(x,y,p,s,ja)),a)
   m.bex_intro(c,js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(x,y,p,js,ja))),s)
   return m.bex_intro(c,jp,A(M(three,x),two),nd.BEX(js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(x,y,jp,js,ja)))),p)
  x=b.t;xx=M(two,x);yy=A(M(four,x),O);c=nd.Ctx();use(c,'skelet17-binary-power-one',{},False)
  for f in cp(xx,yy,O,Z,x)[1:]:m.eq(c,*f[1:])
  pack(c,xx,yy,O,Z,x);m.save('skelet17-ladder-skelet10-carry-base',c,carry(xx,yy),'Base carry constructor. No induction.')
  x,y=b.t,b.u;root=nd.Ctx();prem=carry(x,y);c=root.push(prem);xx=A(M(four,x),O);yy=M(four,y);goal=carry(xx,yy)
  ep,es,ea=[m.declare('syncCarryFresh'+n) for n in ('P','S','A')]
  def pfound(pc):
   def sfound(sc):
    def afound(ac):
     fs=cp(x,y,ep,es,ea);nd.unpack(ac,fs)
     np,ns=M(four,ep),A(M(four,es),O)
     use(ac,'skelet17-binary-power-double',{'t':ep});use(ac,'skelet17-binary-power-double',{'t':M(two,ep)})
     m.eq(ac,M(two,M(two,ep)),np);m.rewrite(ac,m.power2(m.a.E),M(two,M(two,ep)),np)
     for f,refs in zip(cp(xx,yy,np,ns,ea)[1:],([fs[1]],[fs[2],fs[1]],[fs[3],fs[1]])):m.eq(ac,*f[1:],refs)
     return pack(ac,xx,yy,np,ns,ea)
    return m.bex_elim(sc,ja,A(x,O),nd.AND(cp(x,y,ep,es,ja)),ea,goal,afound)
   return m.bex_elim(pc,js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(x,y,ep,js,ja))),es,goal,sfound)
  m.bex_elim(c,jp,A(M(three,x),two),nd.BEX(js,A(x,O),nd.BEX(ja,A(x,O),nd.AND(cp(x,y,jp,js,ja)))),ep,goal,pfound)
  m.finish('skelet17-ladder-skelet10-carry-prefix',root,prem,goal,c,'Carry constructor J(x,y) implies J(4x+1,4y). Reuses bounded prefix arithmetic; no new induction.')
 constructors()
