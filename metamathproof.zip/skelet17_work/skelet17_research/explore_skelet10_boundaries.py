"""Untrusted experiment for a proposed counter-boundary relation.

No Dil graph, synchronization invariant, or nonhalting theorem is added
to Metamath by this script. It only records finite computational evidence.
"""
from pathlib import Path
import json
from check_skelet10_left import raw_step
P=Path(__file__).resolve().parent

def sparse(x):return not x&(x>>1)
def spread(x):
 out=0;p=1
 while x:
  if x&1:out+=p
  p*=4;x//=2
 return out

def main():
 words=[x for x in range(10000) if sparse(x)][:101]
 expected={}
 for w,nxt in zip(words,words[1:]):
  whole=10*spread(w)//4
  expected[(3,whole//2,whole%2,nxt)]=w
 c=(0,0,0,0);seen=[]
 for t in range(200000):
  if c in expected:
   w=expected[c]
   if not seen or seen[-1]['word']!=w:seen.append({'index':len(seen),'word':w,'step':t,'configuration':c})
   if len(seen)==100:break
  assert c[0]!=5;c=raw_step(c)
 assert [x['word'] for x in seen]==words[:100]
 result={'experimental_only':True,
  'candidate_boundary':'q=D, 2L+b=floor(10*Spread(w)/4), R=least Sparse number greater than w',
  'consecutive_boundaries_checked':len(seen),'last_raw_step':seen[-1]['step'],'first_boundaries':seen[:8],
  'formal_nonhalting_claim':False,'experiment_itself_formalizes_Dil':False}
 (P/'skelet10_boundary_experiment.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
