# Carry-output uniqueness on Sparse inputs

The new public interface is
`skelet17-ladder-skelet10-carry-unique-sparse`:

    Sparse(x) and J(x,y) and J(x,z) imply y=z.

J and Sparse are exactly the earlier bounded predicates. This theorem
neither assumes nor proves that every input has a J output. It does not
assume that the transformed-word graph T is functional. Its purpose is
to identify two independently constructed counter-output witnesses in
the proposed synchronization proof for Skelet #10.

## The precise induction instance

Fix a free term parameter H. Define

    U(x;H) := forall y<H forall z<H,
                (Sparse(x) and J(x,y) and J(x,z)) -> y=z.

Use bounded induction on i with

    Phi(i;H) := forall x<i+1, U(x;H).

All quantifiers in Phi are bounded, including the quantifiers in Sparse
and J. H stays fixed during this induction. There is no appeal to a
strong-induction axiom: the bounded universal range in Phi implements
the argument using the existing ordinary bounded-induction schema.

The proof generates bounded universal introductions with fresh variables,
then explicitly proves the alpha-renaming implications needed to match
U and Phi. It does not introduce new quantifier rules or arithmetic axioms.

## Base and successor

For x=0, the even-input inverse gives y=z=1. Consequently U(0;H)
holds for every H. The only x<1 is 0, proving Phi(0;H).

Assume Phi(i;H). To prove Phi(i+1;H), a word below i+1 is covered by
the hypothesis. The only remaining word is x=i+1. Fix candidate outputs
y,z<H and assume Sparse(x), J(x,y), J(x,z). Divide x by 2 using the
existing bounded division theorem.

If x=2a, apply the even-input inverse twice: both outputs equal 4a+1.
This case needs no induction hypothesis.

If x is odd, the existing Sparse-odd-tail and Sparse-pop lemmas provide
x=4a+1 and Sparse(a). The identity x=4a+1 proves a<x, with explicit
nonnegative gap 3a. Since x=i+1, Phi(i;H) therefore supplies U(a;H).

Apply the recursive inverse twice to obtain

    v<y+1, y=4v, J(a,v),
    w<z+1, z=4w, J(a,w).

The bounds v<y+1 and y<H imply v<H by the earlier order lemma;
similarly w<H. Thus U(a;H) applies to these two smaller outputs. It
gives v=w, and substitution into the two output equations gives y=z.
Discharge the candidate output assumptions and quantify their bounds.
This proves U(x;H), completing the successor case.

After induction, specialize the word range to the desired x to obtain
U(x;H) for arbitrary H. This bounded lemma is a private project theorem,
`z10-carry-unique-bounded`.

## Removing the temporary output bound

For arbitrary y,z, set H=y+z+1. The inequalities y<H and z<H have
explicit additive-gap proofs. Instantiate U(x;H) with these outputs and
apply its implication. The final public statement has no H parameter
and no bounds on y,z in its premise.

Keeping H fixed through the induction avoids an extra lemma bounding
each recursive output by a polynomial in its smaller input. The inverse
rules already supply bounds relative to the old output, which suffice.

## Formal files and checks

- Generator: ladder_skelet10_carry_unique.py.
- Incremental driver: extend_skelet10_carry_unique.py.
- Exported formula: skelet10_unique_carry_theorems.json.
- Independent statement reconstruction: check_skelet10_carry_unique.py.
- Active proof database: idelta0_machines.mm.
- Kernel output and proof-dependency counts: ladder_verification.log and
  ladder_manifest.json, respectively.

The independent numerical check enumerates possible J scale witnesses
for all Sparse inputs below 2048 (233 inputs). These finite tests are
supplementary; they are not the universal formal proof.

The theorem introduces one bounded-induction construction and reuses the
earlier bounded division proof, so the expected dependency count is two.
The actual count is checked from the verified proof graph. These counts
are upper bounds for this proof, not lower bounds on necessary strength.

## What remains

The global synchronization relation and blank-start nonhalting endpoint
are still unfinished. Carry uniqueness resolves the ambiguity between a
routine's independently constructed output and the witness already in a
canonical boundary invariant. The three boundary compositions, short
alignment steps, history-suffix lemmas and global remaining-length
induction must still be formalized.
