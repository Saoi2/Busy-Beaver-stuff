"""Prune/scope only newly generated proofs, treating the old file as leaves.

The output must pass Metamath together with its unchanged base before being
appended. No stub axioms, added assertions, or inferred proof steps occur.
This avoids parsing the old database's proof bodies into Python objects.
"""
from pathlib import Path
import sys,re,itertools,json,hashlib
from simplify_metamath import parse_intern,pack_dv
from minimize_library import rewrite
P=Path(__file__).resolve().parent
base=P/(sys.argv[4] if len(sys.argv)>4 else 'idelta0_machines.mm');raw=P/sys.argv[1];out=P/sys.argv[2]
roots=set(json.loads((P/sys.argv[3]).read_text()))
# Current generator sources have one statement/scope marker per line.
# Fail closed if the metadata layout differs. Ignore all source comments.
floats=[];scopes=[];comment=False
with base.open() as stream:
 for line in stream:
  words=[]
  for token in line.split():
   if comment:
    if token=='$)':comment=False
   elif token=='$(':comment=True
   else:words.append(token)
  if not words:continue
  if words==['${']:scopes.append(len(floats));continue
  if words==['$}']:del floats[scopes.pop():];continue
  assert '${' not in words and '$}' not in words,'Nonstandard scope layout'
  if '$f' in words:
   assert len(words)==5 and words[1]=='$f' and words[-1]=='$.'
   floats.append((words[0],words[2],words[3]))
assert not scopes and not comment
assert len({name for _,_,name in floats})==len(floats)
header='$v '+' '.join(name for _,_,name in floats)+' $.\n'+''.join(label+' $f '+typ+' '+name+' $.\n' for label,typ,name in floats)
# Require byte-for-byte equality of the base embedded in the generator output.
sha=hashlib.sha256()
with base.open('rb') as a,raw.open('rb') as z:
 while chunk:=a.read(1048576):assert z.read(len(chunk))==chunk;sha.update(chunk)
 assert z.read(1)==b'\n'
 tail=z.read().decode()
source=header+tail;records,rules,variables=parse_intern(source);cut=len(header)
new={r['label']:r for r in records if r['kind']=='p'}
assert roots<=new.keys() and all(r['kind']!='a' for r in records)
assert all(r['proof'] and r['proof'][0]!='(' for r in new.values()),'Expected explicit generated proofs'
keep=set();todo=list(roots)
while todo:
 label=todo.pop()
 if label in keep:continue
 keep.add(label);todo.extend(x for x in new[label]['proof'] if x in new)
active=set();stack=[];kept=0
with out.open('w') as dest:
 for r in records:
  kind=r['kind']
  if kind=='{':stack.append(active.copy())
  elif kind=='}':active=stack.pop()
  elif kind=='d':active.update(tuple(sorted(x)) for x in itertools.combinations(r['expr'],2));continue
  if r['start']<cut:continue
  if kind=='p':
   if r['label'] not in keep:continue
   used=set(r['expr'])&variables
   for label in r['proof']+r['hyps']:
    if label in rules and rules[label]['kind'] in ('f','e'):used.update(set(rules[label]['expr'])&variables)
   pairs=tuple(sorted(x for x in itertools.combinations(sorted(used),2) if x in active))
   proof,_=rewrite(r,{})
   dest.write('${\n'+pack_dv(pairs)+r['label']+' $p '+' '.join(r['expr'])+' $=\n '+proof+' $.\n$}\n');kept+=1
  elif kind not in ('{','}'):
   assert kind in ('v','f'),'Unexpected new essential hypothesis or declaration'
   dest.write(source[r['start']:r['end']]+'\n')
assert not stack
report={'base_bytes':base.stat().st_size,'base_sha256':sha.hexdigest(),'generated_new_proofs':len(new),'retained_new_proofs':kept,'new_axioms':0,'output_bytes':out.stat().st_size,'roots':sorted(roots),'requires_kernel_verification':True}
out.with_name(out.stem+'_scope_report.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
