from pathlib import Path
import json,os
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_skelet10_return import add_skelet10_return
from ladder_skelet10_right import add_skelet10_right
m=r.m;P=Path(__file__).resolve().parent
if 'skelet17-ladder-skelet10-right-counter-entry' in m.theorems:raise SystemExit('Input already contains this extension.')
m.nd.OUTPUT_PREFIX='ladder-z10-right-';m.a.OUTPUT_PREFIX='ladder-z10-right-';old=set(m.theorems)
api=add_skelet10(m,proofs=False);ret=add_skelet10_return(m,api,proofs=False)
rp=add_skelet10_right(m,api,ret)
if os.environ.get('RIGHT_STAGE','all')!='local':
 from ladder_skelet10_right_history import add_skelet10_right_history
 add_skelet10_right_history(m,api,rp,ret)
with (P/'skelet10_right_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
(P/'skelet10_right_theorems.json').write_text(json.dumps({k:m.b.tok(v) for k,v in m.theorems.items() if k not in old and k.startswith('skelet17-')},indent=2)+'\n')
print('Right-counter extension generated.',flush=True)
