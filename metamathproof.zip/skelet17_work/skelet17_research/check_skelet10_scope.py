"""Reconstruct the new public statements independently from the generator.

This checks statement scope; Metamath checks their derivations. In
particular the right-scan result ends at D and is not nonhalting.
"""
import json
from pathlib import Path
P=Path(__file__).resolve().parent

def parse(s):
 it=iter(s.split())
 def read():
  t=next(it)
  if t=='(':
   x=read();op=next(it);y=read();assert next(it)==')';return op,x,y
  if t in ('A.','E.'):return t,next(it),read()
  if t=='-.':return t,read()
  return t
 x=read();assert next(it,None) is None;return x

def plus(x,y):return '+',x,y
def times(x,y):return '*',x,y
def eq(x,y):return '=',x,y
def lt(x,y):return '<',x,y
def implies(x,y):return '->',x,y
def both(x,y):return '/\\',x,y
def either(x,y):return '\\/',x,y
def num(n):return '0' if n==0 else '1' if n==1 else plus(num(n-1),'1')
def AND(xs):return xs[0] if len(xs)==1 else both(xs[0],AND(xs[1:]))
def OR(xs):return xs[0] if len(xs)==1 else either(xs[0],OR(xs[1:]))
def ALL(v,upper,body):return 'A.',v,implies(lt(v,upper),body)
def EX(v,upper,body):return 'E.',v,both(lt(v,upper),body)
TWO,THREE,FOUR=map(num,(2,3,4))
def even(x):return EX('grayHalf',plus(x,'1'),eq(x,times(TWO,'grayHalf')))
def power(x):
 d,e='grayDivisor','grayQuotient'
 div=EX(e,plus(x,'1'),eq(times(d,e),x))
 return both(lt('0',x),ALL(d,plus(x,'1'),implies(div,either(eq(d,'1'),even(d)))))
def sparse(x):
 p,q,r='z10SparsePlace','z10SparseQuotient','z10SparseLow'
 forbidden=eq(x,plus(plus(times(times(FOUR,p),q),times(THREE,p)),r))
 return ALL(p,plus(x,'1'),implies(power(p),ALL(q,plus(x,'1'),ALL(r,p,('-.',forbidden)))))
def odd(x):return EX('z10Odd',plus(x,'1'),eq(x,plus(times(TWO,'z10Odd'),'1')))
def scan(c):
 q,l,b,r=c
 return OR([AND([eq(q,'0'),eq(b,'0'),sparse(r)]),
            AND([eq(q,'1'),odd(l),sparse(plus(times(TWO,r),b))]),
            AND([eq(q,TWO),eq(b,'1')])])
text='1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB'
table=[]
for row in text.split('_'):
 for ins in (row[:3],row[3:]):
  table.append((5,True,1) if ins=='---' else (ord(ins[2])-65,ins[1]=='R',int(ins[0])))
def step(c,n):
 q,l,b,r=c;nq,nl,nb,nr=n;rows=[]
 for j,(qs,right,w) in enumerate(table):
  es=[eq(nl,plus(times(TWO,l),num(w))),eq(r,plus(times(TWO,nr),nb))] if right else [eq(nr,plus(times(TWO,r),num(w))),eq(l,plus(times(TWO,nl),nb))]
  rows.append(AND([eq(q,num(j//2)),eq(b,num(j%2)),eq(nq,num(qs)),*es,either(eq(nb,'0'),eq(nb,'1'))]))
 return OR(rows)
c=['z10Current'+s for s in ('Q','L','Bit','R')]
n=['z10Next'+s for s in ('Q','L','Bit','R')]
expect={
 'sparse-zero':sparse('0'),
 'sparse-pop':implies(AND([sparse('t'),eq('t',plus(times(TWO,'u'),'v')),lt('v',TWO)]),sparse('u')),
 'sparse-odd-tail':implies(sparse(plus(times(TWO,'t'),'1')),even('t')),
 'double-window-bound':implies(lt(plus(times(TWO,'t'),'v'),times(TWO,'u')),lt('t','u')),
 'sparse-push':implies(AND([sparse('t'),lt('u',TWO),either(eq('u','0'),even('t'))]),sparse(plus(times(TWO,'t'),'u'))),
 'sparse-prefix-0':implies(sparse('t'),sparse(times(TWO,'t'))),
 'sparse-prefix-10':implies(sparse('t'),sparse(plus(times(FOUR,'t'),'1'))),
 'right-scan-to-D':implies(both(scan(c),step(c,n)),either(scan(n),eq(n[0],THREE))),
 'blank-enters-right-scan':implies(step(['0']*4,n),scan(n)),
}
def main():
 actual=json.loads((P/'skelet10_theorems.json').read_text())
 assert len(actual)==len(expect)
 for name,expected in expect.items():
  label='skelet17-ladder-skelet10-'+name
  assert parse(actual[label])==expected,label
 out={'machine':text,'statements_checked':len(expect),'ordinary_instructions':10,
  'right_scan_stops_at_state':'D','whole_machine_nonhalting':False,
  'modified_computation_encoding':False,'scope':'independent statement reconstruction; derivation checked by Metamath'}
 (P/'skelet10_scope.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))

if __name__=='__main__':main()
