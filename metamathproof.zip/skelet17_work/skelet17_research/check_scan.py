"""Finite checks for the interpretation of the polynomial scan lemma."""
import json
from pathlib import Path
TM=[(1,1,1),None,(2,-1,0),(4,1,1),(3,-1,0),(2,-1,1),(0,1,1),(1,-1,1),(1,1,0),(0,1,0)]
def step(c):
 q,L,b,R=c;e=TM[2*q+b]
 if e is None:return None
 nq,d,w=e
 return(nq,2*L+w,R%2,R//2)if d==1 else(nq,L//2,L%2,2*R+w)
checks=0
for L in range(32):
 for y in range(64):
  # X=b+2R=4y+1, so scanned bit 1 and right stack 2y.
  c=(1,L,1,2*y);m=step(c);out=step(m)
  assert m[0]==4 and m[2]==0
  nq,lp,bp,rp=out;xp=bp+2*rp
  assert(nq,lp,xp)==(1,4*L+2,y)
  assert(3*lp+2)*(3*xp+1)==(3*L+2)*(3*(4*y+1)+1)
  checks+=1
c=(0,0,0,0);pairs=0
for i in range(200000):
 if c[0]==1 and c[2]==1 and c[3]%2==0:pairs+=1
 c=step(c);assert c is not None
report={'finite_pair_scan_cases':checks,'ordinary_steps_tested':200000,'scan_phase_entries':pairs,'purpose':'Regression checks only; not a nonhalting proof.'}
Path(__file__).with_name('simulation_checks.json').write_text(json.dumps(report,indent=2));print(report)
