"""Derived arithmetic for the bouncer product invariant."""
three=num(3);four=num(4)
bres=m.declare('bouncerResidue');bk=m.declare('bouncerResidueFresh');bh=m.declare('bouncerHalfFresh')
bq=m.declare('bouncerQuotientFresh');br=m.declare('bouncerRemainderFresh')
def RES(x,c):return nd.BEX(bres,A(x,O),Q(x,A(M(three,bres),num(c))))
def res_intro(ctx,x,c,w,fs=()):
 relation=Q(x,A(M(three,w),num(c)));m.eq(ctx,*relation[1:],fs)
 m.bound(ctx,w,A(x,O),A(M(two,w),num(c)),[relation])
 return m.bex_intro(ctx,bres,A(x,O),Q(x,A(M(three,bres),num(c))),w)
def pow_transport(ctx,old,new,fs=()):
 m.eq(ctx,old,new,fs);return m.rewrite(ctx,m.power2(a.E),old,new)
def res_transport(ctx,old,new,c,fs=()):
 m.eq(ctx,old,new,fs);return m.rewrite(ctx,RES(a.E,c),old,new)
def factors_proof():
 x,y=b.t,b.u;P=M(x,y);prem=m.power2(P);goal=b.And(m.power2(x),m.power2(y))
 root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]));use(ctx,'skelet17-binary-positive-factor',{'t':x,'u':y})
 m.eq(ctx,P,M(y,x));m.rewrite(ctx,L(Z,a.E),P,M(y,x));use(ctx,'skelet17-binary-positive-factor',{'t':y,'u':x})
 for d,e in [(x,y),(y,x)]:
  use(ctx,'skelet17-binary-factor-bound',{'t':e,'u':d})
  m.eq(ctx,A(M(d,e),O),A(P,O));m.rewrite(ctx,L(e,a.E),A(M(d,e),O),A(P,O))
  m.eq(ctx,M(d,e),P);m.bex_intro(ctx,m.pe,A(P,O),Q(M(d,m.pe),P),e)
  ctx.both(prem,m.divides(d,P));use(ctx,'skelet17-binary-power-divisor',{'t':P,'u':d})
 ctx.both(*goal[1:]);finish('skelet17-ladder-bouncer-power-factors',root,prem,goal,ctx)
factors_proof()
def factor_pow(ctx,x,y):
 use(ctx,'skelet17-ladder-bouncer-power-factors',{'t':x,'u':y});nd.unpack(ctx,[m.power2(x),m.power2(y)])
def odd_power_proof():
 x=b.t;p0=A(M(two,x),O);prem=m.power2(p0);goal=Q(x,Z);root=nd.Ctx();ctx=root.push(prem)
 use(ctx,'skelet17-binary-power-halving',{'t':p0})
 half=nd.BEX(m.pz,A(p0,O),b.And(Q(p0,M(two,m.pz)),m.power2(m.pz)))
 m.bound(ctx,O,two,Z);m.bound(ctx,Z,two,O)
 def branch(ec,k):
  if k==0:
   m.eq(ec,A(M(two,x),O),A(M(two,Z),O),[Q(p0,O)])
   m.quotient_unique(ec,two,x,O,Z,O);return ec.get(goal)
  def havehalf(hc):
   nd.unpack(hc,[Q(p0,M(two,bh)),m.power2(bh)])
   m.eq(hc,A(M(two,x),O),A(M(two,bh),Z),[Q(p0,M(two,bh))])
   m.quotient_unique(hc,two,x,O,bh,Z);m.flip(hc,Q(O,Z));return m.false_zero_one(hc,goal)
  return m.bex_elim(ec,m.pz,A(p0,O),b.And(Q(p0,M(two,m.pz)),m.power2(m.pz)),bh,goal,havehalf)
 nd.cases(ctx,[Q(p0,O),half],goal,branch);finish('skelet17-ladder-bouncer-odd-power',root,prem,goal,ctx)
odd_power_proof()
def odd_zero(ctx,p0,q,fs=()):
 pow_transport(ctx,p0,A(M(two,q),O),fs);return use(ctx,'skelet17-ladder-bouncer-odd-power',{'t':q})
def res_bad(ctx,x,c,w,d,goal,fs=()):
 assert c!=d
 def havek(ec):
  relation=Q(x,A(M(three,bk),num(c)))
  m.eq(ec,A(M(three,bk),num(c)),A(M(three,w),num(d)),[m.flip(ec,relation),*fs])
  for z in (c,d):m.bound(ec,num(z),three,num(2-z))
  m.quotient_unique(ec,three,bk,num(c),w,num(d))
  ec.put(Q(num(c),num(c)),b.refl(ec.g,num(c)))
  return contradiction(ec,num(c),c,d,goal)
 return m.bex_elim(ctx,bres,A(x,O),Q(x,A(M(three,bres),num(c))),bk,goal,havek)
def double_res(ctx,x,y,fs):
 # y=2*x and x has residue 2 -> y has residue 1.
 goal=RES(y,1)
 def havek(ec):return res_intro(ec,y,1,A(M(two,bk),O),[ *fs,Q(x,A(M(three,bk),two))])
 return m.bex_elim(ctx,bres,A(x,O),Q(x,A(M(three,bres),two)),bk,goal,havek)
def half_res(ctx,x,y,fs):
 # x=2*y and x has residue 1 -> y has residue 2.
 goal=RES(y,2)
 def havek(ec):
  m.bound(ec,Z,three,two);use(ec,'skelet17-bounded-division-exists',{'t':y,'u':three})
  def haveq(qc):
   def haver(rc):
    def residue(dc,j):
     eqs=[Q(x,A(M(three,bk),O)),*fs,Q(y,A(M(three,bq),br)),Q(br,num(j))]
     if j==2:return res_intro(dc,y,2,bq,[Q(y,A(M(three,bq),br)),Q(br,two)])
     m.eq(dc,A(M(three,bk),O),A(M(three,M(two,bq)),num(2*j)),[m.flip(dc,eqs[0]),*eqs[1:]])
     m.bound(dc,O,three,O);m.bound(dc,num(2*j),three,num(2-2*j))
     m.quotient_unique(dc,three,bk,O,M(two,bq),num(2*j))
     dc.put(Q(O,O),b.refl(dc.g,O));return contradiction(dc,O,1,2*j,goal)
    # A fixed three-way split; not an induction instance.
    resume.module.finite_cases(rc,br,3,goal,residue)
    return rc.get(goal)
   return m.bex_elim(qc,m.r,three,Q(y,A(M(three,bq),m.r)),br,goal,haver)
  return m.bex_elim(ec,m.q,A(y,O),nd.BEX(m.r,three,Q(y,A(M(three,m.q),m.r))),bq,goal,haveq)
 return m.bex_elim(ctx,bres,A(x,O),Q(x,A(M(three,bres),O)),bk,goal,havek)
def scale_safe(ctx,old,new,c,mode,relation):
 # Return Pow2(new), RES(new,newc). Relation is oriented new=scale*old,
 # except half: old=2*new. Fixed products are normalized by ordinary equality.
 if mode=='same':
  pow_transport(ctx,old,new,[m.flip(ctx,relation)]);res_transport(ctx,old,new,c,[m.flip(ctx,relation)]);return c
 if mode=='double':
  use(ctx,'skelet17-binary-power-double',{'t':old});pow_transport(ctx,M(two,old),new,[m.flip(ctx,relation)])
  double_res(ctx,old,new,[relation]);return 1
 if mode=='quad':
  use(ctx,'skelet17-binary-power-double',{'t':old});use(ctx,'skelet17-binary-power-double',{'t':M(two,old)})
  qrelation=Q(new,M(two,M(two,old)));m.eq(ctx,*qrelation[1:],[relation])
  pow_transport(ctx,M(two,M(two,old)),new,[m.flip(ctx,qrelation)])
  # First double sends residue 1 to 2; construct directly in two steps.
  mid=M(two,old);goal=RES(mid,2)
  def one(ec):return res_intro(ec,mid,2,M(two,bk),[Q(old,A(M(three,bk),O))])
  m.bex_elim(ctx,bres,A(old,O),Q(old,A(M(three,bres),O)),bk,goal,one)
  double_res(ctx,mid,new,[qrelation]);return 1
 assert mode=='half'
 pow_transport(ctx,old,M(two,new),[relation]);factor_pow(ctx,two,new)
 half_res(ctx,old,new,[relation]);return 2
