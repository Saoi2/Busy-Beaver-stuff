# Carry arithmetic for Skelet #10 synchronization

The three interfaces added at this checkpoint concern the existing
bounded graph J, with its original definition and variable bounds:

J(x,y) iff there exist p<3x+2, s<x+1, a<x+1 such that
Pow2(p), p=3s+1, x=p(2a)+s and y=p(4a+1).

They do not change the machine or its raw beta-history encoding.

- `skelet17-ladder-skelet10-carry-strict-growth`:
  J(x,y) implies x<y.
- `skelet17-ladder-skelet10-carry-base`:
  J(2x,4x+1).
- `skelet17-ladder-skelet10-carry-prefix`:
  J(x,y) implies J(4x+1,4y).

For growth, eliminate the three bounded witnesses. The defining equations
imply y=2x+s+1. Thus y=x+(x+s)+1, an explicit positive gap. This argument
uses only arithmetic and natural deduction, with no induction.

For the base constructor choose p=1, s=0 and a=x. The already proved
Pow2(1) supplies the scale condition. Prove each bound and each equation,
then introduce the three bounded existentials.

For the prefix constructor eliminate the old witnesses and choose
p'=4p, s'=4s+1 and a'=a. Two applications of the existing Pow2-doubling
lemma give Pow2(p'). The defining equations become

    p'=3s'+1,
    4x+1=p'(2a)+s',
    4y=p'(4a+1).

The existing prefix-bound lemma gives the new bounds on p', s' and 2a;
ordinary order reasoning bounds a as well. Introduce the bounded
existentials. This reuses earlier arithmetic and adds no induction
construction. Actual induction dependency counts are audited separately.

These constructions are universal deductions, not finite simulations.
`check_skelet10_sync.py` independently reconstructs their formulas and
checks that all quantifiers are bounded. Its supplementary numerical
checks are explicitly not formal proofs.

Growth will bound a canonical auxiliary counter input by an actual
history coordinate. The constructors explain the arithmetic behind the
three candidate boundary compositions in SKELET10_GLOBAL_PLAN.md.
Both inverse rules are now proved; see SKELET10_BASE_INVERSE.md and
SKELET10_ODD_INVERSE.md. Functional uniqueness remains unproved. The global synchronization/history theorem and Skelet #10
blank-start nonhalting remain unfinished.
