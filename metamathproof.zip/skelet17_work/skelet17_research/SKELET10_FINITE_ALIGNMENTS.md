# Finite routine alignments for Skelet #10

These are ordinary finite-path theorems in the canonical Metamath file.
They connect the already proved counter contracts without changing the
machine, tape representation, or definition of a computation history.
They do not yet prove the three complete boundary compositions or
blank-start nonhalting.

Write c=(q,L,b,R), W_L(c)=2L+b and W_R(c)=2R+b. The machine remains
`1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB`, with E0 completed by 1RZ.
Let h be an arbitrary middle configuration and d an arbitrary final one.
Each displayed implication assumes the two ordinary relations
Step(c,h) and Step(h,d), not an annotated or accelerated transition.

## D0,C1 enters the left counter

`skelet17-ladder-skelet10-left-entry-two-step` proves

    q(c)=D and W_L(c)=4t+2 and Step(c,h) and Step(h,d)
    -> q(d)=D and W_L(d)=t and R(d)=4R(c)+3 and b(d)<2.

The first Step supplies a binary read bit. Quotient/remainder uniqueness
modulo 2, applied to 4t+2=2(2t+1)+0, forces the source bit to be 0
and L(c)=2t+1. Therefore only D0 matches. Its write-1 left move gives

    q(h)=C, W_L(h)=2t+1, R(h)=2R(c)+1, b(h)<2.

The second Step similarly forces the scanned bit of h to be 1 and
L(h)=t. Only C1 matches: its write-1 left move reaches D with the
whole-left word t and right half 2(2R(c)+1)+1=4R(c)+3.
The new bit bound is proved from Step's explicit zero-or-one clause.

For the odd canonical boundary, substitute t=T(a) in the explanatory
function notation. The two moves produce exactly the left-routine entry
shape, once its existing Sparse and transform-graph premises are supplied.
No transform value is introduced by this alignment theorem.

## Two A1 moves clear a return word

`skelet17-ladder-skelet10-return-clear-two-step` proves

    q(c)=A and W_R(c)=4t+3 and Step(c,h) and Step(h,d)
    -> q(d)=A and L(d)=4L(c) and W_R(d)=t and b(d)<2.

Since 4t+3=2(2t+1)+1, the first Step must use A1. That instruction
writes 0, moves right, and stays in A. Thus L(h)=2L(c) and
W_R(h)=2t+1. The next Step must again use A1, giving L(d)=4L(c)
and W_R(d)=t. No assertion that a general endpoint bit is binary is
silently assumed: the two actual Steps supply the required facts.

This is the alignment required after the left routine in the
n=8b+2 boundary case. Its transform constructor T(v,L)->T(2v,4L)
is a separate existing theorem, reused when the full composition is built.

## An even A word enters the right counter

`skelet17-ladder-skelet10-even-right-enters-counter` proves

    q(c)=A and W_R(c)=2t and Sparse(t) and Step(c,d)
    -> q(d)=B and L(d)=2L(c)+1 and W_R(d)=t
       and b(d)<2 and Sparse(t).

The equation 2R(c)+b(c)=2t, together with the read bit supplied by
Step, forces b(c)=0 and R(c)=t. The proof then reuses the existing
A0-entry theorem. The conclusion is exactly the right-counter entry
with input t and left target L(c). This avoids separately adding a
scanned-bit hypothesis to return endpoints that specify only W_R.

## Proof organization and verification

Three private one-step contracts, `z10-align-d0`, `z10-align-c1`, and
`z10-align-a1`, are shared rather than repeating two-step instruction
case splits. The D0 and C1 contracts retain the intermediate states,
which will also be useful for ruling out an early halt in a short suffix.
Each proof explicitly eliminates all ten ordinary instruction cases.
Wrong states or read bits contradict numeral inequalities; the matching
case uses quotient/remainder uniqueness and semiring equations.

All three public theorems and their private dependencies use zero bounded
induction constructions. Their statements are independently reconstructed
by check_skelet10_alignments.py. Supplementary tests cover 4,096 D0,C1
paths, 4,096 A1,A1 paths, and 1,088 even A entries. These finite tests
are not the formal proofs; the Metamath kernel checks the deductions.

All active proofs remain in idelta0_machines.mm. The source module is
ladder_skelet10_alignments.py, integrated into build_ladder.py. The
three complete boundary-to-boundary compositions and global history
induction remain unfinished; see SKELET10_GLOBAL_PLAN.md.
