"""Reconstruct shared-history statements independently of their generators."""
from pathlib import Path
import json
from check_skelet10_scope import AND,both,eq,lt,plus,times,num,implies,parse,EX,ALL,step
from check_skelet10_left import norm
from check_skelet10_spread import bounded
P=Path(__file__).resolve().parent
H,N,o,k,n,idx,y=['sharedHistory'+s for s in ('H','N','Offset','Start','Length','CompareIndex','SecondValue')]
Bj=['sharedHistoryB'+str(j) for j in range(4)];Cj=['sharedHistoryC'+str(j) for j in range(4)]
q='sharedHistoryBetaQuotient';ti,si,sti,ssi=['sharedHistory'+s for s in ('TotalIndex','StepIndex','SuffixTotalIndex','SuffixStepIndex')]
TV=['sharedHistoryTotalRow'+s for s in ('Q','L','Bit','R')]
SV=['sharedHistoryStepRow'+str(j)+s for j in (0,1) for s in ('Q','L','Bit','R')]
SSV=['sharedHistorySuffixRow'+str(j)+s for j in (0,1) for s in ('Q','L','Bit','R')]
c=['z10Current'+s for s in ('Q','L','Bit','R')];d=['z10Next'+s for s in ('Q','L','Bit','R')]
def balls(vs,body):
 for v in reversed(vs):body=ALL(v,H,body)
 return body
def bexs(vs,body):
 for v in reversed(vs):body=EX(v,H,body)
 return body
def beta(B,C,i,x):
 mod=plus('1',times(plus(i,'1'),C));return EX(q,H,both(eq(B,plus(times(q,mod),x)),lt(x,mod)))
def at(o,i,row):return AND([beta(Bj[j],Cj[j],plus(o,i),v) for j,v in enumerate(row)])
def total(o,n,iv):return ALL(iv,plus(n,'1'),bexs(TV,at(o,iv,TV)))
def steps(o,n,iv,rows):return ALL(iv,n,balls(rows,implies(both(at(o,iv,rows[:4]),at(o,plus(iv,'1'),rows[4:])),step(rows[:4],rows[4:]))))
expected={
 'beta-value-unique':implies(both(beta('t','u','v','w'),beta('t','u','v',y)),eq('w',y)),
 'row-unique':implies(both(at(o,idx,c),at(o,idx,d)),AND([eq(x,y) for x,y in zip(c,d)])),
 'total-suffix':implies(both(total(o,N,ti),eq(plus(k,n),N)),total(plus(o,k),n,sti)),
 'steps-suffix':implies(both(steps(o,N,si,SV),eq(plus(k,n),N)),steps(plus(o,k),n,ssi,SSV)),
}
def main():
 data=json.loads((P/'history_tools_theorems.json').read_text());assert len(data)==4
 for name,f in expected.items():
  label='skelet17-ladder-history-'+name;assert norm(parse(data[label]))==norm(f),label;assert bounded(f),label
 residues=ranges=0
 for B in range(128):
  for C in range(8):
   for i in range(16):
    mod=1+(i+1)*C;quo,rem=divmod(B,mod)
    assert B==quo*mod+rem and 0<=rem<mod;residues+=1
 for N0 in range(64):
  for k0 in range(N0+1):
   n0=N0-k0
   for i in range(n0+1):
    assert k0+i<=N0 and (7+k0)+i==7+(k0+i)
    if i<n0:assert k0+i<N0 and (7+k0)+(i+1)==7+((k0+i)+1)
    ranges+=1
 out={'statements_checked':4,'independent_reconstruction_matches':True,'all_new_statements_delta0':True,'bounded_beta_quotients_unchanged':True,'suffix_uses_identical_codes_and_bound':True,'suffix_changes_only_offset_and_length':True,'steps_suffix_uses_original_skelet10_table':True,'finite_residue_cases':residues,'finite_suffix_index_cases':ranges,'finite_tests_are_not_formal_proofs':True,'no_induction_constructions':True,'global_nonhalting_assembled':False}
 (P/'history_tools_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
