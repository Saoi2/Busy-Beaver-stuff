"""Two actual first-order arithmetic theorems; no nonhalting claim."""
from pathlib import Path
import sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension/proof_tools'))
import nd
b,a=nd.b,nd.a
A,M,Q=b.Add,b.Mul,b.Eq
one=b.O;two=A(one,one);three=A(two,one);four=A(three,one)
l,x,y,lp=b.t,b.u,b.v,b.w
# L'=4L+2 and X=4Y+1, for a B -> E -> B rightward scan of 10.
push=A(M(four,l),two);pop=A(M(four,y),one)
left=lambda z:M(A(M(three,z),two),A(M(three,y),one))
right=lambda z:M(A(M(three,l),two),A(M(three,z),one))
prem=b.And(Q(lp,push),Q(x,pop));target=Q(left(lp),right(x))
root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));start=Q(left(push),right(pop))
# Factor the product rather than expanding it into dozens of monomials.
F=A(M(three,push),two);G=A(M(three,pop),one);P0=A(M(three,l),two);Q0=A(M(three,y),one)
pF=a.equal(F,M(four,P0));pG=a.equal(G,M(four,Q0))
p0=a.cong2('*',F,M(four,P0),Q0,Q0,pF,b.refl(b.NIL,Q0))
q1=M(M(four,P0),Q0);q2=M(M(P0,four),Q0);q3=M(P0,M(four,Q0))
p1=a.cong2('*',M(four,P0),M(P0,four),Q0,Q0,b.ax('A5',b.NIL,t=four,u=P0),b.refl(b.NIL,Q0))
p2=b.ax('A4',b.NIL,t=P0,u=four,v=Q0)
p3=a.cong2('*',P0,P0,M(four,Q0),G,b.refl(b.NIL,P0),a.sym(G,M(four,Q0),pG))
p0=a.trans(left(push),q1,q2,p0,p1);p0=a.trans(left(push),q2,q3,p0,p2);p0=a.trans(left(push),q3,right(pop),p0,p3)
c.theorem(start,p0)
p=a.replace(c.g,Q(left(a.E),right(pop)),push,lp,a.sym(lp,push,c.get(Q(lp,push)),c.g),c.get(start));mid=Q(left(lp),right(pop));c.put(mid,p)
p=a.replace(c.g,Q(left(lp),right(a.E)),pop,x,a.sym(x,pop,c.get(Q(x,pop)),c.g),c.get(mid));c.put(target,p);root.intro(prem,target,c);b.theorem('skelet17-pair-scan-product',b.Imp(prem,target),root.get(b.Imp(prem,target)))
# A geometric block already contained in a supplied tape yields a scale bound.
p,u,t,x=b.t,b.u,b.v,b.w
p3=A(M(three,u),one);concat=A(M(p,t),u);witness=M(three,M(p,t));big=lambda z:A(M(three,z),two)
prem=b.And(Q(p,p3),Q(x,concat));goal=b.Lt(p,big(x));root=nd.Ctx();c=root.push(prem);nd.unpack(c,list(prem[1:]));start=Q(big(concat),A(A(p3,witness),one));c.theorem(start,a.equal(*start[1:]))
mid=Q(big(x),A(A(p3,witness),one));c.put(mid,a.replace(c.g,Q(big(a.E),A(A(p3,witness),one)),concat,x,a.sym(x,concat,c.get(Q(x,concat)),c.g),c.get(start)))
last=Q(big(x),A(A(p,witness),one));c.put(last,a.replace(c.g,Q(big(x),A(A(a.E,witness),one)),p3,p,a.sym(p,p3,c.get(Q(p,p3)),c.g),c.get(mid)))
c.put(goal,a.boundless_lt(c.g,p,big(x),witness,c.get(last)));root.intro(prem,goal,c);b.theorem('skelet17-contained-block-scale-bound',b.Imp(prem,goal),root.get(b.Imp(prem,goal)))
(P/'scan_lemmas.mm').write_text('\n'.join(b.lines)+'\n')
print('Generated',len(b.lines),'declarations/proofs',flush=True)
