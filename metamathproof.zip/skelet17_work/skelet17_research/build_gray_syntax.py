"""Explicit Delta0 input-word predicate; syntax certificate, not a truth theorem."""
from pathlib import Path
import sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension/proof_tools'))
import nd
b,a=nd.b,nd.a
A,M,Q,L=b.Add,b.Mul,b.Eq,b.Lt
O,Z=b.O,b.Z
names=['grayWeight','grayDivisor','grayQuotient','grayHalf','grayBitQ','grayBitR']
vs=[]
for name in names:
    old=list(b.metas);b.lines.extend(['$v '+name+' $.','f-'+name+' $f var '+name+' $.'])
    b.metas[name]='var';b.floats[name]='f-'+name
    for other in old:b.lines.append('$d '+name+' '+other+' $.')
    vs.append(b.V(name))
p,d,e,z,q,r=vs
x=b.t;two=A(O,O)
def divides(d,p):return nd.BEX(e,A(p,O),Q(M(d,e),p))
def even(d):return nd.BEX(z,A(d,O),Q(d,M(two,z)))
def power2(p):return b.And(L(Z,p),nd.BALL(d,A(p,O),b.Imp(divides(d,p),b.Or(Q(d,O),even(d)))))
def bit1(x,p):return nd.BEX(q,A(x,O),nd.BEX(r,p,Q(x,A(A(M(q,M(two,p)),p),r))))
word=nd.BALL(p,A(x,O),b.Imp(b.And(power2(p),L(M(two,p),A(x,O))),b.Or(bit1(x,p),bit1(x,M(two,p)))))
proof=nd.classify(word)
b.lines.append('$( This proves syntactic boundedness only, not decoder totality or a semantic characterization. $)')
b.lines.append('skelet17-lower-word-bounded $p bnd '+b.tok(word)+' $= '+' '.join(proof.labels)+' $.')
(P/'gray_syntax_raw.mm').write_text('\n'.join(b.lines)+'\n')
(P/'gray_word_formula.txt').write_text(b.tok(word)+'\n')
print('Generated explicit bounded formula and classification certificate.')
