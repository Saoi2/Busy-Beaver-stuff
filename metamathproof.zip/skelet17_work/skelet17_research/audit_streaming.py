"""Low-memory audit of an append-only, kernel-verified extension.

Old assertion interfaces and axioms are preserved by checking the entire
old byte prefix against its verified SHA256. New statements are checked
against independent reconstructions. Compressed proof dependencies are
decoded from their actual used indices, not merely their label headers.
This auditor deliberately rejects a non-append-only rewrite.
"""
from pathlib import Path
import sys,re,json,hashlib,subprocess,resource
P=Path(__file__).resolve().parent
current=json.loads((P/'simplification_report.json').read_text())
prior=json.loads((P/'preceding_checkpoint_report.json').read_text())
baseline=json.loads((P/'ladder_manifest.json').read_text())
path=P/'idelta0_machines.mm';prefixbytes=prior['output_bytes']
with path.open('rb') as f:
 digest=hashlib.sha256();remaining=prefixbytes
 while remaining:
  block=f.read(min(1048576,remaining));assert block;digest.update(block);remaining-=len(block)
 assert digest.hexdigest()==prior['output_sha256'],'Not an append-only extension'
 tail=f.read(1048576)
 while tail:digest.update(tail);tail=f.read(1048576)
 assert digest.hexdigest()==current['output_sha256']
new=set(current['interface_digests'])-set(prior['interface_digests'])
registry={
 'skelet17-ladder-skelet10-odd-boundary-cycle':('skelet10_odd_cycle_theorems.json','check_skelet10_odd_cycle.py',4),
 'skelet17-ladder-skelet10-even-zero-boundary-cycle':('skelet10_even_zero_theorems.json','check_skelet10_even_zero_cycle.py',2),
 'skelet17-ladder-skelet10-even-one-boundary-cycle':('skelet10_even_one_theorems.json','check_skelet10_even_one_cycle.py',4),
 'skelet17-ladder-skelet10-boundary-progress':('skelet10_progress_theorems.json','check_skelet10_progress.py',4),
 'skelet17-ladder-skelet10-boundary-index-maximum':('skelet10_maximum_theorems.json','check_skelet10_maximum.py',1),
 'skelet17-ladder-skelet10-no-halting-history-with-boundary':('skelet10_global_theorems.json','check_skelet10_global.py',5),
 'skelet17-ladder-skelet10-no-blank-halting-history':('skelet10_global_theorems.json','check_skelet10_global.py',5),
}
assert new and new<=registry.keys(),('Unregistered new interfaces',new-registry.keys())
expected={key:['|-','[]','=>',*json.loads((P/registry[key][0]).read_text())[key].split()] for key in new}
def tokens():
 comment=False;offset=0
 with path.open() as f:
  for line in f:
   start=offset;offset+=len(line.encode())
   for match in re.finditer(r'\S+',line):
    value=match.group()
    if comment:
     if value=='$)':comment=False
     continue
    if value=='$(' :comment=True;continue
    yield value,start
 assert not comment
it=iter(tokens())
def take():return next(it)
def until(end):
 while True:
  token,pos=take()
  if token==end:return
  yield token
floats={};ess=[];undo=[];scopes=[];deps={};axioms=set();newind=[];seen=set();statements=0
for label,position in it:
 if label=='${':scopes.append((len(undo),len(ess)));continue
 if label=='$}':
  marker,epos=scopes.pop()
  while len(undo)>marker:
   name,old=undo.pop()
   if old is None:floats.pop(name,None)
   else:floats[name]=old
  del ess[epos:];continue
 if label in ('$c','$v','$d'):list(until('$.'));continue
 assert label!='$[','Includes are not supported by this one-file audit'
 kind,_=take();assert kind in ('$f','$e','$a','$p'),(label,kind)
 if kind=='$f':
  expression=list(until('$.'));assert len(expression)==2
  name=expression[1]
  if scopes:undo.append((name,floats.get(name)))
  floats[name]=label;continue
 if kind=='$e':ess.append(set(until('$.')));continue
 variables=set();capture=[] if label in expected else None
 for token in until('$.') if kind=='$a' else until('$='):
  if token in floats:variables.add(token)
  if capture is not None:capture.append(token)
 if capture is not None:assert capture==expected[label],label;seen.add(label)
 if kind=='$a':axioms.add(sys.intern(label));continue
 statements+=1
 for e in ess:variables.update(t for t in e if t in floats)
 mandatory=len(variables)+len(ess);references=set();first,_=take()
 if first=='(':
  header=list(until(')'));accumulator=0
  for word in until('$.'):
   for char in word:
    if 'U'<=char<='Y':accumulator=5*accumulator+ord(char)-ord('U')+1
    elif 'A'<=char<='T':
     number=20*accumulator+ord(char)-ord('A')+1;accumulator=0
     if mandatory<number<=mandatory+len(header):references.add(sys.intern(header[number-mandatory-1]))
    else:assert char=='Z',char
  assert accumulator==0
 else:
  assert first!='?';references.add(sys.intern(first));references.update(sys.intern(t) for t in until('$.'))
 refs=tuple(r for r in references if r in deps or r in axioms)
 deps[sys.intern(label)]=refs
 if position>=prefixbytes and 'ax-ind-bounded' in refs:newind.append(label)
assert not scopes and len(axioms)==93 and statements==current['output_proofs'] and seen==new
if 'skelet17-ladder-skelet10-boundary-index-maximum' in new:
 assert len(newind)==1,('Expected exactly one new maximum induction',newind)
 reached=set();todo=['skelet17-ladder-skelet10-boundary-index-maximum']
 while todo:
  label=todo.pop()
  if label not in reached:reached.add(label);todo.extend(deps.get(label,()))
 assert set(newind)<=reached
else:assert not newind,newind
log=(P/'ladder_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
assert int(re.search(r'93 are \$a and (\d+) are \$p',log).group(1))==statements
indnodes={k for k,rs in deps.items() if 'ax-ind-bounded' in rs}
metrics={}
wanted={k:v['count'] for k,v in baseline['new_results'].items()}
wanted.update({key:registry[key][2] for key in new})
for label,count in wanted.items():
 reached=set();todo=[label]
 while todo:
  item=todo.pop()
  if item in reached:continue
  reached.add(item);todo.extend(deps.get(item,()))
 nodes=sorted(reached&indnodes);assert len(nodes)==count,(label,count,nodes)
 metrics[label]={'bounded_induction_nodes':nodes,'count':len(nodes)}
for checker in sorted({registry[key][1] for key in new}):subprocess.run([sys.executable,str(P/checker)],check=True,capture_output=True)
report={'method':'streaming actual compressed-proof dependency decoding plus verified-prefix preservation','kernel_verification':'passed','source_sha256':current['output_sha256'],'trusted_declarations':93,'trusted_core_and_previous_interfaces_preserved_by_exact_prefix':True,'previous_interfaces_preserved':len(prior['interface_digests']),'new_interfaces_checked':sorted(new),'proved_assertions':statements,'new_direct_induction_constructions':newind,'dependency_counts_checked':len(metrics),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'legacy_large_audit_completed_this_run':False}
(P/'streaming_audit_report.json').write_text(json.dumps(report,indent=2)+'\n')
files=set(baseline['files'])|{'audit_streaming.py','streaming_audit_report.json','refresh_streaming_report.py','extract_streaming.py','AUDIT_WORKFLOW.md'}
for key in new:
 files.update(registry[key][:2])
if 'skelet17-ladder-skelet10-odd-boundary-cycle' in new:
 files.update(['ladder_skelet10_odd_cycle.py','extend_skelet10_odd_cycle.py','skelet10_odd_cycle_checks.json','SKELET10_ODD_BOUNDARY_CYCLE.md'])
if 'skelet17-ladder-skelet10-even-zero-boundary-cycle' in new:
 files.update(['ladder_skelet10_even_zero_cycle.py','extend_skelet10_even_zero_cycle.py','skelet10_even_zero_checks.json','SKELET10_EVEN_ZERO_CYCLE.md'])
if 'skelet17-ladder-skelet10-even-one-boundary-cycle' in new:
 files.update(['ladder_skelet10_even_one_cycle.py','extend_skelet10_even_one_cycle.py','skelet10_even_one_checks.json','SKELET10_EVEN_ONE_CYCLE.md','check_even_one_base.py','check_even_one_dependencies.py','even_one_roots.json'])
if 'skelet17-ladder-skelet10-boundary-progress' in new:
 files.update(['ladder_skelet10_boundary_progress.py','extend_skelet10_progress.py','check_progress_base.py','check_progress_dependencies.py','progress_roots.json','skelet10_progress_checks.json'])
if 'skelet17-ladder-skelet10-boundary-index-maximum' in new:
 files.update(['ladder_skelet10_boundary_maximum.py','extend_skelet10_maximum.py','check_maximum_dependencies.py','skelet10_maximum_checks.json'])
if 'skelet17-ladder-skelet10-no-blank-halting-history' in new:
 files.update(['ladder_skelet10_boundary_exclusion.py','ladder_skelet10_blank_endpoint.py','extend_skelet10_global.py','resume_streaming.py','scope_new_extension.py','global_scope_report.json','global_final_roots.json','skelet10_global_checks.json','SKELET10_NONHALTING.md'])
def filehash(name):
 with (P/name).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=dict(baseline);manifest.update(proof_audit_method=report['method'],proofs_verified=True,proved_statement_count=statements,new_results=metrics,append_only_audit_passed=True)
if 'skelet17-ladder-skelet10-odd-boundary-cycle' in current['interface_digests']:manifest.update(skelet10_odd_boundary_composition=True,skelet10_proved_boundary_cases=1,skelet10_remaining_boundary_cases=2)
if 'skelet17-ladder-skelet10-even-zero-boundary-cycle' in current['interface_digests']:manifest.update(skelet10_even_zero_boundary_composition=True,skelet10_proved_boundary_cases=2,skelet10_remaining_boundary_cases=1)
if 'skelet17-ladder-skelet10-even-one-boundary-cycle' in current['interface_digests']:manifest.update(skelet10_even_one_boundary_composition=True,skelet10_proved_boundary_cases=3,skelet10_remaining_boundary_cases=0)
if 'skelet17-ladder-skelet10-boundary-progress' in current['interface_digests']:manifest.update(skelet10_complete_boundary_compositions=True,skelet10_complete_counter_cycle=True)
if 'skelet17-ladder-skelet10-no-blank-halting-history' in current['interface_digests']:manifest.update(skelet10_global_boundary_exclusion=True,skelet10_blank_start_connected=True,skelet10_whole_nonhalting=True)
manifest['files']={name:{'bytes':(P/name).stat().st_size,'sha256':filehash(name)} for name in sorted(files)}
(P/'ladder_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if '--extract' in sys.argv:
 target=P/sys.argv[sys.argv.index('--extract')+1]
 roots=json.loads((P/sys.argv[sys.argv.index('--roots')+1]).read_text())
 assert all(key in deps or key in axioms for key in roots)
 keep=set();todo=list(roots)
 while todo:
  key=todo.pop()
  if key in keep:continue
  keep.add(key);todo.extend(deps.get(key,()))
 skip=False;retained=0
 with path.open() as source,target.open('w') as output:
  for line in source:
   match=re.match(r'^(\S+)\s+\$p\s',line)
   if match:
    assert not skip
    skip=match.group(1) not in keep
    if not skip:retained+=1
   if skip:
    if '$.' in line:skip=False
    continue
   output.write(line)
 assert not skip
 print({'extracted':str(target),'proofs_retained':retained,'bytes':target.stat().st_size,'metadata_and_original_scopes_preserved':True},flush=True)
