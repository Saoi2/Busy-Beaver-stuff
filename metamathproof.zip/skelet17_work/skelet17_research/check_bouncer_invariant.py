"""Finite interpretation checks; not a substitute for the Metamath proof."""
import json
from pathlib import Path
TABLE=[(1,1,1),(2,0,0),(2,0,0),(0,1,1),(5,1,1),(0,0,1)]
def inv(c):
 q,l,b,r=c;p=(l+1)*(3*r+(1 if q==0 else 2))
 if p<=0 or p&(p-1):return False
 return (q==0 and p%3==1+b) or (q==1 and p%3==1 and (b==1 or r==0)) or (q==2 and b==1 and p%3==2)
def step(c):
 q,l,b,r=c;nq,d,w=TABLE[2*q+b]
 return (nq,2*l+w,r%2,r//2) if d else (nq,l//2,l%2,2*r+w)
count=0
for q in range(3):
 for l in range(128):
  for b in range(2):
   for r in range(128):
    c=(q,l,b,r)
    if inv(c):assert inv(step(c)),(c,step(c));count+=1
c=(0,0,0,0)
for _ in range(100000):assert inv(c),c;c=step(c)
out={'finite_invariant_configurations_checked':count,'raw_run_steps_checked':100000,'scope':'standard-integer interpretation checks only'}
Path(__file__).with_name('bouncer_invariant_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
