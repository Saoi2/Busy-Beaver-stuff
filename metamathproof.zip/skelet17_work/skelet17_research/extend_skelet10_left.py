"""Incremental driver from a checkpoint containing the right-scan fragment."""
from pathlib import Path
import json
import resume_canonical as r
from ladder_skelet10 import add_skelet10
from ladder_skelet10_left import add_skelet10_left
m=r.m;P=Path(__file__).resolve().parent
if 'skelet17-ladder-skelet10-left-exit-five-step' in m.theorems:
 raise SystemExit('Input already contains the left-counter extension.')
m.nd.OUTPUT_PREFIX='ladder-z10-left-';m.a.OUTPUT_PREFIX='ladder-z10-left-'
api=add_skelet10(m,proofs=False)
add_skelet10_left(m,api)
with (P/'skelet10_left_extension_raw.mm').open('w') as out:
 for line in m.b.lines:
  for i in range(0,len(line),1048576):out.write(line[i:i+1048576])
  out.write('\n')
names=('left-exit-five-step','left-carry-four-step','return-clear-four-step','left-zero-return-to-scan')
(P/'skelet10_left_theorems.json').write_text(json.dumps({k:m.b.tok(m.theorems[k]) for k in ('skelet17-ladder-skelet10-'+n for n in names)},indent=2)+'\n')
print('Left-counter extension generated.',flush=True)
