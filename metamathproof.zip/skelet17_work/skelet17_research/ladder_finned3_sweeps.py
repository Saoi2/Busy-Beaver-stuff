"""Ten local phase proofs for Finned #3.

The full bounded assembly and history proof are supplied by
ladder_finned3_global.py and ladder_finned3_history.py.

These are ordinary one-step results for polynomial phase predicates.
They do not alter the tape/history encoding or assume phase annotations
as part of the definition of a computation.
"""
TABLES['finned3']=[(1,1,1),(4,1,1),(2,0,1),(1,1,1),(0,1,0),
                  (3,0,0),(1,0,1),(3,0,1),(5,1,1),(0,1,0)]
def STEP(c,d,kind='finned3',previous=STEP):return previous(c,d,kind)
fhalf=m.declare('finnedHalf');ffresh=m.declare('finnedHalfFresh')
def fsq(x):return M(x,x)
def fcube(x):return M(x,fsq(x))
def fmul(*args):
 if len(args)==1:return args[0]
 return M(args[0],fmul(*args[1:]))
def fA0(c,s):
 return [Q(c[0],Z),Q(c[2],Z),m.power2(s),
         Q(A(M(three,c[1]),two),M(two,fsq(s))),Q(A(c[3],O),s)]
def fA1(c,s,w):
 return [Q(c[0],Z),Q(c[2],O),m.power2(s),m.power2(w),
         Q(A(M(three,c[1]),two),M(two,fsq(s))),
         Q(A(A(c[3],O),M(two,fsq(w))),fmul(num(8),s,fcube(w)))]
def fE1(c,s,w):
 return [Q(c[0],four),Q(c[2],O),m.power2(s),m.power2(w),
         Q(A(M(three,c[1]),O),fsq(s)),
         Q(A(A(c[3],O),fsq(w)),fmul(two,s,fcube(w)))]
def fB0(c,s,v):
 return [Q(c[0],O),Q(c[2],Z),m.power2(s),m.power2(v),
         Q(M(three,A(c[1],O)),fmul(two,s,fsq(v),A(M(two,fsq(s)),O))),
         Q(A(c[3],O),v)]
def fB1(c,s,w,z,v):
 return [Q(c[0],O),Q(c[2],O),*[m.power2(t) for t in (s,w,z,v)],
         Q(M(three,A(c[1],O)),M(w,A(M(two,fsq(s)),O))),
         Q(A(A(c[3],O),z),fmul(two,z,v)),Q(M(w,z),M(s,fsq(v)))]
def fproof(source,target,state,bit,label,matching):
 prem=b.And(nd.AND(source),STEP(CF,NF));root=nd.Ctx();ctx=root.push(prem)
 nd.unpack(ctx,list(prem[1:]));nd.unpack(ctx,source)
 def move(sc,j):
  pf=parts(TABLES['finned3'],CF,NF,j);nd.unpack(sc,pf)
  if j//2!=state:return contradiction(sc,CF[0],state,j//2,target)
  if j%2!=bit:return contradiction(sc,CF[2],bit,j%2,target)
  return matching(sc,pf)
 nd.cases(ctx,[nd.AND(parts(TABLES['finned3'],CF,NF,j)) for j in range(10)],target,move)
 finish(label,root,prem,target,ctx,'Ordinary Finned #3 step on the explicitly stated polynomial phase domain. Not a whole-machine nonhalting theorem.')

def fequal_via(ctx,left,right,known,fs=()):
 """Transport a known equality through checked semiring identities."""
 m.eq(ctx,known[1],left,fs);m.eq(ctx,known[2],right,fs)
 mid=a.trans(known[1],known[2],right,ctx.get(known),ctx.get(Q(known[2],right)),ctx.g)
 return ctx.put(Q(left,right),a.trans(left,known[1],right,a.sym(known[1],left,ctx.get(Q(known[1],left)),ctx.g),mid,ctx.g))
def fcancel(ctx,scale,left,right,known,fs=()):
 fequal_via(ctx,A(M(num(scale),left),Z),A(M(num(scale),right),Z),known,fs)
 m.bound(ctx,Z,num(scale),num(scale-1))
 m.quotient_unique(ctx,num(scale),left,Z,right,Z)
 return ctx.get(Q(left,right))
def fparity_bad(ctx,oddq,evenq,known,goal,fs=()):
 fequal_via(ctx,A(M(two,oddq),O),A(M(two,evenq),Z),known,fs)
 m.bound(ctx,O,two,Z);m.bound(ctx,Z,two,O)
 m.quotient_unique(ctx,two,oddq,O,evenq,Z)
 m.flip(ctx,Q(O,Z));return m.false_zero_one(ctx,goal)
def fhalf_cases(ctx,x,goal,one,half):
 use(ctx,'skelet17-binary-power-halving',{'t':x})
 body=b.And(Q(x,M(two,m.pz)),m.power2(m.pz))
 opts=[Q(x,O),nd.BEX(m.pz,A(x,O),body)]
 def branch(ec,k):
  if k==0:return one(ec)
  def haveh(hc):
   nd.unpack(hc,[Q(x,M(two,ffresh)),m.power2(ffresh)])
   return half(hc,ffresh,Q(x,M(two,ffresh)))
  return m.bex_elim(ec,m.pz,A(x,O),body,ffresh,goal,haveh)
 return nd.cases(ctx,opts,goal,branch)
def fbit_cases(ctx,pf,goal,fn):return nd.cases(ctx,list(pf[-1][1:]),goal,fn)
def fleft_a(ctx,source,leftmove):
 target=Q(A(M(three,NF[1]),two),M(two,fsq(b.t)))
 # E1 writes zero on a right move: L'=2L.
 middle=M(two,source[1]);m.eq(ctx,target[1],middle,[leftmove])
 m.eq(ctx,*target[1:],[Q(target[1],middle),source])
 return target

def finned_a1():
 s,w=b.t,b.u;source=fA1(CF,s,w);target=nd.AND(fE1(NF,M(two,s),w))
 def matching(sc,pf):
  def bit(dc,nb):
   eqs=[pf[4],Q(NF[2],num(nb))]
   if nb==0:return fparity_bad(dc,A(NF[3],fsq(w)),fmul(four,s,fcube(w)),source[-1],target,eqs)
   left=Q(A(M(three,NF[1]),O),fsq(M(two,s)))
   mid=M(two,source[-2][1]);m.eq(dc,left[1],mid,[pf[3]])
   m.eq(dc,*left[1:],[Q(left[1],mid),source[-2]])
   fcancel(dc,2,A(A(NF[3],O),fsq(w)),fmul(two,M(two,s),fcube(w)),source[-1],eqs)
   use(dc,'skelet17-binary-power-double',{'t':s})
   return nd.conj(dc,fE1(NF,M(two,s),w))
  return fbit_cases(sc,pf,target,bit)
 fproof(source,target,0,1,'skelet17-ladder-finned3-a1-to-e1',matching)
finned_a1()

def finned_e1():
 s,w=b.t,b.u;source=fE1(CF,s,w)
 options=[nd.AND(fA0(NF,s)),nd.BEX(fhalf,A(w,O),nd.AND(fA1(NF,s,fhalf)))]
 target=nd.OR(options)
 def matching(sc,pf):
  fleft_a(sc,source[-2],pf[3])
  def one(ec):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),Q(w,O)]
    if nb==1:return fparity_bad(dc,A(NF[3],O),s,source[-1],target,fs)
    fcancel(dc,2,A(NF[3],O),s,source[-1],fs)
    nd.conj(dc,fA0(NF,s));return nd.disj(dc,options,0)
   return fbit_cases(ec,pf,target,bit)
  def half(ec,h,heq):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),heq]
    if nb==0:return fparity_bad(dc,A(NF[3],M(two,fsq(h))),fmul(num(8),s,fcube(h)),source[-1],target,fs)
    fcancel(dc,2,A(A(NF[3],O),M(two,fsq(h))),fmul(num(8),s,fcube(h)),source[-1],fs)
    nd.conj(dc,fA1(NF,s,h))
    m.bex_intro(dc,fhalf,A(w,O),nd.AND(fA1(NF,s,fhalf)),h)
    return nd.disj(dc,options,1)
   return fbit_cases(ec,pf,target,bit)
  return fhalf_cases(sc,w,target,one,half)
 fproof(source,target,4,1,'skelet17-ladder-finned3-e1-to-a',matching)
finned_e1()

def finned_a0():
 s=b.t;source=fA0(CF,s)
 options=[nd.AND(fB0(NF,s,O)),nd.BEX(fhalf,A(s,O),nd.AND(fB1(NF,s,two,fhalf,O)))]
 target=nd.OR(options)
 def matching(sc,pf):
  use(sc,'skelet17-binary-power-one',{},False)
  use(sc,'skelet17-binary-power-double',{'t':O})
  m.eq(sc,M(two,O),two)
  m.rewrite(sc,m.power2(a.E),M(two,O),two)
  leftnew=M(three,A(NF[1],O));mid=A(M(two,source[-2][1]),two)
  m.eq(sc,leftnew,mid,[pf[3]])
  leftb=M(two,A(M(two,fsq(s)),O))
  m.eq(sc,leftnew,leftb,[Q(leftnew,mid),source[-2]])
  def one(ec):
   # R+1=1 gives R=0 by additive cancellation, then ordinary pop uniqueness.
   m.eq(ec,A(CF[3],O),A(Z,O),[source[-1],Q(s,O)])
   imp=b.Imp(Q(A(CF[3],O),A(Z,O)),Q(CF[3],Z))
   ec.theorem(imp,b.apply('add-cancel',{'t':CF[3],'u':Z,'v':O}));ec.mp(imp[1],imp[2])
   m.eq(ec,A(M(two,NF[3]),NF[2]),A(M(two,Z),Z),[m.flip(ec,pf[4]),Q(CF[3],Z)])
   def bit(dc,k):
    m.bound(dc,num(k),two,num(1-k))
    return m.rewrite(dc,L(a.E,two),num(k),NF[2],dc.get(m.flip(dc,Q(NF[2],num(k)))))
   fbit_cases(ec,pf,L(NF[2],two),bit);m.bound(ec,Z,two,O)
   m.quotient_unique(ec,two,NF[3],NF[2],Z,Z)
   fields=fB0(NF,s,O)
   m.eq(ec,*fields[-2][1:],[Q(leftnew,leftb),Q(s,O)])
   m.eq(ec,*fields[-1][1:],[Q(NF[3],Z)])
   nd.conj(ec,fields);return nd.disj(ec,options,0)
  def half(ec,h,heq):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),heq]
    if nb==0:return fparity_bad(dc,NF[3],h,source[-1],target,fs)
    fcancel(dc,2,A(NF[3],O),h,source[-1],fs)
    fields=fB1(NF,s,two,h,O)
    m.eq(dc,*fields[-2][1:],[Q(A(NF[3],O),h)])
    m.eq(dc,*fields[-1][1:],[m.flip(dc,heq)])
    nd.conj(dc,fields)
    m.bex_intro(dc,fhalf,A(s,O),nd.AND(fB1(NF,s,two,fhalf,O)),h)
    return nd.disj(dc,options,1)
   return fbit_cases(ec,pf,target,bit)
  return fhalf_cases(sc,s,target,one,half)
 fproof(source,target,0,0,'skelet17-ladder-finned3-a0-to-b',matching)
finned_a0()

def fC1(c,s,v):
 return [Q(c[0],two),Q(c[2],O),m.power2(s),m.power2(v),
         Q(M(three,A(c[1],O)),fmul(s,fsq(v),A(M(two,fsq(s)),O))),
         Q(A(c[3],O),M(two,v))]
def fBfinal(c,w):
 return [Q(c[0],O),Q(c[2],Z),Q(c[1],Z),m.power2(w),
         Q(A(A(c[3],O),M(two,fsq(w))),M(num(8),fcube(w)))]
def fCfinal(c,w):
 return [Q(c[0],two),Q(c[2],Z),Q(c[1],Z),m.power2(w),
         Q(A(A(c[3],O),M(four,fsq(w))),M(num(16),fcube(w)))]

def finned_b1():
 s,w,z,v=b.t,b.u,b.v,b.w;source=fB1(CF,s,w,z,v)
 options=[nd.AND(fB0(NF,s,v)),nd.BEX(fhalf,A(z,O),nd.AND(fB1(NF,s,M(two,w),fhalf,v)))]
 target=nd.OR(options)
 def matching(sc,pf):
  leftnew=M(three,A(NF[1],O));mid=M(two,source[-3][1])
  m.eq(sc,leftnew,mid,[pf[3]])
  def one(ec):
   fequal_via(ec,w,M(s,fsq(v)),source[-1],[Q(z,O)])
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),Q(z,O)]
    if nb==1:return fparity_bad(dc,A(NF[3],O),v,source[-2],target,fs)
    fcancel(dc,2,A(NF[3],O),v,source[-2],fs)
    fields=fB0(NF,s,v)
    m.eq(dc,*fields[-2][1:],[Q(leftnew,mid),source[-3],Q(w,M(s,fsq(v)))])
    nd.conj(dc,fields);return nd.disj(dc,options,0)
   return fbit_cases(ec,pf,target,bit)
  def half(ec,h,heq):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),heq]
    if nb==0:return fparity_bad(dc,A(NF[3],h),fmul(two,h,v),source[-2],target,fs)
    fields=fB1(NF,s,M(two,w),h,v)
    fcancel(dc,2,fields[-2][1],fields[-2][2],source[-2],fs)
    m.eq(dc,*fields[-3][1:],[Q(leftnew,mid),source[-3]])
    fequal_via(dc,*fields[-1][1:],source[-1],[heq])
    use(dc,'skelet17-binary-power-double',{'t':w})
    nd.conj(dc,fields)
    m.bex_intro(dc,fhalf,A(z,O),nd.AND(fB1(NF,s,M(two,w),fhalf,v)),h)
    return nd.disj(dc,options,1)
   return fbit_cases(ec,pf,target,bit)
  return fhalf_cases(sc,z,target,one,half)
 fproof(source,target,1,1,'skelet17-ladder-finned3-b1-scan',matching)
finned_b1()

def finned_b0_work():
 s,v=b.t,b.u;source=fB0(CF,s,v);target=nd.AND(fC1(NF,s,v))
 def matching(sc,pf):
  def bit(dc,nb):
   fs=[pf[4],Q(NF[2],num(nb))]
   if nb==0:return fparity_bad(dc,A(M(three,NF[1]),O),fmul(s,fsq(v),A(M(two,fsq(s)),O)),source[-2],target,fs)
   fields=fC1(NF,s,v)
   fcancel(dc,2,*fields[-2][1:],source[-2],fs)
   mid=M(two,source[-1][1]);m.eq(dc,fields[-1][1],mid,[pf[3]])
   m.eq(dc,*fields[-1][1:],[Q(fields[-1][1],mid),source[-1]])
   return nd.conj(dc,fields)
  return fbit_cases(sc,pf,target,bit)
 fproof(source,target,1,0,'skelet17-ladder-finned3-b0-work-to-c1',matching)
finned_b0_work()

def fpop_zero(ctx,old,quot,rem,pop,pf):
 m.eq(ctx,A(M(two,quot),rem),A(M(two,Z),Z),[m.flip(ctx,pop),Q(old,Z)])
 def bit(dc,k):
  m.bound(dc,num(k),two,num(1-k))
  return m.rewrite(dc,L(a.E,two),num(k),rem,dc.get(m.flip(dc,Q(rem,num(k)))))
 fbit_cases(ctx,pf,L(rem,two),bit);m.bound(ctx,Z,two,O)
 return m.quotient_unique(ctx,two,quot,rem,Z,Z)
def finned_b0_final():
 w=b.t;source=fBfinal(CF,w);fields=fCfinal(NF,w);target=nd.AND(fields)
 def matching(sc,pf):
  fpop_zero(sc,CF[1],NF[1],NF[2],pf[4],pf)
  mid=M(two,source[-1][1]);m.eq(sc,fields[-1][1],mid,[pf[3]])
  m.eq(sc,*fields[-1][1:],[Q(fields[-1][1],mid),source[-1]])
  return nd.conj(sc,fields)
 fproof(source,target,1,0,'skelet17-ladder-finned3-b0-final-to-c0',matching)
finned_b0_final()

def finned_c0_final():
 w=b.t;source=fCfinal(CF,w);fields=fA1(NF,O,w);target=nd.AND(fields)
 def matching(sc,pf):
  m.eq(sc,NF[1],Z,[pf[3],Q(CF[1],Z)])
  m.eq(sc,*fields[-2][1:],[Q(NF[1],Z)])
  use(sc,'skelet17-binary-power-one',{},False)
  def bit(dc,nb):
   fs=[pf[4],Q(NF[2],num(nb))]
   if nb==0:return fparity_bad(dc,A(NF[3],M(two,fsq(w))),M(num(8),fcube(w)),source[-1],target,fs)
   fcancel(dc,2,*fields[-1][1:],source[-1],fs)
   return nd.conj(dc,fields)
  return fbit_cases(sc,pf,target,bit)
 fproof(source,target,2,0,'skelet17-ladder-finned3-c0-final-to-a1',matching)
finned_c0_final()

def fcancel_rem(ctx,scale,rem,left,right,known,fs=()):
 fequal_via(ctx,A(M(num(scale),left),num(rem)),A(M(num(scale),right),num(rem)),known,fs)
 m.bound(ctx,num(rem),num(scale),num(scale-rem-1))
 m.quotient_unique(ctx,num(scale),left,num(rem),right,num(rem))
 return ctx.get(Q(left,right))
def fD0(c,s,u,v):
 return [Q(c[0],three),Q(c[2],Z),*[m.power2(t) for t in (s,u,v)],
         Q(A(M(three,c[1]),O),fsq(s)),
         Q(A(A(c[3],O),u),fmul(two,u,v)),Q(M(four,u),M(s,fsq(v)))]
def fD1(c,s,w,u,v):
 return [Q(c[0],three),Q(c[2],O),*[m.power2(t) for t in (s,w,u,v)],
         Q(M(three,A(c[1],O)),M(w,A(M(two,fsq(s)),O))),
         Q(A(A(c[3],O),u),fmul(two,u,v)),Q(fmul(num(8),u,w),M(s,fsq(v)))]

def finned_d1():
 s,w,u,v=b.t,b.u,b.v,b.w;source=fD1(CF,s,w,u,v)
 options=[nd.AND(fD0(NF,s,M(two,u),v)),nd.BEX(fhalf,A(w,O),nd.AND(fD1(NF,s,fhalf,M(two,u),v)))]
 target=nd.OR(options)
 def matching(sc,pf):
  use(sc,'skelet17-binary-power-double',{'t':u})
  def right(dc,fields):
   mid=M(two,source[-2][1]);m.eq(dc,fields[-2][1],mid,[pf[3]])
   return m.eq(dc,*fields[-2][1:],[Q(fields[-2][1],mid),source[-2]])
  def one(ec):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),Q(w,O)]
    if nb==1:return fparity_bad(dc,fsq(s),M(three,A(NF[1],O)),m.flip(dc,source[-3]),target,fs)
    fields=fD0(NF,s,M(two,u),v)
    fcancel_rem(dc,2,1,*fields[-3][1:],source[-3],fs)
    right(dc,fields);fequal_via(dc,*fields[-1][1:],source[-1],[Q(w,O)])
    nd.conj(dc,fields);return nd.disj(dc,options,0)
   return fbit_cases(ec,pf,target,bit)
  def half(ec,h,heq):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),heq]
    if nb==0:return fparity_bad(dc,A(M(three,NF[1]),O),M(h,A(M(two,fsq(s)),O)),source[-3],target,fs)
    fields=fD1(NF,s,h,M(two,u),v)
    fcancel(dc,2,*fields[-3][1:],source[-3],fs)
    right(dc,fields);fequal_via(dc,*fields[-1][1:],source[-1],[heq])
    nd.conj(dc,fields)
    m.bex_intro(dc,fhalf,A(w,O),nd.AND(fD1(NF,s,fhalf,M(two,u),v)),h)
    return nd.disj(dc,options,1)
   return fbit_cases(ec,pf,target,bit)
  return fhalf_cases(sc,w,target,one,half)
 fproof(source,target,3,1,'skelet17-ladder-finned3-d1-scan',matching)
finned_d1()

def finned_d0():
 s,u,v=b.t,b.u,b.v;source=fD0(CF,s,u,v)
 options=[nd.BEX(fhalf,A(v,O),nd.AND(fBfinal(NF,fhalf))),
          nd.BEX(fhalf,A(s,O),nd.AND(fB1(NF,fhalf,O,M(two,u),v)))]
 target=nd.OR(options)
 def matching(sc,pf):
  use(sc,'skelet17-binary-power-one',{},False)
  use(sc,'skelet17-binary-power-double',{'t':u})
  def one(ec):
   fcancel_rem(ec,3,1,CF[1],Z,source[-3],[Q(s,O)])
   fpop_zero(ec,CF[1],NF[1],NF[2],pf[4],pf)
   def vone(dc):return fparity_bad(dc,Z,M(two,u),m.flip(dc,source[-1]),target,[Q(s,O),Q(v,O)])
   def vhalf(dc,h,heq):
    fcancel(dc,4,u,fsq(h),source[-1],[Q(s,O),heq])
    fields=fBfinal(NF,h);mid=M(two,source[-2][1])
    m.eq(dc,fields[-1][1],mid,[pf[3],Q(u,fsq(h))])
    m.eq(dc,*fields[-1][1:],[Q(fields[-1][1],mid),source[-2],heq,Q(u,fsq(h))])
    nd.conj(dc,fields);m.bex_intro(dc,fhalf,A(v,O),nd.AND(fBfinal(NF,fhalf)),h)
    return nd.disj(dc,options,0)
   return fhalf_cases(ec,v,target,vone,vhalf)
  def half(ec,h,heq):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),heq]
    if nb==0:return fparity_bad(dc,M(three,NF[1]),M(two,fsq(h)),source[-3],target,fs)
    fields=fB1(NF,h,O,M(two,u),v)
    addtwo=Q(A(source[-3][1],two),A(source[-3][2],two))
    m.eq(dc,*addtwo[1:],[source[-3]])
    fcancel(dc,2,*fields[-3][1:],addtwo,fs)
    mid=M(two,source[-2][1]);m.eq(dc,fields[-2][1],mid,[pf[3]])
    m.eq(dc,*fields[-2][1:],[Q(fields[-2][1],mid),source[-2]])
    fcancel(dc,2,M(two,u),M(h,fsq(v)),source[-1],[heq])
    m.eq(dc,*fields[-1][1:],[Q(M(two,u),M(h,fsq(v)))])
    nd.conj(dc,fields)
    m.bex_intro(dc,fhalf,A(s,O),nd.AND(fB1(NF,fhalf,O,M(two,u),v)),h)
    return nd.disj(dc,options,1)
   return fbit_cases(ec,pf,target,bit)
  return fhalf_cases(sc,s,target,one,half)
 fproof(source,target,3,0,'skelet17-ladder-finned3-d0-to-b',matching)
finned_d0()

mulI=m.declare('finnedMulIndex');mulX=m.declare('finnedMulBound');mulFresh=m.declare('finnedMulFresh')
def finned_power_product():
 x,y=b.t,b.u;prem=b.And(m.power2(x),m.power2(y));goal=m.power2(M(x,y))
 root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]))
 def inner(z):return b.Imp(m.power2(z),m.power2(M(z,y)))
 def phi(i):return nd.BALL(mulX,A(i,O),inner(mulX))
 def build_bounded(parent,index,prove):
  guard=L(mulFresh,A(index,O));gc=parent.push(guard);ac=gc.push(m.power2(mulFresh))
  ac.put(m.power2(M(mulFresh,y)),prove(ac))
  gc.intro(m.power2(mulFresh),m.power2(M(mulFresh,y)),ac)
  parent.intro(guard,inner(mulFresh),gc);parent.all_intro(mulFresh,b.Imp(guard,inner(mulFresh)))
  m.rename_all(parent,mulFresh,mulX,lambda z:b.Imp(L(z,A(index,O)),inner(z)))
 def base(ac):
  out=m.power2(M(mulFresh,y))
  use(ac,'skelet17-binary-below-successor',{'t':mulFresh,'u':Z})
  def small(ec,k):
   if k==0:
    ec.put(b.Not(L(mulFresh,Z)),b.ax('O4',ec.g,t=mulFresh));return ec.explode(L(mulFresh,Z),out)
   nd.unpack(ec,list(m.power2(mulFresh)[1:]));m.rewrite(ec,L(Z,a.E),mulFresh,Z)
   ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z));return ec.explode(L(Z,Z),out)
  return nd.cases(ac,[L(mulFresh,Z),Q(mulFresh,Z)],out,small)
 build_bounded(ctx,Z,base)
 sc=ctx.push(phi(mulI))
 def succ(ac):
  out=m.power2(M(mulFresh,y))
  use(ac,'skelet17-binary-below-successor',{'t':mulFresh,'u':A(mulI,O)})
  def apply_ih(ec,t):
   _,pp=ec.all_elim(mulX,phi(mulI)[2],t)
   ec.mp(L(t,A(mulI,O)),inner(t),pp)
   return ec.mp(m.power2(t),m.power2(M(t,y)))
  def where(ec,k):
   if k==0:return apply_ih(ec,mulFresh)
   def one(dc):
    m.eq(dc,M(mulFresh,y),y,[Q(mulFresh,O)])
    return m.rewrite(dc,m.power2(a.E),y,M(mulFresh,y),a.sym(M(mulFresh,y),y,dc.get(Q(M(mulFresh,y),y)),dc.g))
   def half(dc,h,heq):
    nd.unpack(dc,list(m.power2(h)[1:]));use(dc,'skelet17-binary-double-larger',{'t':h})
    m.eq(dc,M(two,h),A(mulI,O),[m.flip(dc,heq),Q(mulFresh,A(mulI,O))])
    m.rewrite(dc,L(h,a.E),M(two,h),A(mulI,O))
    apply_ih(dc,h);use(dc,'skelet17-binary-power-double',{'t':M(h,y)})
    m.eq(dc,M(mulFresh,y),M(two,M(h,y)),[heq])
    return m.rewrite(dc,m.power2(a.E),M(two,M(h,y)),M(mulFresh,y),a.sym(M(mulFresh,y),M(two,M(h,y)),dc.get(Q(M(mulFresh,y),M(two,M(h,y)))),dc.g))
   return fhalf_cases(ec,mulFresh,out,one,half)
  return nd.cases(ac,[L(mulFresh,A(mulI,O)),Q(mulFresh,A(mulI,O))],out,where)
 build_bounded(sc,A(mulI,O),succ)
 ctx.intro(phi(mulI),phi(A(mulI,O)),sc);step=b.All(mulI,b.Imp(phi(mulI),phi(A(mulI,O))))
 ctx.all_intro(mulI,b.Imp(phi(mulI),phi(A(mulI,O))))
 m.induction(ctx,mulI,phi(mulI),phi(Z),step)
 ctx.all_elim(mulI,phi(mulI),x);m.successor(ctx,x)
 _,pp=ctx.all_elim(mulX,phi(x)[2],x);ctx.mp(L(x,A(x,O)),inner(x),pp);ctx.mp(m.power2(x),goal)
 finish('skelet17-ladder-finned3-power-product',root,prem,goal,ctx,
        'Multiplication closure for the bounded divisor Pow2 predicate. One bounded strong-induction construction, reusing earlier arithmetic. No total exponentiation.')
finned_power_product()

def finned_c1():
 s,v=b.t,b.u;k=M(s,fsq(v));source=fC1(CF,s,v)
 options=[nd.AND(fD0(NF,s,O,M(two,v))),
          nd.BEX(fhalf,A(k,O),nd.AND(fD1(NF,s,fhalf,O,M(two,v))))]
 target=nd.OR(options)
 def matching(sc,pf):
  sc.both(m.power2(v),m.power2(v));use(sc,'skelet17-ladder-finned3-power-product',{'t':v,'u':v})
  sc.both(m.power2(s),m.power2(fsq(v)));use(sc,'skelet17-ladder-finned3-power-product',{'t':s,'u':fsq(v)})
  use(sc,'skelet17-binary-power-one',{},False)
  use(sc,'skelet17-binary-power-double',{'t':v})
  left=Q(source[-2][1],M(k,A(M(two,fsq(s)),O)))
  fequal_via(sc,*left[1:],source[-2])
  def right(dc,fields):
   mid=M(two,source[-1][1]);m.eq(dc,fields[-2][1],mid,[pf[3]])
   return m.eq(dc,*fields[-2][1:],[Q(fields[-2][1],mid),source[-1]])
  def one(ec):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),Q(k,O)]
    if nb==1:return fparity_bad(dc,fsq(s),M(three,A(NF[1],O)),m.flip(dc,left),target,fs)
    fields=fD0(NF,s,O,M(two,v));fcancel_rem(dc,2,1,*fields[-3][1:],left,fs)
    right(dc,fields)
    mid=M(four,k);m.eq(dc,fields[-1][2],mid)
    m.eq(dc,fields[-1][2],fields[-1][1],[Q(fields[-1][2],mid),Q(k,O)]);m.flip(dc,Q(fields[-1][2],fields[-1][1]))
    nd.conj(dc,fields);return nd.disj(dc,options,0)
   return fbit_cases(ec,pf,target,bit)
  def half(ec,h,heq):
   def bit(dc,nb):
    fs=[pf[4],Q(NF[2],num(nb)),heq]
    if nb==0:return fparity_bad(dc,A(M(three,NF[1]),O),M(h,A(M(two,fsq(s)),O)),left,target,fs)
    fields=fD1(NF,s,h,O,M(two,v));fcancel(dc,2,*fields[-3][1:],left,fs)
    right(dc,fields)
    mid=M(four,k);m.eq(dc,fields[-1][2],mid)
    m.eq(dc,fields[-1][2],fields[-1][1],[Q(fields[-1][2],mid),heq]);m.flip(dc,Q(fields[-1][2],fields[-1][1]))
    nd.conj(dc,fields)
    m.bex_intro(dc,fhalf,A(k,O),nd.AND(fD1(NF,s,fhalf,O,M(two,v))),h)
    return nd.disj(dc,options,1)
   return fbit_cases(ec,pf,target,bit)
  return fhalf_cases(sc,k,target,one,half)
 fproof(source,target,2,1,'skelet17-ladder-finned3-c1-to-d',matching)
finned_c1()
