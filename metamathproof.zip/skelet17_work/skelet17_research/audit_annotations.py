"""Audit the checked annotation construction against the original core."""
from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse,rewrite
orr,orules,_=parse((P/'scan_checked.mm').read_text())
nrr,nrules,_=parse((P/'annotations_checked.mm').read_text())
def trusted(records,rules):
    return {r['label']:{'expression':r['expr'],'hypotheses':[rules[h]['expr'] for h in r['hyps']],
        'disjoint':sorted(r['dv'])} for r in records if r['kind']=='a'}
assert trusted(orr,orules)==trusted(nrr,nrules)
assert len(trusted(nrr,nrules))==93
log=(P/'annotation_verification.log').read_text()
assert '?Error' not in log and 'No errors were found.' in log and 'All proofs in the database were verified' in log
deps={r['label']:rewrite(r,{})[1] for r in nrr if r['kind']=='p'}
def closure(root):
    seen=set();todo=[root]
    while todo:
        k=todo.pop()
        if k in seen:continue
        seen.add(k);todo.extend(deps.get(k,()))
    return seen
metrics={}
for r in nrr:
    root=r.get('label','')
    if r['kind']!='p' or not root.startswith('skelet17-annotation-'):continue
    reach=closure(root);instances=sorted(k for k in reach if 'ax-ind-bounded' in deps.get(k,set()))
    metrics[root]={'bounded_induction_application_nodes':instances,'induction_application_count':len(instances)}
for root in ['append-local','empty','table-total','leading-control-zero']:
    assert metrics['skelet17-annotation-'+root]['induction_application_count']==0
assert metrics['skelet17-annotation-one-step-exists']['induction_application_count']==1
assert metrics['skelet17-annotation-certificate-exists']['induction_application_count']==2
assert metrics['skelet17-annotation-positive-certificate']['induction_application_count']==2
files=['annotations_checked.mm','build_annotations.py','annotation_theorems.json','annotation_verification.log',
       'check_annotations.py','annotation_checks.json','CONTROL_ANNOTATIONS.md','audit_annotations.py']
out={'control_annotation_existence_proved':True,'control_annotation_bound':'S < 8*(x+1)^3',
    'parser_correspondence_on_LowerWord_proved':False,'compressed_Gray_decoder_totality_proved':False,
    'whole_machine_nonhalting_proved':False,'trusted_declarations_unchanged':True,'trusted_count':93,
    'verifier_log_clean':True,'proved_statement_count':sum(r['kind']=='p' for r in nrr),
    'public_interfaces':metrics,
    'files':{s:{'bytes':(P/s).stat().st_size,'sha256':hashlib.sha256((P/s).read_bytes()).hexdigest()} for s in files}}
(P/'annotation_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('files','public_interfaces')},indent=2))
