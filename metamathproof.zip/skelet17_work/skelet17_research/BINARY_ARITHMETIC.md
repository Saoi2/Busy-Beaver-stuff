# Checked arithmetic prerequisites for the Gray certificate

The auxiliary `binary_checked.mm` adds no trusted axioms and changes no
machine configurations or histories. It does not prove decoder totality
or Skelet #17 nonhalting. Its proofs use the same 93 trusted declarations
as the original core. The official Metamath verifier checks every proof;
`audit_binary.py` compares trusted expressions, hypotheses and
distinct-variable requirements exactly with `scan_checked.mm`.

## Bounded division

`skelet17-bounded-division-exists` proves

    0<m -> exists q<x+1 exists r<m (x=m*q+r).

Its induction formula, with m a parameter, is exactly

    phi(i;m) := exists q<i+1 exists r<m (i=m*q+r).

Every quantifier is bounded. At 0 choose q=r=0. Discreteness gives r+1<m
or r+1=m in the successor step. In the first case retain q and choose r+1;
in the second choose q+1 and remainder 0. The witness bounds are proved
in each branch. This is one bounded-induction construction. The earlier
derived `division-unique` supplies uniqueness without induction.

## Shared packed-field existence and uniqueness

`skelet17-bounded-field-exists` proves

    0<P and 0<B -> exists q<x+1 exists v<B exists r<P
      (x=(B*P)*q+P*v+r).

P is the field's scale, B its range, v its value, r everything below it,
and q everything above it. Divide x by P and the first quotient by B.
The last quotient bound is proved explicitly. This reuses division twice
and introduces no further induction construction. Binary digit existence
is a short specialization to B=2, not a duplicate implementation.

`skelet17-bounded-field-unique` proves that two representations of the same
x at the same P and B, with v,v'<B and r,r'<P, have q=q', v=v' and r=r'.
No induction is used. The bound P*v+r<P*B follows from the discrete-order
witnesses B=v+k+1 and P=r+l+1:

    P*B = (P*v+r) + (l+P*k) + 1.

Use quotient/remainder uniqueness first at modulus B*P and then at P.
For example, 173=32*5+4*3+1 gives q=5,v=3,r=1 at P=4,B=8. At P=4,B=2,
173=8*21+4*1+1 extracts the bit 1 at weight 4.

The bit predicates are explicit bounded formulas:

    Zero(x,p) := exists q<x+1 exists r<p (x=q*(2*p)+r).
    One(x,p)  := exists q<x+1 exists r<p (x=q*(2*p)+p+r).

One is the earlier Gray-input predicate up to bound-variable names.
`skelet17-binary-bit-dichotomy` proves 0<p -> (Zero(x,p) or One(x,p)).
`skelet17-binary-bit-exclusive` proves Zero(x,p) -> not One(x,p), without
induction, by applying packed-field uniqueness to values 0 and 1.
At arbitrary p these are mixed-radix digits; at binary places they are bits.

## A bounded binary place

The power predicate is unchanged from the preceding syntax proposal:

    Div(d,p) := exists e<p+1 (d*e=p).
    Even(d)  := exists z<d+1 (d=2*z).
    Pow2(p)  := 0<p and
      forall d<p+1 (Div(d,p) -> (d=1 or Even(d))).

In standard natural numbers this defines positive powers of two. The
new proofs establish particular properties internally:

* `skelet17-binary-power-one`: Pow2(1).
* `skelet17-binary-power-double`: Pow2(p) -> Pow2(2*p).
* `skelet17-binary-power-divisor`: Pow2(p) and Div(h,p) -> Pow2(h).
* `skelet17-binary-power-halving`:

      Pow2(p) -> (p=1 or exists h<p+1 (p=2*h and Pow2(h))).

* `skelet17-bounded-leading-power`:

      0<x -> exists p<x+1 (Pow2(p) and x<2*p).

For doubling closure, consider d*e=2*p. Divide d and e by 2. If d is even
the divisor condition is satisfied. If both are odd, their product is odd,
contradicting remainder uniqueness modulo 2. Otherwise e=2*h and p=d*h.
Elementary product bounds justify the bounded witnesses needed to apply
the assumed divisor condition on p. Parity uses bounded division.

Divisor closure and halving need no induction. For divisor closure,
transitivity makes each divisor of h a divisor of p, with every witness
bound proved using positive-factor bounds. For halving, apply the defining
divisor condition to p itself. Either p=1 or it has an evenness witness h.
That h divides p with cofactor 2, so divisor closure supplies Pow2(h).

The second induction construction uses the bounded formula

    psi(i) := i=0 or exists p<i+1 (Pow2(p) and i<2*p).

The base is i=0. At its successor use place 1. Otherwise retain p when
i+1<2*p; if i+1=2*p use 2*p and doubling closure. All bounds are proved.
The dependency closure has two explicit induction constructions, with
division reused at several arguments. This does not assert totality of
an indexed exponentiation function or yet establish all of its relations
with Pow2 and binary length. The place p is bounded by x, rather than
chosen for an arbitrary input exponent.

## Appending a digit preserves fields at shifted places

`skelet17-binary-field-shift` proves the following uniform rule, with no
induction. Suppose

    x=D*y+d, d<D,
    y=(B*P)*q+P*v+r, r<P.

Then

    x=(B*(D*P))*q+(D*P)*v+(D*r+d),
    D*r+d<D*P.

Thus the old field value v is retained when its scale P is shifted to D*P.
The low remainder becomes D*r+d. Use D=2 for appending an input bit; a
fixed larger D handles a block of control-state bits. The same theorem
covers both cases. For example, appending 0 to binary input 173 gives 346;
its old field P=4,B=8,v=3 moves to scale 8:
346=64*5+8*3+2.

This rule is the local arithmetic needed for a recursive construction of
annotations. It does not by itself supply a code for every annotation.

## Remaining gap and verification

Individual fields and a suitable leading place now have existence proofs.
A complete decoder annotation, count tree, output word, local rank paths,
their correctness, and the global invariant excluding B111 are still
unproved. Earlier machine-history theorems are unchanged.

Regenerate from the archive root:

    python3 skelet17_research/build_binary.py
    python3 skelet17_research/prune.py binary_raw.mm binary_checked.mm
    metamath 'read "skelet17_research/binary_checked.mm"' 'verify proof *' exit
    python3 skelet17_research/audit_binary.py

Capture the verifier output in `binary_verification.log` before running
the audit. Require a clean parse as well as complete proof verification.

## Subsequent control-only existence result

The additional annotations_checked.mm now uses this arithmetic to prove
bounded existence of power-indexed control annotations. See
CONTROL_ANNOTATIONS.md for the exact scope, including the explicitly
totalized auxiliary table and remaining source-parser correspondence.
Full decoder-output and nonhalting theorems remain unproved.
