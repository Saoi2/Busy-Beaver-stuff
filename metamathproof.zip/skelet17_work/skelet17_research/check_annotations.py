"""Interpretation/regression checks; the proofs are checked by Metamath."""
from pathlib import Path
from itertools import product
import json
from gray_transducer import transition,word
TABLE=[[0,4],[0,5],[0,6],[0,7],[2,4],[3,5],[0,5],[1,4]]
def encode_state(state):return 4*state[0]+2*state[1]+state[2]
def make(x):
    S=control=0
    for ch in bin(x)[2:] if x else '':
        control=TABLE[control][int(ch)];S=8*S+control
    return S
def verify(x,S):
    if not x:
        assert S==0;return
    P=1<<(x.bit_length()-1)
    assert P<=x<2*P and S<8*P**3 and S<8*(x+1)**3
    assert S//((2*P)**3)%8==0
    p=1
    while p<=x:
        before=S//((2*p)**3)%8;bit=x//p%2;after=S//(p**3)%8
        assert TABLE[before][bit]==after
        p*=2
if __name__=='__main__':
    for x in range(16384):verify(x,make(x))
    valid=0
    for size in range(1,8):
        for xs in product(range(4),repeat=size):
            w=word(xs);x=int(w,2) if w else 0;S=make(x);verify(x,S)
            state=(0,0,0);number=0
            for ch in w:
                state,_=transition(state,int(ch));number=8*number+encode_state(state)
            assert number==S
            valid+=1
    out={'status':'Regression tests, not proofs. They check code interpretation and agreement with the original parser controls on valid words.',
        'all_binary_inputs':16384,'exhaustive_valid_list_inputs':valid,
        'packed_field_base':8,'place_rule':'input weight p corresponds to control weight p^3',
        'polynomial_bound':'S < 8*(x+1)^3','table':TABLE,
        'examples':[{'input':x,'word':bin(x)[2:] if x else '',
                     'control_code':make(x),'control_code_octal':oct(make(x))[2:]} for x in [0,1,2,3,6,7,13,173]]}
    Path(__file__).with_name('annotation_checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k not in ('table','examples')})
