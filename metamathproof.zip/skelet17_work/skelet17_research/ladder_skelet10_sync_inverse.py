"""Inverse carry rules; ordinary deductions over the existing graph."""
def add_skelet10_sync_inverse(m,right):
 nd,b=m.nd,m.b;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;use=m.invoke
 two,three,four=map(m.a.num,(2,3,4));carry=right['carry'];x,y=b.t,b.u;xx=M(two,x)
 jp,js,ja=right['jp'],right['js'],right['ja']
 ep,es,ea,dq,dr=[m.declare('syncInverse'+n) for n in ('P','S','A','Quotient','Digit')]
 def cp(p,s,a):return [m.power2(p),Q(p,A(M(three,s),O)),Q(xx,A(M(p,M(two,a)),s)),Q(y,M(p,A(M(four,a),O)))]
 root=nd.Ctx();prem=carry(xx,y);c=root.push(prem);goal=Q(y,A(M(four,x),O))
 def pfound(pc):
  def sfound(sc):
   def afound(ac):
    fs=cp(ep,es,ea);nd.unpack(ac,fs);m.bound(ac,Z,two,O);use(ac,'skelet17-bounded-division-exists',{'t':es,'u':two})
    def qfound(qc):
     def rfound(rc):
      se=Q(es,A(M(two,dq),dr));use(rc,'skelet17-binary-digit-cases',{'t':dr})
      def digit(dc,k):
       de=Q(dr,O if k else Z)
       if k:
        rhs=A(M(two,A(M(ep,ea),dq)),O)
        m.eq(dc,A(M(two,x),Z),rhs,[fs[2],se,de]);m.bound(dc,O,two,Z)
        m.quotient_unique(dc,two,x,Z,A(M(ep,ea),dq),O)
        return m.false_zero_one(dc,goal)
       odd=A(M(two,M(three,dq)),O)
       m.eq(dc,ep,odd,[fs[1],se,de]);m.rewrite(dc,m.power2(m.a.E),ep,odd)
       use(dc,'skelet17-ladder-bouncer-odd-power',{'t':M(three,dq)})
       m.eq(dc,A(M(three,dq),Z),A(M(three,Z),Z),[Q(M(three,dq),Z)])
       m.bound(dc,Z,three,two);m.quotient_unique(dc,three,dq,Z,Z,Z)
       m.eq(dc,es,Z,[se,de,Q(dq,Z)]);m.eq(dc,ep,O,[fs[1],Q(es,Z)])
       m.eq(dc,A(M(two,x),Z),A(M(two,ea),Z),[fs[2],Q(es,Z),Q(ep,O)])
       m.bound(dc,Z,two,O);m.quotient_unique(dc,two,x,Z,ea,Z)
       return m.eq(dc,*goal[1:],[fs[3],Q(ep,O),m.flip(dc,Q(x,ea))])
      return nd.cases(rc,[Q(dr,Z),Q(dr,O)],goal,digit)
     return m.bex_elim(qc,m.r,two,Q(es,A(M(two,dq),m.r)),dr,goal,rfound)
    return m.bex_elim(ac,m.q,A(es,O),nd.BEX(m.r,two,Q(es,A(M(two,m.q),m.r))),dq,goal,qfound)
   return m.bex_elim(sc,ja,A(xx,O),nd.AND(cp(ep,es,ja)),ea,goal,afound)
  return m.bex_elim(pc,js,A(xx,O),nd.BEX(ja,A(xx,O),nd.AND(cp(ep,js,ja))),es,goal,sfound)
 m.bex_elim(c,jp,A(M(three,xx),two),nd.BEX(js,A(xx,O),nd.BEX(ja,A(xx,O),nd.AND(cp(jp,js,ja)))),ep,goal,pfound)
 m.finish('skelet17-ladder-skelet10-carry-base-inverse',root,prem,goal,c,'Even-input carry inversion by bounded parity division and the existing odd-Pow2 lemma. No new induction construction.')
