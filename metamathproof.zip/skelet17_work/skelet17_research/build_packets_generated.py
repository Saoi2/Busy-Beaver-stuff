"""Packed control annotations for the auxiliary Gray parser.

No machine or history encoding changes. No additional trusted axioms.
The partial parser is totalized on invalid inputs; correspondence with the
original parser is claimed only on valid words and must be proved separately.
"""
from pathlib import Path
import json
import build_binary as m
nd,b,a=m.nd,m.b,m.a
A,M,Q,L,O,Z,N=m.A,m.M,m.Q,m.L,m.O,m.Z,m.N
two=m.two;eight=a.num(32)
declare,eq,rewrite,bound,invoke=m.declare,m.eq,m.rewrite,m.bound,m.invoke
finish,save,flip=m.finish,m.save,m.flip
fq=declare('annFieldQ');fr=declare('annFieldR')
qf=declare('annFreshQ');rf=declare('annFreshR');vf=declare('annFreshValue')
agap=declare('annGap')
place=declare('annPlace');pf=declare('annFreshPlace');hf=declare('annFreshHalf')
av,bv,cv=[declare('ann'+s) for s in ('Before','Bit','After')]
codevar=declare('annCertificate')
choicevar=declare('annChoice')
af,bf,cf=[declare('annFresh'+s) for s in ('Before','Bit','After')]
x,y,s,t,d,c,prev=[declare('ann'+n,'term') for n in ('Input','Prefix','States','OldStates','Low','Next','Previous')]
P,B,D,value=[declare('ann'+n,'term') for n in ('Scale','Base','Radix','Value')]
def power5(p):return M(M(M(p,p),p),M(p,p))
def FIELD(x,p,base,v):return nd.BEX(fq,A(x,O),nd.BEX(fr,p,Q(x,m.whole(p,base,fq,v,fr))))
TABLE=[[0, 4], [0, 5], [0, 6], [0, 7], [2, 12], [3, 29], [0, 29], [1, 12], [0, 4], [0, 5], [0, 6], [0, 7], [2, 12], [3, 29], [0, 29], [1, 12], [0, 4], [0, 5], [0, 6], [0, 7], [2, 12], [3, 29], [0, 29], [1, 12], [0, 4], [0, 5], [0, 6], [0, 7], [2, 12], [3, 29], [0, 29], [1, 12]]
def DELTA(a0,b0,c0):
    return nd.OR([nd.AND([Q(a0,a.num(i)),Q(b0,a.num(j)),Q(c0,a.num(TABLE[i][j]))]) for i in range(32) for j in range(2)])
def BODY(x,S,p,aa,bb,cc):
    return nd.AND([FIELD(S,power5(M(two,p)),eight,aa),FIELD(x,p,two,bb),
        FIELD(S,power5(p),eight,cc),DELTA(aa,bb,cc)])
def LOCAL(x,S,p):return nd.BEX(av,eight,nd.BEX(bv,two,nd.BEX(cv,eight,BODY(x,S,p,av,bv,cv))))
def RUN(x,S):return nd.BALL(place,A(x,O),b.Imp(m.power2(place),LOCAL(x,S,place)))


# A derived scaling identity replaces repeated expansion of 32*32 terms.
scale_formula=Q(power5(M(two,b.t)),M(eight,power5(b.t)))
b.theorem('skelet17-packet-power-double',scale_formula,a.equal(*scale_formula[1:]))
m.theorems['skelet17-packet-power-double']=scale_formula
original_eq=eq
def normalized_weight(ctx,t):
    if t==power5(O):return O,ctx.theorem(Q(t,O),a.equal(t,O))
    if t[0]=='*':
        try:base=t[1][1][1]
        except (IndexError,TypeError):base=None
        if base is not None and t==power5(base) and base[0]=='*' and base[1]==two:
            mid=M(eight,power5(base[2]));f=Q(t,mid)
            proof=ctx.theorem(f,b.apply('skelet17-packet-power-double',{'t':base[2]}))
            out,rest=normalized_weight(ctx,mid)
            return out,a.trans(t,mid,out,proof,rest,ctx.g)
    if t[0] not in ('+','*'):return t,b.refl(ctx.g,t)
    left,lp=normalized_weight(ctx,t[1]);right,rp=normalized_weight(ctx,t[2])
    out=(t[0],left,right)
    return out,a.cong2(t[0],t[1],left,t[2],right,lp,rp,ctx.g)
def eq(ctx,l,r,fs=()):
    left,right=l,r;lp=b.refl(ctx.g,l);rp=b.refl(ctx.g,r)
    for f in fs:
        nl,np=a.rewrite_term(ctx.g,left,f[1],f[2],ctx.get(f));nr,nq=a.rewrite_term(ctx.g,right,f[1],f[2],ctx.get(f))
        lp=a.trans(l,left,nl,lp,np,ctx.g);rp=a.trans(r,right,nr,rp,nq,ctx.g);left,right=nl,nr
    nl,np=normalized_weight(ctx,left);nr,nq=normalized_weight(ctx,right)
    lp=a.trans(l,left,nl,lp,np,ctx.g);rp=a.trans(r,right,nr,rp,nq,ctx.g)
    middle=b.refl(ctx.g,nl) if nl==nr else ctx.theorem(Q(nl,nr),a.equal(nl,nr))
    proof=a.trans(l,nl,nr,lp,middle,ctx.g)
    return ctx.put(Q(l,r),a.trans(l,nr,r,proof,a.sym(r,nr,rp,ctx.g),ctx.g))

def prefix_bound():
    prem=b.And(L(Z,D),Q(x,A(M(D,y),d)));goal=L(y,A(x,O))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]))
    def fromgap(ec,geq):return bound(ec,y,A(x,O),A(M(agap,y),d),[prem[2],geq])
    m.gap_elim(ctx,Z,D,agap,goal,fromgap)
    finish('skelet17-packet-prefix-bound',root,prem,goal,ctx)
prefix_bound()

def field_total():
    prem=b.And(L(Z,P),L(Z,B));root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]))
    goal=nd.BEX(av,B,FIELD(x,P,B,av))
    invoke(ctx,'skelet17-bounded-field-exists',{'t':x,'u':P,'v':B})
    def haveq(qc):
        def havev(vc):
            def haver(rc):
                m.bex_intro(rc,fr,P,Q(x,m.whole(P,B,qf,vf,fr)),rf)
                m.bex_intro(rc,fq,A(x,O),nd.BEX(fr,P,Q(x,m.whole(P,B,fq,vf,fr))),qf)
                return m.bex_intro(rc,av,B,FIELD(x,P,B,av),vf)
            return m.bex_elim(vc,m.r,P,Q(x,m.whole(P,B,qf,vf,m.r)),rf,goal,haver)
        return m.bex_elim(qc,m.digit,B,nd.BEX(m.r,P,Q(x,m.whole(P,B,qf,m.digit,m.r))),vf,goal,havev)
    m.bex_elim(ctx,m.q,A(x,O),nd.BEX(m.digit,B,nd.BEX(m.r,P,Q(x,m.whole(P,B,m.q,m.digit,m.r)))),qf,goal,haveq)
    finish('skelet17-packet-field-total',root,prem,goal,ctx)
field_total()

def field_append():
    fs=[L(Z,D),Q(x,A(M(D,y),d)),L(d,D),FIELD(y,P,B,value)]
    prem=nd.AND(fs);goal=FIELD(x,M(D,P),B,value);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    ctx.both(fs[0],fs[1]);invoke(ctx,'skelet17-packet-prefix-bound')
    def haveq(qc):
        def haver(rc):
            parts=[fs[1],fs[2],Q(y,m.whole(P,B,qf,value,rf)),L(rf,P)]
            nd.conj(rc,parts);invoke(rc,'skelet17-binary-field-shift',{
                't':x,'u':y,'v':d,'w':D,'fieldShiftScale':P,'fieldShiftBase':B,
                'fieldQA':qf,'fieldVA':value,'fieldRA':rf})
            rem=A(M(D,rf),d);eqn=Q(x,m.whole(M(D,P),B,qf,value,rem))
            nd.unpack(rc,[eqn,L(rem,M(D,P))]);rc.both(L(qf,A(y,O)),L(y,A(x,O)))
            invoke(rc,'skelet17-binary-le-lt-trans',{'t':qf,'u':y,'v':A(x,O)})
            m.bex_intro(rc,fr,M(D,P),Q(x,m.whole(M(D,P),B,qf,value,fr)),rem)
            return m.bex_intro(rc,fq,A(x,O),nd.BEX(fr,M(D,P),Q(x,m.whole(M(D,P),B,fq,value,fr))),qf)
        return m.bex_elim(qc,fr,P,Q(y,m.whole(P,B,qf,value,fr)),rf,goal,haver)
    m.bex_elim(ctx,fq,A(y,O),nd.BEX(fr,P,Q(y,m.whole(P,B,fq,value,fr))),qf,goal,haveq)
    finish('skelet17-packet-field-append',root,prem,goal,ctx,
           'Shift a bounded field predicate while preserving the bounds on its existential witnesses. No induction.')
field_append()

def field_low():
    fs=[L(Z,B),Q(x,A(M(B,y),value)),L(value,B)]
    prem=nd.AND(fs);goal=FIELD(x,O,B,value);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    ctx.both(fs[0],fs[1]);invoke(ctx,'skelet17-packet-prefix-bound',{'annRadix':B,'annLow':value})
    bound(ctx,Z,O,Z);eq(ctx,x,m.whole(O,B,y,value,Z),[fs[1]])
    m.bex_intro(ctx,fr,O,Q(x,m.whole(O,B,y,value,fr)),Z)
    m.bex_intro(ctx,fq,A(x,O),nd.BEX(fr,O,Q(x,m.whole(O,B,fq,value,fr))),y)
    finish('skelet17-packet-low-field',root,prem,goal,ctx)
field_low()

def field_small():
    prem=L(x,P);goal=FIELD(x,P,B,Z);root=nd.Ctx();ctx=root.push(prem)
    bound(ctx,Z,A(x,O),x);eq(ctx,x,m.whole(P,B,Z,Z,x))
    m.bex_intro(ctx,fr,P,Q(x,m.whole(P,B,Z,Z,fr)),x)
    m.bex_intro(ctx,fq,A(x,O),nd.BEX(fr,P,Q(x,m.whole(P,B,fq,Z,fr))),Z)
    finish('skelet17-packet-small-field',root,prem,goal,ctx)
field_small()

def half_order():
    h=prev
    fs=[Q(x,A(M(two,y),d)),L(d,two),L(M(two,h),A(x,O))]
    prem=nd.AND(fs);goal=L(h,A(y,O));root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    tri=[L(h,y),Q(h,y),L(y,h)];ctx.put(nd.OR(tri),b.ax('O3',ctx.g,t=h,u=y))
    def branch(ec,k):
        if k==0:
            m.successor(ec,y);return m.translt(ec,h,y,A(y,O))
        if k==1:
            m.successor(ec,y);return rewrite(ec,L(a.E,A(y,O)),y,h,ec.get(flip(ec,Q(h,y))))
        def havegap(gc,geq):
            invoke(gc,'skelet17-binary-digit-cases',{'t':d})
            def bitcase(bc,j):
                w=A(M(two,agap),O) if j==0 else M(two,agap)
                bound(bc,x,M(two,h),w,[fs[0],geq,Q(d,Z if j==0 else O)])
                invoke(bc,'skelet17-binary-below-successor',{'t':M(two,h),'u':x})
                def ordercase(cc,l):
                    if l==0:m.translt(cc,x,M(two,h),x)
                    else:rewrite(cc,L(x,a.E),M(two,h),x)
                    bad=L(x,x);cc.put(b.Not(bad),b.ax('O1',cc.g,t=x));return cc.explode(bad,goal)
                return nd.cases(bc,[L(M(two,h),x),Q(M(two,h),x)],goal,ordercase)
            return nd.cases(gc,[Q(d,Z),Q(d,O)],goal,bitcase)
        return m.gap_elim(ec,y,h,agap,goal,havegap)
    nd.cases(ctx,tri,goal,branch)
    finish('skelet17-packet-half-order',root,prem,goal,ctx,
           'A binary place below the new input halves to a place below its prefix. No induction.')
half_order()

def local_intro(ctx,x,S,p,aa,bb,cc):
    nd.conj(ctx,list_body(x,S,p,aa,bb,cc))
    m.bex_intro(ctx,cv,eight,BODY(x,S,p,aa,bb,cv),cc)
    m.bex_intro(ctx,bv,two,nd.BEX(cv,eight,BODY(x,S,p,aa,bv,cv)),bb)
    return m.bex_intro(ctx,av,eight,nd.BEX(bv,two,nd.BEX(cv,eight,BODY(x,S,p,av,bv,cv))),aa)
def list_body(x,S,p,aa,bb,cc):
    return [FIELD(S,power5(M(two,p)),eight,aa),FIELD(x,p,two,bb),FIELD(S,power5(p),eight,cc),DELTA(aa,bb,cc)]

def run_base():
    root=nd.Ctx();guard=L(pf,A(Z,O));gc=root.push(guard);pc=gc.push(m.power2(pf));goal=LOCAL(Z,Z,pf)
    nd.unpack(pc,list(m.power2(pf)[1:]));invoke(pc,'skelet17-binary-below-successor',{'t':pf,'u':Z})
    def branch(ec,k):
        if k==0:
            ec.put(b.Not(L(pf,Z)),b.ax('O4',ec.g,t=pf));return ec.explode(L(pf,Z),goal)
        rewrite(ec,L(Z,a.E),pf,Z);ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z));return ec.explode(L(Z,Z),goal)
    nd.cases(pc,[L(pf,Z),Q(pf,Z)],goal,branch)
    gc.intro(m.power2(pf),goal,pc);root.intro(guard,b.Imp(m.power2(pf),goal),gc)
    root.all_intro(pf,b.Imp(guard,b.Imp(m.power2(pf),goal)))
    m.rename_all(root,pf,place,lambda p:b.Imp(L(p,A(Z,O)),b.Imp(m.power2(p),LOCAL(Z,Z,p))))
    save('skelet17-packet-empty',root,RUN(Z,Z))
run_base()

def transfer_field(ctx,new,old,low,radix,scale,base,val):
    fs=[L(Z,radix),Q(new,A(M(radix,old),low)),L(low,radix),FIELD(old,scale,base,val)]
    nd.conj(ctx,fs);return invoke(ctx,'skelet17-packet-field-append',{
        'annInput':new,'annPrefix':old,'annLow':low,'annRadix':radix,
        'annScale':scale,'annBase':base,'annValue':val})
def low_field(ctx,new,old,base,val):
    fs=[L(Z,base),Q(new,A(M(base,old),val)),L(val,base)]
    nd.conj(ctx,fs);return invoke(ctx,'skelet17-packet-low-field',{
        'annInput':new,'annPrefix':old,'annBase':base,'annValue':val})
def scale_field(ctx,input,oldscale,newscale,base,val,fs=()):
    eq(ctx,oldscale,newscale,fs);return rewrite(ctx,FIELD(input,a.E,base,val),oldscale,newscale)

def run_append():
    fs=[RUN(y,t),Q(x,A(M(two,y),d)),L(d,two),Q(s,A(M(eight,t),c)),L(c,eight),L(prev,eight),FIELD(t,O,eight,prev),DELTA(prev,d,c)]
    prem=nd.AND(fs);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    bound(ctx,Z,two,O);bound(ctx,Z,eight,a.num(31))
    guard=L(pf,A(x,O));gc=ctx.push(guard);pc=gc.push(m.power2(pf));goal=LOCAL(x,s,pf)
    invoke(pc,'skelet17-binary-power-halving',{'t':pf})
    half=nd.BEX(m.pz,A(pf,O),b.And(Q(pf,M(two,m.pz)),m.power2(m.pz)))
    def branch(ec,k):
        if k==0:
            low_field(ec,x,y,two,d);low_field(ec,s,t,eight,c)
            transfer_field(ec,s,t,c,eight,O,eight,prev)
            scale_field(ec,s,M(eight,O),power5(M(two,O)),eight,prev)
            scale_field(ec,s,O,power5(O),eight,c)
            local_intro(ec,x,s,O,prev,d,c)
            return rewrite(ec,LOCAL(x,s,a.E),O,pf,ec.get(flip(ec,Q(pf,O))))
        def havehalf(hc):
            p_eq=Q(pf,M(two,hf));nd.unpack(hc,[p_eq,m.power2(hf)])
            rewrite(hc,L(a.E,A(x,O)),pf,M(two,hf))
            nd.conj(hc,[fs[1],fs[2],L(M(two,hf),A(x,O))])
            invoke(hc,'skelet17-packet-half-order',{'annPrevious':hf})
            _,rp=hc.all_elim(place,RUN(y,t)[2],hf)
            inner=b.Imp(m.power2(hf),LOCAL(y,t,hf));hc.mp(L(hf,A(y,O)),inner,rp);hc.mp(m.power2(hf),LOCAL(y,t,hf))
            def before(ac):
                def bit(bc):
                    def after(cc):
                        nd.unpack(cc,list_body(y,t,hf,af,bf,cf))
                        transfer_field(cc,x,y,d,two,hf,two,bf)
                        scale_field(cc,x,M(two,hf),pf,two,bf,[p_eq])
                        transfer_field(cc,s,t,c,eight,power5(hf),eight,cf)
                        scale_field(cc,s,M(eight,power5(hf)),power5(pf),eight,cf,[p_eq])
                        transfer_field(cc,s,t,c,eight,power5(M(two,hf)),eight,af)
                        scale_field(cc,s,M(eight,power5(M(two,hf))),power5(M(two,pf)),eight,af,[p_eq])
                        return local_intro(cc,x,s,pf,af,bf,cf)
                    return m.bex_elim(bc,cv,eight,BODY(y,t,hf,af,bf,cv),cf,goal,after)
                return m.bex_elim(ac,bv,two,nd.BEX(cv,eight,BODY(y,t,hf,af,bv,cv)),bf,goal,bit)
            return m.bex_elim(hc,av,eight,nd.BEX(bv,two,nd.BEX(cv,eight,BODY(y,t,hf,av,bv,cv))),af,goal,before)
        return m.bex_elim(ec,m.pz,A(pf,O),b.And(Q(pf,M(two,m.pz)),m.power2(m.pz)),hf,goal,havehalf)
    nd.cases(pc,[Q(pf,O),half],goal,branch)
    gc.intro(m.power2(pf),goal,pc);ctx.intro(guard,b.Imp(m.power2(pf),goal),gc)
    ctx.all_intro(pf,b.Imp(guard,b.Imp(m.power2(pf),goal)))
    m.rename_all(ctx,pf,place,lambda p:b.Imp(L(p,A(x,O)),b.Imp(m.power2(p),LOCAL(x,s,p))))
    finish('skelet17-packet-append-local',root,prem,RUN(x,s),ctx,
           'Appending an input bit and a supplied valid next control state preserves every local annotation condition. No induction. No complete certificate-existence claim.')
run_append()

def finite_cases(ctx,val,n,goal,callback):
    """Unroll a fixed finite bound. This is a proof generator, not induction."""
    top=a.num(n);below=a.num(n-1)
    if n==1:
        eq(ctx,O,A(Z,O));rewrite(ctx,L(val,a.E),O,A(Z,O))
    invoke(ctx,'skelet17-binary-below-successor',{'t':val,'u':below})
    def branch(ec,k):
        if k==1:return callback(ec,n-1)
        if n>1:return finite_cases(ec,val,n-1,goal,callback)
        ec.put(b.Not(L(val,Z)),b.ax('O4',ec.g,t=val));return ec.explode(L(val,Z),goal)
    return nd.cases(ctx,[L(val,below),Q(val,below)],goal,branch)

def table_total():
    prem=b.And(L(prev,eight),L(d,two));goal=nd.BEX(cv,eight,DELTA(prev,d,cv))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,list(prem[1:]))
    def state(ec,i):
        def bit(bc,j):
            out=a.num(TABLE[i][j]);bc.put(Q(out,out),b.refl(bc.g,out))
            parts=[nd.AND([Q(prev,a.num(k)),Q(d,a.num(l)),Q(out,a.num(TABLE[k][l]))]) for k in range(32) for l in range(2)]
            nd.conj(bc,[Q(prev,a.num(i)),Q(d,a.num(j)),Q(out,out)])
            nd.disj(bc,parts,2*i+j);bound(bc,out,eight,a.num(31-TABLE[i][j]))
            return m.bex_intro(bc,cv,eight,DELTA(prev,d,cv),out)
        invoke(ec,'skelet17-binary-digit-cases',{'t':d})
        return nd.cases(ec,[Q(d,Z),Q(d,O)],goal,bit)
    finite_cases(ctx,prev,32,goal,state)
    finish('skelet17-packet-table-total',root,prem,goal,ctx,
           'The fixed auxiliary table is total on 32 records and 2 inputs. 64 explicit cases, no induction. Invalid parser transitions were explicitly totalized to state 0.')
table_total()

def extend_exists():
    fs=[RUN(y,t),Q(x,A(M(two,y),d)),L(d,two)];prem=nd.AND(fs)
    goal=nd.BEX(choicevar,eight,RUN(x,A(M(eight,t),choicevar)))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    bound(ctx,Z,O,Z);bound(ctx,Z,eight,a.num(31));ctx.both(L(Z,O),L(Z,eight))
    invoke(ctx,'skelet17-packet-field-total',{'annInput':t,'annScale':O,'annBase':eight})
    def before(ec):
        ec.both(L(af,eight),L(d,two));invoke(ec,'skelet17-packet-table-total',{'annPrevious':af})
        def after(cc):
            new=A(M(eight,t),cf);eq(cc,new,new)
            fs2=[RUN(y,t),fs[1],fs[2],Q(new,new),L(cf,eight),L(af,eight),FIELD(t,O,eight,af),DELTA(af,d,cf)]
            nd.conj(cc,fs2);invoke(cc,'skelet17-packet-append-local',{'annStates':new,'annNext':cf,'annPrevious':af})
            return m.bex_intro(cc,choicevar,eight,RUN(x,A(M(eight,t),choicevar)),cf)
        return m.bex_elim(ec,cv,eight,DELTA(af,d,cv),cf,goal,after)
    m.bex_elim(ctx,av,eight,FIELD(t,O,eight,av),af,goal,before)
    finish('skelet17-packet-one-step-exists',root,prem,goal,ctx,
           'Every supplied local annotation extends to one more input bit, with a witnessed next state <8 and new code 32*oldcode+nextstate. Uses bounded division; no new induction construction.')
extend_exists()

def mult_lt(ctx,l,r,k):
    ante=b.And(L(l,r),L(Z,k));ctx.both(*ante[1:]);out=L(M(l,k),M(r,k))
    return ctx.put(out,b.mp(ctx.g,ante,out,b.ax('O6',ctx.g,t=l,u=r,v=k),ctx.get(ante)))
def posmul(ctx,l,r):
    mult_lt(ctx,Z,l,r);eq(ctx,M(Z,r),Z);return rewrite(ctx,L(a.E,M(l,r)),M(Z,r),Z)
def norm_lt(ctx,l,r,ll,rr,fs=()):
    eq(ctx,l,ll,fs);rewrite(ctx,L(a.E,r),l,ll)
    eq(ctx,r,rr,fs);return rewrite(ctx,L(ll,a.E),r,rr)
def cube_bound():
    fs=[L(Z,P),L(P,B)];prem=b.And(*fs);root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    m.translt(ctx,Z,P,B);bound(ctx,Z,O,Z)
    def prod(xs):
        out=O
        for f in xs:out=M(out,f)
        return out
    chain=[]
    for j in range(5):
        factors=[P]*(4-j)+[B]*j;k=O
        for f in factors:
            posmul(ctx,k,f);k=M(k,f)
        left=prod([P]*(5-j)+[B]*j);right=prod([P]*(4-j)+[B]*(j+1))
        mult_lt(ctx,P,B,k);norm_lt(ctx,M(P,k),M(B,k),left,right);chain.append((left,right))
    first=chain[0][0];current=chain[0][1]
    for left,right in chain[1:]:
        m.translt(ctx,first,current,right);current=right
    norm_lt(ctx,first,current,power5(P),power5(B))
    bound(ctx,Z,eight,a.num(31));mult_lt(ctx,power5(P),power5(B),eight)
    norm_lt(ctx,M(power5(P),eight),M(power5(B),eight),M(eight,power5(P)),M(eight,power5(B)))
    finish('skelet17-packet-power-bound',root,prem,L(M(eight,power5(P)),M(eight,power5(B))),ctx)

cube_bound()

def prefix_smaller():
    fs=[L(Z,x),Q(x,A(M(two,y),d))];prem=b.And(*fs);goal=L(y,x)
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    invoke(ctx,'skelet17-binary-zero-or-positive',{'t':y},False)
    def branch(ec,k):
        if k==0:return rewrite(ec,L(a.E,x),Z,y,ec.get(flip(ec,Q(y,Z))))
        def havegap(gc,geq):return bound(gc,y,x,A(agap,d),[fs[1],geq])
        return m.gap_elim(ec,Z,y,agap,goal,havegap)
    nd.cases(ctx,[Q(y,Z),L(Z,y)],goal,branch)
    finish('skelet17-packet-prefix-smaller',root,prem,goal,ctx)
prefix_smaller()

def double_place_bound():
    fs=[L(P,A(y,O)),Q(x,A(M(two,y),d))];prem=b.And(*fs);goal=L(M(two,P),A(x,O))
    root=nd.Ctx();ctx=root.push(prem);nd.unpack(ctx,fs)
    invoke(ctx,'skelet17-binary-below-successor',{'t':P,'u':y});bound(ctx,Z,two,O)
    def branch(ec,k):
        if k==1:return bound(ec,M(two,P),A(x,O),d,[fs[1],Q(P,y)])
        mult_lt(ec,P,y,two);norm_lt(ec,M(P,two),M(y,two),M(two,P),M(two,y))
        bound(ec,M(two,y),A(x,O),d,[fs[1]])
        return m.translt(ec,M(two,P),M(two,y),A(x,O))
    nd.cases(ctx,[L(P,y),Q(P,y)],goal,branch)
    finish('skelet17-packet-double-place-bound',root,prem,goal,ctx)
double_place_bound()

lead=declare('annLeading');strong=declare('annStrongIndex');index=declare('annIndIndex')
zf=declare('annStrongFresh');yy=declare('annPrefixWitness');dd=declare('annBitWitness')
lp=declare('annLeadingWitness');st=declare('annCodeWitness');chv=declare('annChoiceWitness')
def K(n):return M(eight,power5(A(n,O)))
def CERT_BODY(n,p,S):return nd.AND([m.power2(p),L(n,M(two,p)),L(S,M(eight,power5(p))),RUN(n,S)])
def POSCERT(n):return nd.BEX(lead,A(n,O),nd.BEX(codevar,K(n),CERT_BODY(n,lead,codevar)))
def CERT(n):return b.Or(Q(n,Z),POSCERT(n))
def cert_intro(ctx,n,p,S):
    nd.conj(ctx,[m.power2(p),L(n,M(two,p)),L(S,M(eight,power5(p))),RUN(n,S)])
    m.bex_intro(ctx,codevar,K(n),CERT_BODY(n,p,codevar),S)
    m.bex_intro(ctx,lead,A(n,O),nd.BEX(codevar,K(n),CERT_BODY(n,lead,codevar)),p)
    return nd.disj(ctx,list(CERT(n)[1:]),1)
def cert_one():
    root=nd.Ctx();four=a.num(4);bound(root,Z,O,Z);bound(root,Z,two,O);bound(root,Z,eight,a.num(31));bound(root,O,two,Z);bound(root,four,eight,a.num(27))
    invoke(root,'skelet17-packet-empty',{},False)
    invoke(root,'skelet17-packet-small-field',{'annInput':Z,'annScale':O,'annBase':eight})
    parts=[nd.AND([Q(Z,a.num(i)),Q(O,a.num(j)),Q(four,a.num(TABLE[i][j]))]) for i in range(32) for j in range(2)]
    for v in [Z,O,four]:root.put(Q(v,v),b.refl(N,v))
    nd.conj(root,[Q(Z,Z),Q(O,O),Q(four,four)]);nd.disj(root,parts,1)
    eq(root,O,A(M(two,Z),O));eq(root,four,A(M(eight,Z),four))
    fs=[RUN(Z,Z),Q(O,A(M(two,Z),O)),L(O,two),Q(four,A(M(eight,Z),four)),L(four,eight),L(Z,eight),FIELD(Z,O,eight,Z),DELTA(Z,O,four)]
    nd.conj(root,fs);invoke(root,'skelet17-packet-append-local',{'annInput':O,'annPrefix':Z,'annStates':four,'annOldStates':Z,'annLow':O,'annNext':four,'annPrevious':Z})
    invoke(root,'skelet17-binary-power-one',{},False)
    eq(root,eight,M(eight,power5(O)));rewrite(root,L(four,a.E),eight,M(eight,power5(O)))
    root.both(L(Z,O),L(O,A(O,O)));invoke(root,'skelet17-packet-power-bound',{'annScale':O,'annBase':A(O,O)})
    m.translt(root,four,M(eight,power5(O)),K(O))
    eq(root,two,M(two,O));rewrite(root,L(O,a.E),two,M(two,O))
    cert_intro(root,O,O,four);save('skelet17-packet-certificate-one',root,CERT(O))
cert_one()

def PHI(i):return nd.BALL(strong,A(i,O),CERT(strong))
def next_certificate(ctx,X):
    """Build CERT(X) from the current bounded strong-induction hypothesis."""
    goal=CERT(X);bound(ctx,Z,X,index);bound(ctx,Z,two,O);bound(ctx,Z,eight,a.num(31))
    invoke(ctx,'skelet17-bounded-division-exists',{'t':X,'u':two})
    def prefix(qc):
        def bit(rc):
            xe=Q(X,A(M(two,yy),dd));rc.both(L(Z,X),xe)
            invoke(rc,'skelet17-packet-prefix-smaller',{'annInput':X,'annPrefix':yy,'annLow':dd})
            _,ip=rc.all_elim(strong,PHI(index)[2],yy);rc.mp(L(yy,X),CERT(yy),ip)
            def source(ec,k):
                if k==0:
                    invoke(ec,'skelet17-binary-digit-cases',{'t':dd})
                    def small(cc,j):
                        eq(cc,X,Z if j==0 else O,[xe,Q(yy,Z),Q(dd,Z if j==0 else O)])
                        if j==0:
                            rewrite(cc,L(Z,a.E),X,Z);cc.put(b.Not(L(Z,Z)),b.ax('O1',cc.g,t=Z));return cc.explode(L(Z,Z),goal)
                        invoke(cc,'skelet17-packet-certificate-one',{},False)
                        return rewrite(cc,CERT(a.E),O,X,cc.get(flip(cc,Q(X,O))))
                    return nd.cases(ec,[Q(dd,Z),Q(dd,O)],goal,small)
                def haveplace(pc):
                    def havecode(sc):
                        fields=[m.power2(lp),L(yy,M(two,lp)),L(st,M(eight,power5(lp))),RUN(yy,st)]
                        nd.unpack(sc,fields);nd.conj(sc,[RUN(yy,st),xe,L(dd,two)])
                        invoke(sc,'skelet17-packet-one-step-exists',{'annInput':X,'annPrefix':yy,'annOldStates':st,'annLow':dd})
                        def havechoice(cc):
                            newp=M(two,lp);news=A(M(eight,st),chv)
                            invoke(cc,'skelet17-binary-power-double',{'t':lp});nd.unpack(cc,list(m.power2(newp)[1:]))
                            cc.both(L(lp,A(yy,O)),xe)
                            invoke(cc,'skelet17-packet-double-place-bound',{'annInput':X,'annPrefix':yy,'annLow':dd,'annScale':lp})
                            cc.both(L(yy,M(two,lp)),L(dd,two))
                            invoke(cc,'skelet17-binary-field-range',{'t':yy,'u':dd,'v':two,'w':M(two,lp)})
                            norm_lt(cc,A(M(two,yy),dd),M(two,newp),X,M(two,newp),[xe])
                            cc.both(L(st,M(eight,power5(lp))),L(chv,eight))
                            invoke(cc,'skelet17-binary-field-range',{'t':st,'u':chv,'v':eight,'w':M(eight,power5(lp))})
                            norm_lt(cc,news,M(eight,M(eight,power5(lp))),news,M(eight,power5(newp)))
                            cc.both(L(Z,newp),L(newp,A(X,O)))
                            invoke(cc,'skelet17-packet-power-bound',{'annScale':newp,'annBase':A(X,O)})
                            m.translt(cc,news,M(eight,power5(newp)),K(X))
                            return cert_intro(cc,X,newp,news)
                        return m.bex_elim(sc,choicevar,eight,RUN(X,A(M(eight,st),choicevar)),chv,goal,havechoice)
                    return m.bex_elim(pc,codevar,K(yy),CERT_BODY(yy,lp,codevar),st,goal,havecode)
                return m.bex_elim(ec,lead,A(yy,O),nd.BEX(codevar,K(yy),CERT_BODY(yy,lead,codevar)),lp,goal,haveplace)
            return nd.cases(rc,[Q(yy,Z),POSCERT(yy)],goal,source)
        return m.bex_elim(qc,m.r,two,Q(X,A(M(two,yy),m.r)),dd,goal,bit)
    return m.bex_elim(ctx,m.q,A(X,O),nd.BEX(m.r,two,Q(X,A(M(two,m.q),m.r))),yy,goal,prefix)

def all_certificates():
    root=nd.Ctx();phi=PHI(index);base=PHI(Z)
    guard=L(zf,A(Z,O));bc=root.push(guard);invoke(bc,'skelet17-binary-below-successor',{'t':zf,'u':Z})
    def basecase(ec,k):
        if k==1:return nd.disj(ec,list(CERT(zf)[1:]),0)
        ec.put(b.Not(L(zf,Z)),b.ax('O4',ec.g,t=zf));return ec.explode(L(zf,Z),CERT(zf))
    nd.cases(bc,[L(zf,Z),Q(zf,Z)],CERT(zf),basecase)
    root.intro(guard,CERT(zf),bc);root.all_intro(zf,b.Imp(guard,CERT(zf)))
    m.rename_all(root,zf,strong,lambda z:b.Imp(L(z,A(Z,O)),CERT(z)))
    sc=root.push(phi);X=A(index,O);s_guard=L(zf,A(X,O));gc=sc.push(s_guard)
    invoke(gc,'skelet17-binary-below-successor',{'t':zf,'u':X})
    def successor(ec,k):
        if k==0:
            _,ip=ec.all_elim(strong,phi[2],zf);return ec.mp(L(zf,X),CERT(zf),ip)
        next_certificate(ec,X)
        return rewrite(ec,CERT(a.E),X,zf,ec.get(flip(ec,Q(zf,X))))
    nd.cases(gc,[L(zf,X),Q(zf,X)],CERT(zf),successor)
    sc.intro(s_guard,CERT(zf),gc);sc.all_intro(zf,b.Imp(s_guard,CERT(zf)))
    m.rename_all(sc,zf,strong,lambda z:b.Imp(L(z,A(X,O)),CERT(z)))
    out=PHI(X);root.intro(phi,out,sc);step=b.All(index,b.Imp(phi,out));root.all_intro(index,b.Imp(phi,out))
    m.induction(root,index,phi,base,step);root.all_elim(index,phi,x)
    m.successor(root,x);_,ip=root.all_elim(strong,PHI(x)[2],x);root.mp(L(x,A(x,O)),CERT(x),ip)
    save('skelet17-packet-certificate-exists',root,CERT(x),
         'Every positive binary input has a complete locally checked control annotation, bounded by 32*(x+1)^5 with a leading-place witness. One additional bounded strong-induction construction. No output-count or compressed-Gray correctness claim.')
all_certificates()

def positive_certificate():
    prem=L(Z,x);goal=POSCERT(x);root=nd.Ctx();ctx=root.push(prem)
    invoke(ctx,'skelet17-packet-certificate-exists',{},False)
    def branch(ec,k):
        if k==1:return ec.get(goal)
        rewrite(ec,L(Z,a.E),x,Z);ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z));return ec.explode(L(Z,Z),goal)
    nd.cases(ctx,[Q(x,Z),goal],goal,branch)
    finish('skelet17-packet-positive-certificate',root,prem,goal,ctx)
positive_certificate()

def initial_control_zero():
    fs=[L(s,M(eight,power5(P)))];prem=fs[0];goal=FIELD(s,power5(M(two,P)),eight,Z)
    root=nd.Ctx();ctx=root.push(prem)
    eq(ctx,M(eight,power5(P)),power5(M(two,P)));rewrite(ctx,L(s,a.E),M(eight,power5(P)),power5(M(two,P)))
    invoke(ctx,'skelet17-packet-small-field',{'annInput':s,'annScale':power5(M(two,P)),'annBase':eight})
    finish('skelet17-packet-leading-control-zero',root,prem,goal,ctx,
           'The certificate size bound forces control 0 before the leading input place. No induction.')
initial_control_zero()

syntax=nd.classify(RUN(x,s))
b.lines.append('skelet17-packet-predicate-bounded $p bnd '+b.tok(RUN(x,s))+' $= '+' '.join(syntax.labels)+' $.')
syntax=nd.classify(CERT(x))
b.lines.append('skelet17-packet-certificate-bounded $p bnd '+b.tok(CERT(x))+' $= '+' '.join(syntax.labels)+' $.')

def write():
    (m.P/'packets_raw.mm').write_text('\n'.join(b.lines)+'\n')
    (m.P/'packet_theorems.json').write_text(json.dumps({k:b.tok(v) for k,v in m.theorems.items() if 'packet-' in k},indent=2)+'\n')
if __name__=='__main__':write()
