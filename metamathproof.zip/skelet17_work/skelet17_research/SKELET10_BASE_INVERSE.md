# Even-input carry inversion: current extension

Goal: J(2x,y) implies y=4x+1, for the unchanged bounded carry graph.
The proof generator is ladder_skelet10_sync_inverse.py. It is generated
from the canonical project by extend_skelet10_sync_inverse.py. The verified extension is now integrated into idelta0_machines.mm.
The full canonical file passes kernel verification. Rebuild-script integration and the dependency audit now pass. The
proof has one bounded-induction dependency: earlier bounded division.

Eliminate the bounded witnesses p,s,a. They satisfy Pow2(p), p=3s+1,
2x=p(2a)+s, and y=p(4a+1). Bounded division writes s=2q+d, d<2.

If d=1, the input equation reads 2x=2(pa+q)+1. Quotient/remainder
uniqueness contradicts 0=1. Thus d=0.

Now p=6q+1 is odd. Rewrite its Pow2 predicate and apply the earlier
odd-power theorem: 3q=0. Quotient uniqueness at modulus 3 gives q=0;
then s=0 and p=1. The input equation reduces to 2x=2a, so quotient
uniqueness at modulus 2 gives x=a. Substitute into the output equation.

The only induction dependency expected is the existing bounded division
proof. No new induction construction, machine instruction or axiom is
added. Kernel verification status is recorded in inverse_carry_verification.log.
The separate inverse_carry_check.mm is a temporary dependency extraction
for checking this extension; it is not a second active proof project.

The odd-input inverse rule is now proved; see SKELET10_ODD_INVERSE.md.
Carry uniqueness, global synchronization and whole-machine nonhalting
remain unfinished. The canonical checkpoint's
prior 245 interfaces remain unchanged during this development.
