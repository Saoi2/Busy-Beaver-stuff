"""Lift the complete right-counter rank through unchanged raw beta histories."""
def add_skelet10_right_history(m,api,right,ret,proofs=True):
 nd,b,a=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O;use=m.invoke
 cf,nf=api['current'],api['next'];step=api['step']
 rank,endpoint,entry=right['rank'],right['endpoint'],right['entry'];outscale=right['outscale']
 def finish(name,root,prem,goal,c,comment):m.finish('skelet17-ladder-skelet10-'+name,root,prem,goal,c,comment)
 if proofs:
  if 'z10-return-clock-step' not in m.theorems:ret['clock_step']()
  if 'z10-return-clock-positive' not in m.theorems:ret['clock_end']()
 H,n,offset=[m.declare('rightRun'+s,'term') for s in ('H','N','Offset')]
 P=right['initial_rank']
 Bj=[m.declare('rightRunB'+str(j),'term') for j in range(4)];Cj=[m.declare('rightRunC'+str(j),'term') for j in range(4)]
 i,ti,si,avoid_i=[m.declare('rightRun'+s) for s in ('Index','TotalIndex','StepIndex','AvoidIndex')]
 quo=m.declare('rightRunBetaQuotient')
 IP=[m.declare('rightRunIndRow'+s) for s in ('Q','L','Bit','R')]
 IV=[m.declare('rightRunInitialRow'+s) for s in ('Q','L','Bit','R')]
 TV=[m.declare('rightRunTotalRow'+s) for s in ('Q','L','Bit','R')]
 SV=[m.declare('rightRunStepRow'+str(j)+s) for j in (0,1) for s in ('Q','L','Bit','R')]
 EV=[m.declare('rightRunAvoidRow'+s) for s in ('Q','L','Bit','R')]
 CR=[m.declare('rightRunCurrentRow'+s) for s in ('Q','L','Bit','R')]
 NR=[m.declare('rightRunNextRow'+s) for s in ('Q','L','Bit','R')]
 last=[m.declare('rightRunLastRow'+s) for s in ('Q','L','Bit','R')]
 scale=m.declare('rightRunHistoryScale');freshscale=m.declare('rightRunFreshScale');nextscale=m.declare('rightRunFreshNextScale')
 def beta(index,v,j):
  mod=A(O,M(A(index,O),Cj[j]));return nd.BEX(quo,H,b.And(Q(Bj[j],A(M(quo,mod),v)),L(v,mod)))
 def AT(index,row):return nd.AND([beta(A(offset,index),v,j) for j,v in enumerate(row)])
 total=nd.BALL(ti,A(n,O),nd.bexs(TV,H,AT(ti,TV)))
 initial=nd.balls(IV,H,b.Imp(AT(Z,IV),entry(IV)))
 steps=nd.BALL(si,n,nd.balls(SV,H,b.Imp(b.And(AT(si,SV[:4]),AT(A(si,O),SV[4:])),step(SV[:4],SV[4:]))))
 avoid=nd.BALL(avoid_i,A(n,O),nd.balls(EV,H,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV)))))
 def inv(index,row):return nd.BEX(scale,A(P,O),b.And(rank(row,scale),L(A(index,scale),A(P,O))))
 def phi(index):return b.Imp(L(index,A(n,O)),nd.balls(IP,H,b.Imp(AT(index,IP),inv(index,IP))))
 def bforall(ctx,vs,body,prove):
  if not vs:return ctx.put(body,prove(ctx))
  v=vs[0];ch=ctx.push(L(v,H));inner=nd.balls(vs[1:],H,body)
  bforall(ch,vs[1:],body,prove);ctx.intro(L(v,H),inner,ch);return ctx.all_intro(v,b.Imp(L(v,H),inner))
 def eliminate(ctx,vs,body,freshs,goal,prove):
  if not vs:return ctx.put(goal,prove(ctx))
  v,fresh=vs[0],freshs[0];rest=nd.bexs(vs[1:],H,body);full=b.And(L(v,H),rest)
  actual,_=b.subst(full,v,fresh,True);ch=ctx.push(actual);nd.unpack(ch,list(actual[1:]));newbody,_=b.subst(body,v,fresh,True)
  eliminate(ch,vs[1:],newbody,freshs[1:],goal,prove);return ctx.ex_elim(v,full,fresh,goal,ch)
 def rename(ctx,old,new,body):
  before=nd.balls(old,H,body(old));after=nd.balls(new,H,body(new));root=nd.Ctx();c=root.push(before)
  bforall(c,new,body(new),lambda cc:nd.inst_balls(cc,old,H,body(old),new)[1]);root.intro(before,after,c)
  ctx.theorem(b.Imp(before,after),root.get(b.Imp(before,after)));return ctx.mp(before,after)
 def inst_avoid(ctx,index,row):
  body=avoid[2];ctx.all_elim(avoid_i,body,index);inner=nd.balls(EV,H,b.Imp(AT(index,EV),b.Not(endpoint(EV))))
  ctx.mp(L(index,A(n,O)),inner);nd.inst_balls(ctx,EV,H,b.Imp(AT(index,EV),b.Not(endpoint(EV))),row)
  return ctx.mp(AT(index,row),b.Not(endpoint(row)))
 def history():
  fields=[total,initial,steps,avoid];prem=nd.AND(fields);root=nd.Ctx();c=root.push(prem);nd.unpack(c,fields)
  baseguard=L(Z,A(n,O));bc=c.push(baseguard)
  def base(cc):
   ac=cc.push(AT(Z,NR));nd.inst_balls(ac,IV,H,b.Imp(AT(Z,IV),entry(IV)),NR);ac.mp(AT(Z,NR),entry(NR))
   use(ac,'skelet17-ladder-skelet10-right-counter-entry',{v[1]:x for v,x in zip(cf,NR)})
   m.successor(ac,P);m.eq(ac,A(Z,P),P);m.rewrite(ac,L(a.E,A(P,O)),P,A(Z,P),a.sym(A(Z,P),P,ac.get(Q(A(Z,P),P)),ac.g))
   ac.both(rank(NR,P),L(A(Z,P),A(P,O)));m.bex_intro(ac,scale,A(P,O),b.And(rank(NR,scale),L(A(Z,scale),A(P,O))),P)
   cc.intro(AT(Z,NR),inv(Z,NR),ac);return cc.get(b.Imp(AT(Z,NR),inv(Z,NR)))
  bforall(bc,NR,b.Imp(AT(Z,NR),inv(Z,NR)),base);rename(bc,NR,IP,lambda row:b.Imp(AT(Z,row),inv(Z,row)))
  c.intro(baseguard,nd.balls(IP,H,b.Imp(AT(Z,IP),inv(Z,IP))),bc)
  sc=c.push(phi(i));guard=L(A(i,O),A(n,O));gc=sc.push(guard)
  use(gc,'skelet17-ladder-lt-add-cancel',{'t':i,'u':n,'v':O});m.successor(gc,n);m.translt(gc,i,n,A(n,O))
  def successor(cc):
   atnext=AT(A(i,O),NR);goal=inv(A(i,O),NR);ac=cc.push(atnext)
   ac.all_elim(ti,total[2],i);ac.mp(L(i,A(n,O)),nd.bexs(TV,H,AT(i,TV)))
   def current(pc):
    pc.mp(L(i,A(n,O)),nd.balls(IP,H,b.Imp(AT(i,IP),inv(i,IP))));nd.inst_balls(pc,IP,H,b.Imp(AT(i,IP),inv(i,IP)),CR);pc.mp(AT(i,CR),inv(i,CR))
    inst_avoid(pc,i,CR)
    pc.all_elim(si,steps[2],i);inner=nd.balls(SV,H,b.Imp(b.And(AT(i,SV[:4]),AT(A(i,O),SV[4:])),step(SV[:4],SV[4:])))
    pc.mp(L(i,n),inner);nd.inst_balls(pc,SV,H,b.Imp(b.And(AT(i,SV[:4]),AT(A(i,O),SV[4:])),step(SV[:4],SV[4:])),CR+NR)
    pc.both(AT(i,CR),atnext);pc.mp(b.And(AT(i,CR),atnext),step(CR,NR))
    def current_scale(dc):
     nd.unpack(dc,[rank(CR,freshscale),L(A(i,freshscale),A(P,O))])
     nd.conj(dc,[rank(CR,freshscale),b.Not(endpoint(CR)),step(CR,NR)])
     mapping={'t':freshscale,**{v[1]:x for v,x in zip(cf,CR)},**{v[1]:x for v,x in zip(nf,NR)}}
     use(dc,'skelet17-ladder-skelet10-right-counter-step',mapping)
     def next_scale(ec):
      ec.both(L(nextscale,freshscale),L(freshscale,A(P,O)));m.translt(ec,nextscale,freshscale,A(P,O))
      ec.both(L(nextscale,freshscale),L(A(i,freshscale),A(P,O)))
      use(ec,'z10-return-clock-step',{'t':i,'u':freshscale,'v':nextscale,'w':P})
      ec.both(rank(NR,nextscale),L(A(A(i,O),nextscale),A(P,O)))
      return m.bex_intro(ec,scale,A(P,O),b.And(rank(NR,scale),L(A(A(i,O),scale),A(P,O))),nextscale)
     return m.bex_elim(dc,outscale,freshscale,rank(NR,outscale),nextscale,goal,next_scale)
    return m.bex_elim(pc,scale,A(P,O),b.And(rank(CR,scale),L(A(i,scale),A(P,O))),freshscale,goal,current_scale)
   eliminate(ac,TV,AT(i,TV),CR,goal,current);cc.intro(atnext,goal,ac);return cc.get(b.Imp(atnext,goal))
  bforall(gc,NR,b.Imp(AT(A(i,O),NR),inv(A(i,O),NR)),successor)
  rename(gc,NR,IP,lambda row:b.Imp(AT(A(i,O),row),inv(A(i,O),row)))
  sc.intro(guard,nd.balls(IP,H,b.Imp(AT(A(i,O),IP),inv(A(i,O),IP))),gc)
  c.intro(phi(i),phi(A(i,O)),sc);c.all_intro(i,b.Imp(phi(i),phi(A(i,O))))
  m.induction(c,i,phi(i),phi(Z),b.All(i,b.Imp(phi(i),phi(A(i,O)))))
  finish('right-window-invariant',root,prem,b.All(i,phi(i)),c,
   'Construct bounded phases, carry witnesses and remaining rank at every row of a target-avoiding ordinary right-counter history. Exactly one bounded history induction.')
  root=nd.Ctx();c=root.push(prem);nd.unpack(c,fields)
  use(c,'skelet17-ladder-skelet10-right-window-invariant')
  c.all_elim(i,phi(i),n);m.successor(c,n);c.mp(L(n,A(n,O)),nd.balls(IP,H,b.Imp(AT(n,IP),inv(n,IP))))
  c.all_elim(ti,total[2],n);c.mp(L(n,A(n,O)),nd.bexs(TV,H,AT(n,TV)))
  def finalrow(cc):
   nd.inst_balls(cc,IP,H,b.Imp(AT(n,IP),inv(n,IP)),last);cc.mp(AT(n,last),inv(n,last))
   def finalscale(dc):
    nd.unpack(dc,[rank(last,freshscale),L(A(n,freshscale),A(P,O))]);use(dc,'z10-right-rank-positive',{'t':freshscale,**{v[1]:x for v,x in zip(cf,last)}})
    dc.both(L(Z,freshscale),L(A(n,freshscale),A(P,O)));return use(dc,'z10-return-clock-positive',{'t':n,'u':freshscale,'v':P})
   return m.bex_elim(cc,scale,A(P,O),b.And(rank(last,scale),L(A(n,scale),A(P,O))),freshscale,L(n,P),finalscale)
  eliminate(c,TV,AT(n,TV),last,L(n,P),finalrow)
  finish('right-window-bound',root,prem,L(n,P),c,'Any target-avoiding ordinary right-counter history has n<20w+18. One bounded history induction, no totality of history coding.')
 if proofs: history()
 exit_index=m.declare('rightRunExitIndex');exit_rows=[m.declare('rightRunExitRow'+s) for s in ('Q','L','Bit','R')]
 def has_exit():return nd.BEX(exit_index,A(n,O),nd.bexs(exit_rows,H,b.And(AT(exit_index,exit_rows),endpoint(exit_rows))))
 def pack_rows(c,vs,body,values):
  if not vs:return c.get(body)
  freshbody,_=b.subst(body,vs[0],values[0],True)
  pack_rows(c,vs[1:],freshbody,values[1:]);return m.bex_intro(c,vs[0],H,nd.bexs(vs[1:],H,body),values[0])
 def no_exit_avoid():
  goal=has_exit()
  root=nd.Ctx();nc=root.push(b.Not(goal));ic=nc.push(L(avoid_i,A(n,O)))
  def avoid_row(cc):
   at=AT(avoid_i,EV);ac=cc.push(at);ec=ac.push(endpoint(EV));ec.both(at,endpoint(EV))
   body=b.And(AT(avoid_i,exit_rows),endpoint(exit_rows));pack_rows(ec,exit_rows,body,EV)
   m.bex_intro(ec,exit_index,A(n,O),nd.bexs(exit_rows,H,b.And(AT(exit_index,exit_rows),endpoint(exit_rows))),avoid_i)
   ec.put(L(Z,Z),ec.explode(goal,L(Z,Z)));ec.put(b.Not(L(Z,Z)),b.ax('O1',ec.g,t=Z))
   ac.put(b.Not(endpoint(EV)),a.not_intro(ac.g,endpoint(EV),L(Z,Z),ec.get(L(Z,Z)),ec.get(b.Not(L(Z,Z)))))
   cc.intro(at,b.Not(endpoint(EV)),ac);return cc.get(b.Imp(at,b.Not(endpoint(EV))))
  bforall(ic,EV,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV))),avoid_row)
  nc.intro(L(avoid_i,A(n,O)),nd.balls(EV,H,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV)))),ic)
  nc.all_intro(avoid_i,b.Imp(L(avoid_i,A(n,O)),nd.balls(EV,H,b.Imp(AT(avoid_i,EV),b.Not(endpoint(EV))))))
  m.finish('z10-right-no-exit-avoid',root,b.Not(goal),avoid,nc,'Negating the bounded existential exit yields the unannotated target-avoidance premise. Pure first-order logic.')
 if proofs: no_exit_avoid()
 def exit_proof():
  fs=[total,initial,steps,L(P,A(n,O))];prem=nd.AND(fs);goal=has_exit();root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  nc=c.push(b.Not(goal));use(nc,'z10-right-no-exit-avoid')
  nd.conj(nc,[total,initial,steps,avoid]);use(nc,'skelet17-ladder-skelet10-right-window-bound')
  use(nc,'skelet17-binary-below-successor',{'t':P,'u':n})
  def impossible(cc,k):
   if k==0:m.translt(cc,n,P,n)
   else:m.rewrite(cc,L(n,a.E),P,n)
   return cc.get(L(n,n))
  nd.cases(nc,[L(P,n),Q(P,n)],L(n,n),impossible);nc.put(b.Not(L(n,n)),b.ax('O1',nc.g,t=n))
  c.put(b.Not(b.Not(goal)),a.not_intro(c.g,b.Not(goal),L(n,n),nc.get(L(n,n)),nc.get(b.Not(L(n,n)))))
  c.put(goal,b.apply('nd-dne',{'ga':c.g,'ph':goal},[c.get(b.Not(b.Not(goal)))]))
  finish('right-window-exit',root,prem,goal,c,'A supplied ordinary right-counter window of length at least 20w+18 visits a correct D output endpoint. Derived from the bounded return clock; no extra induction construction.')
 if proofs: exit_proof()

 haltrow=[m.declare('rightRunHalt'+s,'term') for s in ('Q','L','Bit','R')]
 def barrier_proof():
  fs=[total,initial,steps,*[L(x,H) for x in haltrow],AT(n,haltrow),Q(haltrow[0],a.num(5))]
  prem=nd.AND(fs);goal=has_exit();root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  nc=c.push(b.Not(goal));use(nc,'z10-right-no-exit-avoid');nd.conj(nc,[total,initial,steps,avoid])
  use(nc,'skelet17-ladder-skelet10-right-window-invariant')
  nc.all_elim(i,phi(i),n);m.successor(nc,n);nc.mp(L(n,A(n,O)),nd.balls(IP,H,b.Imp(AT(n,IP),inv(n,IP))))
  nd.inst_balls(nc,IP,H,b.Imp(AT(n,IP),inv(n,IP)),haltrow);nc.mp(AT(n,haltrow),inv(n,haltrow))
  def impossible(cc):
   nd.unpack(cc,[rank(haltrow,freshscale),L(A(n,freshscale),A(P,O))])
   use(cc,'z10-right-rank-safe',{'t':freshscale,**{v[1]:x for v,x in zip(cf,haltrow)}})
   return cc.explode(Q(haltrow[0],a.num(5)),L(Z,Z))
  m.bex_elim(nc,scale,A(P,O),b.And(rank(haltrow,scale),L(A(n,scale),A(P,O))),freshscale,L(Z,Z),impossible)
  nc.put(b.Not(L(Z,Z)),b.ax('O1',nc.g,t=Z))
  c.put(b.Not(b.Not(goal)),a.not_intro(c.g,b.Not(goal),L(Z,Z),nc.get(L(Z,Z)),nc.get(b.Not(L(Z,Z)))))
  c.put(goal,b.apply('nd-dne',{'ga':c.g,'ph':goal},[c.get(b.Not(b.Not(goal)))]))
  finish('right-window-halting-barrier',root,prem,goal,c,'Every supplied ordinary history from a right-counter entry to halt has visited its correct D output endpoint. Reuses the same single history induction.')
 if proofs: barrier_proof()

 return {'AT':AT,'total':total,'initial':initial,'steps':steps,'avoid':avoid,'has_exit':has_exit,'P':P,'H':H,'n':n,'offset':offset,'Bj':Bj,'Cj':Cj,'IP':IP,'IV':IV,'EV':EV,'TV':TV,'SV':SV,'haltrow':haltrow,'phi':phi,'inv':inv}
