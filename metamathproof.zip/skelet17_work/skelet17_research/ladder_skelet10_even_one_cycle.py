"""Complete n=8b+2 boundary composition in the unchanged supplied history."""
def add_skelet10_even_one_cycle(m,api,sp,right,left,h,assembly,bd,align,cycles,finite,proofs=True):
 nd,b,ar=m.nd,m.b,m.a;A,M,Q,L=m.A,m.M,m.Q,m.L;Z,O=m.Z,m.O
 H,N,o,k=[h[x] for x in ('H','n','offset','start')];AT=h['AT'];cf,nf=api['current'],api['next']
 two,three,four,eight,ten,sixteen=map(ar.num,(2,3,4,8,10,16));T=sp['transform'];J=right['carry'];sparse=api['sparse'];step=api['step']
 apply,unpack,collect,pack_rows,bounds=[assembly[x] for x in ('apply','unpack','collect','pack_rows','bounds')]
 advance,run_counter=cycles['advance'],cycles['run_counter'];n=cycles['input'];halt=assembly['halt'];prefix=finite['prefix']
 word=m.declare('oneCycleWord','term')
 half,vv,tt,xx,dd=[m.declare('oneCycle'+s) for s in ('Half','Carry','Tail','Quotient','Digit')]
 block=m.declare('blockTail');vbound=m.declare('syncOddOutput')
 actual=[[m.declare('oneCyclePrefix'+str(j)+s) for s in ('Q','L','Bit','R')] for j in range(1,5)]
 clear1=[m.declare('oneCycleClearFirst'+s) for s in ('Q','L','Bit','R')]
 clear2=[m.declare('oneCycleClearSecond'+s) for s in ('Q','L','Bit','R')]
 re=[m.declare('oneCycleRightEntry'+s) for s in ('Q','L','Bit','R')]
 outi,outr=cycles['output_index'],cycles['output_row']
 def wl(row):return A(M(two,row[1]),row[2])
 def wr(row):return A(M(two,row[3]),row[2])
 def push(x,d):return A(M(two,x),d)
 def prove():
  fs=[h['total'](o,N),h['steps'](o,N),*bounds(halt),AT(o,N,halt),Q(halt[0],ar.num(5)),*bounds(cf),L(k,A(N,O)),AT(o,k,cf),Q(cf[0],three),L(cf[2],two),sparse(n),sparse(cf[3]),bd['even'](n,cf),Q(n,A(M(eight,word),two))]
  prem=nd.AND(fs)
  def result(i,row):return nd.AND([L(k,i),AT(o,i,row),bd['boundary'](cf[3],row)])
  goal=nd.BEX(outi,A(N,O),nd.bexs(outr,H,result(outi,outr)));root=nd.Ctx();c=root.push(prem);nd.unpack(c,fs)
  ba=bd['ba'];oddhalf=A(M(four,word),O)
  def efields(a):return [Q(n,M(two,a)),T(a,wl(cf)),J(a,cf[3])]
  def have_half(hc):
   efs=efields(half);nd.unpack(hc,efs);m.bound(hc,Z,two,O)
   m.eq(hc,A(M(two,half),Z),A(M(two,oddhalf),Z),[m.flip(hc,efs[0]),fs[-1]])
   m.quotient_unique(hc,two,half,Z,oddhalf,Z)
   m.rewrite(hc,T(ar.E,wl(cf)),half,oddhalf);m.rewrite(hc,J(ar.E,cf[3]),half,oddhalf)
   m.rewrite(hc,sparse(ar.E),n,M(two,half),hc.get(efs[0]));m.eq(hc,M(two,half),push(half,Z))
   apply(hc,'skelet17-ladder-skelet10-sparse-pop',{'t':M(two,half),'u':half,'v':Z})
   m.rewrite(hc,sparse(ar.E),half,oddhalf);m.eq(hc,oddhalf,push(M(two,word),O));m.bound(hc,O,two,Z)
   apply(hc,'skelet17-ladder-skelet10-sparse-pop',{'t':oddhalf,'u':M(two,word),'v':O})
   m.eq(hc,M(two,word),push(word,Z));apply(hc,'skelet17-ladder-skelet10-sparse-pop',{'t':M(two,word),'u':word,'v':Z})
   apply(hc,'skelet17-ladder-skelet10-carry-prefix-inverse',{'t':word,'u':cf[3]})
   def have_carry(vc):
    r=cf[3];carrybody=b.And(Q(r,M(four,vv)),J(word,vv));unpack(vc,carrybody)
    apply(vc,'skelet17-ladder-skelet10-transform-decompose-10',{'t':word,'u':wl(cf)})
    def have_tail(tc):
     split=Q(wl(cf),A(M(sixteen,tt),ten));unpack(tc,b.And(split,T(word,tt)))
     leftvalue=A(M(eight,tt),ar.num(5));m.eq(tc,wl(cf),push(leftvalue,Z),[split]);m.quotient_unique(tc,two,cf[1],cf[2],leftvalue,Z)
     apply(tc,'skelet17-bounded-division-exists',{'t':tt,'u':two})
     def have_quotient(qc):
      def have_digit(dc):
       teq=Q(tt,push(xx,dd));r1=push(r,O);r2=push(r1,O);r3=push(r2,O)
       l1=A(M(four,tt),two);l2=push(tt,O)
       updates=[(6,l1,r,O),(5,l2,r1,Z),(6,tt,r2,O),(5,xx,r3,dd)]
       rows=[]
       for j,t,u,v in updates[:3]:
        sr,tr,_=finite['instructions']['instruction'](j,t,u,v)
        if not rows:rows.append(sr)
        rows.append(tr)
       m.eq(dc,cf[1],rows[0][1],[Q(cf[1],leftvalue)]);m.eq(dc,cf[3],rows[0][3])
       def completed(pc,pr,pi):
        m.rewrite(pc,L(ar.E,two),dd,pr[2],ar.sym(pr[2],dd,pc.get(Q(pr[2],dd)),pc.g))
        m.eq(pc,wl(pr),tt,[Q(pr[1],xx),Q(pr[2],dd),m.flip(pc,teq)])
        final_target=finite['instructions']['instruction'](*updates[-1])[1]
        m.eq(pc,pr[3],A(M(four,A(M(four,r),three)),three),[Q(pr[3],final_target[3])])
        m.rewrite(pc,T(word,ar.E),tt,wl(pr),ar.sym(wl(pr),tt,pc.get(Q(wl(pr),tt)),pc.g))
        leftparams={left['word'][1]:word,left['tail'][1]:A(M(four,r),three)};collect(pc,m.sub(left['entry'](pr),leftparams))
        def left_output(lc,li,lr):
         apply(lc,'skelet17-ladder-skelet10-left-output-identify',{'t':word,'v':vv,'w':A(M(four,r),three),**{v[1]:x for v,x in zip(cf,lr)}})
         m.eq(lc,wr(lr),push(push(r,O),O),[Q(wr(lr),A(M(four,r),three))])
         def first_clear(fc):
          apply(fc,'z10-align-a1',{'t':push(r,O),**{v[1]:x for v,x in zip(cf,lr)},**{v[1]:x for v,x in zip(nf,clear1)}})
          def second_clear(sc):
           apply(sc,'skelet17-ladder-skelet10-return-clear-two-step',{'t':r,**{v[1]:x for v,x in zip(cf,lr)},**{v[1]:x for v,x in zip(align['middle'],clear1)},**{v[1]:x for v,x in zip(nf,clear2)}})
           apply(sc,'skelet17-ladder-skelet10-transform-prefix-0',{'t':vv,'u':lr[1]})
           m.rewrite(sc,T(M(two,vv),ar.E),M(four,lr[1]),clear2[1],ar.sym(clear2[1],M(four,lr[1]),sc.get(Q(clear2[1],M(four,lr[1]))),sc.g))
           apply(sc,'skelet17-ladder-skelet10-sparse-prefix-0',{'t':vv})
           m.eq(sc,wr(clear2),M(two,M(two,vv)),[Q(wr(clear2),r),Q(r,M(four,vv))])
           def enter_right(ec):
            apply(ec,'skelet17-ladder-skelet10-even-right-enters-counter',{'t':M(two,vv),**{v[1]:x for v,x in zip(cf,clear2)},**{v[1]:x for v,x in zip(nf,re)}})
            rightparams={right['word'][1]:M(two,vv),right['ell'][1]:clear2[1]}
            def right_output(rc,ri,rr):
             m.rewrite(rc,T(M(two,vv),ar.E),clear2[1],wl(rr),ar.sym(wl(rr),clear2[1],rc.get(Q(wl(rr),clear2[1])),rc.g))
             apply(rc,'skelet17-ladder-skelet10-boundary-even-output',{'t':M(two,vv),**{v[1]:x for v,x in zip(cf,rr)}})
             m.eq(rc,M(two,M(two,vv)),r,[Q(r,M(four,vv))])
             m.rewrite(rc,bd['boundary'](ar.E,rr),M(two,M(two,vv)),r)
             m.bound(rc,k,pi,ar.num(3));m.translt(rc,k,pi,li)
             entryi=A(A(A(li,O),O),O);m.bound(rc,li,entryi,two);m.translt(rc,k,li,entryi);m.translt(rc,k,entryi,ri)
             nd.conj(rc,[L(k,ri),AT(o,ri,rr),bd['boundary'](r,rr)]);pack_rows(rc,outr,result(ri,outr),rr)
             return m.bex_intro(rc,outi,A(N,O),nd.bexs(outr,H,result(outi,outr)),ri)
            return run_counter(ec,'right',re,A(A(A(li,O),O),O),rightparams,goal,right_output)
           return advance(sc,clear2,A(A(li,O),O),0,re,goal,enter_right)
          return advance(fc,clear1,A(li,O),0,clear2,goal,second_clear)
         return advance(lc,lr,li,0,clear1,goal,first_clear)
        return run_counter(pc,'left',pr,pi,leftparams,goal,left_output)
       # The generic prefix uses exact source rows. Its third target is
       # rewritten to the quotient/remainder source before the fourth move.
       def first_three(pc,pr,pi):
        source,target,_=finite['instructions']['instruction'](*updates[-1])
        for x,y,z in zip(pr,source,rows[-1]):m.eq(pc,x,y,[Q(x,z),teq])
        return prefix(pc,pr,pi,[source,target],updates[-1:],actual[-1:],goal,completed)
       return prefix(dc,cf,k,rows[:4],updates[:3],actual[:3],goal,first_three)
      return m.bex_elim(qc,m.r,two,Q(tt,push(xx,m.r)),dd,goal,have_digit)
     return m.bex_elim(tc,m.q,A(tt,O),nd.BEX(m.r,two,Q(tt,push(m.q,m.r))),xx,goal,have_quotient)
    return m.bex_elim(vc,block,A(wl(cf),O),b.And(Q(wl(cf),A(M(sixteen,block),ten)),T(word,block)),tt,goal,have_tail)
   return m.bex_elim(hc,vbound,A(cf[3],O),b.And(Q(cf[3],M(four,vbound)),J(word,vbound)),vv,goal,have_carry)
  m.bex_elim(c,ba,A(n,O),nd.AND(efields(ba)),half,goal,have_half)
  m.finish('skelet17-ladder-skelet10-even-one-boundary-cycle',root,prem,goal,c,'Complete n=8b+2 canonical boundary composition in the original raw history. Constructs four carry moves, both counter outputs, two return-clearing moves and the right entry. No new induction or axioms.')
 if proofs:prove()
 return {'word':word}
