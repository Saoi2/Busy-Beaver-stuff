$c var term wff ctx open bnd subt subf |- => [] ; 0 1 + * = < ( ) -. /\ \/ -> <-> A. E. $.
$v x y z k t u v w ph ps ch th ga $.
f-x $f var x $.
f-y $f var y $.
f-z $f var z $.
f-k $f var k $.
f-t $f term t $.
f-u $f term u $.
f-v $f term v $.
f-w $f term w $.
f-ph $f wff ph $.
f-ps $f wff ps $.
f-ch $f wff ch $.
f-th $f wff th $.
f-ga $f ctx ga $.
${
term-zero $a term 0 $.
$}
${
term-one $a term 1 $.
$}
${
term-var $a term x $.
$}
${
term-add $a term ( t + u ) $.
$}
${
term-mul $a term ( t * u ) $.
$}
${
w-eq $a wff ( t = u ) $.
$}
${
w-lt $a wff ( t < u ) $.
$}
${
w-not $a wff -. ph $.
$}
${
w-and $a wff ( ph /\ ps ) $.
$}
${
w-or $a wff ( ph \/ ps ) $.
$}
${
w-imp $a wff ( ph -> ps ) $.
$}
${
w-iff $a wff ( ph <-> ps ) $.
$}
${
w-all $a wff A. x ph $.
$}
${
w-ex $a wff E. x ph $.
$}
${
ctx-empty $a ctx [] $.
$}
${
ctx-cons $a ctx ( ga ; ph ) $.
$}
${
st-same $a subt x x t t $.
$}
${
${
$d t x $.
st-fresh $a subt t x u t $.
$}
$}
${
${
$d x y $.
st-other $a subt y x t y $.
$}
$}
${
st-zero $a subt 0 x t 0 $.
$}
${
st-one $a subt 1 x t 1 $.
$}
$v r $.
f-r $f term r $.
${
st-add-general.h1 $e subt u x t w $.
st-add-general.h2 $e subt v x t r $.
${
st-add-general $a subt ( u + v ) x t ( w + r ) $.
$}
$}
${
st-mul-general.h1 $e subt u x t w $.
st-mul-general.h2 $e subt v x t r $.
${
st-mul-general $a subt ( u * v ) x t ( w * r ) $.
$}
$}
${
sf-eq.h1 $e subt u x t w $.
sf-eq.h2 $e subt v x t r $.
${
sf-eq $a subf ( u = v ) x t ( w = r ) $.
$}
$}
${
sf-lt.h1 $e subt u x t w $.
sf-lt.h2 $e subt v x t r $.
${
sf-lt $a subf ( u < v ) x t ( w < r ) $.
$}
$}
${
sf-not.h1 $e subf ph x t ps $.
${
sf-not $a subf -. ph x t -. ps $.
$}
$}
${
sf-and.h1 $e subf ph x t ch $.
sf-and.h2 $e subf ps x t th $.
${
sf-and $a subf ( ph /\ ps ) x t ( ch /\ th ) $.
$}
$}
${
sf-or.h1 $e subf ph x t ch $.
sf-or.h2 $e subf ps x t th $.
${
sf-or $a subf ( ph \/ ps ) x t ( ch \/ th ) $.
$}
$}
${
sf-imp.h1 $e subf ph x t ch $.
sf-imp.h2 $e subf ps x t th $.
${
sf-imp $a subf ( ph -> ps ) x t ( ch -> th ) $.
$}
$}
${
sf-iff.h1 $e subf ph x t ch $.
sf-iff.h2 $e subf ps x t th $.
${
sf-iff $a subf ( ph <-> ps ) x t ( ch <-> th ) $.
$}
$}
${
sf-all-same $a subf A. x ph x t A. x ph $.
$}
${
sf-all-other.h1 $e subf ph x t ps $.
${
$d t y $.
$d x y $.
sf-all-other $a subf A. y ph x t A. y ps $.
$}
$}
${
sf-ex-same $a subf E. x ph x t E. x ph $.
$}
${
sf-ex-other.h1 $e subf ph x t ps $.
${
$d t y $.
$d x y $.
sf-ex-other $a subf E. y ph x t E. y ps $.
$}
$}
${
open-eq $a open ( t = u ) $.
$}
${
open-lt $a open ( t < u ) $.
$}
${
open-not.h1 $e open ph $.
${
open-not $a open -. ph $.
$}
$}
${
open-and.h1 $e open ph $.
open-and.h2 $e open ps $.
${
open-and $a open ( ph /\ ps ) $.
$}
$}
${
open-or.h1 $e open ph $.
open-or.h2 $e open ps $.
${
open-or $a open ( ph \/ ps ) $.
$}
$}
${
open-imp.h1 $e open ph $.
open-imp.h2 $e open ps $.
${
open-imp $a open ( ph -> ps ) $.
$}
$}
${
open-iff.h1 $e open ph $.
open-iff.h2 $e open ps $.
${
open-iff $a open ( ph <-> ps ) $.
$}
$}
${
bnd-open.h1 $e open ph $.
${
bnd-open $a bnd ph $.
$}
$}
${
bnd-not.h1 $e bnd ph $.
${
bnd-not $a bnd -. ph $.
$}
$}
${
bnd-and.h1 $e bnd ph $.
bnd-and.h2 $e bnd ps $.
${
bnd-and $a bnd ( ph /\ ps ) $.
$}
$}
${
bnd-or.h1 $e bnd ph $.
bnd-or.h2 $e bnd ps $.
${
bnd-or $a bnd ( ph \/ ps ) $.
$}
$}
${
bnd-imp.h1 $e bnd ph $.
bnd-imp.h2 $e bnd ps $.
${
bnd-imp $a bnd ( ph -> ps ) $.
$}
$}
${
bnd-iff.h1 $e bnd ph $.
bnd-iff.h2 $e bnd ps $.
${
bnd-iff $a bnd ( ph <-> ps ) $.
$}
$}
${
bnd-ex.h1 $e bnd ph $.
${
$d t x $.
bnd-ex $a bnd E. x ( ( x < t ) /\ ph ) $.
$}
$}
${
bnd-all.h1 $e bnd ph $.
${
$d t x $.
bnd-all $a bnd A. x ( ( x < t ) -> ph ) $.
$}
$}
${
nd-assume $a |- ( ga ; ph ) => ph $.
$}
${
nd-weaken.h1 $e |- ga => ph $.
${
nd-weaken $a |- ( ga ; ps ) => ph $.
$}
$}
${
nd-empty-weaken.h1 $e |- [] => ph $.
${
nd-empty-weaken $a |- ga => ph $.
$}
$}
${
nd-imp-intro.h1 $e |- ( ga ; ph ) => ps $.
${
nd-imp-intro $a |- ga => ( ph -> ps ) $.
$}
$}
${
nd-mp.h1 $e |- ga => ( ph -> ps ) $.
nd-mp.h2 $e |- ga => ph $.
${
nd-mp $a |- ga => ps $.
$}
$}
${
nd-and-intro.h1 $e |- ga => ph $.
nd-and-intro.h2 $e |- ga => ps $.
${
nd-and-intro $a |- ga => ( ph /\ ps ) $.
$}
$}
${
nd-and-left.h1 $e |- ga => ( ph /\ ps ) $.
${
nd-and-left $a |- ga => ph $.
$}
$}
${
nd-and-right.h1 $e |- ga => ( ph /\ ps ) $.
${
nd-and-right $a |- ga => ps $.
$}
$}
${
nd-or-left.h1 $e |- ga => ph $.
${
nd-or-left $a |- ga => ( ph \/ ps ) $.
$}
$}
${
nd-or-right.h1 $e |- ga => ps $.
${
nd-or-right $a |- ga => ( ph \/ ps ) $.
$}
$}
${
nd-or-elim.h1 $e |- ga => ( ph \/ ps ) $.
nd-or-elim.h2 $e |- ( ga ; ph ) => ch $.
nd-or-elim.h3 $e |- ( ga ; ps ) => ch $.
${
nd-or-elim $a |- ga => ch $.
$}
$}
${
nd-all-intro.h1 $e |- ga => ph $.
${
$d ga x $.
nd-all-intro $a |- ga => A. x ph $.
$}
$}
${
nd-all-elim.h1 $e |- ga => A. x ph $.
nd-all-elim.h2 $e subf ph x t ps $.
${
nd-all-elim $a |- ga => ps $.
$}
$}
${
nd-ex-intro.h1 $e subf ph x t ps $.
nd-ex-intro.h2 $e |- ga => ps $.
${
nd-ex-intro $a |- ga => E. x ph $.
$}
$}
${
nd-ex-elim.h1 $e |- ga => E. x ph $.
nd-ex-elim.h2 $e subf ph x y ps $.
nd-ex-elim.h3 $e |- ( ga ; ps ) => ch $.
${
$d ch y $.
$d ga y $.
$d ph y $.
$d x y $.
nd-ex-elim $a |- ga => ch $.
$}
$}
${
nd-iff-left.h1 $e |- ga => ( ph <-> ps ) $.
${
nd-iff-left $a |- ga => ( ph -> ps ) $.
$}
$}
${
nd-iff-right.h1 $e |- ga => ( ph <-> ps ) $.
${
nd-iff-right $a |- ga => ( ps -> ph ) $.
$}
$}
${
nd-iff-intro.h1 $e |- ga => ( ph -> ps ) $.
nd-iff-intro.h2 $e |- ga => ( ps -> ph ) $.
${
nd-iff-intro $a |- ga => ( ph <-> ps ) $.
$}
$}
${
nd-excluded-middle $a |- ga => ( ph \/ -. ph ) $.
$}
${
nd-explosion.h1 $e |- ga => ph $.
nd-explosion.h2 $e |- ga => -. ph $.
${
nd-explosion $a |- ga => ps $.
$}
$}
${
nd-not-intro.h1 $e |- ( ga ; ph ) => ps $.
nd-not-intro.h2 $e |- ( ga ; ph ) => -. ps $.
${
nd-not-intro $a |- ga => -. ph $.
$}
$}
${
nd-dne.h1 $e |- ga => -. -. ph $.
${
nd-dne $a |- ga => ph $.
$}
$}
${
eq-refl $a |- ga => ( t = t ) $.
$}
${
eq-sym.h1 $e |- ga => ( t = u ) $.
${
eq-sym $a |- ga => ( u = t ) $.
$}
$}
${
eq-trans.h1 $e |- ga => ( t = u ) $.
eq-trans.h2 $e |- ga => ( u = v ) $.
${
eq-trans $a |- ga => ( t = v ) $.
$}
$}
${
eq-add-cong.h1 $e |- ga => ( t = u ) $.
eq-add-cong.h2 $e |- ga => ( v = w ) $.
${
eq-add-cong $a |- ga => ( ( t + v ) = ( u + w ) ) $.
$}
$}
${
eq-mul-cong.h1 $e |- ga => ( t = u ) $.
eq-mul-cong.h2 $e |- ga => ( v = w ) $.
${
eq-mul-cong $a |- ga => ( ( t * v ) = ( u * w ) ) $.
$}
$}
${
eq-replace.h1 $e |- ga => ( t = u ) $.
eq-replace.h2 $e subf ph x t ps $.
eq-replace.h3 $e subf ph x u ch $.
eq-replace.h4 $e |- ga => ps $.
${
eq-replace $a |- ga => ch $.
$}
$}
${
ax-A1 $a |- ga => ( ( ( t + u ) + v ) = ( t + ( u + v ) ) ) $.
$}
${
ax-A2 $a |- ga => ( ( t + u ) = ( u + t ) ) $.
$}
${
ax-A3 $a |- ga => ( ( t + 0 ) = t ) $.
$}
${
ax-A4 $a |- ga => ( ( ( t * u ) * v ) = ( t * ( u * v ) ) ) $.
$}
${
ax-A5 $a |- ga => ( ( t * u ) = ( u * t ) ) $.
$}
${
ax-A6 $a |- ga => ( ( t * 1 ) = t ) $.
$}
${
ax-A7 $a |- ga => ( ( t * 0 ) = 0 ) $.
$}
${
ax-A8 $a |- ga => ( ( t * ( u + v ) ) = ( ( t * u ) + ( t * v ) ) ) $.
$}
${
ax-O1 $a |- ga => -. ( t < t ) $.
$}
${
ax-O2 $a |- ga => ( ( ( t < u ) /\ ( u < v ) ) -> ( t < v ) ) $.
$}
${
ax-O3 $a |- ga => ( ( t < u ) \/ ( ( t = u ) \/ ( u < t ) ) ) $.
$}
${
ax-O4 $a |- ga => -. ( t < 0 ) $.
$}
${
ax-O5 $a |- ga => ( ( t < u ) -> ( ( t + v ) < ( u + v ) ) ) $.
$}
${
ax-O6 $a |- ga => ( ( ( t < u ) /\ ( 0 < v ) ) -> ( ( t * v ) < ( u * v ) ) ) $.
$}
${
${
$d t x $.
$d u x $.
ax-O7 $a |- ga => ( ( t < u ) <-> E. x ( u = ( ( t + x ) + 1 ) ) ) $.
$}
$}
${
ax-ind-bounded.h1 $e bnd ph $.
ax-ind-bounded.h2 $e subf ph x 0 ps $.
ax-ind-bounded.h3 $e subf ph x ( x + 1 ) ch $.
${
ax-ind-bounded $a |- ga => ( ( ps /\ A. x ( ph -> ch ) ) -> A. x ph ) $.
$}
$}
${
ind-open.h1 $e open ph $.
ind-open.h2 $e subf ph x 0 ps $.
ind-open.h3 $e subf ph x ( x + 1 ) ch $.
$}
$v e0 $.
f-e0 $f var e0 $.
$v e1 $.
f-e1 $f var e1 $.
$v e2 $.
f-e2 $f var e2 $.
$v e3 $.
f-e3 $f var e3 $.
$v i $.
f-i $f var i $.
$v j $.
f-j $f var j $.
$v n $.
f-n $f var n $.
$v h $.
f-h $f var h $.
$v q $.
f-q $f var q $.
$v ll $.
f-ll $f var ll $.
$v rr $.
f-rr $f var rr $.
$v bit $.
f-bit $f var bit $.
$v bb0 $.
f-bb0 $f var bb0 $.
$v cc0 $.
f-cc0 $f var cc0 $.
$v bb1 $.
f-bb1 $f var bb1 $.
$v cc1 $.
f-cc1 $f var cc1 $.
$v bb2 $.
f-bb2 $f var bb2 $.
$v cc2 $.
f-cc2 $f var cc2 $.
$v bb3 $.
f-bb3 $f var bb3 $.
$v cc3 $.
f-cc3 $f var cc3 $.
$v aa $.
f-aa $f var aa $.
$v dd $.
f-dd $f var dd $.
${
arith-6 $p |- [] => ( ( 1 * 1 ) = 1 ) $=
 term-one term-one term-mul term-one term-one term-mul term-one ctx-empty term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-mul-cong term-one ctx-empty ax-A6 eq-trans $.
$}
${
arith-21 $p |- [] => ( ( u * 1 ) = u ) $=
 f-u term-one term-mul f-u term-one term-mul f-u ctx-empty f-u f-u term-one term-one ctx-empty f-u ctx-empty eq-refl term-one ctx-empty eq-refl eq-mul-cong f-u ctx-empty ax-A6 eq-trans $.
$}
${
arith-58 $p |- [] => ( ( v * 1 ) = v ) $=
 f-v term-one term-mul f-v term-one term-mul f-v ctx-empty f-v f-v term-one term-one ctx-empty f-v ctx-empty eq-refl term-one ctx-empty eq-refl eq-mul-cong f-v ctx-empty ax-A6 eq-trans $.
$}
${
arith-78 $p |- [] => ( ( t * v ) = ( t * v ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul ctx-empty f-t f-t f-v f-v ctx-empty f-t ctx-empty eq-refl f-v ctx-empty eq-refl eq-mul-cong f-t f-t f-v f-v ctx-empty f-t ctx-empty eq-refl f-v ctx-empty eq-refl eq-mul-cong eq-trans $.
$}
$v mn $.
f-mn $f term mn $.
$v mh $.
f-mh $f term mh $.
$v d0 $.
f-d0 $f term d0 $.
$v d1 $.
f-d1 $f term d1 $.
$v d2 $.
f-d2 $f term d2 $.
$v d3 $.
f-d3 $f term d3 $.
$v d4 $.
f-d4 $f term d4 $.
$v d5 $.
f-d5 $f term d5 $.
$v B0 $.
f-B0 $f term B0 $.
$v C0 $.
f-C0 $f term C0 $.
$v B1 $.
f-B1 $f term B1 $.
$v C1 $.
f-C1 $f term C1 $.
$v B2 $.
f-B2 $f term B2 $.
$v C2 $.
f-C2 $f term C2 $.
$v B3 $.
f-B3 $f term B3 $.
$v C3 $.
f-C3 $f term C3 $.
$v ti $.
f-ti $f var ti $.
$v tq $.
f-tq $f var tq $.
$v tl $.
f-tl $f var tl $.
$v tb $.
f-tb $f var tb $.
$v tr $.
f-tr $f var tr $.
$v iq $.
f-iq $f var iq $.
$v il $.
f-il $f var il $.
$v ib $.
f-ib $f var ib $.
$v ir $.
f-ir $f var ir $.
$v si $.
f-si $f var si $.
$v sq $.
f-sq $f var sq $.
$v sl $.
f-sl $f var sl $.
$v sb $.
f-sb $f var sb $.
$v sr $.
f-sr $f var sr $.
$v nq $.
f-nq $f var nq $.
$v nl $.
f-nl $f var nl $.
$v nb $.
f-nb $f var nb $.
$v nr $.
f-nr $f var nr $.
$v fq $.
f-fq $f var fq $.
$v fl $.
f-fl $f var fl $.
$v fb $.
f-fb $f var fb $.
$v fr $.
f-fr $f var fr $.
$v iv $.
f-iv $f var iv $.
$v pq $.
f-pq $f var pq $.
$v pl $.
f-pl $f var pl $.
$v pb $.
f-pb $f var pb $.
$v pr $.
f-pr $f var pr $.
$v oq $.
f-oq $f var oq $.
$v ol $.
f-ol $f var ol $.
$v ob $.
f-ob $f var ob $.
$v orr $.
f-orr $f var orr $.
$v cq $.
f-cq $f var cq $.
$v cl $.
f-cl $f var cl $.
$v cb $.
f-cb $f var cb $.
$v cr $.
f-cr $f var cr $.
$v vq $.
f-vq $f var vq $.
$v vl $.
f-vl $f var vl $.
$v vb $.
f-vb $f var vb $.
$v vr $.
f-vr $f var vr $.
$v bu $.
f-bu $f var bu $.
$v iu $.
f-iu $f var iu $.
$v ju $.
f-ju $f var ju $.
$v evl $.
f-evl $f var evl $.
$v evr $.
f-evr $f var evr $.
$v pv $.
f-pv $f var pv $.
$v pd $.
f-pd $f var pd $.
$v clu $.
f-clu $f var clu $.
$v cru $.
f-cru $f var cru $.
$v nlq $.
f-nlq $f var nlq $.
$v nrq $.
f-nrq $f var nrq $.
$v code0 $.
f-code0 $f var code0 $.
$v code1 $.
f-code1 $f var code1 $.
$v code2 $.
f-code2 $f var code2 $.
$v code3 $.
f-code3 $f var code3 $.
$v hn $.
f-hn $f var hn $.
$v hh $.
f-hh $f var hh $.
$v hB0 $.
f-hB0 $f var hB0 $.
$v hC0 $.
f-hC0 $f var hC0 $.
$v hB1 $.
f-hB1 $f var hB1 $.
$v hC1 $.
f-hC1 $f var hC1 $.
$v hB2 $.
f-hB2 $f var hB2 $.
$v hC2 $.
f-hC2 $f var hC2 $.
$v hB3 $.
f-hB3 $f var hB3 $.
$v hC3 $.
f-hC3 $f var hC3 $.
${
syn-0 $p term ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) $=
 term-one term-one term-add term-one term-add term-one term-add f-t term-mul term-one term-one term-add term-add $.
$}
${
syn-1 $p wff ( w = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) $=
 f-w f-t syn-0 w-eq $.
$}
${
syn-2 $p term ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) $=
 term-one term-one term-add term-one term-add term-one term-add f-v term-mul term-one term-add $.
$}
${
syn-3 $p wff ( u = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) $=
 f-u f-v syn-2 w-eq $.
$}
${
syn-4 $p wff ( ( w = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) /\ ( u = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) ) $=
 f-t f-w syn-1 f-u f-v syn-3 w-and $.
$}
${
syn-5 $p ctx ( [] ; ( ( w = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) /\ ( u = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) ) ) $=
 f-t f-u f-v f-w syn-4 ctx-empty ctx-cons $.
$}
${
arith-85 $p |- [] => ( ( 1 + 1 ) = ( 1 + 1 ) ) $=
 term-one term-one term-add term-one term-one term-add term-one term-one term-add ctx-empty term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-6 $p |- [] => ( ( ( 1 + 1 ) + 1 ) = ( 1 + ( 1 + 1 ) ) ) $=
 term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one term-one term-add term-one term-add term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add ctx-empty term-one term-one term-add term-one term-one term-add term-one term-one ctx-empty term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong term-one ctx-empty eq-refl eq-add-cong term-one term-one term-one ctx-empty ax-A1 eq-trans term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-7 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) + 1 ) = ( 1 + ( ( 1 + 1 ) + 1 ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-add term-one term-one term-one term-add term-add term-one term-add term-one term-one term-one term-add term-one term-add term-add ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add term-one term-one ctx-empty term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong term-one term-one term-one term-add term-one ctx-empty ax-A1 eq-trans $.
$}
${
dag-8 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) + 1 ) = ( 1 + ( 1 + ( 1 + 1 ) ) ) ) $=
 term-one term-one term-add term-one term-add term-one term-add term-one term-one term-one term-add term-add term-one term-add term-one term-one term-one term-one term-add term-add term-add ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add term-one term-one ctx-empty dag-6 term-one ctx-empty eq-refl eq-add-cong term-one term-one term-one term-add term-add term-one term-add term-one term-one term-one term-add term-one term-add term-add term-one term-one term-one term-one term-add term-add term-add ctx-empty dag-7 term-one term-one term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl dag-6 eq-add-cong eq-trans eq-trans $.
$}
${
syn-9 $p term ( ( t * 1 ) + ( t * ( 1 + ( 1 + 1 ) ) ) ) $=
 f-t term-one term-mul f-t term-one term-one term-one term-add term-add term-mul term-add $.
$}
${
dag-10 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) = ( ( t * 1 ) + ( t * ( 1 + ( 1 + 1 ) ) ) ) ) $=
 term-one term-one term-add term-one term-add term-one term-add f-t term-mul term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t syn-9 ctx-empty term-one term-one term-add term-one term-add term-one term-add term-one term-one term-one term-one term-add term-add term-add f-t f-t ctx-empty dag-8 f-t ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t term-one term-one term-one term-one term-add term-add term-add term-mul f-t syn-9 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-t ctx-empty ax-A5 f-t term-one term-one term-one term-one term-add term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-88 $p |- [] => ( ( t * 1 ) = t ) $=
 f-t term-one term-mul f-t term-one term-mul f-t ctx-empty f-t f-t term-one term-one ctx-empty f-t ctx-empty eq-refl term-one ctx-empty eq-refl eq-mul-cong f-t ctx-empty ax-A6 eq-trans $.
$}
${
dag-11 $p |- [] => ( ( 1 + ( 1 + 1 ) ) = ( 1 + ( 1 + 1 ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl arith-85 eq-add-cong term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
arith-90 $p |- [] => ( ( ( t * 1 ) + ( t * 1 ) ) = ( t + t ) ) $=
 f-t term-one term-mul f-t term-one term-mul term-add f-t f-t term-add f-t f-t term-add ctx-empty f-t term-one term-mul f-t f-t term-one term-mul f-t ctx-empty f-t arith-88 f-t arith-88 eq-add-cong f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-12 $p |- [] => ( ( t * ( 1 + 1 ) ) = ( t + t ) ) $=
 f-t term-one term-one term-add term-mul f-t term-one term-mul f-t term-one term-mul term-add f-t f-t term-add ctx-empty f-t term-one term-one term-add term-mul f-t term-one term-one term-add term-mul f-t term-one term-mul f-t term-one term-mul term-add ctx-empty f-t f-t term-one term-one term-add term-one term-one term-add ctx-empty f-t ctx-empty eq-refl arith-85 eq-mul-cong f-t term-one term-one ctx-empty ax-A8 eq-trans f-t arith-90 eq-trans $.
$}
${
dag-13 $p |- [] => ( ( ( t * 1 ) + ( t * ( 1 + 1 ) ) ) = ( t + ( t + t ) ) ) $=
 f-t term-one term-mul f-t term-one term-one term-add term-mul term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t term-one term-mul f-t f-t term-one term-one term-add term-mul f-t f-t term-add ctx-empty f-t arith-88 f-t dag-12 eq-add-cong f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-14 $p |- [] => ( ( t * ( 1 + ( 1 + 1 ) ) ) = ( t + ( t + t ) ) ) $=
 f-t term-one term-one term-one term-add term-add term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add f-t f-t f-t term-add term-add ctx-empty f-t term-one term-one term-one term-add term-add term-mul f-t term-one term-one term-one term-add term-add term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add ctx-empty f-t f-t term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty f-t ctx-empty eq-refl dag-11 eq-mul-cong f-t term-one term-one term-one term-add ctx-empty ax-A8 eq-trans f-t dag-13 eq-trans $.
$}
${
dag-15 $p |- [] => ( ( ( t * 1 ) + ( t * ( 1 + ( 1 + 1 ) ) ) ) = ( t + ( t + ( t + t ) ) ) ) $=
 f-t syn-9 f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t term-one term-mul f-t f-t term-one term-one term-one term-add term-add term-mul f-t f-t f-t term-add term-add ctx-empty f-t arith-88 f-t dag-14 eq-add-cong f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
arith-95 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) = ( t + ( t + ( t + t ) ) ) ) $=
 term-one term-one term-add term-one term-add term-one term-add f-t term-mul f-t syn-9 f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t dag-10 f-t dag-15 eq-trans $.
$}
${
dag-16 $p |- [] => ( ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) = ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-17 $p term ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) $=
 f-t f-t f-t f-t term-add term-add term-add term-one term-one term-add term-add $.
$}
${
syn-18 $p term ( t + ( ( t + ( t + t ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t f-t f-t term-add term-add term-one term-one term-add term-add term-add $.
$}
${
dag-19 $p |- [] => ( ( ( t + ( t + t ) ) + ( 1 + 1 ) ) = ( ( t + ( t + t ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
dag-20 $p |- [] => ( ( ( t + t ) + ( 1 + 1 ) ) = ( t + ( t + ( 1 + 1 ) ) ) ) $=
 f-t f-t term-add term-one term-one term-add term-add f-t f-t term-add term-one term-one term-add term-add f-t f-t term-one term-one term-add term-add term-add ctx-empty f-t f-t term-add f-t f-t term-add term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
dag-21 $p |- [] => ( ( ( t + ( t + t ) ) + ( 1 + 1 ) ) = ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) $=
 f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t f-t f-t term-add term-one term-one term-add term-add term-add f-t f-t f-t term-one term-one term-add term-add term-add term-add ctx-empty f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t f-t f-t term-add term-one term-one term-add term-add term-add ctx-empty f-t dag-19 f-t f-t f-t term-add term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-t f-t f-t term-add term-one term-one term-add term-add f-t f-t term-one term-one term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-20 eq-add-cong eq-trans $.
$}
${
syn-22 $p term ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) $=
 f-t f-t f-t f-t term-one term-one term-add term-add term-add term-add term-add $.
$}
${
dag-23 $p |- [] => ( ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) = ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) $=
 f-t syn-17 f-t syn-18 f-t syn-22 ctx-empty f-t syn-17 f-t syn-17 f-t syn-18 ctx-empty f-t dag-16 f-t f-t f-t f-t term-add term-add term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-t f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t f-t f-t term-one term-one term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-21 eq-add-cong eq-trans $.
$}
${
dag-24 $p |- [] => ( ( t + ( 1 + 1 ) ) = ( ( 1 + t ) + 1 ) ) $=
 f-t term-one term-one term-add term-add f-t term-one term-add term-one term-add term-one f-t term-add term-one term-add ctx-empty f-t term-one term-add term-one term-add f-t term-one term-one term-add term-add ctx-empty f-t term-one term-one ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add term-one term-one ctx-empty f-t term-one ctx-empty ax-A2 term-one ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-25 $p |- [] => ( ( t + ( t + ( t + ( 1 + 1 ) ) ) ) = ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) $=
 f-t f-t f-t f-t term-one term-one term-add term-add term-add f-t term-one f-t term-one term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t term-one term-one term-add term-add term-one f-t term-one term-add term-add ctx-empty f-t ctx-empty eq-refl f-t term-one term-one term-add term-add term-one f-t term-add term-one term-add term-one f-t term-one term-add term-add ctx-empty f-t dag-24 term-one f-t term-one ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-26 $p term ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) $=
 f-t f-t f-t term-one f-t term-one term-add term-add term-add term-add term-add $.
$}
${
dag-27 $p |- [] => ( ( t + ( t + ( 1 + ( t + 1 ) ) ) ) = ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) $=
 f-t f-t f-t term-one f-t term-one term-add term-add term-add f-t term-one term-one f-t term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t term-one f-t term-one term-add term-add term-one term-one f-t term-add term-add ctx-empty f-t ctx-empty eq-refl term-one term-one f-t term-one term-add term-one f-t term-add ctx-empty term-one ctx-empty eq-refl f-t term-one ctx-empty ax-A2 eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-28 $p term ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) $=
 f-t f-t f-t term-one term-one f-t term-add term-add term-add term-add term-add $.
$}
${
dag-29 $p |- [] => ( ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) = ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) $=
 f-t syn-17 f-t syn-26 f-t syn-28 ctx-empty f-t syn-17 f-t syn-22 f-t syn-26 ctx-empty f-t dag-23 f-t f-t f-t f-t f-t term-one term-one term-add term-add term-add term-add f-t f-t term-one f-t term-one term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-25 eq-add-cong eq-trans f-t f-t f-t f-t term-one f-t term-one term-add term-add term-add term-add f-t f-t term-one term-one f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-27 eq-add-cong eq-trans $.
$}
${
dag-30 $p |- [] => ( ( t + ( 1 + ( 1 + t ) ) ) = ( ( 1 + t ) + ( 1 + t ) ) ) $=
 f-t term-one term-one f-t term-add term-add term-add f-t term-one term-add term-one f-t term-add term-add term-one f-t term-add term-one f-t term-add term-add ctx-empty f-t term-one term-add term-one f-t term-add term-add f-t term-one term-one f-t term-add term-add term-add ctx-empty f-t term-one term-one f-t term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add term-one f-t term-add term-one f-t term-add ctx-empty f-t term-one ctx-empty ax-A2 term-one f-t term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-31 $p |- [] => ( ( t + ( t + ( 1 + ( 1 + t ) ) ) ) = ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) $=
 f-t f-t f-t term-one term-one f-t term-add term-add term-add term-one f-t term-one f-t term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t term-one term-one f-t term-add term-add term-add term-one f-t term-add term-one f-t term-add term-add term-one f-t term-one f-t term-add term-add term-add ctx-empty f-t dag-30 term-one f-t term-one f-t term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-32 $p term ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) $=
 f-t f-t term-one f-t term-one f-t term-add term-add term-add term-add term-add $.
$}
${
dag-33 $p |- [] => ( ( t + ( 1 + t ) ) = ( ( 1 + t ) + t ) ) $=
 f-t term-one f-t term-add term-add f-t term-one term-add f-t term-add term-one f-t term-add f-t term-add ctx-empty f-t term-one term-add f-t term-add f-t term-one f-t term-add term-add ctx-empty f-t term-one f-t ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t f-t ctx-empty f-t term-one ctx-empty ax-A2 f-t ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-34 $p |- [] => ( ( t + ( 1 + ( t + ( 1 + t ) ) ) ) = ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) $=
 f-t f-t term-one f-t term-one f-t term-add term-add term-add term-one term-one f-t f-t term-add term-add term-add ctx-empty f-t ctx-empty eq-refl term-one term-one f-t term-one f-t term-add term-add term-one f-t f-t term-add term-add ctx-empty term-one ctx-empty eq-refl f-t term-one f-t term-add term-add term-one f-t term-add f-t term-add term-one f-t f-t term-add term-add ctx-empty f-t dag-33 term-one f-t f-t ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-35 $p term ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) $=
 f-t f-t term-one term-one f-t f-t term-add term-add term-add term-add term-add $.
$}
${
dag-36 $p |- [] => ( ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) = ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) $=
 f-t syn-17 f-t syn-32 f-t syn-35 ctx-empty f-t syn-17 f-t syn-28 f-t syn-32 ctx-empty f-t dag-29 f-t f-t f-t f-t term-one term-one f-t term-add term-add term-add term-add f-t term-one f-t term-one f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-31 eq-add-cong eq-trans f-t f-t f-t term-one f-t term-one f-t term-add term-add term-add term-add f-t term-one term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-34 eq-add-cong eq-trans $.
$}
${
dag-37 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + t ) ) ) ) = ( ( 1 + t ) + ( 1 + ( t + t ) ) ) ) $=
 f-t term-one term-one f-t f-t term-add term-add term-add term-add f-t term-one term-add term-one f-t f-t term-add term-add term-add term-one f-t term-add term-one f-t f-t term-add term-add term-add ctx-empty f-t term-one term-add term-one f-t f-t term-add term-add term-add f-t term-one term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t term-one term-one f-t f-t term-add term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add term-one f-t f-t term-add term-add term-one f-t f-t term-add term-add ctx-empty f-t term-one ctx-empty ax-A2 term-one f-t f-t term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-38 $p |- [] => ( ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) = ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) $=
 f-t f-t f-t term-one term-one f-t f-t term-add term-add term-add term-add term-one f-t term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t term-one term-one f-t f-t term-add term-add term-add term-add term-one f-t term-add term-one f-t f-t term-add term-add term-add term-one f-t term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t dag-37 term-one f-t term-one f-t f-t term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-39 $p term ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) $=
 f-t term-one f-t term-one f-t f-t term-add term-add term-add term-add term-add $.
$}
${
dag-40 $p |- [] => ( ( t + ( 1 + ( t + t ) ) ) = ( ( 1 + t ) + ( t + t ) ) ) $=
 f-t term-one f-t f-t term-add term-add term-add f-t term-one term-add f-t f-t term-add term-add term-one f-t term-add f-t f-t term-add term-add ctx-empty f-t term-one term-add f-t f-t term-add term-add f-t term-one f-t f-t term-add term-add term-add ctx-empty f-t term-one f-t f-t term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t f-t term-add f-t f-t term-add ctx-empty f-t term-one ctx-empty ax-A2 f-t f-t term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-41 $p |- [] => ( ( 1 + ( t + ( 1 + ( t + t ) ) ) ) = ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) $=
 term-one term-one f-t term-one f-t f-t term-add term-add term-add term-one f-t f-t f-t term-add term-add term-add ctx-empty term-one ctx-empty eq-refl f-t term-one f-t f-t term-add term-add term-add term-one f-t term-add f-t f-t term-add term-add term-one f-t f-t f-t term-add term-add term-add ctx-empty f-t dag-40 term-one f-t f-t f-t term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-42 $p term ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) $=
 f-t term-one term-one f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
syn-43 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + t ) ) ) ) $=
 f-t term-one term-add term-one f-t f-t f-t term-add term-add term-add term-add $.
$}
${
syn-44 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + t ) ) ) ) $=
 term-one f-t term-add term-one f-t f-t f-t term-add term-add term-add term-add $.
$}
${
dag-45 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) = ( ( 1 + t ) + ( 1 + ( t + ( t + t ) ) ) ) ) $=
 f-t syn-42 f-t syn-43 f-t syn-44 ctx-empty f-t syn-43 f-t syn-42 ctx-empty f-t term-one term-one f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add term-one f-t f-t f-t term-add term-add term-add term-one f-t f-t f-t term-add term-add term-add ctx-empty f-t term-one ctx-empty ax-A2 term-one f-t f-t f-t term-add term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-46 $p term ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) $=
 term-one f-t term-one f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
dag-47 $p |- [] => ( ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) = ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-17 f-t syn-42 f-t syn-46 ctx-empty f-t syn-17 f-t syn-39 f-t syn-42 ctx-empty f-t syn-17 f-t syn-35 f-t syn-39 ctx-empty f-t dag-36 f-t dag-38 eq-trans f-t f-t term-one f-t term-one f-t f-t term-add term-add term-add term-add term-one term-one f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-41 eq-add-cong eq-trans f-t syn-42 f-t syn-44 f-t syn-46 ctx-empty f-t dag-45 term-one f-t term-one f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-trans eq-trans $.
$}
${
dag-48 $p |- [] => ( ( t + ( 1 + ( t + ( t + t ) ) ) ) = ( ( 1 + t ) + ( t + ( t + t ) ) ) ) $=
 f-t term-one f-t f-t f-t term-add term-add term-add term-add f-t term-one term-add f-t f-t f-t term-add term-add term-add term-one f-t term-add f-t f-t f-t term-add term-add term-add ctx-empty f-t term-one term-add f-t f-t f-t term-add term-add term-add f-t term-one f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t term-one f-t f-t f-t term-add term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t term-one ctx-empty ax-A2 f-t f-t f-t term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-49 $p |- [] => ( ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) = ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one term-one f-t term-one f-t f-t f-t term-add term-add term-add term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty term-one ctx-empty eq-refl f-t term-one f-t f-t f-t term-add term-add term-add term-add term-one f-t term-add f-t f-t f-t term-add term-add term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t dag-48 term-one f-t f-t f-t f-t term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-50 $p term ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) $=
 term-one term-one f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
arith-96 $p |- [] => ( ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-0 f-t syn-17 f-t syn-50 ctx-empty term-one term-one term-add term-one term-add term-one term-add f-t term-mul f-t f-t f-t f-t term-add term-add term-add term-one term-one term-add term-one term-one term-add ctx-empty f-t arith-95 arith-85 eq-add-cong f-t syn-17 f-t syn-46 f-t syn-50 ctx-empty f-t dag-47 f-t dag-49 eq-trans eq-trans $.
$}
${
syn-51 $p term ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) $=
 term-one term-one term-add term-one term-add f-t syn-0 term-mul $.
$}
${
syn-52 $p term ( ( 1 + ( 1 + 1 ) ) * ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t syn-50 term-mul $.
$}
${
syn-53 $p term ( ( 1 + ( 1 + 1 ) ) * ( 1 + ( t + ( t + ( t + t ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add term-mul $.
$}
${
syn-54 $p term ( ( ( 1 + ( 1 + 1 ) ) * 1 ) + ( ( 1 + ( 1 + 1 ) ) * ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-mul f-t syn-53 term-add $.
$}
${
dag-55 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * 1 ) = ( ( 1 * 1 ) + ( 1 * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-mul term-one term-one term-one term-add term-add term-one term-mul term-one term-one term-mul term-one term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add term-one term-one ctx-empty dag-11 term-one ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-add term-add term-one term-mul term-one term-one term-one term-one term-add term-add term-mul term-one term-one term-mul term-one term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add term-one ctx-empty ax-A5 term-one term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-97 $p |- [] => ( ( ( 1 * 1 ) + ( 1 * 1 ) ) = ( 1 + 1 ) ) $=
 term-one term-one term-mul term-one term-one term-mul term-add term-one term-one term-add term-one term-one term-add ctx-empty term-one term-one term-mul term-one term-one term-one term-mul term-one ctx-empty arith-6 arith-6 eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-56 $p |- [] => ( ( 1 * ( 1 + 1 ) ) = ( 1 + 1 ) ) $=
 term-one term-one term-one term-add term-mul term-one term-one term-mul term-one term-one term-mul term-add term-one term-one term-add ctx-empty term-one term-one term-one term-add term-mul term-one term-one term-one term-add term-mul term-one term-one term-mul term-one term-one term-mul term-add ctx-empty term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl arith-85 eq-mul-cong term-one term-one term-one ctx-empty ax-A8 eq-trans arith-97 eq-trans $.
$}
${
dag-57 $p |- [] => ( ( ( 1 * 1 ) + ( 1 * ( 1 + 1 ) ) ) = ( 1 + ( 1 + 1 ) ) ) $=
 term-one term-one term-mul term-one term-one term-one term-add term-mul term-add term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one term-one term-mul term-one term-one term-one term-one term-add term-mul term-one term-one term-add ctx-empty arith-6 dag-56 eq-add-cong term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
arith-100 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * 1 ) = ( 1 + ( 1 + 1 ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-mul term-one term-one term-mul term-one term-one term-one term-add term-mul term-add term-one term-one term-one term-add term-add ctx-empty dag-55 dag-57 eq-trans $.
$}
${
arith-101 $p |- [] => ( ( t + t ) = ( t + t ) ) $=
 f-t f-t term-add f-t f-t term-add f-t f-t term-add ctx-empty f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-58 $p |- [] => ( ( t + ( t + t ) ) = ( t + ( t + t ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t arith-101 eq-add-cong f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-59 $p |- [] => ( ( t + ( t + ( t + t ) ) ) = ( t + ( t + ( t + t ) ) ) ) $=
 f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-58 eq-add-cong f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-60 $p |- [] => ( ( 1 + ( t + ( t + ( t + t ) ) ) ) = ( 1 + ( t + ( t + ( t + t ) ) ) ) ) $=
 term-one term-one f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty term-one ctx-empty eq-refl f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-61 $p term ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + ( t + t ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t f-t f-t f-t term-add term-add term-add term-mul $.
$}
${
syn-62 $p term ( ( ( 1 + ( 1 + 1 ) ) * 1 ) + ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + ( t + t ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-mul f-t syn-61 term-add $.
$}
${
dag-63 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( 1 + ( t + ( t + ( t + t ) ) ) ) ) = ( ( ( 1 + ( 1 + 1 ) ) * 1 ) + ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-53 f-t syn-53 f-t syn-62 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty dag-11 f-t dag-60 eq-mul-cong term-one term-one term-one term-add term-add term-one f-t f-t f-t f-t term-add term-add term-add ctx-empty ax-A8 eq-trans $.
$}
${
syn-64 $p term ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + t ) ) ) $=
 term-one term-one term-one term-add term-add f-t f-t f-t term-add term-add term-mul $.
$}
${
syn-65 $p term ( ( ( 1 + ( 1 + 1 ) ) * t ) + ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + t ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t term-mul f-t syn-64 term-add $.
$}
${
dag-66 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * t ) = ( ( t * 1 ) + ( t * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t term-mul term-one term-one term-one term-add term-add f-t term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t f-t ctx-empty dag-11 f-t ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-add term-add f-t term-mul f-t term-one term-one term-one term-add term-add term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add f-t ctx-empty ax-A5 f-t term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-105 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * t ) = ( t + ( t + t ) ) ) $=
 term-one term-one term-one term-add term-add f-t term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add f-t f-t f-t term-add term-add ctx-empty f-t dag-66 f-t dag-13 eq-trans $.
$}
${
syn-67 $p term ( ( ( 1 + ( 1 + 1 ) ) * t ) + ( ( 1 + ( 1 + 1 ) ) * ( t + t ) ) ) $=
 term-one term-one term-one term-add term-add f-t term-mul term-one term-one term-one term-add term-add f-t f-t term-add term-mul term-add $.
$}
${
syn-68 $p term ( ( ( 1 + ( 1 + 1 ) ) * t ) + ( ( 1 + ( 1 + 1 ) ) * t ) ) $=
 term-one term-one term-one term-add term-add f-t term-mul term-one term-one term-one term-add term-add f-t term-mul term-add $.
$}
${
dag-69 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( t + t ) ) = ( ( ( 1 + ( 1 + 1 ) ) * t ) + ( ( 1 + ( 1 + 1 ) ) * t ) ) ) $=
 term-one term-one term-one term-add term-add f-t f-t term-add term-mul term-one term-one term-one term-add term-add f-t f-t term-add term-mul f-t syn-68 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t f-t term-add f-t f-t term-add ctx-empty dag-11 f-t arith-101 eq-mul-cong term-one term-one term-one term-add term-add f-t f-t ctx-empty ax-A8 eq-trans $.
$}
${
dag-70 $p |- [] => ( ( ( t + ( t + t ) ) + ( t + ( t + t ) ) ) = ( ( t + ( t + t ) ) + ( t + ( t + t ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-71 $p term ( ( t + ( t + t ) ) + ( t + ( t + t ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add term-add $.
$}
${
syn-72 $p term ( t + ( ( t + t ) + ( t + ( t + t ) ) ) ) $=
 f-t f-t f-t term-add f-t f-t f-t term-add term-add term-add term-add $.
$}
${
dag-73 $p |- [] => ( ( ( t + t ) + ( t + ( t + t ) ) ) = ( ( t + t ) + ( t + ( t + t ) ) ) ) $=
 f-t f-t term-add f-t f-t term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-74 $p |- [] => ( ( t + ( t + ( t + ( t + t ) ) ) ) = ( t + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-75 $p |- [] => ( ( ( t + t ) + ( t + ( t + t ) ) ) = ( t + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t term-add f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t f-t term-add f-t f-t f-t term-add term-add term-add f-t f-t term-add f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t dag-73 f-t f-t f-t f-t f-t term-add term-add ctx-empty ax-A1 eq-trans f-t dag-74 eq-trans $.
$}
${
syn-76 $p term ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
dag-77 $p |- [] => ( ( ( t + ( t + t ) ) + ( t + ( t + t ) ) ) = ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-71 f-t syn-72 f-t syn-76 ctx-empty f-t syn-71 f-t syn-71 f-t syn-72 ctx-empty f-t dag-70 f-t f-t f-t term-add f-t f-t f-t term-add term-add ctx-empty ax-A1 eq-trans f-t f-t f-t f-t term-add f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-75 eq-add-cong eq-trans $.
$}
${
arith-106 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * t ) + ( ( 1 + ( 1 + 1 ) ) * t ) ) = ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-68 f-t syn-71 f-t syn-76 ctx-empty term-one term-one term-one term-add term-add f-t term-mul f-t f-t f-t term-add term-add term-one term-one term-one term-add term-add f-t term-mul f-t f-t f-t term-add term-add ctx-empty f-t arith-105 f-t arith-105 eq-add-cong f-t dag-77 eq-trans $.
$}
${
arith-107 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( t + t ) ) = ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t f-t term-add term-mul f-t syn-68 f-t syn-76 ctx-empty f-t dag-69 f-t arith-106 eq-trans $.
$}
${
dag-78 $p |- [] => ( ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) = ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add f-t syn-76 f-t syn-76 ctx-empty f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong $.
$}
${
syn-79 $p term ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t syn-76 term-add $.
$}
${
syn-80 $p term ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t f-t term-add f-t syn-76 term-add $.
$}
${
syn-81 $p term ( t + ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-80 term-add $.
$}
${
dag-82 $p |- [] => ( ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) = ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t term-add f-t f-t term-add f-t syn-76 f-t syn-76 ctx-empty f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong $.
$}
${
syn-83 $p term ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t f-t syn-76 term-add $.
$}
${
syn-84 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-83 term-add $.
$}
${
dag-85 $p |- [] => ( ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t syn-80 f-t syn-84 f-t syn-84 ctx-empty f-t syn-80 f-t syn-80 f-t syn-84 ctx-empty f-t dag-82 f-t f-t f-t syn-76 ctx-empty ax-A1 eq-trans f-t f-t f-t syn-83 f-t syn-83 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-76 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-86 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-84 term-add $.
$}
${
dag-87 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * t ) + ( ( 1 + ( 1 + 1 ) ) * ( t + t ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t syn-67 f-t syn-79 f-t syn-86 ctx-empty term-one term-one term-one term-add term-add f-t term-mul f-t f-t f-t term-add term-add term-one term-one term-one term-add term-add f-t f-t term-add term-mul f-t syn-76 ctx-empty f-t arith-105 f-t arith-107 eq-add-cong f-t syn-79 f-t syn-81 f-t syn-86 ctx-empty f-t syn-79 f-t syn-79 f-t syn-81 ctx-empty f-t dag-78 f-t f-t f-t term-add f-t syn-76 ctx-empty ax-A1 eq-trans f-t f-t f-t syn-80 f-t syn-84 ctx-empty f-t ctx-empty eq-refl f-t dag-85 eq-add-cong eq-trans eq-trans $.
$}
${
dag-88 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + t ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t syn-64 f-t syn-67 f-t syn-86 ctx-empty f-t syn-64 f-t syn-64 f-t syn-67 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty dag-11 f-t dag-58 eq-mul-cong term-one term-one term-one term-add term-add f-t f-t f-t term-add ctx-empty ax-A8 eq-trans f-t dag-87 eq-trans $.
$}
${
dag-89 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-84 f-t syn-84 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-83 f-t syn-83 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-76 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-90 $p term ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t syn-86 term-add $.
$}
${
syn-91 $p term ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t term-add f-t syn-86 term-add $.
$}
${
syn-92 $p term ( t + ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-91 term-add $.
$}
${
dag-93 $p |- [] => ( ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) = ( t + ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-90 f-t syn-90 f-t syn-92 ctx-empty f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add f-t syn-86 f-t syn-86 ctx-empty f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong f-t dag-89 eq-add-cong f-t f-t f-t term-add f-t syn-86 ctx-empty ax-A1 eq-trans $.
$}
${
syn-94 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-86 term-add $.
$}
${
syn-95 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-94 term-add $.
$}
${
dag-96 $p |- [] => ( ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-91 f-t syn-95 f-t syn-95 ctx-empty f-t syn-91 f-t syn-91 f-t syn-95 ctx-empty f-t f-t term-add f-t f-t term-add f-t syn-86 f-t syn-86 ctx-empty f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong f-t dag-89 eq-add-cong f-t f-t f-t syn-86 ctx-empty ax-A1 eq-trans f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-97 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-95 term-add $.
$}
${
dag-98 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * t ) + ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + t ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-65 f-t syn-90 f-t syn-97 ctx-empty term-one term-one term-one term-add term-add f-t term-mul f-t f-t f-t term-add term-add f-t syn-64 f-t syn-86 ctx-empty f-t arith-105 f-t dag-88 eq-add-cong f-t syn-90 f-t syn-92 f-t syn-97 ctx-empty f-t dag-93 f-t f-t f-t syn-91 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t dag-96 eq-add-cong eq-trans eq-trans $.
$}
${
dag-99 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + ( t + t ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-61 f-t syn-65 f-t syn-97 ctx-empty f-t syn-61 f-t syn-61 f-t syn-65 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty dag-11 f-t dag-59 eq-mul-cong term-one term-one term-one term-add term-add f-t f-t f-t f-t term-add term-add ctx-empty ax-A8 eq-trans f-t dag-98 eq-trans $.
$}
${
dag-100 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + ( 1 + 1 ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t syn-97 f-t syn-97 ctx-empty term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t f-t syn-95 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-101 $p term ( ( 1 + ( 1 + 1 ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t syn-97 term-add $.
$}
${
syn-102 $p term ( ( 1 + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-add f-t syn-97 term-add $.
$}
${
syn-103 $p term ( 1 + ( ( 1 + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-102 term-add $.
$}
${
dag-104 $p |- [] => ( ( ( 1 + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-add term-one term-one term-add f-t syn-97 f-t syn-97 ctx-empty term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong f-t f-t f-t syn-95 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-105 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-97 term-add $.
$}
${
syn-106 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-105 term-add $.
$}
${
dag-107 $p |- [] => ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-105 f-t syn-105 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-97 f-t syn-97 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-95 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-108 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-106 term-add $.
$}
${
dag-109 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-101 f-t syn-103 f-t syn-108 ctx-empty f-t syn-101 f-t syn-101 f-t syn-103 ctx-empty f-t dag-100 term-one term-one term-one term-add f-t syn-97 ctx-empty ax-A1 eq-trans term-one term-one f-t syn-102 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t syn-102 f-t syn-106 f-t syn-106 ctx-empty f-t syn-102 f-t syn-102 f-t syn-106 ctx-empty f-t dag-104 term-one term-one f-t syn-97 ctx-empty ax-A1 eq-trans f-t dag-107 eq-trans eq-add-cong eq-trans $.
$}
${
arith-112 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * 1 ) + ( ( 1 + ( 1 + 1 ) ) * ( t + ( t + ( t + t ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-62 f-t syn-101 f-t syn-108 ctx-empty term-one term-one term-one term-add term-add term-one term-mul term-one term-one term-one term-add term-add f-t syn-61 f-t syn-97 ctx-empty arith-100 f-t dag-99 eq-add-cong f-t dag-109 eq-trans $.
$}
${
arith-113 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( 1 + ( t + ( t + ( t + t ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-53 f-t syn-62 f-t syn-108 ctx-empty f-t dag-63 f-t arith-112 eq-trans $.
$}
${
dag-110 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + ( 1 + 1 ) ) + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t syn-108 f-t syn-108 ctx-empty term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong $.
$}
${
syn-111 $p term ( ( 1 + ( 1 + 1 ) ) + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t syn-108 term-add $.
$}
${
syn-112 $p term ( ( 1 + 1 ) + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-add f-t syn-108 term-add $.
$}
${
syn-113 $p term ( 1 + ( ( 1 + 1 ) + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-112 term-add $.
$}
${
syn-114 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-108 term-add $.
$}
${
syn-115 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-114 term-add $.
$}
${
dag-116 $p |- [] => ( ( ( 1 + 1 ) + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-112 f-t syn-112 f-t syn-115 ctx-empty term-one term-one term-add term-one term-one term-add f-t syn-108 f-t syn-108 ctx-empty term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong term-one term-one f-t syn-108 ctx-empty ax-A1 eq-trans $.
$}
${
dag-117 $p |- [] => ( ( 1 + ( ( 1 + 1 ) + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-112 f-t syn-115 ctx-empty term-one ctx-empty eq-refl f-t syn-112 f-t syn-115 f-t syn-115 ctx-empty f-t dag-116 term-one term-one f-t syn-114 f-t syn-114 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-108 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-118 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-115 term-add $.
$}
${
dag-119 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * 1 ) + ( ( 1 + ( 1 + 1 ) ) * ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-54 f-t syn-111 f-t syn-118 ctx-empty term-one term-one term-one term-add term-add term-one term-mul term-one term-one term-one term-add term-add f-t syn-53 f-t syn-108 ctx-empty arith-100 f-t arith-113 eq-add-cong f-t syn-111 f-t syn-113 f-t syn-118 ctx-empty f-t syn-111 f-t syn-111 f-t syn-113 ctx-empty f-t dag-110 term-one term-one term-one term-add f-t syn-108 ctx-empty ax-A1 eq-trans f-t dag-117 eq-trans eq-trans $.
$}
${
dag-120 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-51 f-t syn-54 f-t syn-118 ctx-empty f-t syn-51 f-t syn-52 f-t syn-54 ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add f-t syn-0 f-t syn-50 ctx-empty dag-6 f-t arith-96 eq-mul-cong term-one term-one term-one term-add term-add term-one term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty ax-A8 eq-trans f-t dag-119 eq-trans $.
$}
${
dag-121 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t syn-118 f-t syn-118 term-one term-one term-add term-one term-one term-add ctx-empty term-one term-one f-t syn-115 f-t syn-115 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-114 f-t syn-114 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-108 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-122 $p term ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-118 term-one term-one term-add term-add $.
$}
${
syn-123 $p term ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-115 term-one term-one term-add term-add $.
$}
${
syn-124 $p term ( 1 + ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 term-one f-t syn-123 term-add $.
$}
${
dag-125 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t syn-115 f-t syn-115 term-one term-one term-add term-one term-one term-add ctx-empty term-one term-one f-t syn-114 f-t syn-114 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-108 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-126 $p term ( ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-114 term-one term-one term-add term-add $.
$}
${
syn-127 $p term ( 1 + ( ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 term-one f-t syn-126 term-add $.
$}
${
syn-128 $p term ( ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-108 term-one term-one term-add term-add $.
$}
${
syn-129 $p term ( 1 + ( ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 term-one f-t syn-128 term-add $.
$}
${
dag-130 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) ) $=
 f-t syn-126 f-t syn-126 f-t syn-129 ctx-empty f-t syn-114 f-t syn-114 term-one term-one term-add term-one term-one term-add ctx-empty term-one term-one f-t syn-108 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong term-one f-t syn-108 term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
syn-131 $p term ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-106 term-one term-one term-add term-add $.
$}
${
syn-132 $p term ( 1 + ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 term-one f-t syn-131 term-add $.
$}
${
dag-133 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) ) $=
 f-t syn-128 f-t syn-128 f-t syn-132 ctx-empty f-t syn-108 f-t syn-108 term-one term-one term-add term-one term-one term-add ctx-empty term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong term-one f-t syn-106 term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
syn-134 $p term ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-105 term-one term-one term-add term-add $.
$}
${
syn-135 $p term ( 1 + ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 term-one f-t syn-134 term-add $.
$}
${
dag-136 $p |- [] => ( ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t syn-105 f-t syn-105 term-one term-one term-add term-one term-one term-add ctx-empty term-one term-one f-t syn-97 f-t syn-97 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-95 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-137 $p term ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-97 term-one term-one term-add term-add $.
$}
${
syn-138 $p term ( 1 + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 term-one f-t syn-137 term-add $.
$}
${
dag-139 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t syn-97 f-t syn-97 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t syn-95 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-140 $p term ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-95 term-one term-one term-add term-add $.
$}
${
syn-141 $p term ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-140 term-add $.
$}
${
syn-142 $p term ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-94 term-one term-one term-add term-add $.
$}
${
syn-143 $p term ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-142 term-add $.
$}
${
dag-144 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) ) $=
 f-t syn-140 f-t syn-140 f-t syn-143 ctx-empty f-t syn-95 f-t syn-95 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t syn-94 term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
syn-145 $p term ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-86 term-one term-one term-add term-add $.
$}
${
syn-146 $p term ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-145 term-add $.
$}
${
dag-147 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) ) $=
 f-t syn-142 f-t syn-142 f-t syn-146 ctx-empty f-t syn-94 f-t syn-94 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t syn-86 term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
syn-148 $p term ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-84 term-one term-one term-add term-add $.
$}
${
syn-149 $p term ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-148 term-add $.
$}
${
dag-150 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t syn-84 f-t syn-84 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t syn-83 f-t syn-83 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-76 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-151 $p term ( ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-83 term-one term-one term-add term-add $.
$}
${
syn-152 $p term ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-151 term-add $.
$}
${
dag-153 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) + ( 1 + 1 ) ) = ( ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t syn-83 f-t syn-83 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t syn-76 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-154 $p term ( ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-76 term-one term-one term-add term-add $.
$}
${
syn-155 $p term ( t + ( ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-154 term-add $.
$}
${
dag-156 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) + ( 1 + 1 ) ) = ( ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t syn-76 f-t syn-76 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-157 $p term ( ( t + ( t + ( t + ( t + t ) ) ) ) + ( 1 + 1 ) ) $=
 f-t f-t f-t f-t f-t term-add term-add term-add term-add term-one term-one term-add term-add $.
$}
${
syn-158 $p term ( t + ( ( t + ( t + ( t + ( t + t ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-157 term-add $.
$}
${
syn-159 $p term ( t + ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-t syn-17 term-add $.
$}
${
dag-160 $p |- [] => ( ( ( t + ( t + ( t + ( t + t ) ) ) ) + ( 1 + 1 ) ) = ( t + ( ( t + ( t + ( t + t ) ) ) + ( 1 + 1 ) ) ) ) $=
 f-t syn-157 f-t syn-157 f-t syn-159 ctx-empty f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add term-one term-one term-add term-one term-one term-add ctx-empty f-t dag-74 term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t f-t f-t f-t term-add term-add term-add term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
syn-161 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) $=
 f-t f-t syn-22 term-add $.
$}
${
syn-162 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) $=
 f-t f-t syn-161 term-add $.
$}
${
dag-163 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) + ( 1 + 1 ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) $=
 f-t syn-154 f-t syn-158 f-t syn-162 ctx-empty f-t syn-154 f-t syn-154 f-t syn-158 ctx-empty f-t dag-156 f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-t f-t syn-157 f-t syn-161 ctx-empty f-t ctx-empty eq-refl f-t syn-157 f-t syn-159 f-t syn-161 ctx-empty f-t dag-160 f-t f-t f-t syn-17 f-t syn-22 ctx-empty f-t ctx-empty eq-refl f-t dag-23 eq-add-cong eq-trans eq-add-cong eq-trans $.
$}
${
syn-164 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) $=
 f-t f-t syn-162 term-add $.
$}
${
syn-165 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-164 term-add $.
$}
${
dag-166 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-148 f-t syn-152 f-t syn-165 ctx-empty f-t syn-148 f-t syn-148 f-t syn-152 ctx-empty f-t dag-150 f-t f-t syn-83 term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-t f-t syn-151 f-t syn-164 ctx-empty f-t ctx-empty eq-refl f-t syn-151 f-t syn-155 f-t syn-164 ctx-empty f-t syn-151 f-t syn-151 f-t syn-155 ctx-empty f-t dag-153 f-t f-t syn-76 term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-t f-t syn-154 f-t syn-162 ctx-empty f-t ctx-empty eq-refl f-t dag-163 eq-add-cong eq-trans eq-add-cong eq-trans $.
$}
${
syn-167 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-165 term-add $.
$}
${
dag-168 $p |- [] => ( ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-145 f-t syn-149 f-t syn-167 ctx-empty f-t syn-145 f-t syn-145 f-t syn-149 ctx-empty f-t syn-86 f-t syn-86 term-one term-one term-add term-one term-one term-add ctx-empty f-t dag-89 term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t syn-84 term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-t f-t syn-148 f-t syn-165 ctx-empty f-t ctx-empty eq-refl f-t dag-166 eq-add-cong eq-trans $.
$}
${
syn-169 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-167 term-add $.
$}
${
syn-170 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-169 term-add $.
$}
${
dag-171 $p |- [] => ( ( t + ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-140 f-t syn-170 ctx-empty f-t ctx-empty eq-refl f-t syn-140 f-t syn-143 f-t syn-170 ctx-empty f-t dag-144 f-t f-t f-t syn-142 f-t syn-169 ctx-empty f-t ctx-empty eq-refl f-t syn-142 f-t syn-146 f-t syn-169 ctx-empty f-t dag-147 f-t f-t f-t syn-145 f-t syn-167 ctx-empty f-t ctx-empty eq-refl f-t dag-168 eq-add-cong eq-trans eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-172 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-170 term-add $.
$}
${
syn-173 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-172 term-add $.
$}
${
dag-174 $p |- [] => ( ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-134 f-t syn-138 f-t syn-173 ctx-empty f-t syn-134 f-t syn-134 f-t syn-138 ctx-empty f-t dag-136 term-one f-t syn-97 term-one term-one term-add ctx-empty ax-A1 eq-trans term-one term-one f-t syn-137 f-t syn-172 ctx-empty term-one ctx-empty eq-refl f-t syn-137 f-t syn-141 f-t syn-172 ctx-empty f-t syn-137 f-t syn-137 f-t syn-141 ctx-empty f-t dag-139 f-t f-t syn-95 term-one term-one term-add ctx-empty ax-A1 eq-trans f-t dag-171 eq-trans eq-add-cong eq-trans $.
$}
${
syn-175 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-173 term-add $.
$}
${
dag-176 $p |- [] => ( ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-131 f-t syn-135 f-t syn-175 ctx-empty f-t syn-131 f-t syn-131 f-t syn-135 ctx-empty f-t syn-106 f-t syn-106 term-one term-one term-add term-one term-one term-add ctx-empty f-t dag-107 term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong term-one f-t syn-105 term-one term-one term-add ctx-empty ax-A1 eq-trans term-one term-one f-t syn-134 f-t syn-173 ctx-empty term-one ctx-empty eq-refl f-t dag-174 eq-add-cong eq-trans $.
$}
${
syn-177 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-175 term-add $.
$}
${
syn-178 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-177 term-add $.
$}
${
dag-179 $p |- [] => ( ( 1 + ( ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-126 f-t syn-178 ctx-empty term-one ctx-empty eq-refl f-t syn-126 f-t syn-129 f-t syn-178 ctx-empty f-t dag-130 term-one term-one f-t syn-128 f-t syn-177 ctx-empty term-one ctx-empty eq-refl f-t syn-128 f-t syn-132 f-t syn-177 ctx-empty f-t dag-133 term-one term-one f-t syn-131 f-t syn-175 ctx-empty term-one ctx-empty eq-refl f-t dag-176 eq-add-cong eq-trans eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-180 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-178 term-add $.
$}
${
syn-181 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-180 term-add $.
$}
${
dag-182 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-124 f-t syn-181 ctx-empty f-t syn-122 f-t syn-122 f-t syn-124 ctx-empty f-t dag-121 term-one f-t syn-115 term-one term-one term-add ctx-empty ax-A1 eq-trans term-one term-one f-t syn-123 f-t syn-180 ctx-empty term-one ctx-empty eq-refl f-t syn-123 f-t syn-127 f-t syn-180 ctx-empty f-t syn-123 f-t syn-123 f-t syn-127 ctx-empty f-t dag-125 term-one f-t syn-114 term-one term-one term-add ctx-empty ax-A1 eq-trans f-t dag-179 eq-trans eq-add-cong eq-trans $.
$}
${
syn-183 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) $=
 f-t f-t syn-26 term-add $.
$}
${
syn-184 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) $=
 f-t f-t syn-183 term-add $.
$}
${
dag-185 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-162 f-t syn-184 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-161 f-t syn-183 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-22 f-t syn-26 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t term-one term-one term-add term-add term-add term-add f-t f-t term-one f-t term-one term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-25 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-186 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) $=
 f-t f-t syn-184 term-add $.
$}
${
syn-187 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-186 term-add $.
$}
${
syn-188 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-187 term-add $.
$}
${
syn-189 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-188 term-add $.
$}
${
syn-190 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-189 term-add $.
$}
${
dag-191 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-170 f-t syn-190 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-169 f-t syn-189 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-167 f-t syn-188 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-165 f-t syn-187 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-164 f-t syn-186 ctx-empty f-t ctx-empty eq-refl f-t dag-185 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-192 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-190 term-add $.
$}
${
syn-193 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-192 term-add $.
$}
${
syn-194 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-193 term-add $.
$}
${
syn-195 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-194 term-add $.
$}
${
syn-196 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-195 term-add $.
$}
${
dag-197 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-178 f-t syn-196 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-177 f-t syn-195 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-175 f-t syn-194 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-173 f-t syn-193 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-172 f-t syn-192 ctx-empty term-one ctx-empty eq-refl f-t dag-191 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-198 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-196 term-add $.
$}
${
syn-199 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-198 term-add $.
$}
${
syn-200 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) $=
 f-t f-t syn-28 term-add $.
$}
${
syn-201 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) $=
 f-t f-t syn-200 term-add $.
$}
${
dag-202 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-184 f-t syn-201 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-183 f-t syn-200 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-26 f-t syn-28 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-one f-t term-one term-add term-add term-add term-add f-t f-t term-one term-one f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-27 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-203 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-201 term-add $.
$}
${
syn-204 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-203 term-add $.
$}
${
syn-205 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-204 term-add $.
$}
${
syn-206 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-205 term-add $.
$}
${
syn-207 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-206 term-add $.
$}
${
dag-208 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-190 f-t syn-207 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-189 f-t syn-206 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-188 f-t syn-205 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-187 f-t syn-204 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-186 f-t syn-203 ctx-empty f-t ctx-empty eq-refl f-t dag-202 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-209 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-207 term-add $.
$}
${
syn-210 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-209 term-add $.
$}
${
syn-211 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-210 term-add $.
$}
${
syn-212 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-211 term-add $.
$}
${
syn-213 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-212 term-add $.
$}
${
dag-214 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-196 f-t syn-213 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-195 f-t syn-212 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-194 f-t syn-211 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-193 f-t syn-210 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-192 f-t syn-209 ctx-empty term-one ctx-empty eq-refl f-t dag-208 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-215 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-213 term-add $.
$}
${
syn-216 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-215 term-add $.
$}
${
syn-217 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) $=
 f-t f-t syn-32 term-add $.
$}
${
syn-218 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) $=
 f-t f-t syn-217 term-add $.
$}
${
dag-219 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-201 f-t syn-218 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-200 f-t syn-217 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-28 f-t syn-32 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-one term-one f-t term-add term-add term-add term-add f-t term-one f-t term-one f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-31 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-220 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-218 term-add $.
$}
${
syn-221 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-220 term-add $.
$}
${
syn-222 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-221 term-add $.
$}
${
syn-223 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-222 term-add $.
$}
${
syn-224 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-223 term-add $.
$}
${
dag-225 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-207 f-t syn-224 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-206 f-t syn-223 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-205 f-t syn-222 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-204 f-t syn-221 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-203 f-t syn-220 ctx-empty f-t ctx-empty eq-refl f-t dag-219 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-226 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-224 term-add $.
$}
${
syn-227 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-226 term-add $.
$}
${
syn-228 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-227 term-add $.
$}
${
syn-229 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-228 term-add $.
$}
${
syn-230 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-229 term-add $.
$}
${
dag-231 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-213 f-t syn-230 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-212 f-t syn-229 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-211 f-t syn-228 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-210 f-t syn-227 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-209 f-t syn-226 ctx-empty term-one ctx-empty eq-refl f-t dag-225 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-232 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-230 term-add $.
$}
${
syn-233 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-232 term-add $.
$}
${
dag-234 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-216 f-t syn-233 ctx-empty f-t syn-122 f-t syn-199 f-t syn-216 ctx-empty f-t syn-122 f-t syn-181 f-t syn-199 ctx-empty f-t dag-182 term-one term-one f-t syn-180 f-t syn-198 ctx-empty term-one ctx-empty eq-refl f-t dag-197 eq-add-cong eq-trans term-one term-one f-t syn-198 f-t syn-215 ctx-empty term-one ctx-empty eq-refl f-t dag-214 eq-add-cong eq-trans term-one term-one f-t syn-215 f-t syn-232 ctx-empty term-one ctx-empty eq-refl f-t dag-231 eq-add-cong eq-trans $.
$}
${
syn-235 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) $=
 f-t f-t syn-35 term-add $.
$}
${
syn-236 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-235 term-add $.
$}
${
dag-237 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-218 f-t syn-236 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-217 f-t syn-235 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-32 f-t syn-35 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t term-one f-t term-one f-t term-add term-add term-add term-add f-t term-one term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-34 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-238 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-236 term-add $.
$}
${
syn-239 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-238 term-add $.
$}
${
syn-240 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-239 term-add $.
$}
${
syn-241 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-240 term-add $.
$}
${
syn-242 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-241 term-add $.
$}
${
dag-243 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-224 f-t syn-242 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-223 f-t syn-241 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-222 f-t syn-240 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-221 f-t syn-239 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-220 f-t syn-238 ctx-empty f-t ctx-empty eq-refl f-t dag-237 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-244 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-242 term-add $.
$}
${
syn-245 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-244 term-add $.
$}
${
syn-246 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-245 term-add $.
$}
${
syn-247 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-246 term-add $.
$}
${
syn-248 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-247 term-add $.
$}
${
dag-249 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-230 f-t syn-248 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-229 f-t syn-247 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-228 f-t syn-246 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-227 f-t syn-245 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-226 f-t syn-244 ctx-empty term-one ctx-empty eq-refl f-t dag-243 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-250 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-248 term-add $.
$}
${
syn-251 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-250 term-add $.
$}
${
syn-252 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) $=
 f-t f-t syn-39 term-add $.
$}
${
syn-253 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-252 term-add $.
$}
${
syn-254 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-253 term-add $.
$}
${
syn-255 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-254 term-add $.
$}
${
dag-256 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-239 f-t syn-255 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-238 f-t syn-254 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-236 f-t syn-253 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-235 f-t syn-252 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-35 f-t syn-39 ctx-empty f-t ctx-empty eq-refl f-t dag-38 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-257 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-255 term-add $.
$}
${
syn-258 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-257 term-add $.
$}
${
syn-259 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-258 term-add $.
$}
${
syn-260 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-259 term-add $.
$}
${
syn-261 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-260 term-add $.
$}
${
dag-262 $p |- [] => ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-245 f-t syn-261 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-244 f-t syn-260 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-242 f-t syn-259 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-241 f-t syn-258 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-240 f-t syn-257 ctx-empty f-t ctx-empty eq-refl f-t dag-256 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-263 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-261 term-add $.
$}
${
syn-264 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-263 term-add $.
$}
${
syn-265 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-264 term-add $.
$}
${
syn-266 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-265 term-add $.
$}
${
syn-267 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-266 term-add $.
$}
${
dag-268 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-251 f-t syn-267 ctx-empty f-t syn-122 f-t syn-233 f-t syn-251 ctx-empty f-t dag-234 term-one term-one f-t syn-232 f-t syn-250 ctx-empty term-one ctx-empty eq-refl f-t dag-249 eq-add-cong eq-trans term-one term-one f-t syn-250 f-t syn-266 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-248 f-t syn-265 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-247 f-t syn-264 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-246 f-t syn-263 ctx-empty term-one ctx-empty eq-refl f-t dag-262 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-269 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) $=
 f-t f-t syn-42 term-add $.
$}
${
syn-270 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-269 term-add $.
$}
${
dag-271 $p |- [] => ( ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-253 f-t syn-270 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-252 f-t syn-269 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-39 f-t syn-42 ctx-empty f-t ctx-empty eq-refl f-t f-t term-one f-t term-one f-t f-t term-add term-add term-add term-add term-one term-one f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-41 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-272 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-270 term-add $.
$}
${
syn-273 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-272 term-add $.
$}
${
syn-274 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-273 term-add $.
$}
${
syn-275 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-274 term-add $.
$}
${
syn-276 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-275 term-add $.
$}
${
dag-277 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-259 f-t syn-276 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-258 f-t syn-275 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-257 f-t syn-274 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-255 f-t syn-273 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-254 f-t syn-272 ctx-empty f-t ctx-empty eq-refl f-t dag-271 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-278 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-276 term-add $.
$}
${
syn-279 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-278 term-add $.
$}
${
syn-280 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-279 term-add $.
$}
${
syn-281 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-280 term-add $.
$}
${
syn-282 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-281 term-add $.
$}
${
dag-283 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-265 f-t syn-282 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-264 f-t syn-281 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-263 f-t syn-280 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-261 f-t syn-279 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-260 f-t syn-278 ctx-empty term-one ctx-empty eq-refl f-t dag-277 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-284 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-282 term-add $.
$}
${
syn-285 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-284 term-add $.
$}
${
syn-286 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) $=
 f-t f-t syn-46 term-add $.
$}
${
syn-287 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-286 term-add $.
$}
${
dag-288 $p |- [] => ( ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-270 f-t syn-287 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-269 f-t syn-286 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-42 f-t syn-46 ctx-empty f-t ctx-empty eq-refl f-t syn-42 f-t syn-44 f-t syn-46 ctx-empty f-t dag-45 term-one f-t term-one f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-289 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-287 term-add $.
$}
${
syn-290 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-289 term-add $.
$}
${
syn-291 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-290 term-add $.
$}
${
syn-292 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-291 term-add $.
$}
${
syn-293 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-292 term-add $.
$}
${
dag-294 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-276 f-t syn-293 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-275 f-t syn-292 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-274 f-t syn-291 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-273 f-t syn-290 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-272 f-t syn-289 ctx-empty f-t ctx-empty eq-refl f-t dag-288 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-295 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-293 term-add $.
$}
${
syn-296 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-295 term-add $.
$}
${
syn-297 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-296 term-add $.
$}
${
syn-298 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-297 term-add $.
$}
${
syn-299 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-298 term-add $.
$}
${
dag-300 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-282 f-t syn-299 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-281 f-t syn-298 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-280 f-t syn-297 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-279 f-t syn-296 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-278 f-t syn-295 ctx-empty term-one ctx-empty eq-refl f-t dag-294 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-301 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-299 term-add $.
$}
${
syn-302 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-301 term-add $.
$}
${
syn-303 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t f-t syn-50 term-add $.
$}
${
syn-304 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-303 term-add $.
$}
${
syn-305 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-304 term-add $.
$}
${
syn-306 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-305 term-add $.
$}
${
dag-307 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-290 f-t syn-306 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-289 f-t syn-305 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-287 f-t syn-304 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-286 f-t syn-303 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-46 f-t syn-50 ctx-empty f-t ctx-empty eq-refl f-t dag-49 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-308 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-306 term-add $.
$}
${
syn-309 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-308 term-add $.
$}
${
syn-310 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-309 term-add $.
$}
${
syn-311 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-310 term-add $.
$}
${
syn-312 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-311 term-add $.
$}
${
dag-313 $p |- [] => ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-296 f-t syn-312 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-295 f-t syn-311 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-293 f-t syn-310 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-292 f-t syn-309 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-291 f-t syn-308 ctx-empty f-t ctx-empty eq-refl f-t dag-307 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-314 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-312 term-add $.
$}
${
syn-315 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-314 term-add $.
$}
${
syn-316 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-315 term-add $.
$}
${
syn-317 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-316 term-add $.
$}
${
syn-318 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-317 term-add $.
$}
${
dag-319 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-302 f-t syn-318 ctx-empty f-t syn-122 f-t syn-285 f-t syn-302 ctx-empty f-t syn-122 f-t syn-267 f-t syn-285 ctx-empty f-t dag-268 term-one term-one f-t syn-266 f-t syn-284 ctx-empty term-one ctx-empty eq-refl f-t dag-283 eq-add-cong eq-trans term-one term-one f-t syn-284 f-t syn-301 ctx-empty term-one ctx-empty eq-refl f-t dag-300 eq-add-cong eq-trans term-one term-one f-t syn-301 f-t syn-317 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-299 f-t syn-316 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-298 f-t syn-315 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-297 f-t syn-314 ctx-empty term-one ctx-empty eq-refl f-t dag-313 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-320 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t term-one term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
syn-321 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) $=
 term-one f-t term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
dag-322 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) = ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-303 f-t syn-320 f-t syn-321 ctx-empty f-t syn-320 f-t syn-303 ctx-empty f-t term-one term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t term-one ctx-empty ax-A2 term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-323 $p term ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t term-one f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
syn-324 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one f-t syn-323 term-add $.
$}
${
syn-325 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-324 term-add $.
$}
${
syn-326 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-325 term-add $.
$}
${
dag-327 $p |- [] => ( ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-305 f-t syn-326 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-304 f-t syn-325 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-303 f-t syn-324 ctx-empty f-t ctx-empty eq-refl f-t syn-303 f-t syn-321 f-t syn-324 ctx-empty f-t dag-322 term-one f-t term-one f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-328 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-326 term-add $.
$}
${
syn-329 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-328 term-add $.
$}
${
syn-330 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-329 term-add $.
$}
${
syn-331 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-330 term-add $.
$}
${
syn-332 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-331 term-add $.
$}
${
dag-333 $p |- [] => ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-311 f-t syn-332 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-310 f-t syn-331 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-309 f-t syn-330 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-308 f-t syn-329 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-306 f-t syn-328 ctx-empty f-t ctx-empty eq-refl f-t dag-327 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-334 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-332 term-add $.
$}
${
syn-335 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-334 term-add $.
$}
${
syn-336 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-335 term-add $.
$}
${
syn-337 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-336 term-add $.
$}
${
syn-338 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-337 term-add $.
$}
${
dag-339 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-317 f-t syn-338 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-316 f-t syn-337 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-315 f-t syn-336 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-314 f-t syn-335 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-312 f-t syn-334 ctx-empty term-one ctx-empty eq-refl f-t dag-333 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-340 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-338 term-add $.
$}
${
syn-341 $p term ( ( t + 1 ) + ( t + ( t + ( t + t ) ) ) ) $=
 f-t term-one term-add f-t f-t f-t f-t term-add term-add term-add term-add $.
$}
${
syn-342 $p term ( ( 1 + t ) + ( t + ( t + ( t + t ) ) ) ) $=
 term-one f-t term-add f-t f-t f-t f-t term-add term-add term-add term-add $.
$}
${
dag-343 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) = ( ( 1 + t ) + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t syn-323 f-t syn-341 f-t syn-342 ctx-empty f-t syn-341 f-t syn-323 ctx-empty f-t term-one f-t f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t term-one ctx-empty ax-A2 f-t f-t f-t f-t term-add term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-344 $p term ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) $=
 term-one f-t f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
syn-345 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one f-t syn-344 term-add $.
$}
${
syn-346 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-345 term-add $.
$}
${
dag-347 $p |- [] => ( ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-325 f-t syn-346 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-324 f-t syn-345 ctx-empty f-t ctx-empty eq-refl term-one term-one f-t syn-323 f-t syn-344 ctx-empty term-one ctx-empty eq-refl f-t syn-323 f-t syn-342 f-t syn-344 ctx-empty f-t dag-343 term-one f-t f-t f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-348 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-346 term-add $.
$}
${
syn-349 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-348 term-add $.
$}
${
syn-350 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-349 term-add $.
$}
${
syn-351 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-350 term-add $.
$}
${
syn-352 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-351 term-add $.
$}
${
dag-353 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-331 f-t syn-352 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-330 f-t syn-351 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-329 f-t syn-350 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-328 f-t syn-349 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-326 f-t syn-348 ctx-empty f-t ctx-empty eq-refl f-t dag-347 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-354 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-352 term-add $.
$}
${
syn-355 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-354 term-add $.
$}
${
syn-356 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-355 term-add $.
$}
${
syn-357 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-356 term-add $.
$}
${
syn-358 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-357 term-add $.
$}
${
dag-359 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-337 f-t syn-358 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-336 f-t syn-357 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-335 f-t syn-356 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-334 f-t syn-355 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-332 f-t syn-354 ctx-empty term-one ctx-empty eq-refl f-t dag-353 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-360 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-358 term-add $.
$}
${
syn-361 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-360 term-add $.
$}
${
syn-362 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-344 term-add $.
$}
${
syn-363 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-344 term-add $.
$}
${
syn-364 $p term ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t f-t syn-344 term-add $.
$}
${
syn-365 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 term-one f-t syn-364 term-add $.
$}
${
dag-366 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) = ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t syn-346 f-t syn-363 f-t syn-365 ctx-empty f-t syn-346 f-t syn-362 f-t syn-363 ctx-empty f-t syn-362 f-t syn-346 ctx-empty f-t term-one f-t syn-344 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-344 f-t syn-344 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-344 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-344 ctx-empty ax-A1 eq-trans $.
$}
${
syn-367 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-365 term-add $.
$}
${
syn-368 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-367 term-add $.
$}
${
syn-369 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-368 term-add $.
$}
${
syn-370 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-369 term-add $.
$}
${
dag-371 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-351 f-t syn-370 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-350 f-t syn-369 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-349 f-t syn-368 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-348 f-t syn-367 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-346 f-t syn-365 ctx-empty f-t ctx-empty eq-refl f-t dag-366 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-372 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-370 term-add $.
$}
${
syn-373 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-372 term-add $.
$}
${
syn-374 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-373 term-add $.
$}
${
syn-375 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-374 term-add $.
$}
${
syn-376 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-375 term-add $.
$}
${
dag-377 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-357 f-t syn-376 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-356 f-t syn-375 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-355 f-t syn-374 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-354 f-t syn-373 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-352 f-t syn-372 ctx-empty f-t ctx-empty eq-refl f-t dag-371 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-378 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-376 term-add $.
$}
${
syn-379 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-378 term-add $.
$}
${
syn-380 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-379 term-add $.
$}
${
dag-381 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-361 f-t syn-380 ctx-empty f-t syn-122 f-t syn-340 f-t syn-361 ctx-empty f-t syn-122 f-t syn-318 f-t syn-340 ctx-empty f-t dag-319 f-t dag-339 eq-trans term-one term-one f-t syn-338 f-t syn-360 ctx-empty term-one ctx-empty eq-refl f-t dag-359 eq-add-cong eq-trans term-one term-one f-t syn-360 f-t syn-379 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-358 f-t syn-378 ctx-empty term-one ctx-empty eq-refl f-t dag-377 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-382 $p term ( ( t + 1 ) + ( t + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t term-one term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
syn-383 $p term ( ( 1 + t ) + ( t + ( t + ( t + ( t + t ) ) ) ) ) $=
 term-one f-t term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add term-add $.
$}
${
dag-384 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) = ( ( 1 + t ) + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-364 f-t syn-382 f-t syn-383 ctx-empty f-t syn-382 f-t syn-364 ctx-empty f-t term-one f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t term-one ctx-empty ax-A2 f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-385 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one f-t syn-76 term-add $.
$}
${
syn-386 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 term-one f-t syn-385 term-add $.
$}
${
syn-387 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-386 term-add $.
$}
${
dag-388 $p |- [] => ( ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) = ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-367 f-t syn-387 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-365 f-t syn-386 ctx-empty f-t ctx-empty eq-refl term-one term-one f-t syn-364 f-t syn-385 ctx-empty term-one ctx-empty eq-refl f-t syn-364 f-t syn-383 f-t syn-385 ctx-empty f-t dag-384 term-one f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-389 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-387 term-add $.
$}
${
syn-390 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-389 term-add $.
$}
${
syn-391 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-390 term-add $.
$}
${
syn-392 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-391 term-add $.
$}
${
syn-393 $p term ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-392 term-add $.
$}
${
dag-394 $p |- [] => ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-373 f-t syn-393 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-372 f-t syn-392 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-370 f-t syn-391 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-369 f-t syn-390 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-368 f-t syn-389 ctx-empty f-t ctx-empty eq-refl f-t dag-388 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-395 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-393 term-add $.
$}
${
syn-396 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-395 term-add $.
$}
${
syn-397 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-396 term-add $.
$}
${
syn-398 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-397 term-add $.
$}
${
syn-399 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-398 term-add $.
$}
${
dag-400 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-379 f-t syn-399 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-378 f-t syn-398 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-376 f-t syn-397 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-375 f-t syn-396 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-374 f-t syn-395 ctx-empty term-one ctx-empty eq-refl f-t dag-394 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-401 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-399 term-add $.
$}
${
syn-402 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-385 term-add $.
$}
${
syn-403 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-385 term-add $.
$}
${
syn-404 $p term ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t f-t syn-385 term-add $.
$}
${
syn-405 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 term-one f-t syn-404 term-add $.
$}
${
dag-406 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t syn-387 f-t syn-403 f-t syn-405 ctx-empty f-t syn-387 f-t syn-402 f-t syn-403 ctx-empty f-t syn-402 f-t syn-387 ctx-empty f-t term-one f-t syn-385 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-385 f-t syn-385 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-385 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-385 ctx-empty ax-A1 eq-trans $.
$}
${
syn-407 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-405 term-add $.
$}
${
syn-408 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-407 term-add $.
$}
${
syn-409 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-408 term-add $.
$}
${
syn-410 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-409 term-add $.
$}
${
dag-411 $p |- [] => ( ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-392 f-t syn-410 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-391 f-t syn-409 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-390 f-t syn-408 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-389 f-t syn-407 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-387 f-t syn-405 ctx-empty f-t ctx-empty eq-refl f-t dag-406 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-412 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-410 term-add $.
$}
${
syn-413 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-412 term-add $.
$}
${
syn-414 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-413 term-add $.
$}
${
syn-415 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-414 term-add $.
$}
${
syn-416 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-415 term-add $.
$}
${
dag-417 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-398 f-t syn-416 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-397 f-t syn-415 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-396 f-t syn-414 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-395 f-t syn-413 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-393 f-t syn-412 ctx-empty term-one ctx-empty eq-refl f-t dag-411 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-418 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-416 term-add $.
$}
${
syn-419 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-418 term-add $.
$}
${
syn-420 $p term ( ( t + 1 ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-76 term-add $.
$}
${
syn-421 $p term ( ( 1 + t ) + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-76 term-add $.
$}
${
syn-422 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 term-one f-t syn-83 term-add $.
$}
${
dag-423 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t syn-404 f-t syn-421 f-t syn-422 ctx-empty f-t syn-404 f-t syn-420 f-t syn-421 ctx-empty f-t syn-420 f-t syn-404 ctx-empty f-t term-one f-t syn-76 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-76 f-t syn-76 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-76 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-76 ctx-empty ax-A1 eq-trans $.
$}
${
syn-424 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 term-one f-t syn-422 term-add $.
$}
${
syn-425 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-424 term-add $.
$}
${
syn-426 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-425 term-add $.
$}
${
syn-427 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-426 term-add $.
$}
${
dag-428 $p |- [] => ( ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-409 f-t syn-427 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-408 f-t syn-426 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-407 f-t syn-425 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-405 f-t syn-424 ctx-empty f-t ctx-empty eq-refl term-one term-one f-t syn-404 f-t syn-422 ctx-empty term-one ctx-empty eq-refl f-t dag-423 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-429 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-427 term-add $.
$}
${
syn-430 $p term ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-429 term-add $.
$}
${
syn-431 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-430 term-add $.
$}
${
syn-432 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-431 term-add $.
$}
${
syn-433 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-432 term-add $.
$}
${
dag-434 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-415 f-t syn-433 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-414 f-t syn-432 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-413 f-t syn-431 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-412 f-t syn-430 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-410 f-t syn-429 ctx-empty f-t ctx-empty eq-refl f-t dag-428 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-435 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-433 term-add $.
$}
${
syn-436 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-435 term-add $.
$}
${
syn-437 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-436 term-add $.
$}
${
dag-438 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-419 f-t syn-437 ctx-empty f-t syn-122 f-t syn-401 f-t syn-419 ctx-empty f-t syn-122 f-t syn-380 f-t syn-401 ctx-empty f-t dag-381 f-t dag-400 eq-trans term-one term-one f-t syn-399 f-t syn-418 ctx-empty term-one ctx-empty eq-refl f-t dag-417 eq-add-cong eq-trans term-one term-one f-t syn-418 f-t syn-436 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-416 f-t syn-435 ctx-empty term-one ctx-empty eq-refl f-t dag-434 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-439 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-422 term-add $.
$}
${
syn-440 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-422 term-add $.
$}
${
syn-441 $p term ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t syn-422 term-add $.
$}
${
syn-442 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-441 term-add $.
$}
${
dag-443 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-425 f-t syn-440 f-t syn-442 ctx-empty f-t syn-425 f-t syn-439 f-t syn-440 ctx-empty f-t syn-439 f-t syn-425 ctx-empty f-t term-one f-t syn-422 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-422 f-t syn-422 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-422 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-422 ctx-empty ax-A1 eq-trans $.
$}
${
syn-444 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-442 term-add $.
$}
${
syn-445 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-444 term-add $.
$}
${
syn-446 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-445 term-add $.
$}
${
syn-447 $p term ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-446 term-add $.
$}
${
dag-448 $p |- [] => ( ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-430 f-t syn-447 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-429 f-t syn-446 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-427 f-t syn-445 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-426 f-t syn-444 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-425 f-t syn-442 ctx-empty f-t ctx-empty eq-refl f-t dag-443 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-449 $p term ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-447 term-add $.
$}
${
syn-450 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-449 term-add $.
$}
${
syn-451 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-450 term-add $.
$}
${
syn-452 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-451 term-add $.
$}
${
syn-453 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-452 term-add $.
$}
${
dag-454 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-436 f-t syn-453 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-435 f-t syn-452 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-433 f-t syn-451 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-432 f-t syn-450 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-431 f-t syn-449 ctx-empty term-one ctx-empty eq-refl f-t dag-448 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-455 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-453 term-add $.
$}
${
syn-456 $p term ( ( t + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-83 term-add $.
$}
${
syn-457 $p term ( ( 1 + t ) + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-83 term-add $.
$}
${
syn-458 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 term-one f-t syn-84 term-add $.
$}
${
dag-459 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t syn-441 f-t syn-457 f-t syn-458 ctx-empty f-t syn-441 f-t syn-456 f-t syn-457 ctx-empty f-t syn-456 f-t syn-441 ctx-empty f-t term-one f-t syn-83 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-83 f-t syn-83 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-83 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-83 ctx-empty ax-A1 eq-trans $.
$}
${
syn-460 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-458 term-add $.
$}
${
syn-461 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-460 term-add $.
$}
${
syn-462 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-461 term-add $.
$}
${
syn-463 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-462 term-add $.
$}
${
dag-464 $p |- [] => ( ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-446 f-t syn-463 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-445 f-t syn-462 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-444 f-t syn-461 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-442 f-t syn-460 ctx-empty f-t ctx-empty eq-refl term-one term-one f-t syn-441 f-t syn-458 ctx-empty term-one ctx-empty eq-refl f-t dag-459 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-465 $p term ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-463 term-add $.
$}
${
syn-466 $p term ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-465 term-add $.
$}
${
syn-467 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-466 term-add $.
$}
${
syn-468 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-467 term-add $.
$}
${
syn-469 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-468 term-add $.
$}
${
dag-470 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-452 f-t syn-469 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-451 f-t syn-468 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-450 f-t syn-467 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-449 f-t syn-466 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-447 f-t syn-465 ctx-empty term-one ctx-empty eq-refl f-t dag-464 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-471 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-469 term-add $.
$}
${
syn-472 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-471 term-add $.
$}
${
syn-473 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-458 term-add $.
$}
${
syn-474 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-458 term-add $.
$}
${
syn-475 $p term ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-458 term-add $.
$}
${
syn-476 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-475 term-add $.
$}
${
dag-477 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-461 f-t syn-474 f-t syn-476 ctx-empty f-t syn-461 f-t syn-473 f-t syn-474 ctx-empty f-t syn-473 f-t syn-461 ctx-empty f-t term-one f-t syn-458 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-458 f-t syn-458 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-458 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-458 ctx-empty ax-A1 eq-trans $.
$}
${
syn-478 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-476 term-add $.
$}
${
syn-479 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-478 term-add $.
$}
${
syn-480 $p term ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-479 term-add $.
$}
${
syn-481 $p term ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-480 term-add $.
$}
${
dag-482 $p |- [] => ( ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-466 f-t syn-481 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-465 f-t syn-480 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-463 f-t syn-479 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-462 f-t syn-478 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-461 f-t syn-476 ctx-empty f-t ctx-empty eq-refl f-t dag-477 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-483 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-481 term-add $.
$}
${
syn-484 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-483 term-add $.
$}
${
syn-485 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-484 term-add $.
$}
${
syn-486 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-485 term-add $.
$}
${
syn-487 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-486 term-add $.
$}
${
dag-488 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-472 f-t syn-487 ctx-empty f-t syn-122 f-t syn-455 f-t syn-472 ctx-empty f-t syn-122 f-t syn-437 f-t syn-455 ctx-empty f-t dag-438 f-t dag-454 eq-trans term-one term-one f-t syn-453 f-t syn-471 ctx-empty term-one ctx-empty eq-refl f-t dag-470 eq-add-cong eq-trans term-one term-one f-t syn-471 f-t syn-486 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-469 f-t syn-485 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-468 f-t syn-484 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-467 f-t syn-483 ctx-empty term-one ctx-empty eq-refl f-t dag-482 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-489 $p term ( ( t + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-84 term-add $.
$}
${
syn-490 $p term ( ( 1 + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-84 term-add $.
$}
${
syn-491 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-86 term-add $.
$}
${
dag-492 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-475 f-t syn-490 f-t syn-491 ctx-empty f-t syn-475 f-t syn-489 f-t syn-490 ctx-empty f-t syn-489 f-t syn-475 ctx-empty f-t term-one f-t syn-84 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-84 f-t syn-84 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-84 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-84 ctx-empty ax-A1 eq-trans $.
$}
${
syn-493 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-491 term-add $.
$}
${
syn-494 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-493 term-add $.
$}
${
syn-495 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-494 term-add $.
$}
${
syn-496 $p term ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-495 term-add $.
$}
${
dag-497 $p |- [] => ( ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-480 f-t syn-496 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-479 f-t syn-495 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-478 f-t syn-494 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-476 f-t syn-493 ctx-empty f-t ctx-empty eq-refl term-one term-one f-t syn-475 f-t syn-491 ctx-empty term-one ctx-empty eq-refl f-t dag-492 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-498 $p term ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-496 term-add $.
$}
${
syn-499 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-498 term-add $.
$}
${
syn-500 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-499 term-add $.
$}
${
syn-501 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-500 term-add $.
$}
${
syn-502 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-501 term-add $.
$}
${
dag-503 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-486 f-t syn-502 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-485 f-t syn-501 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-484 f-t syn-500 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-483 f-t syn-499 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-481 f-t syn-498 ctx-empty term-one ctx-empty eq-refl f-t dag-497 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-504 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-502 term-add $.
$}
${
syn-505 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-491 term-add $.
$}
${
syn-506 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-491 term-add $.
$}
${
syn-507 $p term ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-491 term-add $.
$}
${
syn-508 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-507 term-add $.
$}
${
dag-509 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-494 f-t syn-506 f-t syn-508 ctx-empty f-t syn-494 f-t syn-505 f-t syn-506 ctx-empty f-t syn-505 f-t syn-494 ctx-empty f-t term-one f-t syn-491 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-491 f-t syn-491 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-491 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-491 ctx-empty ax-A1 eq-trans $.
$}
${
syn-510 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-508 term-add $.
$}
${
syn-511 $p term ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-510 term-add $.
$}
${
syn-512 $p term ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-511 term-add $.
$}
${
syn-513 $p term ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-512 term-add $.
$}
${
dag-514 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-499 f-t syn-513 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-498 f-t syn-512 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-496 f-t syn-511 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-495 f-t syn-510 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-494 f-t syn-508 ctx-empty f-t ctx-empty eq-refl f-t dag-509 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-515 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-513 term-add $.
$}
${
syn-516 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-515 term-add $.
$}
${
syn-517 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-516 term-add $.
$}
${
syn-518 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-517 term-add $.
$}
${
dag-519 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-504 f-t syn-518 ctx-empty f-t syn-122 f-t syn-487 f-t syn-504 ctx-empty f-t dag-488 f-t dag-503 eq-trans term-one term-one f-t syn-502 f-t syn-517 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-501 f-t syn-516 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-500 f-t syn-515 ctx-empty term-one ctx-empty eq-refl f-t dag-514 eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-520 $p term ( ( t + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-86 term-add $.
$}
${
syn-521 $p term ( ( 1 + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-86 term-add $.
$}
${
syn-522 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-94 term-add $.
$}
${
dag-523 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-507 f-t syn-521 f-t syn-522 ctx-empty f-t syn-507 f-t syn-520 f-t syn-521 ctx-empty f-t syn-520 f-t syn-507 ctx-empty f-t term-one f-t syn-86 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-86 f-t syn-86 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-86 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-86 ctx-empty ax-A1 eq-trans $.
$}
${
syn-524 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-522 term-add $.
$}
${
syn-525 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-524 term-add $.
$}
${
syn-526 $p term ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-525 term-add $.
$}
${
syn-527 $p term ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-526 term-add $.
$}
${
dag-528 $p |- [] => ( ( 1 + ( 1 + ( t + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-512 f-t syn-527 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-511 f-t syn-526 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-510 f-t syn-525 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-508 f-t syn-524 ctx-empty f-t ctx-empty eq-refl term-one term-one f-t syn-507 f-t syn-522 ctx-empty term-one ctx-empty eq-refl f-t dag-523 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-529 $p term ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-527 term-add $.
$}
${
syn-530 $p term ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-529 term-add $.
$}
${
syn-531 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-530 term-add $.
$}
${
syn-532 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-531 term-add $.
$}
${
syn-533 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-532 term-add $.
$}
${
dag-534 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-518 f-t syn-533 ctx-empty f-t dag-519 term-one term-one f-t syn-517 f-t syn-532 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-516 f-t syn-531 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-515 f-t syn-530 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-513 f-t syn-529 ctx-empty term-one ctx-empty eq-refl f-t dag-528 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-535 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-522 term-add $.
$}
${
syn-536 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-522 term-add $.
$}
${
syn-537 $p term ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-522 term-add $.
$}
${
syn-538 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-537 term-add $.
$}
${
dag-539 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-525 f-t syn-536 f-t syn-538 ctx-empty f-t syn-525 f-t syn-535 f-t syn-536 ctx-empty f-t syn-535 f-t syn-525 ctx-empty f-t term-one f-t syn-522 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-522 f-t syn-522 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-522 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-522 ctx-empty ax-A1 eq-trans $.
$}
${
syn-540 $p term ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-538 term-add $.
$}
${
syn-541 $p term ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-540 term-add $.
$}
${
syn-542 $p term ( 1 + ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-541 term-add $.
$}
${
syn-543 $p term ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-542 term-add $.
$}
${
dag-544 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-530 f-t syn-543 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-529 f-t syn-542 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-527 f-t syn-541 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-526 f-t syn-540 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-525 f-t syn-538 ctx-empty f-t ctx-empty eq-refl f-t dag-539 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-545 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-543 term-add $.
$}
${
syn-546 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-545 term-add $.
$}
${
syn-547 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-546 term-add $.
$}
${
syn-548 $p term ( ( t + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-94 term-add $.
$}
${
syn-549 $p term ( ( 1 + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-94 term-add $.
$}
${
syn-550 $p term ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-95 term-add $.
$}
${
dag-551 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-537 f-t syn-549 f-t syn-550 ctx-empty f-t syn-537 f-t syn-548 f-t syn-549 ctx-empty f-t syn-548 f-t syn-537 ctx-empty f-t term-one f-t syn-94 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-94 f-t syn-94 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-94 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-94 ctx-empty ax-A1 eq-trans $.
$}
${
syn-552 $p term ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-550 term-add $.
$}
${
syn-553 $p term ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-552 term-add $.
$}
${
syn-554 $p term ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-553 term-add $.
$}
${
syn-555 $p term ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-554 term-add $.
$}
${
dag-556 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-542 f-t syn-555 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-541 f-t syn-554 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-540 f-t syn-553 ctx-empty term-one ctx-empty eq-refl f-t f-t f-t syn-538 f-t syn-552 ctx-empty f-t ctx-empty eq-refl term-one term-one f-t syn-537 f-t syn-550 ctx-empty term-one ctx-empty eq-refl f-t dag-551 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-557 $p term ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-555 term-add $.
$}
${
syn-558 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-557 term-add $.
$}
${
syn-559 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-558 term-add $.
$}
${
syn-560 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-559 term-add $.
$}
${
dag-561 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-547 f-t syn-560 ctx-empty f-t syn-122 f-t syn-533 f-t syn-547 ctx-empty f-t dag-534 term-one term-one f-t syn-532 f-t syn-546 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-531 f-t syn-545 ctx-empty term-one ctx-empty eq-refl f-t dag-544 eq-add-cong eq-add-cong eq-trans term-one term-one f-t syn-546 f-t syn-559 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-545 f-t syn-558 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-543 f-t syn-557 ctx-empty term-one ctx-empty eq-refl f-t dag-556 eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-562 $p term ( ( t + 1 ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-550 term-add $.
$}
${
syn-563 $p term ( ( 1 + t ) + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-550 term-add $.
$}
${
syn-564 $p term ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-550 term-add $.
$}
${
syn-565 $p term ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-564 term-add $.
$}
${
dag-566 $p |- [] => ( ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-553 f-t syn-563 f-t syn-565 ctx-empty f-t syn-553 f-t syn-562 f-t syn-563 ctx-empty f-t syn-562 f-t syn-553 ctx-empty f-t term-one f-t syn-550 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-550 f-t syn-550 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-550 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-550 ctx-empty ax-A1 eq-trans $.
$}
${
syn-567 $p term ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-565 term-add $.
$}
${
syn-568 $p term ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-567 term-add $.
$}
${
syn-569 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-568 term-add $.
$}
${
syn-570 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-569 term-add $.
$}
${
dag-571 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-558 f-t syn-570 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-557 f-t syn-569 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-555 f-t syn-568 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-554 f-t syn-567 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-553 f-t syn-565 ctx-empty term-one ctx-empty eq-refl f-t dag-566 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-572 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-570 term-add $.
$}
${
syn-573 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-572 term-add $.
$}
${
syn-574 $p term ( ( t + 1 ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t term-one term-add f-t syn-95 term-add $.
$}
${
syn-575 $p term ( ( 1 + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t term-add f-t syn-95 term-add $.
$}
${
dag-576 $p |- [] => ( ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-564 f-t syn-575 f-t syn-105 ctx-empty f-t syn-564 f-t syn-574 f-t syn-575 ctx-empty f-t syn-574 f-t syn-564 ctx-empty f-t term-one f-t syn-95 ctx-empty ax-A1 eq-sym f-t term-one term-add term-one f-t term-add f-t syn-95 f-t syn-95 ctx-empty f-t term-one ctx-empty ax-A2 f-t syn-95 ctx-empty eq-refl eq-add-cong eq-trans term-one f-t f-t syn-95 ctx-empty ax-A1 eq-trans $.
$}
${
dag-577 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-t syn-569 f-t syn-115 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-568 f-t syn-114 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-567 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-565 f-t syn-106 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-564 f-t syn-105 ctx-empty term-one ctx-empty eq-refl f-t dag-576 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-578 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-118 term-add $.
$}
${
syn-579 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-578 term-add $.
$}
${
dag-580 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-122 f-t syn-573 f-t syn-579 ctx-empty f-t syn-122 f-t syn-560 f-t syn-573 ctx-empty f-t dag-561 term-one term-one f-t syn-559 f-t syn-572 ctx-empty term-one ctx-empty eq-refl f-t dag-571 eq-add-cong eq-trans term-one term-one f-t syn-572 f-t syn-578 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-570 f-t syn-118 ctx-empty term-one ctx-empty eq-refl f-t dag-577 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-581 $p term ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) + ( 1 + 1 ) ) $=
 f-t syn-51 term-one term-one term-add term-add $.
$}
${
arith-116 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-581 f-t syn-122 f-t syn-579 ctx-empty f-t syn-51 f-t syn-118 term-one term-one term-add term-one term-one term-add ctx-empty f-t dag-120 arith-85 eq-add-cong f-t dag-580 eq-trans $.
$}
${
dag-582 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * t ) = ( ( t * 1 ) + ( t * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-one term-add term-add f-t term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add f-t f-t ctx-empty dag-6 f-t ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-add term-add f-t term-mul f-t term-one term-one term-one term-add term-add term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add f-t ctx-empty ax-A5 f-t term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-117 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * t ) = ( t + ( t + t ) ) ) $=
 term-one term-one term-add term-one term-add f-t term-mul f-t term-one term-mul f-t term-one term-one term-add term-mul term-add f-t f-t f-t term-add term-add ctx-empty f-t dag-582 f-t dag-13 eq-trans $.
$}
${
dag-583 $p |- [] => ( ( ( t + ( t + t ) ) + ( 1 + 1 ) ) = ( t + ( t + ( 1 + ( 1 + t ) ) ) ) ) $=
 f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t f-t term-one f-t term-one term-add term-add term-add term-add f-t f-t term-one term-one f-t term-add term-add term-add term-add ctx-empty f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t f-t f-t term-one term-one term-add term-add term-add term-add f-t f-t term-one f-t term-one term-add term-add term-add term-add ctx-empty f-t dag-21 f-t dag-25 eq-trans f-t dag-27 eq-trans $.
$}
${
dag-584 $p |- [] => ( ( ( t + ( t + t ) ) + ( 1 + 1 ) ) = ( t + ( 1 + ( 1 + ( t + t ) ) ) ) ) $=
 f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t term-one f-t term-one f-t term-add term-add term-add term-add f-t term-one term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t f-t term-one term-one f-t term-add term-add term-add term-add f-t term-one f-t term-one f-t term-add term-add term-add term-add ctx-empty f-t dag-583 f-t dag-31 eq-trans f-t dag-34 eq-trans $.
$}
${
dag-585 $p |- [] => ( ( ( t + ( t + t ) ) + ( 1 + 1 ) ) = ( 1 + ( t + ( 1 + ( t + t ) ) ) ) ) $=
 f-t f-t f-t term-add term-add term-one term-one term-add term-add f-t term-one term-one f-t f-t term-add term-add term-add term-add term-one f-t term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t dag-584 f-t term-one term-one f-t f-t term-add term-add term-add term-add term-one f-t term-add term-one f-t f-t term-add term-add term-add term-one f-t term-one f-t f-t term-add term-add term-add term-add ctx-empty f-t dag-37 term-one f-t term-one f-t f-t term-add term-add ctx-empty ax-A1 eq-trans eq-trans $.
$}
${
syn-586 $p term ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) $=
 term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add term-add $.
$}
${
dag-587 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) = ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) $=
 f-t syn-586 f-t f-t f-t term-add term-add term-one term-one term-add term-add term-one term-one f-t f-t f-t term-add term-add term-add term-add ctx-empty term-one term-one term-add term-one term-add f-t term-mul f-t f-t f-t term-add term-add term-one term-one term-add term-one term-one term-add ctx-empty f-t arith-117 arith-85 eq-add-cong f-t f-t f-t term-add term-add term-one term-one term-add term-add term-one f-t term-one f-t f-t term-add term-add term-add term-add term-one term-one f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t dag-585 f-t dag-41 eq-trans eq-trans $.
$}
${
syn-588 $p term ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) $=
 term-one term-one term-add term-one term-add term-one term-add f-t syn-586 term-mul $.
$}
${
syn-589 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( 1 + ( t + ( t + t ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-one f-t f-t f-t term-add term-add term-add term-add term-mul $.
$}
${
syn-590 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( t + ( t + t ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one f-t f-t f-t term-add term-add term-add term-mul $.
$}
${
syn-591 $p term ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( t + ( t + t ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-mul f-t syn-590 term-add $.
$}
${
dag-592 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) = ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-588 f-t syn-589 f-t syn-591 ctx-empty term-one term-one term-add term-one term-add term-one term-add term-one term-one term-one term-one term-add term-add term-add f-t syn-586 term-one term-one f-t f-t f-t term-add term-add term-add term-add ctx-empty dag-8 f-t dag-587 eq-mul-cong term-one term-one term-one term-one term-add term-add term-add term-one term-one f-t f-t f-t term-add term-add term-add ctx-empty ax-A8 eq-trans $.
$}
${
dag-593 $p |- [] => ( ( 1 + ( 1 + ( 1 + 1 ) ) ) = ( 1 + ( 1 + ( 1 + 1 ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add ctx-empty term-one term-one term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl dag-11 eq-add-cong term-one term-one term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-594 $p term ( ( 1 * 1 ) + ( 1 * ( 1 + ( 1 + 1 ) ) ) ) $=
 term-one term-one term-mul term-one term-one term-one term-one term-add term-add term-mul term-add $.
$}
${
dag-595 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) = ( ( 1 * 1 ) + ( 1 * ( 1 + ( 1 + 1 ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-mul term-one term-one term-one term-one term-add term-add term-add term-one term-mul syn-594 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add term-one term-one ctx-empty dag-593 term-one ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-one term-add term-add term-add term-one term-mul term-one term-one term-one term-one term-one term-add term-add term-add term-mul syn-594 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one ctx-empty ax-A5 term-one term-one term-one term-one term-one term-add term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
dag-596 $p |- [] => ( ( 1 * ( 1 + ( 1 + 1 ) ) ) = ( 1 + ( 1 + 1 ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-mul term-one term-one term-mul term-one term-one term-one term-add term-mul term-add term-one term-one term-one term-add term-add ctx-empty term-one term-one term-one term-one term-add term-add term-mul term-one term-one term-one term-one term-add term-add term-mul term-one term-one term-mul term-one term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl dag-11 eq-mul-cong term-one term-one term-one term-one term-add ctx-empty ax-A8 eq-trans dag-57 eq-trans $.
$}
${
dag-597 $p |- [] => ( ( ( 1 * 1 ) + ( 1 * ( 1 + ( 1 + 1 ) ) ) ) = ( 1 + ( 1 + ( 1 + 1 ) ) ) ) $=
 syn-594 term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add ctx-empty term-one term-one term-mul term-one term-one term-one term-one term-one term-add term-add term-mul term-one term-one term-one term-add term-add ctx-empty arith-6 dag-596 eq-add-cong term-one term-one term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
arith-122 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) = ( 1 + ( 1 + ( 1 + 1 ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-mul syn-594 term-one term-one term-one term-one term-add term-add term-add ctx-empty dag-595 dag-597 eq-trans $.
$}
${
dag-598 $p |- [] => ( ( 1 + ( t + ( t + t ) ) ) = ( 1 + ( t + ( t + t ) ) ) ) $=
 term-one f-t f-t f-t term-add term-add term-add term-one f-t f-t f-t term-add term-add term-add term-one f-t f-t f-t term-add term-add term-add ctx-empty term-one term-one f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty term-one ctx-empty eq-refl f-t dag-58 eq-add-cong term-one term-one f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty term-one ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-599 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + ( t + t ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t f-t f-t term-add term-add term-mul $.
$}
${
syn-600 $p term ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + ( t + t ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-mul f-t syn-599 term-add $.
$}
${
dag-601 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( t + ( t + t ) ) ) ) = ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + ( t + t ) ) ) ) ) $=
 f-t syn-590 f-t syn-590 f-t syn-600 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add term-one f-t f-t f-t term-add term-add term-add term-one f-t f-t f-t term-add term-add term-add ctx-empty dag-593 f-t dag-598 eq-mul-cong term-one term-one term-one term-one term-add term-add term-add term-one f-t f-t f-t term-add term-add ctx-empty ax-A8 eq-trans $.
$}
${
syn-602 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + t ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t f-t term-add term-mul $.
$}
${
syn-603 $p term ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + t ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t syn-602 term-add $.
$}
${
dag-604 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) = ( ( t * 1 ) + ( t * ( 1 + ( 1 + 1 ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t term-mul term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t syn-9 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-t f-t ctx-empty dag-593 f-t ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t term-one term-one term-one term-one term-add term-add term-add term-mul f-t syn-9 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-t ctx-empty ax-A5 f-t term-one term-one term-one term-one term-add term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-124 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) = ( t + ( t + ( t + t ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t syn-9 f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t dag-604 f-t dag-15 eq-trans $.
$}
${
syn-605 $p term ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t term-mul term-one term-one term-one term-one term-add term-add term-add f-t term-mul term-add $.
$}
${
dag-606 $p |- [] => ( ( ( t + ( t + ( t + t ) ) ) + ( t + ( t + ( t + t ) ) ) ) = ( ( t + ( t + ( t + t ) ) ) + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-607 $p term ( ( t + ( t + ( t + t ) ) ) + ( t + ( t + ( t + t ) ) ) ) $=
 f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add term-add $.
$}
${
syn-608 $p term ( ( t + ( t + t ) ) + ( t + ( t + ( t + t ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t f-t term-add term-add term-add term-add $.
$}
${
syn-609 $p term ( t + ( ( t + ( t + t ) ) + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t syn-608 term-add $.
$}
${
dag-610 $p |- [] => ( ( ( t + ( t + t ) ) + ( t + ( t + ( t + t ) ) ) ) = ( ( t + ( t + t ) ) + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-611 $p term ( ( t + t ) + ( t + ( t + ( t + t ) ) ) ) $=
 f-t f-t term-add f-t f-t f-t f-t term-add term-add term-add term-add $.
$}
${
syn-612 $p term ( t + ( ( t + t ) + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t syn-611 term-add $.
$}
${
dag-613 $p |- [] => ( ( ( t + t ) + ( t + ( t + ( t + t ) ) ) ) = ( ( t + t ) + ( t + ( t + ( t + t ) ) ) ) ) $=
 f-t f-t term-add f-t f-t term-add f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-614 $p |- [] => ( ( ( t + t ) + ( t + ( t + ( t + t ) ) ) ) = ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) $=
 f-t syn-611 f-t syn-76 f-t syn-76 ctx-empty f-t syn-611 f-t syn-611 f-t syn-76 ctx-empty f-t dag-613 f-t f-t f-t f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-trans f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-trans $.
$}
${
dag-615 $p |- [] => ( ( t + ( ( t + ( t + t ) ) + ( t + ( t + ( t + t ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t f-t syn-608 f-t syn-83 ctx-empty f-t ctx-empty eq-refl f-t syn-608 f-t syn-612 f-t syn-83 ctx-empty f-t syn-608 f-t syn-608 f-t syn-612 ctx-empty f-t dag-610 f-t f-t f-t term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-trans f-t f-t f-t syn-611 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t dag-614 eq-add-cong eq-trans eq-add-cong $.
$}
${
dag-616 $p |- [] => ( ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t syn-605 f-t syn-607 f-t syn-84 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t f-t f-t f-t term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t f-t f-t f-t term-add term-add term-add ctx-empty f-t arith-124 f-t arith-124 eq-add-cong f-t syn-607 f-t syn-609 f-t syn-84 ctx-empty f-t syn-607 f-t syn-607 f-t syn-609 ctx-empty f-t dag-606 f-t f-t f-t f-t term-add term-add f-t f-t f-t f-t term-add term-add term-add ctx-empty ax-A1 eq-trans f-t dag-615 eq-trans eq-trans $.
$}
${
dag-617 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + t ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t syn-602 f-t syn-605 f-t syn-84 ctx-empty f-t syn-602 f-t syn-602 f-t syn-605 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-t f-t term-add f-t f-t term-add ctx-empty dag-593 f-t arith-101 eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-t f-t ctx-empty ax-A8 eq-trans f-t dag-616 eq-trans $.
$}
${
dag-618 $p |- [] => ( ( ( t + ( t + ( t + t ) ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( ( t + ( t + ( t + t ) ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t f-t term-add term-add term-add f-t f-t f-t f-t term-add term-add term-add f-t syn-84 f-t syn-84 ctx-empty f-t f-t f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-t f-t f-t syn-83 f-t syn-83 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-76 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-619 $p term ( ( t + ( t + ( t + t ) ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t f-t f-t term-add term-add term-add f-t syn-84 term-add $.
$}
${
syn-620 $p term ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t syn-84 term-add $.
$}
${
syn-621 $p term ( t + ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-620 term-add $.
$}
${
dag-622 $p |- [] => ( ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add f-t syn-84 f-t syn-84 ctx-empty f-t f-t f-t f-t term-add f-t f-t term-add ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-t f-t syn-83 f-t syn-83 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-76 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-623 $p term ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) $=
 f-t f-t term-add f-t syn-84 term-add $.
$}
${
syn-624 $p term ( t + ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t syn-623 term-add $.
$}
${
dag-625 $p |- [] => ( ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( ( t + t ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) $=
 f-t f-t term-add f-t f-t term-add f-t syn-84 f-t syn-84 ctx-empty f-t f-t f-t f-t ctx-empty f-t ctx-empty eq-refl f-t ctx-empty eq-refl eq-add-cong f-t f-t f-t syn-83 f-t syn-83 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-76 f-t syn-76 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t f-t f-t f-t f-t term-add term-add term-add term-add f-t f-t f-t f-t f-t term-add term-add term-add term-add ctx-empty f-t ctx-empty eq-refl f-t dag-74 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-626 $p |- [] => ( ( ( t + ( t + t ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-620 f-t syn-624 f-t syn-95 ctx-empty f-t syn-620 f-t syn-620 f-t syn-624 ctx-empty f-t dag-622 f-t f-t f-t term-add f-t syn-84 ctx-empty ax-A1 eq-trans f-t f-t f-t syn-623 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t syn-623 f-t syn-94 f-t syn-94 ctx-empty f-t syn-623 f-t syn-623 f-t syn-94 ctx-empty f-t dag-625 f-t f-t f-t syn-84 ctx-empty ax-A1 eq-trans f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-trans eq-add-cong eq-trans $.
$}
${
dag-627 $p |- [] => ( ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * t ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + t ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-603 f-t syn-619 f-t syn-97 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-t term-mul f-t f-t f-t f-t term-add term-add term-add f-t syn-602 f-t syn-84 ctx-empty f-t arith-124 f-t dag-617 eq-add-cong f-t syn-619 f-t syn-621 f-t syn-97 ctx-empty f-t syn-619 f-t syn-619 f-t syn-621 ctx-empty f-t dag-618 f-t f-t f-t f-t term-add term-add f-t syn-84 ctx-empty ax-A1 eq-trans f-t f-t f-t syn-620 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t dag-626 eq-add-cong eq-trans eq-trans $.
$}
${
dag-628 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + ( t + t ) ) ) = ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-599 f-t syn-603 f-t syn-97 ctx-empty f-t syn-599 f-t syn-599 f-t syn-603 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-t f-t f-t term-add term-add f-t f-t f-t term-add term-add ctx-empty dag-593 f-t dag-58 eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-t f-t f-t term-add ctx-empty ax-A8 eq-trans f-t dag-627 eq-trans $.
$}
${
dag-629 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-t syn-97 f-t syn-97 ctx-empty term-one term-one term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-t f-t f-t syn-95 f-t syn-95 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-94 f-t syn-94 ctx-empty f-t ctx-empty eq-refl f-t f-t f-t syn-86 f-t syn-86 ctx-empty f-t ctx-empty eq-refl f-t dag-89 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-630 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t syn-97 term-add $.
$}
${
syn-631 $p term ( 1 + ( ( 1 + ( 1 + 1 ) ) + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-101 term-add $.
$}
${
dag-632 $p |- [] => ( ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( t + ( t + t ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-600 f-t syn-630 f-t syn-114 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-mul term-one term-one term-one term-one term-add term-add term-add f-t syn-599 f-t syn-97 ctx-empty arith-122 f-t dag-628 eq-add-cong f-t syn-630 f-t syn-631 f-t syn-114 ctx-empty f-t syn-630 f-t syn-630 f-t syn-631 ctx-empty f-t dag-629 term-one term-one term-one term-one term-add term-add f-t syn-97 ctx-empty ax-A1 eq-trans term-one term-one f-t syn-101 f-t syn-108 ctx-empty term-one ctx-empty eq-refl f-t dag-109 eq-add-cong eq-trans eq-trans $.
$}
${
arith-130 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( t + ( t + t ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-590 f-t syn-600 f-t syn-114 ctx-empty f-t dag-601 f-t dag-632 eq-trans $.
$}
${
dag-633 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-t syn-114 f-t syn-114 ctx-empty term-one term-one term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong term-one term-one f-t syn-108 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-634 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-t syn-114 term-add $.
$}
${
syn-635 $p term ( ( 1 + ( 1 + 1 ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t syn-114 term-add $.
$}
${
syn-636 $p term ( 1 + ( ( 1 + ( 1 + 1 ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-635 term-add $.
$}
${
dag-637 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + ( 1 + 1 ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t syn-114 f-t syn-114 ctx-empty term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong term-one term-one f-t syn-108 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-638 $p term ( ( 1 + 1 ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-add f-t syn-114 term-add $.
$}
${
syn-639 $p term ( 1 + ( ( 1 + 1 ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-t syn-638 term-add $.
$}
${
dag-640 $p |- [] => ( ( ( 1 + 1 ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-638 f-t syn-638 f-t syn-118 ctx-empty term-one term-one term-add term-one term-one term-add f-t syn-114 f-t syn-114 ctx-empty term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong term-one term-one f-t syn-108 f-t syn-108 ctx-empty term-one ctx-empty eq-refl term-one term-one f-t syn-106 f-t syn-106 ctx-empty term-one ctx-empty eq-refl f-t dag-107 eq-add-cong eq-add-cong eq-add-cong term-one term-one f-t syn-114 ctx-empty ax-A1 eq-trans $.
$}
${
dag-641 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-634 f-t syn-636 f-t syn-579 ctx-empty f-t syn-634 f-t syn-634 f-t syn-636 ctx-empty f-t dag-633 term-one term-one term-one term-one term-add term-add f-t syn-114 ctx-empty ax-A1 eq-trans term-one term-one f-t syn-635 f-t syn-578 ctx-empty term-one ctx-empty eq-refl f-t syn-635 f-t syn-639 f-t syn-578 ctx-empty f-t syn-635 f-t syn-635 f-t syn-639 ctx-empty f-t dag-637 term-one term-one term-one term-add f-t syn-114 ctx-empty ax-A1 eq-trans term-one term-one f-t syn-638 f-t syn-118 ctx-empty term-one ctx-empty eq-refl f-t dag-640 eq-add-cong eq-trans eq-add-cong eq-trans $.
$}
${
arith-131 $p |- [] => ( ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( t + ( t + t ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-591 f-t syn-634 f-t syn-579 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-mul term-one term-one term-one term-one term-add term-add term-add f-t syn-590 f-t syn-114 ctx-empty arith-122 f-t arith-130 eq-add-cong f-t dag-641 eq-trans $.
$}
${
arith-132 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( 1 + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + ( t + t ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-t syn-588 f-t syn-591 f-t syn-579 ctx-empty f-t dag-592 f-t arith-131 eq-trans $.
$}
${
arith-133 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) + ( 1 + 1 ) ) = ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) ) $=
 f-t syn-581 f-t syn-579 f-t syn-588 ctx-empty f-t arith-116 f-t syn-588 f-t syn-579 ctx-empty f-t arith-132 eq-sym eq-trans $.
$}
${
syn-642 $p term ( ( v * 1 ) + ( v * ( 1 + ( 1 + 1 ) ) ) ) $=
 f-v term-one term-mul f-v term-one term-one term-one term-add term-add term-mul term-add $.
$}
${
dag-643 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) = ( ( v * 1 ) + ( v * ( 1 + ( 1 + 1 ) ) ) ) ) $=
 term-one term-one term-add term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v syn-642 ctx-empty term-one term-one term-add term-one term-add term-one term-add term-one term-one term-one term-one term-add term-add term-add f-v f-v ctx-empty dag-8 f-v ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v term-one term-one term-one term-one term-add term-add term-add term-mul f-v syn-642 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-v ctx-empty ax-A5 f-v term-one term-one term-one term-one term-add term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-134 $p |- [] => ( ( ( v * 1 ) + ( v * 1 ) ) = ( v + v ) ) $=
 f-v term-one term-mul f-v term-one term-mul term-add f-v f-v term-add f-v f-v term-add ctx-empty f-v term-one term-mul f-v f-v term-one term-mul f-v ctx-empty f-v arith-58 f-v arith-58 eq-add-cong f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-644 $p |- [] => ( ( v * ( 1 + 1 ) ) = ( v + v ) ) $=
 f-v term-one term-one term-add term-mul f-v term-one term-mul f-v term-one term-mul term-add f-v f-v term-add ctx-empty f-v term-one term-one term-add term-mul f-v term-one term-one term-add term-mul f-v term-one term-mul f-v term-one term-mul term-add ctx-empty f-v f-v term-one term-one term-add term-one term-one term-add ctx-empty f-v ctx-empty eq-refl arith-85 eq-mul-cong f-v term-one term-one ctx-empty ax-A8 eq-trans f-v arith-134 eq-trans $.
$}
${
dag-645 $p |- [] => ( ( ( v * 1 ) + ( v * ( 1 + 1 ) ) ) = ( v + ( v + v ) ) ) $=
 f-v term-one term-mul f-v term-one term-one term-add term-mul term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v term-one term-mul f-v f-v term-one term-one term-add term-mul f-v f-v term-add ctx-empty f-v arith-58 f-v dag-644 eq-add-cong f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-646 $p |- [] => ( ( v * ( 1 + ( 1 + 1 ) ) ) = ( v + ( v + v ) ) ) $=
 f-v term-one term-one term-one term-add term-add term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add f-v f-v f-v term-add term-add ctx-empty f-v term-one term-one term-one term-add term-add term-mul f-v term-one term-one term-one term-add term-add term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add ctx-empty f-v f-v term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty f-v ctx-empty eq-refl dag-11 eq-mul-cong f-v term-one term-one term-one term-add ctx-empty ax-A8 eq-trans f-v dag-645 eq-trans $.
$}
${
dag-647 $p |- [] => ( ( ( v * 1 ) + ( v * ( 1 + ( 1 + 1 ) ) ) ) = ( v + ( v + ( v + v ) ) ) ) $=
 f-v syn-642 f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v term-one term-mul f-v f-v term-one term-one term-one term-add term-add term-mul f-v f-v f-v term-add term-add ctx-empty f-v arith-58 f-v dag-646 eq-add-cong f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
arith-139 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) = ( v + ( v + ( v + v ) ) ) ) $=
 term-one term-one term-add term-one term-add term-one term-add f-v term-mul f-v syn-642 f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v dag-643 f-v dag-647 eq-trans $.
$}
${
dag-648 $p |- [] => ( ( ( v + ( v + ( v + v ) ) ) + 1 ) = ( ( v + ( v + ( v + v ) ) ) + 1 ) ) $=
 f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add term-one term-one ctx-empty f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong $.
$}
${
dag-649 $p |- [] => ( ( ( v + ( v + v ) ) + 1 ) = ( v + ( ( v + v ) + 1 ) ) ) $=
 f-v f-v f-v term-add term-add term-one term-add f-v f-v f-v term-add term-add term-one term-add f-v f-v f-v term-add term-one term-add term-add ctx-empty f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add term-one term-one ctx-empty f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-v f-v f-v term-add term-one ctx-empty ax-A1 eq-trans $.
$}
${
dag-650 $p |- [] => ( ( ( v + v ) + 1 ) = ( v + ( v + 1 ) ) ) $=
 f-v f-v term-add term-one term-add f-v f-v term-one term-add term-add f-v f-v term-one term-add term-add ctx-empty f-v f-v term-add term-one term-add f-v f-v term-add term-one term-add f-v f-v term-one term-add term-add ctx-empty f-v f-v term-add f-v f-v term-add term-one term-one ctx-empty f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-v f-v term-one ctx-empty ax-A1 eq-trans f-v f-v f-v term-one term-add f-v term-one term-add ctx-empty f-v ctx-empty eq-refl f-v f-v term-one term-one ctx-empty f-v ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-651 $p |- [] => ( ( v + ( ( v + ( v + v ) ) + 1 ) ) = ( v + ( v + ( v + ( v + 1 ) ) ) ) ) $=
 f-v f-v f-v f-v f-v term-add term-add term-one term-add f-v f-v f-v term-one term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v term-add term-add term-one term-add f-v f-v f-v term-add term-one term-add term-add f-v f-v f-v term-one term-add term-add term-add ctx-empty f-v dag-649 f-v f-v f-v f-v term-add term-one term-add f-v f-v term-one term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-650 eq-add-cong eq-trans eq-add-cong $.
$}
${
dag-652 $p |- [] => ( ( ( v + ( v + ( v + v ) ) ) + 1 ) = ( v + ( v + ( v + ( v + 1 ) ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v f-v f-v f-v term-add term-add term-one term-add term-add f-v f-v f-v f-v term-one term-add term-add term-add term-add ctx-empty f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v f-v f-v f-v term-add term-add term-one term-add term-add ctx-empty f-v dag-648 f-v f-v f-v f-v term-add term-add term-one ctx-empty ax-A1 eq-trans f-v dag-651 eq-trans $.
$}
${
dag-653 $p |- [] => ( ( v + ( v + ( v + ( v + 1 ) ) ) ) = ( v + ( v + ( v + ( 1 + v ) ) ) ) ) $=
 f-v f-v f-v f-v f-v term-one term-add term-add term-add f-v f-v term-one f-v term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-one term-add term-add f-v term-one f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v term-one term-add term-one f-v term-add ctx-empty f-v ctx-empty eq-refl f-v term-one ctx-empty ax-A2 eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-654 $p |- [] => ( ( v + ( 1 + v ) ) = ( ( 1 + v ) + v ) ) $=
 f-v term-one f-v term-add term-add f-v term-one term-add f-v term-add term-one f-v term-add f-v term-add ctx-empty f-v term-one term-add f-v term-add f-v term-one f-v term-add term-add ctx-empty f-v term-one f-v ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v f-v ctx-empty f-v term-one ctx-empty ax-A2 f-v ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-655 $p |- [] => ( ( v + ( v + ( v + ( 1 + v ) ) ) ) = ( v + ( v + ( 1 + ( v + v ) ) ) ) ) $=
 f-v f-v f-v f-v term-one f-v term-add term-add term-add f-v term-one f-v f-v term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v term-one f-v term-add term-add term-one f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v term-one f-v term-add term-add term-one f-v term-add f-v term-add term-one f-v f-v term-add term-add ctx-empty f-v dag-654 term-one f-v f-v ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
dag-656 $p |- [] => ( ( ( v + ( v + ( v + v ) ) ) + 1 ) = ( v + ( v + ( 1 + ( v + v ) ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v f-v f-v term-one f-v term-add term-add term-add term-add f-v f-v term-one f-v f-v term-add term-add term-add term-add ctx-empty f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v f-v f-v f-v term-one term-add term-add term-add term-add f-v f-v f-v term-one f-v term-add term-add term-add term-add ctx-empty f-v dag-652 f-v dag-653 eq-trans f-v dag-655 eq-trans $.
$}
${
dag-657 $p |- [] => ( ( v + ( 1 + ( v + v ) ) ) = ( ( 1 + v ) + ( v + v ) ) ) $=
 f-v term-one f-v f-v term-add term-add term-add f-v term-one term-add f-v f-v term-add term-add term-one f-v term-add f-v f-v term-add term-add ctx-empty f-v term-one term-add f-v f-v term-add term-add f-v term-one f-v f-v term-add term-add term-add ctx-empty f-v term-one f-v f-v term-add ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v f-v term-add f-v f-v term-add ctx-empty f-v term-one ctx-empty ax-A2 f-v f-v term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-658 $p |- [] => ( ( v + ( v + ( 1 + ( v + v ) ) ) ) = ( v + ( 1 + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v f-v term-one f-v f-v term-add term-add term-add term-one f-v f-v f-v term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v term-one f-v f-v term-add term-add term-add term-one f-v term-add f-v f-v term-add term-add term-one f-v f-v f-v term-add term-add term-add ctx-empty f-v dag-657 term-one f-v f-v f-v term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
dag-659 $p |- [] => ( ( v + ( 1 + ( v + ( v + v ) ) ) ) = ( ( 1 + v ) + ( v + ( v + v ) ) ) ) $=
 f-v term-one f-v f-v f-v term-add term-add term-add term-add f-v term-one term-add f-v f-v f-v term-add term-add term-add term-one f-v term-add f-v f-v f-v term-add term-add term-add ctx-empty f-v term-one term-add f-v f-v f-v term-add term-add term-add f-v term-one f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v term-one f-v f-v f-v term-add term-add ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v term-one ctx-empty ax-A2 f-v f-v f-v term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-660 $p |- [] => ( ( ( v + ( v + ( v + v ) ) ) + 1 ) = ( 1 + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v term-one f-v f-v f-v term-add term-add term-add term-add term-one f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v f-v term-one f-v f-v term-add term-add term-add term-add f-v term-one f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v dag-656 f-v dag-658 eq-trans f-v term-one f-v f-v f-v term-add term-add term-add term-add term-one f-v term-add f-v f-v f-v term-add term-add term-add term-one f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v dag-659 term-one f-v f-v f-v f-v term-add term-add ctx-empty ax-A1 eq-trans eq-trans $.
$}
${
arith-140 $p |- [] => ( ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) = ( 1 + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v syn-2 f-v f-v f-v f-v term-add term-add term-add term-one term-add term-one f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty term-one term-one term-add term-one term-add term-one term-add f-v term-mul f-v f-v f-v f-v term-add term-add term-add term-one term-one ctx-empty f-v arith-139 term-one ctx-empty eq-refl eq-add-cong f-v dag-660 eq-trans $.
$}
${
syn-661 $p term ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) $=
 term-one term-one term-add term-one term-add f-v syn-2 term-mul $.
$}
${
syn-662 $p term ( ( 1 + ( 1 + 1 ) ) * ( 1 + ( v + ( v + ( v + v ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one f-v f-v f-v f-v term-add term-add term-add term-add term-mul $.
$}
${
syn-663 $p term ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + ( v + v ) ) ) ) $=
 term-one term-one term-one term-add term-add f-v f-v f-v f-v term-add term-add term-add term-mul $.
$}
${
syn-664 $p term ( ( ( 1 + ( 1 + 1 ) ) * 1 ) + ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + ( v + v ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-mul f-v syn-663 term-add $.
$}
${
arith-141 $p |- [] => ( ( v + v ) = ( v + v ) ) $=
 f-v f-v term-add f-v f-v term-add f-v f-v term-add ctx-empty f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-665 $p |- [] => ( ( v + ( v + v ) ) = ( v + ( v + v ) ) ) $=
 f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v arith-141 eq-add-cong f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-666 $p |- [] => ( ( v + ( v + ( v + v ) ) ) = ( v + ( v + ( v + v ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-665 eq-add-cong f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-667 $p term ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + v ) ) ) $=
 term-one term-one term-one term-add term-add f-v f-v f-v term-add term-add term-mul $.
$}
${
syn-668 $p term ( ( ( 1 + ( 1 + 1 ) ) * v ) + ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + v ) ) ) ) $=
 term-one term-one term-one term-add term-add f-v term-mul f-v syn-667 term-add $.
$}
${
dag-669 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * v ) = ( ( v * 1 ) + ( v * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-one term-add term-add f-v term-mul term-one term-one term-one term-add term-add f-v term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-v f-v ctx-empty dag-11 f-v ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-add term-add f-v term-mul f-v term-one term-one term-one term-add term-add term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add f-v ctx-empty ax-A5 f-v term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-144 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * v ) = ( v + ( v + v ) ) ) $=
 term-one term-one term-one term-add term-add f-v term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add f-v f-v f-v term-add term-add ctx-empty f-v dag-669 f-v dag-645 eq-trans $.
$}
${
syn-670 $p term ( ( ( 1 + ( 1 + 1 ) ) * v ) + ( ( 1 + ( 1 + 1 ) ) * ( v + v ) ) ) $=
 term-one term-one term-one term-add term-add f-v term-mul term-one term-one term-one term-add term-add f-v f-v term-add term-mul term-add $.
$}
${
syn-671 $p term ( ( ( 1 + ( 1 + 1 ) ) * v ) + ( ( 1 + ( 1 + 1 ) ) * v ) ) $=
 term-one term-one term-one term-add term-add f-v term-mul term-one term-one term-one term-add term-add f-v term-mul term-add $.
$}
${
dag-672 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( v + v ) ) = ( ( ( 1 + ( 1 + 1 ) ) * v ) + ( ( 1 + ( 1 + 1 ) ) * v ) ) ) $=
 term-one term-one term-one term-add term-add f-v f-v term-add term-mul term-one term-one term-one term-add term-add f-v f-v term-add term-mul f-v syn-671 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-v f-v term-add f-v f-v term-add ctx-empty dag-11 f-v arith-141 eq-mul-cong term-one term-one term-one term-add term-add f-v f-v ctx-empty ax-A8 eq-trans $.
$}
${
dag-673 $p |- [] => ( ( ( v + ( v + v ) ) + ( v + ( v + v ) ) ) = ( ( v + ( v + v ) ) + ( v + ( v + v ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-674 $p term ( ( v + ( v + v ) ) + ( v + ( v + v ) ) ) $=
 f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add term-add $.
$}
${
syn-675 $p term ( v + ( ( v + v ) + ( v + ( v + v ) ) ) ) $=
 f-v f-v f-v term-add f-v f-v f-v term-add term-add term-add term-add $.
$}
${
dag-676 $p |- [] => ( ( ( v + v ) + ( v + ( v + v ) ) ) = ( ( v + v ) + ( v + ( v + v ) ) ) ) $=
 f-v f-v term-add f-v f-v term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-677 $p |- [] => ( ( v + ( v + ( v + ( v + v ) ) ) ) = ( v + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-678 $p |- [] => ( ( ( v + v ) + ( v + ( v + v ) ) ) = ( v + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v term-add f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v f-v term-add f-v f-v f-v term-add term-add term-add f-v f-v term-add f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v dag-676 f-v f-v f-v f-v f-v term-add term-add ctx-empty ax-A1 eq-trans f-v dag-677 eq-trans $.
$}
${
syn-679 $p term ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add term-add $.
$}
${
dag-680 $p |- [] => ( ( ( v + ( v + v ) ) + ( v + ( v + v ) ) ) = ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v syn-674 f-v syn-675 f-v syn-679 ctx-empty f-v syn-674 f-v syn-674 f-v syn-675 ctx-empty f-v dag-673 f-v f-v f-v term-add f-v f-v f-v term-add term-add ctx-empty ax-A1 eq-trans f-v f-v f-v f-v term-add f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-678 eq-add-cong eq-trans $.
$}
${
arith-145 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * v ) + ( ( 1 + ( 1 + 1 ) ) * v ) ) = ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v syn-671 f-v syn-674 f-v syn-679 ctx-empty term-one term-one term-one term-add term-add f-v term-mul f-v f-v f-v term-add term-add term-one term-one term-one term-add term-add f-v term-mul f-v f-v f-v term-add term-add ctx-empty f-v arith-144 f-v arith-144 eq-add-cong f-v dag-680 eq-trans $.
$}
${
arith-146 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( v + v ) ) = ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add f-v f-v term-add term-mul f-v syn-671 f-v syn-679 ctx-empty f-v dag-672 f-v arith-145 eq-trans $.
$}
${
dag-681 $p |- [] => ( ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) = ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add f-v syn-679 f-v syn-679 ctx-empty f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong $.
$}
${
syn-682 $p term ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v syn-679 term-add $.
$}
${
syn-683 $p term ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v f-v term-add f-v syn-679 term-add $.
$}
${
syn-684 $p term ( v + ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v syn-683 term-add $.
$}
${
dag-685 $p |- [] => ( ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) = ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v term-add f-v f-v term-add f-v syn-679 f-v syn-679 ctx-empty f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong $.
$}
${
syn-686 $p term ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v f-v syn-679 term-add $.
$}
${
syn-687 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v syn-686 term-add $.
$}
${
dag-688 $p |- [] => ( ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v syn-683 f-v syn-687 f-v syn-687 ctx-empty f-v syn-683 f-v syn-683 f-v syn-687 ctx-empty f-v dag-685 f-v f-v f-v syn-679 ctx-empty ax-A1 eq-trans f-v f-v f-v syn-686 f-v syn-686 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-679 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-689 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-687 term-add $.
$}
${
dag-690 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * v ) + ( ( 1 + ( 1 + 1 ) ) * ( v + v ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v syn-670 f-v syn-682 f-v syn-689 ctx-empty term-one term-one term-one term-add term-add f-v term-mul f-v f-v f-v term-add term-add term-one term-one term-one term-add term-add f-v f-v term-add term-mul f-v syn-679 ctx-empty f-v arith-144 f-v arith-146 eq-add-cong f-v syn-682 f-v syn-684 f-v syn-689 ctx-empty f-v syn-682 f-v syn-682 f-v syn-684 ctx-empty f-v dag-681 f-v f-v f-v term-add f-v syn-679 ctx-empty ax-A1 eq-trans f-v f-v f-v syn-683 f-v syn-687 ctx-empty f-v ctx-empty eq-refl f-v dag-688 eq-add-cong eq-trans eq-trans $.
$}
${
dag-691 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + v ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v syn-667 f-v syn-670 f-v syn-689 ctx-empty f-v syn-667 f-v syn-667 f-v syn-670 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty dag-11 f-v dag-665 eq-mul-cong term-one term-one term-one term-add term-add f-v f-v f-v term-add ctx-empty ax-A8 eq-trans f-v dag-690 eq-trans $.
$}
${
dag-692 $p |- [] => ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-687 f-v syn-687 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-686 f-v syn-686 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-679 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-693 $p term ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v syn-689 term-add $.
$}
${
syn-694 $p term ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v term-add f-v syn-689 term-add $.
$}
${
syn-695 $p term ( v + ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-694 term-add $.
$}
${
dag-696 $p |- [] => ( ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) = ( v + ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-693 f-v syn-693 f-v syn-695 ctx-empty f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add f-v syn-689 f-v syn-689 ctx-empty f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong f-v dag-692 eq-add-cong f-v f-v f-v term-add f-v syn-689 ctx-empty ax-A1 eq-trans $.
$}
${
syn-697 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-689 term-add $.
$}
${
syn-698 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-697 term-add $.
$}
${
dag-699 $p |- [] => ( ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-694 f-v syn-698 f-v syn-698 ctx-empty f-v syn-694 f-v syn-694 f-v syn-698 ctx-empty f-v f-v term-add f-v f-v term-add f-v syn-689 f-v syn-689 ctx-empty f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong f-v dag-692 eq-add-cong f-v f-v f-v syn-689 ctx-empty ax-A1 eq-trans f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-700 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-698 term-add $.
$}
${
dag-701 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * v ) + ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + v ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-668 f-v syn-693 f-v syn-700 ctx-empty term-one term-one term-one term-add term-add f-v term-mul f-v f-v f-v term-add term-add f-v syn-667 f-v syn-689 ctx-empty f-v arith-144 f-v dag-691 eq-add-cong f-v syn-693 f-v syn-695 f-v syn-700 ctx-empty f-v dag-696 f-v f-v f-v syn-694 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v dag-699 eq-add-cong eq-trans eq-trans $.
$}
${
dag-702 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + ( v + v ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-663 f-v syn-668 f-v syn-700 ctx-empty f-v syn-663 f-v syn-663 f-v syn-668 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty dag-11 f-v dag-666 eq-mul-cong term-one term-one term-one term-add term-add f-v f-v f-v f-v term-add term-add ctx-empty ax-A8 eq-trans f-v dag-701 eq-trans $.
$}
${
dag-703 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + ( 1 + 1 ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-v syn-700 f-v syn-700 ctx-empty term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-v f-v f-v syn-698 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-704 $p term ( ( 1 + ( 1 + 1 ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-add term-add f-v syn-700 term-add $.
$}
${
syn-705 $p term ( ( 1 + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-add f-v syn-700 term-add $.
$}
${
syn-706 $p term ( 1 + ( ( 1 + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-705 term-add $.
$}
${
dag-707 $p |- [] => ( ( ( 1 + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-add term-one term-one term-add f-v syn-700 f-v syn-700 ctx-empty term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong f-v f-v f-v syn-698 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-708 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-700 term-add $.
$}
${
syn-709 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-708 term-add $.
$}
${
dag-710 $p |- [] => ( ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-708 f-v syn-708 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-700 f-v syn-700 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-698 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-711 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-709 term-add $.
$}
${
dag-712 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-704 f-v syn-706 f-v syn-711 ctx-empty f-v syn-704 f-v syn-704 f-v syn-706 ctx-empty f-v dag-703 term-one term-one term-one term-add f-v syn-700 ctx-empty ax-A1 eq-trans term-one term-one f-v syn-705 f-v syn-709 ctx-empty term-one ctx-empty eq-refl f-v syn-705 f-v syn-709 f-v syn-709 ctx-empty f-v syn-705 f-v syn-705 f-v syn-709 ctx-empty f-v dag-707 term-one term-one f-v syn-700 ctx-empty ax-A1 eq-trans f-v dag-710 eq-trans eq-add-cong eq-trans $.
$}
${
arith-151 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * 1 ) + ( ( 1 + ( 1 + 1 ) ) * ( v + ( v + ( v + v ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-664 f-v syn-704 f-v syn-711 ctx-empty term-one term-one term-one term-add term-add term-one term-mul term-one term-one term-one term-add term-add f-v syn-663 f-v syn-700 ctx-empty arith-100 f-v dag-702 eq-add-cong f-v dag-712 eq-trans $.
$}
${
dag-713 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-661 f-v syn-664 f-v syn-711 ctx-empty f-v syn-661 f-v syn-662 f-v syn-664 ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add f-v syn-2 term-one f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty dag-6 f-v arith-140 eq-mul-cong term-one term-one term-one term-add term-add term-one f-v f-v f-v f-v term-add term-add term-add ctx-empty ax-A8 eq-trans f-v arith-151 eq-trans $.
$}
${
syn-714 $p term ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-711 term-one term-add $.
$}
${
syn-715 $p term ( ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-709 term-one term-add $.
$}
${
syn-716 $p term ( 1 + ( ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) ) $=
 term-one f-v syn-715 term-add $.
$}
${
syn-717 $p term ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-708 term-one term-add $.
$}
${
syn-718 $p term ( 1 + ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) ) $=
 term-one f-v syn-717 term-add $.
$}
${
dag-719 $p |- [] => ( ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) ) $=
 f-v syn-708 f-v syn-708 term-one term-one ctx-empty term-one term-one f-v syn-700 f-v syn-700 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-698 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong $.
$}
${
syn-720 $p term ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-700 term-one term-add $.
$}
${
syn-721 $p term ( 1 + ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) + 1 ) ) $=
 term-one f-v syn-720 term-add $.
$}
${
syn-722 $p term ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-698 term-one term-add $.
$}
${
syn-723 $p term ( v + ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) + 1 ) ) $=
 f-v f-v syn-722 term-add $.
$}
${
dag-724 $p |- [] => ( ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( v + ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) + 1 ) ) ) $=
 f-v syn-720 f-v syn-720 f-v syn-723 ctx-empty f-v syn-700 f-v syn-700 term-one term-one ctx-empty f-v f-v f-v syn-698 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-v f-v syn-698 term-one ctx-empty ax-A1 eq-trans $.
$}
${
syn-725 $p term ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-697 term-one term-add $.
$}
${
syn-726 $p term ( v + ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) + 1 ) ) $=
 f-v f-v syn-725 term-add $.
$}
${
syn-727 $p term ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-689 term-one term-add $.
$}
${
syn-728 $p term ( v + ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) + 1 ) ) $=
 f-v f-v syn-727 term-add $.
$}
${
syn-729 $p term ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) + 1 ) $=
 f-v syn-687 term-one term-add $.
$}
${
syn-730 $p term ( v + ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) + 1 ) ) $=
 f-v f-v syn-729 term-add $.
$}
${
dag-731 $p |- [] => ( ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) + 1 ) = ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) + 1 ) ) $=
 f-v syn-687 f-v syn-687 term-one term-one ctx-empty f-v f-v f-v syn-686 f-v syn-686 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-679 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong $.
$}
${
syn-732 $p term ( ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) + 1 ) $=
 f-v syn-686 term-one term-add $.
$}
${
syn-733 $p term ( v + ( ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) + 1 ) ) $=
 f-v f-v syn-732 term-add $.
$}
${
syn-734 $p term ( ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) + 1 ) $=
 f-v syn-679 term-one term-add $.
$}
${
syn-735 $p term ( v + ( ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) + 1 ) ) $=
 f-v f-v syn-734 term-add $.
$}
${
dag-736 $p |- [] => ( ( ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) + 1 ) = ( v + ( ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) + 1 ) ) ) $=
 f-v syn-732 f-v syn-732 f-v syn-735 ctx-empty f-v syn-686 f-v syn-686 term-one term-one ctx-empty f-v f-v f-v syn-679 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-v f-v syn-679 term-one ctx-empty ax-A1 eq-trans $.
$}
${
syn-737 $p term ( ( v + ( v + ( v + ( v + v ) ) ) ) + 1 ) $=
 f-v f-v f-v f-v f-v term-add term-add term-add term-add term-one term-add $.
$}
${
syn-738 $p term ( v + ( ( v + ( v + ( v + ( v + v ) ) ) ) + 1 ) ) $=
 f-v f-v syn-737 term-add $.
$}
${
dag-739 $p |- [] => ( ( ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) + 1 ) = ( v + ( ( v + ( v + ( v + ( v + v ) ) ) ) + 1 ) ) ) $=
 f-v syn-734 f-v syn-734 f-v syn-738 ctx-empty f-v syn-679 f-v syn-679 term-one term-one ctx-empty f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add term-one ctx-empty ax-A1 eq-trans $.
$}
${
syn-740 $p term ( v + ( ( v + ( v + ( v + v ) ) ) + 1 ) ) $=
 f-v f-v f-v f-v f-v term-add term-add term-add term-one term-add term-add $.
$}
${
syn-741 $p term ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) $=
 f-v f-v f-v f-v f-v term-one term-add term-add term-add term-add term-add $.
$}
${
dag-742 $p |- [] => ( ( ( v + ( v + ( v + ( v + v ) ) ) ) + 1 ) = ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) $=
 f-v syn-737 f-v syn-740 f-v syn-741 ctx-empty f-v syn-737 f-v syn-737 f-v syn-740 ctx-empty f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add term-one term-one ctx-empty f-v dag-677 term-one ctx-empty eq-refl eq-add-cong f-v f-v f-v f-v f-v term-add term-add term-add term-one ctx-empty ax-A1 eq-trans f-v f-v f-v f-v f-v f-v term-add term-add term-add term-one term-add f-v f-v f-v f-v term-one term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-652 eq-add-cong eq-trans $.
$}
${
syn-743 $p term ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) $=
 f-v f-v syn-741 term-add $.
$}
${
syn-744 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) $=
 f-v f-v syn-743 term-add $.
$}
${
dag-745 $p |- [] => ( ( v + ( ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) + 1 ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-732 f-v syn-744 ctx-empty f-v ctx-empty eq-refl f-v syn-732 f-v syn-735 f-v syn-744 ctx-empty f-v dag-736 f-v f-v f-v syn-734 f-v syn-743 ctx-empty f-v ctx-empty eq-refl f-v syn-734 f-v syn-738 f-v syn-743 ctx-empty f-v dag-739 f-v f-v f-v syn-737 f-v syn-741 ctx-empty f-v ctx-empty eq-refl f-v dag-742 eq-add-cong eq-trans eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-746 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) $=
 f-v f-v syn-744 term-add $.
$}
${
syn-747 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-746 term-add $.
$}
${
dag-748 $p |- [] => ( ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) + 1 ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-727 f-v syn-730 f-v syn-747 ctx-empty f-v syn-727 f-v syn-727 f-v syn-730 ctx-empty f-v syn-689 f-v syn-689 term-one term-one ctx-empty f-v dag-692 term-one ctx-empty eq-refl eq-add-cong f-v f-v syn-687 term-one ctx-empty ax-A1 eq-trans f-v f-v f-v syn-729 f-v syn-746 ctx-empty f-v ctx-empty eq-refl f-v syn-729 f-v syn-733 f-v syn-746 ctx-empty f-v syn-729 f-v syn-729 f-v syn-733 ctx-empty f-v dag-731 f-v f-v syn-686 term-one ctx-empty ax-A1 eq-trans f-v dag-745 eq-trans eq-add-cong eq-trans $.
$}
${
syn-749 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-747 term-add $.
$}
${
dag-750 $p |- [] => ( ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) + 1 ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-725 f-v syn-728 f-v syn-749 ctx-empty f-v syn-725 f-v syn-725 f-v syn-728 ctx-empty f-v syn-697 f-v syn-697 term-one term-one ctx-empty f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-v f-v syn-689 term-one ctx-empty ax-A1 eq-trans f-v f-v f-v syn-727 f-v syn-747 ctx-empty f-v ctx-empty eq-refl f-v dag-748 eq-add-cong eq-trans $.
$}
${
syn-751 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-749 term-add $.
$}
${
dag-752 $p |- [] => ( ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) + 1 ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-722 f-v syn-726 f-v syn-751 ctx-empty f-v syn-722 f-v syn-722 f-v syn-726 ctx-empty f-v syn-698 f-v syn-698 term-one term-one ctx-empty f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-v f-v syn-697 term-one ctx-empty ax-A1 eq-trans f-v f-v f-v syn-725 f-v syn-749 ctx-empty f-v ctx-empty eq-refl f-v dag-750 eq-add-cong eq-trans $.
$}
${
syn-753 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-751 term-add $.
$}
${
syn-754 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-753 term-add $.
$}
${
dag-755 $p |- [] => ( ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-717 f-v syn-721 f-v syn-754 ctx-empty f-v syn-717 f-v syn-717 f-v syn-721 ctx-empty f-v dag-719 term-one f-v syn-700 term-one ctx-empty ax-A1 eq-trans term-one term-one f-v syn-720 f-v syn-753 ctx-empty term-one ctx-empty eq-refl f-v syn-720 f-v syn-723 f-v syn-753 ctx-empty f-v dag-724 f-v f-v f-v syn-722 f-v syn-751 ctx-empty f-v ctx-empty eq-refl f-v dag-752 eq-add-cong eq-trans eq-add-cong eq-trans $.
$}
${
syn-756 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-754 term-add $.
$}
${
dag-757 $p |- [] => ( ( 1 + ( ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-715 f-v syn-756 ctx-empty term-one ctx-empty eq-refl f-v syn-715 f-v syn-718 f-v syn-756 ctx-empty f-v syn-715 f-v syn-715 f-v syn-718 ctx-empty f-v syn-709 f-v syn-709 term-one term-one ctx-empty f-v dag-710 term-one ctx-empty eq-refl eq-add-cong term-one f-v syn-708 term-one ctx-empty ax-A1 eq-trans term-one term-one f-v syn-717 f-v syn-754 ctx-empty term-one ctx-empty eq-refl f-v dag-755 eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-758 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-756 term-add $.
$}
${
syn-759 $p term ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) $=
 f-v f-v f-v f-v term-one f-v term-add term-add term-add term-add term-add $.
$}
${
syn-760 $p term ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) $=
 f-v f-v syn-759 term-add $.
$}
${
syn-761 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) $=
 f-v f-v syn-760 term-add $.
$}
${
dag-762 $p |- [] => ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-744 f-v syn-761 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-743 f-v syn-760 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-741 f-v syn-759 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v term-one term-add term-add term-add term-add f-v f-v f-v term-one f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-653 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-763 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-761 term-add $.
$}
${
syn-764 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-763 term-add $.
$}
${
syn-765 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-764 term-add $.
$}
${
syn-766 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-765 term-add $.
$}
${
syn-767 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-766 term-add $.
$}
${
dag-768 $p |- [] => ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + 1 ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-753 f-v syn-767 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-751 f-v syn-766 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-749 f-v syn-765 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-747 f-v syn-764 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-746 f-v syn-763 ctx-empty f-v ctx-empty eq-refl f-v dag-762 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-769 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-767 term-add $.
$}
${
syn-770 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-769 term-add $.
$}
${
syn-771 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-770 term-add $.
$}
${
dag-772 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-714 f-v syn-758 f-v syn-771 ctx-empty f-v syn-714 f-v syn-716 f-v syn-758 ctx-empty f-v syn-714 f-v syn-714 f-v syn-716 ctx-empty f-v syn-711 f-v syn-711 term-one term-one ctx-empty term-one term-one f-v syn-709 f-v syn-709 ctx-empty term-one ctx-empty eq-refl f-v dag-710 eq-add-cong term-one ctx-empty eq-refl eq-add-cong term-one f-v syn-709 term-one ctx-empty ax-A1 eq-trans f-v dag-757 eq-trans term-one term-one f-v syn-756 f-v syn-770 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-754 f-v syn-769 ctx-empty term-one ctx-empty eq-refl f-v dag-768 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-773 $p term ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) $=
 f-v f-v f-v term-one f-v f-v term-add term-add term-add term-add term-add $.
$}
${
syn-774 $p term ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) $=
 f-v f-v syn-773 term-add $.
$}
${
syn-775 $p term ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v syn-774 term-add $.
$}
${
dag-776 $p |- [] => ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-761 f-v syn-775 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-760 f-v syn-774 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-759 f-v syn-773 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v term-one f-v term-add term-add term-add term-add f-v f-v term-one f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-655 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-777 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-775 term-add $.
$}
${
syn-778 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-777 term-add $.
$}
${
syn-779 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-778 term-add $.
$}
${
syn-780 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-779 term-add $.
$}
${
syn-781 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-780 term-add $.
$}
${
dag-782 $p |- [] => ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + v ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-767 f-v syn-781 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-766 f-v syn-780 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-765 f-v syn-779 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-764 f-v syn-778 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-763 f-v syn-777 ctx-empty f-v ctx-empty eq-refl f-v dag-776 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-783 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-781 term-add $.
$}
${
syn-784 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-783 term-add $.
$}
${
syn-785 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-784 term-add $.
$}
${
syn-786 $p term ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v term-one f-v f-v f-v term-add term-add term-add term-add term-add $.
$}
${
syn-787 $p term ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) $=
 f-v f-v syn-786 term-add $.
$}
${
syn-788 $p term ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v syn-787 term-add $.
$}
${
dag-789 $p |- [] => ( ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-775 f-v syn-788 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-774 f-v syn-787 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-773 f-v syn-786 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-one f-v f-v term-add term-add term-add term-add f-v term-one f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-658 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-790 $p term ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-788 term-add $.
$}
${
syn-791 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-790 term-add $.
$}
${
syn-792 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-791 term-add $.
$}
${
syn-793 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-792 term-add $.
$}
${
syn-794 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-793 term-add $.
$}
${
dag-795 $p |- [] => ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-781 f-v syn-794 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-780 f-v syn-793 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-779 f-v syn-792 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-778 f-v syn-791 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-777 f-v syn-790 ctx-empty f-v ctx-empty eq-refl f-v dag-789 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-796 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-794 term-add $.
$}
${
syn-797 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-796 term-add $.
$}
${
syn-798 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-797 term-add $.
$}
${
dag-799 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-714 f-v syn-785 f-v syn-798 ctx-empty f-v syn-714 f-v syn-771 f-v syn-785 ctx-empty f-v dag-772 term-one term-one f-v syn-770 f-v syn-784 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-769 f-v syn-783 ctx-empty term-one ctx-empty eq-refl f-v dag-782 eq-add-cong eq-add-cong eq-trans term-one term-one f-v syn-784 f-v syn-797 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-783 f-v syn-796 ctx-empty term-one ctx-empty eq-refl f-v dag-795 eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-800 $p |- [] => ( ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) = ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v f-v f-v term-one f-v f-v f-v term-add term-add term-add term-add term-one f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v term-one f-v f-v f-v term-add term-add term-add term-add term-one f-v term-add f-v f-v f-v term-add term-add term-add term-one f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v dag-659 term-one f-v f-v f-v f-v term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-801 $p term ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v term-one f-v f-v f-v f-v term-add term-add term-add term-add term-add $.
$}
${
syn-802 $p term ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v f-v syn-801 term-add $.
$}
${
syn-803 $p term ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v syn-802 term-add $.
$}
${
syn-804 $p term ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-803 term-add $.
$}
${
syn-805 $p term ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-804 term-add $.
$}
${
dag-806 $p |- [] => ( ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-791 f-v syn-805 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-790 f-v syn-804 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-788 f-v syn-803 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-787 f-v syn-802 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-786 f-v syn-801 ctx-empty f-v ctx-empty eq-refl f-v dag-800 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-807 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-805 term-add $.
$}
${
syn-808 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-807 term-add $.
$}
${
syn-809 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-808 term-add $.
$}
${
syn-810 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-809 term-add $.
$}
${
syn-811 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-810 term-add $.
$}
${
dag-812 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-797 f-v syn-811 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-796 f-v syn-810 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-794 f-v syn-809 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-793 f-v syn-808 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-792 f-v syn-807 ctx-empty f-v ctx-empty eq-refl f-v dag-806 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-813 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-811 term-add $.
$}
${
syn-814 $p term ( ( v + 1 ) + ( v + ( v + ( v + v ) ) ) ) $=
 f-v term-one term-add f-v f-v f-v f-v term-add term-add term-add term-add $.
$}
${
syn-815 $p term ( ( 1 + v ) + ( v + ( v + ( v + v ) ) ) ) $=
 term-one f-v term-add f-v f-v f-v f-v term-add term-add term-add term-add $.
$}
${
dag-816 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) = ( ( 1 + v ) + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v syn-801 f-v syn-814 f-v syn-815 ctx-empty f-v syn-814 f-v syn-801 ctx-empty f-v term-one f-v f-v f-v f-v term-add term-add term-add ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v term-one ctx-empty ax-A2 f-v f-v f-v f-v term-add term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-817 $p term ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) $=
 term-one f-v f-v f-v f-v f-v term-add term-add term-add term-add term-add $.
$}
${
syn-818 $p term ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v f-v syn-817 term-add $.
$}
${
syn-819 $p term ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v syn-818 term-add $.
$}
${
dag-820 $p |- [] => ( ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-803 f-v syn-819 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-802 f-v syn-818 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-801 f-v syn-817 ctx-empty f-v ctx-empty eq-refl f-v syn-801 f-v syn-815 f-v syn-817 ctx-empty f-v dag-816 term-one f-v f-v f-v f-v f-v term-add term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-821 $p term ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-819 term-add $.
$}
${
syn-822 $p term ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-821 term-add $.
$}
${
syn-823 $p term ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-822 term-add $.
$}
${
syn-824 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-823 term-add $.
$}
${
syn-825 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-824 term-add $.
$}
${
dag-826 $p |- [] => ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-809 f-v syn-825 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-808 f-v syn-824 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-807 f-v syn-823 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-805 f-v syn-822 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-804 f-v syn-821 ctx-empty f-v ctx-empty eq-refl f-v dag-820 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-827 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-825 term-add $.
$}
${
syn-828 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-827 term-add $.
$}
${
syn-829 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-828 term-add $.
$}
${
syn-830 $p term ( ( v + 1 ) + ( v + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v term-one term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add term-add $.
$}
${
syn-831 $p term ( ( 1 + v ) + ( v + ( v + ( v + ( v + v ) ) ) ) ) $=
 term-one f-v term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add term-add $.
$}
${
dag-832 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) = ( ( 1 + v ) + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v syn-818 f-v syn-830 f-v syn-831 ctx-empty f-v syn-830 f-v syn-818 ctx-empty f-v term-one f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v term-one ctx-empty ax-A2 f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-833 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 term-one f-v syn-679 term-add $.
$}
${
syn-834 $p term ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v f-v syn-833 term-add $.
$}
${
syn-835 $p term ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-834 term-add $.
$}
${
dag-836 $p |- [] => ( ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-821 f-v syn-835 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-819 f-v syn-834 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-818 f-v syn-833 ctx-empty f-v ctx-empty eq-refl f-v syn-818 f-v syn-831 f-v syn-833 ctx-empty f-v dag-832 term-one f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-837 $p term ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-835 term-add $.
$}
${
syn-838 $p term ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-837 term-add $.
$}
${
syn-839 $p term ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-838 term-add $.
$}
${
syn-840 $p term ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-839 term-add $.
$}
${
syn-841 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-840 term-add $.
$}
${
dag-842 $p |- [] => ( ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-827 f-v syn-841 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-825 f-v syn-840 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-824 f-v syn-839 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-823 f-v syn-838 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-822 f-v syn-837 ctx-empty f-v ctx-empty eq-refl f-v dag-836 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-843 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-841 term-add $.
$}
${
syn-844 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-843 term-add $.
$}
${
dag-845 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-714 f-v syn-829 f-v syn-844 ctx-empty f-v syn-714 f-v syn-813 f-v syn-829 ctx-empty f-v syn-714 f-v syn-798 f-v syn-813 ctx-empty f-v dag-799 f-v dag-812 eq-trans term-one term-one f-v syn-811 f-v syn-828 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-810 f-v syn-827 ctx-empty term-one ctx-empty eq-refl f-v dag-826 eq-add-cong eq-add-cong eq-trans term-one term-one f-v syn-828 f-v syn-843 ctx-empty term-one ctx-empty eq-refl f-v dag-842 eq-add-cong eq-trans $.
$}
${
syn-846 $p term ( ( v + 1 ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v term-one term-add f-v syn-679 term-add $.
$}
${
syn-847 $p term ( ( 1 + v ) + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 term-one f-v term-add f-v syn-679 term-add $.
$}
${
syn-848 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 term-one f-v syn-686 term-add $.
$}
${
dag-849 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v syn-834 f-v syn-847 f-v syn-848 ctx-empty f-v syn-834 f-v syn-846 f-v syn-847 ctx-empty f-v syn-846 f-v syn-834 ctx-empty f-v term-one f-v syn-679 ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v syn-679 f-v syn-679 ctx-empty f-v term-one ctx-empty ax-A2 f-v syn-679 ctx-empty eq-refl eq-add-cong eq-trans term-one f-v f-v syn-679 ctx-empty ax-A1 eq-trans $.
$}
${
syn-850 $p term ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v syn-848 term-add $.
$}
${
syn-851 $p term ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-850 term-add $.
$}
${
syn-852 $p term ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-851 term-add $.
$}
${
syn-853 $p term ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-852 term-add $.
$}
${
dag-854 $p |- [] => ( ( v + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-839 f-v syn-853 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-838 f-v syn-852 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-837 f-v syn-851 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-835 f-v syn-850 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-834 f-v syn-848 ctx-empty f-v ctx-empty eq-refl f-v dag-849 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-855 $p term ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-853 term-add $.
$}
${
syn-856 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-855 term-add $.
$}
${
syn-857 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-856 term-add $.
$}
${
syn-858 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-857 term-add $.
$}
${
syn-859 $p term ( ( v + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 f-v term-one term-add f-v syn-686 term-add $.
$}
${
syn-860 $p term ( ( 1 + v ) + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) $=
 term-one f-v term-add f-v syn-686 term-add $.
$}
${
syn-861 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 term-one f-v syn-687 term-add $.
$}
${
dag-862 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v syn-850 f-v syn-860 f-v syn-861 ctx-empty f-v syn-850 f-v syn-859 f-v syn-860 ctx-empty f-v syn-859 f-v syn-850 ctx-empty f-v term-one f-v syn-686 ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v syn-686 f-v syn-686 ctx-empty f-v term-one ctx-empty ax-A2 f-v syn-686 ctx-empty eq-refl eq-add-cong eq-trans term-one f-v f-v syn-686 ctx-empty ax-A1 eq-trans $.
$}
${
syn-863 $p term ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-861 term-add $.
$}
${
syn-864 $p term ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-863 term-add $.
$}
${
syn-865 $p term ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-864 term-add $.
$}
${
syn-866 $p term ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-865 term-add $.
$}
${
dag-867 $p |- [] => ( ( 1 + ( v + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-855 f-v syn-866 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-853 f-v syn-865 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-852 f-v syn-864 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-851 f-v syn-863 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-850 f-v syn-861 ctx-empty f-v ctx-empty eq-refl f-v dag-862 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-868 $p term ( 1 + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-866 term-add $.
$}
${
syn-869 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-868 term-add $.
$}
${
syn-870 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-869 term-add $.
$}
${
dag-871 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-714 f-v syn-858 f-v syn-870 ctx-empty f-v syn-714 f-v syn-844 f-v syn-858 ctx-empty f-v dag-845 term-one term-one f-v syn-843 f-v syn-857 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-841 f-v syn-856 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-840 f-v syn-855 ctx-empty term-one ctx-empty eq-refl f-v dag-854 eq-add-cong eq-add-cong eq-add-cong eq-trans term-one term-one f-v syn-857 f-v syn-869 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-856 f-v syn-868 ctx-empty term-one ctx-empty eq-refl f-v dag-867 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-872 $p term ( ( v + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v term-one term-add f-v syn-687 term-add $.
$}
${
syn-873 $p term ( ( 1 + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 term-one f-v term-add f-v syn-687 term-add $.
$}
${
syn-874 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-689 term-add $.
$}
${
dag-875 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-863 f-v syn-873 f-v syn-874 ctx-empty f-v syn-863 f-v syn-872 f-v syn-873 ctx-empty f-v syn-872 f-v syn-863 ctx-empty f-v term-one f-v syn-687 ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v syn-687 f-v syn-687 ctx-empty f-v term-one ctx-empty ax-A2 f-v syn-687 ctx-empty eq-refl eq-add-cong eq-trans term-one f-v f-v syn-687 ctx-empty ax-A1 eq-trans $.
$}
${
syn-876 $p term ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-874 term-add $.
$}
${
syn-877 $p term ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-876 term-add $.
$}
${
syn-878 $p term ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-877 term-add $.
$}
${
syn-879 $p term ( 1 + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-878 term-add $.
$}
${
dag-880 $p |- [] => ( ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-868 f-v syn-879 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-866 f-v syn-878 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-865 f-v syn-877 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-864 f-v syn-876 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-863 f-v syn-874 ctx-empty f-v ctx-empty eq-refl f-v dag-875 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-881 $p term ( 1 + ( 1 + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-879 term-add $.
$}
${
syn-882 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-881 term-add $.
$}
${
syn-883 $p term ( ( v + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v term-one term-add f-v syn-689 term-add $.
$}
${
syn-884 $p term ( ( 1 + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 term-one f-v term-add f-v syn-689 term-add $.
$}
${
syn-885 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-697 term-add $.
$}
${
dag-886 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-876 f-v syn-884 f-v syn-885 ctx-empty f-v syn-876 f-v syn-883 f-v syn-884 ctx-empty f-v syn-883 f-v syn-876 ctx-empty f-v term-one f-v syn-689 ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v syn-689 f-v syn-689 ctx-empty f-v term-one ctx-empty ax-A2 f-v syn-689 ctx-empty eq-refl eq-add-cong eq-trans term-one f-v f-v syn-689 ctx-empty ax-A1 eq-trans $.
$}
${
syn-887 $p term ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-885 term-add $.
$}
${
syn-888 $p term ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-887 term-add $.
$}
${
syn-889 $p term ( 1 + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-888 term-add $.
$}
${
syn-890 $p term ( 1 + ( 1 + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-889 term-add $.
$}
${
dag-891 $p |- [] => ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( 1 + ( 1 + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one f-v syn-881 f-v syn-890 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-879 f-v syn-889 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-878 f-v syn-888 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-877 f-v syn-887 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-876 f-v syn-885 ctx-empty f-v ctx-empty eq-refl f-v dag-886 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-892 $p term ( 1 + ( 1 + ( 1 + ( v + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-890 term-add $.
$}
${
syn-893 $p term ( ( v + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 f-v term-one term-add f-v syn-697 term-add $.
$}
${
syn-894 $p term ( ( 1 + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v term-add f-v syn-697 term-add $.
$}
${
syn-895 $p term ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-698 term-add $.
$}
${
dag-896 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-887 f-v syn-894 f-v syn-895 ctx-empty f-v syn-887 f-v syn-893 f-v syn-894 ctx-empty f-v syn-893 f-v syn-887 ctx-empty f-v term-one f-v syn-697 ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v syn-697 f-v syn-697 ctx-empty f-v term-one ctx-empty ax-A2 f-v syn-697 ctx-empty eq-refl eq-add-cong eq-trans term-one f-v f-v syn-697 ctx-empty ax-A1 eq-trans $.
$}
${
syn-897 $p term ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-895 term-add $.
$}
${
syn-898 $p term ( 1 + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-897 term-add $.
$}
${
syn-899 $p term ( 1 + ( 1 + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-898 term-add $.
$}
${
syn-900 $p term ( 1 + ( 1 + ( 1 + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-899 term-add $.
$}
${
dag-901 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) + 1 ) = ( 1 + ( 1 + ( 1 + ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-714 f-v syn-892 f-v syn-900 ctx-empty f-v syn-714 f-v syn-882 f-v syn-892 ctx-empty f-v syn-714 f-v syn-870 f-v syn-882 ctx-empty f-v dag-871 term-one term-one f-v syn-869 f-v syn-881 ctx-empty term-one ctx-empty eq-refl f-v dag-880 eq-add-cong eq-trans f-v dag-891 eq-trans term-one term-one f-v syn-890 f-v syn-899 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-889 f-v syn-898 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-888 f-v syn-897 ctx-empty term-one ctx-empty eq-refl f-v f-v f-v syn-887 f-v syn-895 ctx-empty f-v ctx-empty eq-refl f-v dag-896 eq-add-cong eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-902 $p term ( ( v + 1 ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v term-one term-add f-v syn-698 term-add $.
$}
${
syn-903 $p term ( ( 1 + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v term-add f-v syn-698 term-add $.
$}
${
dag-904 $p |- [] => ( ( v + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) = ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-897 f-v syn-903 f-v syn-708 ctx-empty f-v syn-897 f-v syn-902 f-v syn-903 ctx-empty f-v syn-902 f-v syn-897 ctx-empty f-v term-one f-v syn-698 ctx-empty ax-A1 eq-sym f-v term-one term-add term-one f-v term-add f-v syn-698 f-v syn-698 ctx-empty f-v term-one ctx-empty ax-A2 f-v syn-698 ctx-empty eq-refl eq-add-cong eq-trans term-one f-v f-v syn-698 ctx-empty ax-A1 eq-trans $.
$}
${
syn-905 $p term ( 1 + ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-711 term-add $.
$}
${
syn-906 $p term ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) $=
 f-v syn-661 term-one term-add $.
$}
${
dag-907 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) = ( 1 + ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-906 f-v syn-714 f-v syn-905 ctx-empty f-v syn-661 f-v syn-711 term-one term-one ctx-empty f-v dag-713 term-one ctx-empty eq-refl eq-add-cong f-v syn-714 f-v syn-900 f-v syn-905 ctx-empty f-v dag-901 term-one term-one f-v syn-899 f-v syn-711 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-898 f-v syn-709 ctx-empty term-one ctx-empty eq-refl term-one term-one f-v syn-897 f-v syn-708 ctx-empty term-one ctx-empty eq-refl f-v dag-904 eq-add-cong eq-add-cong eq-add-cong eq-trans eq-trans $.
$}
${
dag-908 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * v ) = ( ( v * 1 ) + ( v * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-add term-add f-v term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add f-v f-v ctx-empty dag-6 f-v ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-add term-add f-v term-mul f-v term-one term-one term-one term-add term-add term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add f-v ctx-empty ax-A5 f-v term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-154 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * v ) = ( v + ( v + v ) ) ) $=
 term-one term-one term-add term-one term-add f-v term-mul f-v term-one term-mul f-v term-one term-one term-add term-mul term-add f-v f-v f-v term-add term-add ctx-empty f-v dag-908 f-v dag-645 eq-trans $.
$}
${
dag-909 $p |- [] => ( ( ( v + ( v + v ) ) + 1 ) = ( v + ( v + ( 1 + v ) ) ) ) $=
 f-v f-v f-v term-add term-add term-one term-add f-v f-v f-v term-one term-add term-add term-add f-v f-v term-one f-v term-add term-add term-add ctx-empty f-v f-v f-v term-add term-add term-one term-add f-v f-v f-v term-add term-one term-add term-add f-v f-v f-v term-one term-add term-add term-add ctx-empty f-v dag-649 f-v f-v f-v f-v term-add term-one term-add f-v f-v term-one term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-650 eq-add-cong eq-trans f-v f-v f-v f-v term-one term-add term-add f-v term-one f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v term-one term-add term-one f-v term-add ctx-empty f-v ctx-empty eq-refl f-v term-one ctx-empty ax-A2 eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-910 $p |- [] => ( ( ( v + ( v + v ) ) + 1 ) = ( v + ( 1 + ( v + v ) ) ) ) $=
 f-v f-v f-v term-add term-add term-one term-add f-v f-v term-one f-v term-add term-add term-add f-v term-one f-v f-v term-add term-add term-add ctx-empty f-v dag-909 f-v f-v f-v term-one f-v term-add term-add term-one f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v term-one f-v term-add term-add term-one f-v term-add f-v term-add term-one f-v f-v term-add term-add ctx-empty f-v dag-654 term-one f-v f-v ctx-empty ax-A1 eq-trans eq-add-cong eq-trans $.
$}
${
dag-911 $p |- [] => ( ( ( v + ( v + v ) ) + 1 ) = ( 1 + ( v + ( v + v ) ) ) ) $=
 f-v f-v f-v term-add term-add term-one term-add f-v term-one f-v f-v term-add term-add term-add term-one f-v f-v f-v term-add term-add term-add ctx-empty f-v dag-910 f-v term-one f-v f-v term-add term-add term-add term-one f-v term-add f-v f-v term-add term-add term-one f-v f-v f-v term-add term-add term-add ctx-empty f-v dag-657 term-one f-v f-v f-v term-add ctx-empty ax-A1 eq-trans eq-trans $.
$}
${
arith-155 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) = ( 1 + ( v + ( v + v ) ) ) ) $=
 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-v f-v f-v term-add term-add term-one term-add term-one f-v f-v f-v term-add term-add term-add ctx-empty term-one term-one term-add term-one term-add f-v term-mul f-v f-v f-v term-add term-add term-one term-one ctx-empty f-v arith-154 term-one ctx-empty eq-refl eq-add-cong f-v dag-911 eq-trans $.
$}
${
syn-912 $p term ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) $=
 term-one term-one term-add term-one term-add term-one term-add term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-mul $.
$}
${
syn-913 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( 1 + ( v + ( v + v ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one f-v f-v f-v term-add term-add term-add term-mul $.
$}
${
syn-914 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + ( v + v ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-v f-v f-v term-add term-add term-mul $.
$}
${
syn-915 $p term ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + ( v + v ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-mul f-v syn-914 term-add $.
$}
${
dag-916 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + ( v + v ) ) ) ) ) $=
 f-v syn-912 f-v syn-913 f-v syn-915 ctx-empty term-one term-one term-add term-one term-add term-one term-add term-one term-one term-one term-one term-add term-add term-add term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-one f-v f-v f-v term-add term-add term-add ctx-empty dag-8 f-v arith-155 eq-mul-cong term-one term-one term-one term-one term-add term-add term-add term-one f-v f-v f-v term-add term-add ctx-empty ax-A8 eq-trans $.
$}
${
syn-917 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + v ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-v f-v term-add term-mul $.
$}
${
syn-918 $p term ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + v ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v syn-917 term-add $.
$}
${
dag-919 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) = ( ( v * 1 ) + ( v * ( 1 + ( 1 + 1 ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-v term-mul term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v syn-642 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-v f-v ctx-empty dag-593 f-v ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v term-one term-one term-one term-one term-add term-add term-add term-mul f-v syn-642 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-v ctx-empty ax-A5 f-v term-one term-one term-one term-one term-add term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-156 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) = ( v + ( v + ( v + v ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v syn-642 f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v dag-919 f-v dag-647 eq-trans $.
$}
${
syn-920 $p term ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-v term-mul term-one term-one term-one term-one term-add term-add term-add f-v term-mul term-add $.
$}
${
dag-921 $p |- [] => ( ( ( v + ( v + ( v + v ) ) ) + ( v + ( v + ( v + v ) ) ) ) = ( ( v + ( v + ( v + v ) ) ) + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-922 $p term ( ( v + ( v + ( v + v ) ) ) + ( v + ( v + ( v + v ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add term-add $.
$}
${
syn-923 $p term ( ( v + ( v + v ) ) + ( v + ( v + ( v + v ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v f-v f-v f-v term-add term-add term-add term-add $.
$}
${
syn-924 $p term ( v + ( ( v + ( v + v ) ) + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v syn-923 term-add $.
$}
${
dag-925 $p |- [] => ( ( ( v + ( v + v ) ) + ( v + ( v + ( v + v ) ) ) ) = ( ( v + ( v + v ) ) + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-926 $p term ( ( v + v ) + ( v + ( v + ( v + v ) ) ) ) $=
 f-v f-v term-add f-v f-v f-v f-v term-add term-add term-add term-add $.
$}
${
syn-927 $p term ( v + ( ( v + v ) + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v syn-926 term-add $.
$}
${
dag-928 $p |- [] => ( ( ( v + v ) + ( v + ( v + ( v + v ) ) ) ) = ( ( v + v ) + ( v + ( v + ( v + v ) ) ) ) ) $=
 f-v f-v term-add f-v f-v term-add f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-929 $p |- [] => ( ( ( v + v ) + ( v + ( v + ( v + v ) ) ) ) = ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) $=
 f-v syn-926 f-v syn-679 f-v syn-679 ctx-empty f-v syn-926 f-v syn-926 f-v syn-679 ctx-empty f-v dag-928 f-v f-v f-v f-v f-v f-v term-add term-add term-add ctx-empty ax-A1 eq-trans f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-trans $.
$}
${
dag-930 $p |- [] => ( ( v + ( ( v + ( v + v ) ) + ( v + ( v + ( v + v ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v f-v syn-923 f-v syn-686 ctx-empty f-v ctx-empty eq-refl f-v syn-923 f-v syn-927 f-v syn-686 ctx-empty f-v syn-923 f-v syn-923 f-v syn-927 ctx-empty f-v dag-925 f-v f-v f-v term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty ax-A1 eq-trans f-v f-v f-v syn-926 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v dag-929 eq-add-cong eq-trans eq-add-cong $.
$}
${
dag-931 $p |- [] => ( ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v syn-920 f-v syn-922 f-v syn-687 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v f-v f-v f-v term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v f-v f-v f-v term-add term-add term-add ctx-empty f-v arith-156 f-v arith-156 eq-add-cong f-v syn-922 f-v syn-924 f-v syn-687 ctx-empty f-v syn-922 f-v syn-922 f-v syn-924 ctx-empty f-v dag-921 f-v f-v f-v f-v term-add term-add f-v f-v f-v f-v term-add term-add term-add ctx-empty ax-A1 eq-trans f-v dag-930 eq-trans eq-trans $.
$}
${
dag-932 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + v ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v syn-917 f-v syn-920 f-v syn-687 ctx-empty f-v syn-917 f-v syn-917 f-v syn-920 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-v f-v term-add f-v f-v term-add ctx-empty dag-593 f-v arith-141 eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-v f-v ctx-empty ax-A8 eq-trans f-v dag-931 eq-trans $.
$}
${
dag-933 $p |- [] => ( ( ( v + ( v + ( v + v ) ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) = ( ( v + ( v + ( v + v ) ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add f-v f-v f-v f-v term-add term-add term-add f-v syn-687 f-v syn-687 ctx-empty f-v f-v f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-v f-v f-v syn-686 f-v syn-686 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-679 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-934 $p term ( ( v + ( v + ( v + v ) ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v f-v f-v term-add term-add term-add f-v syn-687 term-add $.
$}
${
syn-935 $p term ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v syn-687 term-add $.
$}
${
syn-936 $p term ( v + ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-935 term-add $.
$}
${
dag-937 $p |- [] => ( ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) = ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add f-v syn-687 f-v syn-687 ctx-empty f-v f-v f-v f-v term-add f-v f-v term-add ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong eq-add-cong f-v f-v f-v syn-686 f-v syn-686 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-679 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-938 $p term ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) $=
 f-v f-v term-add f-v syn-687 term-add $.
$}
${
syn-939 $p term ( v + ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v syn-938 term-add $.
$}
${
dag-940 $p |- [] => ( ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) = ( ( v + v ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) $=
 f-v f-v term-add f-v f-v term-add f-v syn-687 f-v syn-687 ctx-empty f-v f-v f-v f-v ctx-empty f-v ctx-empty eq-refl f-v ctx-empty eq-refl eq-add-cong f-v f-v f-v syn-686 f-v syn-686 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-679 f-v syn-679 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v f-v f-v f-v f-v term-add term-add term-add term-add f-v f-v f-v f-v f-v term-add term-add term-add term-add ctx-empty f-v ctx-empty eq-refl f-v dag-677 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-941 $p |- [] => ( ( ( v + ( v + v ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-935 f-v syn-939 f-v syn-698 ctx-empty f-v syn-935 f-v syn-935 f-v syn-939 ctx-empty f-v dag-937 f-v f-v f-v term-add f-v syn-687 ctx-empty ax-A1 eq-trans f-v f-v f-v syn-938 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v syn-938 f-v syn-697 f-v syn-697 ctx-empty f-v syn-938 f-v syn-938 f-v syn-697 ctx-empty f-v dag-940 f-v f-v f-v syn-687 ctx-empty ax-A1 eq-trans f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-trans eq-add-cong eq-trans $.
$}
${
dag-942 $p |- [] => ( ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * v ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + v ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-918 f-v syn-934 f-v syn-700 ctx-empty term-one term-one term-one term-one term-add term-add term-add f-v term-mul f-v f-v f-v f-v term-add term-add term-add f-v syn-917 f-v syn-687 ctx-empty f-v arith-156 f-v dag-932 eq-add-cong f-v syn-934 f-v syn-936 f-v syn-700 ctx-empty f-v syn-934 f-v syn-934 f-v syn-936 ctx-empty f-v dag-933 f-v f-v f-v f-v term-add term-add f-v syn-687 ctx-empty ax-A1 eq-trans f-v f-v f-v syn-935 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v dag-941 eq-add-cong eq-trans eq-trans $.
$}
${
dag-943 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + ( v + v ) ) ) = ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-914 f-v syn-918 f-v syn-700 ctx-empty f-v syn-914 f-v syn-914 f-v syn-918 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-v f-v f-v term-add term-add f-v f-v f-v term-add term-add ctx-empty dag-593 f-v dag-665 eq-mul-cong term-one term-one term-one term-one term-add term-add term-add f-v f-v f-v term-add ctx-empty ax-A8 eq-trans f-v dag-942 eq-trans $.
$}
${
dag-944 $p |- [] => ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) = ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add term-one term-one term-one term-one term-add term-add term-add f-v syn-700 f-v syn-700 ctx-empty term-one term-one term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one term-add term-one term-one term-add ctx-empty term-one ctx-empty eq-refl term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-v f-v f-v syn-698 f-v syn-698 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-697 f-v syn-697 ctx-empty f-v ctx-empty eq-refl f-v f-v f-v syn-689 f-v syn-689 ctx-empty f-v ctx-empty eq-refl f-v dag-692 eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-945 $p term ( ( 1 + ( 1 + ( 1 + 1 ) ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one term-one term-one term-one term-add term-add term-add f-v syn-700 term-add $.
$}
${
syn-946 $p term ( 1 + ( ( 1 + ( 1 + 1 ) ) + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 term-one f-v syn-704 term-add $.
$}
${
dag-947 $p |- [] => ( ( ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * 1 ) + ( ( 1 + ( 1 + ( 1 + 1 ) ) ) * ( v + ( v + v ) ) ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-915 f-v syn-945 f-v syn-905 ctx-empty term-one term-one term-one term-one term-add term-add term-add term-one term-mul term-one term-one term-one term-one term-add term-add term-add f-v syn-914 f-v syn-700 ctx-empty arith-122 f-v dag-943 eq-add-cong f-v syn-945 f-v syn-946 f-v syn-905 ctx-empty f-v syn-945 f-v syn-945 f-v syn-946 ctx-empty f-v dag-944 term-one term-one term-one term-one term-add term-add f-v syn-700 ctx-empty ax-A1 eq-trans term-one term-one f-v syn-704 f-v syn-711 ctx-empty term-one ctx-empty eq-refl f-v dag-712 eq-add-cong eq-trans eq-trans $.
$}
${
arith-162 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( 1 + ( 1 + ( 1 + ( 1 + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + ( v + v ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) $=
 f-v syn-912 f-v syn-915 f-v syn-905 ctx-empty f-v dag-916 f-v dag-947 eq-trans $.
$}
${
arith-163 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) = ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) ) $=
 f-v syn-906 f-v syn-905 f-v syn-912 ctx-empty f-v dag-907 f-v syn-912 f-v syn-905 ctx-empty f-v arith-162 eq-sym eq-trans $.
$}
${
syn-948 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( 1 + 1 ) + 1 ) + 1 ) ) $=
 f-t syn-586 term-one term-one term-add term-one term-add term-one term-add term-mul $.
$}
${
syn-949 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) $=
 f-t syn-581 term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-mul $.
$}
${
syn-950 $p term ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) $=
 f-t syn-588 term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-mul $.
$}
${
syn-951 $p term ( ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( 1 + 1 ) + 1 ) + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) $=
 f-t syn-948 term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-mul $.
$}
${
dag-952 $p |- [] => ( ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( 1 + 1 ) + 1 ) + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) ) $=
 f-t f-v syn-949 f-t f-v syn-950 f-t f-v syn-951 ctx-empty f-t syn-581 f-t syn-588 term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-one term-one term-add term-one term-add f-v term-mul term-one term-add ctx-empty f-t arith-133 term-one term-one term-add term-one term-add f-v term-mul term-one term-add ctx-empty eq-refl eq-mul-cong f-t syn-588 f-t syn-948 term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-one term-one term-add term-one term-add f-v term-mul term-one term-add ctx-empty term-one term-one term-add term-one term-add term-one term-add f-t syn-586 ctx-empty ax-A5 term-one term-one term-add term-one term-add f-v term-mul term-one term-add ctx-empty eq-refl eq-mul-cong eq-trans $.
$}
${
syn-953 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) ) $=
 f-t syn-586 f-v syn-912 term-mul $.
$}
${
syn-954 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) ) $=
 f-t syn-586 f-v syn-906 term-mul $.
$}
${
dag-955 $p |- [] => ( ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) ) ) $=
 f-t f-v syn-949 f-t f-v syn-953 f-t f-v syn-954 ctx-empty f-t f-v syn-949 f-t f-v syn-951 f-t f-v syn-953 ctx-empty f-t f-v dag-952 f-t syn-586 term-one term-one term-add term-one term-add term-one term-add term-one term-one term-add term-one term-add f-v term-mul term-one term-add ctx-empty ax-A4 eq-trans f-t syn-586 f-t syn-586 f-v syn-912 f-v syn-906 ctx-empty f-t syn-586 ctx-empty eq-refl f-v syn-906 f-v syn-912 ctx-empty f-v arith-163 eq-sym eq-mul-cong eq-trans $.
$}
${
syn-956 $p wff ( ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) ) ) $=
 f-t f-v syn-949 f-t f-v syn-954 w-eq $.
$}
${
syn-957 $p term ( ( ( ( 1 + 1 ) + 1 ) * e0 ) + ( 1 + 1 ) ) $=
 term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-one term-add term-add $.
$}
${
$d e0 v $.
syn-958 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * e0 ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) $=
 f-e0 syn-957 term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-mul $.
$}
${
syn-959 $p term ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) $=
 term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add term-add $.
$}
${
syn-960 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) $=
 f-w syn-959 term-one term-one term-add term-one term-add f-v term-mul term-one term-add term-mul $.
$}
${
$d e0 t $.
$d e0 v $.
syn-961 $p wff ( ( ( ( ( ( 1 + 1 ) + 1 ) * e0 ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) ) ) $=
 f-v f-e0 syn-958 f-t f-v syn-954 w-eq $.
$}
${
syn-962 $p wff ( ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) ) ) $=
 f-v f-w syn-960 f-t f-v syn-954 w-eq $.
$}
${
$d e0 t $.
$d e0 u $.
$d e0 v $.
$d e0 w $.
dag-963 $p |- ( [] ; ( ( w = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) /\ ( u = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) ) ) => ( ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) + 1 ) ) ) $=
 f-e0 f-t syn-0 f-w f-t f-v f-e0 syn-961 f-t f-v syn-956 f-t f-v f-w syn-962 f-t f-u f-v f-w syn-5 f-w f-t syn-0 f-t f-u f-v f-w syn-5 f-t f-w syn-1 f-u f-v syn-3 f-t f-u f-v f-w syn-5 f-t f-u f-v f-w syn-4 ctx-empty nd-assume nd-and-left eq-sym f-e0 f-t syn-0 f-v f-e0 syn-958 f-t f-v syn-954 f-t f-v syn-949 f-t f-v syn-954 f-e0 f-t syn-0 f-e0 syn-957 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-t syn-581 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-e0 f-t syn-0 term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-one term-add f-t syn-51 term-one term-one term-add f-e0 f-t syn-0 term-one term-one term-add term-one term-add f-e0 term-var term-one term-one term-add term-one term-add f-t syn-0 f-e0 f-t syn-0 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t syn-0 term-one term-one term-one term-one f-e0 f-t syn-0 st-one f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 st-same st-mul-general f-e0 f-t syn-0 term-one term-one term-one term-one f-e0 f-t syn-0 st-one f-e0 f-t syn-0 st-one st-add-general st-add-general f-e0 f-t syn-0 term-one term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-add term-one term-add f-v term-mul term-one f-e0 f-t syn-0 term-one term-one term-add term-one term-add f-v term-one term-one term-add term-one term-add f-v f-e0 f-t syn-0 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t syn-0 term-one term-one term-one term-one f-e0 f-t syn-0 st-one f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 st-one st-add-general f-e0 f-v f-t syn-0 st-fresh st-mul-general f-e0 f-t syn-0 st-one st-add-general st-mul-general f-e0 f-t syn-0 f-t syn-586 f-v syn-906 f-t syn-586 f-v syn-906 f-e0 f-t syn-0 term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add f-e0 f-t syn-0 term-one term-one term-add term-one term-add f-t term-one term-one term-add term-one term-add f-t f-e0 f-t syn-0 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t syn-0 term-one term-one term-one term-one f-e0 f-t syn-0 st-one f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 st-one st-add-general f-e0 f-t f-t syn-0 st-fresh st-mul-general f-e0 f-t syn-0 term-one term-one term-one term-one f-e0 f-t syn-0 st-one f-e0 f-t syn-0 st-one st-add-general st-add-general f-e0 f-t syn-0 f-v syn-661 term-one f-v syn-661 term-one f-e0 f-t syn-0 term-one term-one term-add term-one term-add f-v syn-2 term-one term-one term-add term-one term-add f-v syn-2 f-e0 f-t syn-0 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t syn-0 term-one term-one term-one term-one f-e0 f-t syn-0 st-one f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 term-one term-one term-add term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-add term-one term-add term-one term-add f-v term-mul term-one f-e0 f-t syn-0 term-one term-one term-add term-one term-add term-one term-add f-v term-one term-one term-add term-one term-add term-one term-add f-v f-e0 f-t syn-0 term-one term-one term-add term-one term-add term-one term-one term-one term-add term-one term-add term-one f-e0 f-t syn-0 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t syn-0 term-one term-one term-one term-one f-e0 f-t syn-0 st-one f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 st-one st-add-general f-e0 f-t syn-0 st-one st-add-general f-e0 f-v f-t syn-0 st-fresh st-mul-general f-e0 f-t syn-0 st-one st-add-general st-mul-general f-e0 f-t syn-0 st-one st-add-general st-mul-general sf-eq f-e0 f-w f-v f-e0 syn-958 f-t f-v syn-954 f-v f-w syn-960 f-t f-v syn-954 f-e0 f-w f-e0 syn-957 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-w syn-959 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-e0 f-w term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add f-e0 f-w term-one term-one term-add term-one term-add f-e0 term-var term-one term-one term-add term-one term-add f-w f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-w st-same st-mul-general f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general st-add-general f-e0 f-w term-one term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-add term-one term-add f-v term-mul term-one f-e0 f-w term-one term-one term-add term-one term-add f-v term-one term-one term-add term-one term-add f-v f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-v f-w st-fresh st-mul-general f-e0 f-w st-one st-add-general st-mul-general f-e0 f-w f-t syn-586 f-v syn-906 f-t syn-586 f-v syn-906 f-e0 f-w term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add f-e0 f-w term-one term-one term-add term-one term-add f-t term-one term-one term-add term-one term-add f-t f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-t f-w st-fresh st-mul-general f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general st-add-general f-e0 f-w f-v syn-661 term-one f-v syn-661 term-one f-e0 f-w term-one term-one term-add term-one term-add f-v syn-2 term-one term-one term-add term-one term-add f-v syn-2 f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-w term-one term-one term-add term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-add term-one term-add term-one term-add f-v term-mul term-one f-e0 f-w term-one term-one term-add term-one term-add term-one term-add f-v term-one term-one term-add term-one term-add term-one term-add f-v f-e0 f-w term-one term-one term-add term-one term-add term-one term-one term-one term-add term-one term-add term-one f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-v f-w st-fresh st-mul-general f-e0 f-w st-one st-add-general st-mul-general f-e0 f-w st-one st-add-general st-mul-general sf-eq f-t f-v syn-956 f-t f-u f-v f-w syn-5 f-t f-v dag-955 nd-empty-weaken eq-replace $.
$}
${
$d e0 t $.
syn-964 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * e0 ) + 1 ) ) $=
 f-t syn-586 term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-add term-mul $.
$}
${
syn-965 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) $=
 f-t syn-586 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-mul $.
$}
${
$d e0 t $.
$d e0 v $.
$d e0 w $.
syn-966 $p wff ( ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * e0 ) + 1 ) ) ) $=
 f-v f-w syn-960 f-t f-e0 syn-964 w-eq $.
$}
${
syn-967 $p wff ( ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) ) $=
 f-v f-w syn-960 f-t f-u syn-965 w-eq $.
$}
${
$d e0 t $.
$d e0 u $.
$d e0 v $.
$d e0 w $.
dag-968 $p |- ( [] ; ( ( w = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) /\ ( u = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) ) ) => ( ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) ) $=
 f-e0 f-v syn-2 f-u f-t f-v f-w f-e0 syn-966 f-t f-v f-w syn-962 f-t f-u f-v f-w syn-967 f-t f-u f-v f-w syn-5 f-u f-v syn-2 f-t f-u f-v f-w syn-5 f-t f-w syn-1 f-u f-v syn-3 f-t f-u f-v f-w syn-5 f-t f-u f-v f-w syn-4 ctx-empty nd-assume nd-and-right eq-sym f-e0 f-v syn-2 f-v f-w syn-960 f-t f-e0 syn-964 f-v f-w syn-960 f-t f-v syn-954 f-e0 f-v syn-2 f-w syn-959 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-w syn-959 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-w term-one term-one term-add term-one term-add f-w f-e0 f-v syn-2 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-v syn-2 term-one term-one term-one term-one f-e0 f-v syn-2 st-one f-e0 f-v syn-2 st-one st-add-general f-e0 f-v syn-2 st-one st-add-general f-e0 f-w f-v syn-2 st-fresh st-mul-general f-e0 f-v syn-2 term-one term-one term-one term-one f-e0 f-v syn-2 st-one f-e0 f-v syn-2 st-one st-add-general st-add-general f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-add term-one term-add f-v term-mul term-one f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-v term-one term-one term-add term-one term-add f-v f-e0 f-v syn-2 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-v syn-2 term-one term-one term-one term-one f-e0 f-v syn-2 st-one f-e0 f-v syn-2 st-one st-add-general f-e0 f-v syn-2 st-one st-add-general f-e0 f-v f-v syn-2 st-fresh st-mul-general f-e0 f-v syn-2 st-one st-add-general st-mul-general f-e0 f-v syn-2 f-t syn-586 term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-add f-t syn-586 f-v syn-906 f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-t term-one term-one term-add term-one term-add f-t f-e0 f-v syn-2 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-v syn-2 term-one term-one term-one term-one f-e0 f-v syn-2 st-one f-e0 f-v syn-2 st-one st-add-general f-e0 f-v syn-2 st-one st-add-general f-e0 f-t f-v syn-2 st-fresh st-mul-general f-e0 f-v syn-2 term-one term-one term-one term-one f-e0 f-v syn-2 st-one f-e0 f-v syn-2 st-one st-add-general st-add-general f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one f-v syn-661 term-one f-e0 f-v syn-2 term-one term-one term-add term-one term-add f-e0 term-var term-one term-one term-add term-one term-add f-v syn-2 f-e0 f-v syn-2 term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-v syn-2 term-one term-one term-one term-one f-e0 f-v syn-2 st-one f-e0 f-v syn-2 st-one st-add-general f-e0 f-v syn-2 st-one st-add-general f-e0 f-v syn-2 st-same st-mul-general f-e0 f-v syn-2 st-one st-add-general st-mul-general sf-eq f-e0 f-u f-v f-w syn-960 f-t f-e0 syn-964 f-v f-w syn-960 f-t f-u syn-965 f-e0 f-u f-w syn-959 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-w syn-959 term-one term-one term-add term-one term-add f-v term-mul term-one term-add f-e0 f-u term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add f-e0 f-u term-one term-one term-add term-one term-add f-w term-one term-one term-add term-one term-add f-w f-e0 f-u term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-u term-one term-one term-one term-one f-e0 f-u st-one f-e0 f-u st-one st-add-general f-e0 f-u st-one st-add-general f-e0 f-w f-u st-fresh st-mul-general f-e0 f-u term-one term-one term-one term-one f-e0 f-u st-one f-e0 f-u st-one st-add-general st-add-general f-e0 f-u term-one term-one term-add term-one term-add f-v term-mul term-one term-one term-one term-add term-one term-add f-v term-mul term-one f-e0 f-u term-one term-one term-add term-one term-add f-v term-one term-one term-add term-one term-add f-v f-e0 f-u term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-u term-one term-one term-one term-one f-e0 f-u st-one f-e0 f-u st-one st-add-general f-e0 f-u st-one st-add-general f-e0 f-v f-u st-fresh st-mul-general f-e0 f-u st-one st-add-general st-mul-general f-e0 f-u f-t syn-586 term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-add f-t syn-586 term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-e0 f-u term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-t term-mul term-one term-one term-add f-e0 f-u term-one term-one term-add term-one term-add f-t term-one term-one term-add term-one term-add f-t f-e0 f-u term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-u term-one term-one term-one term-one f-e0 f-u st-one f-e0 f-u st-one st-add-general f-e0 f-u st-one st-add-general f-e0 f-t f-u st-fresh st-mul-general f-e0 f-u term-one term-one term-one term-one f-e0 f-u st-one f-e0 f-u st-one st-add-general st-add-general f-e0 f-u term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-one term-one term-add term-one term-add f-u term-mul term-one f-e0 f-u term-one term-one term-add term-one term-add f-e0 term-var term-one term-one term-add term-one term-add f-u f-e0 f-u term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-u term-one term-one term-one term-one f-e0 f-u st-one f-e0 f-u st-one st-add-general f-e0 f-u st-one st-add-general f-e0 f-u st-same st-mul-general f-e0 f-u st-one st-add-general st-mul-general sf-eq f-t f-u f-v f-w dag-963 eq-replace $.
$}
${
skelet17-pair-scan-product $p |- [] => ( ( ( w = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) ) /\ ( u = ( ( ( ( ( 1 + 1 ) + 1 ) + 1 ) * v ) + 1 ) ) ) -> ( ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * v ) + 1 ) ) = ( ( ( ( ( 1 + 1 ) + 1 ) * t ) + ( 1 + 1 ) ) * ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) ) ) $=
 f-t f-u f-v f-w syn-4 f-t f-u f-v f-w syn-967 ctx-empty f-t f-u f-v f-w dag-968 nd-imp-intro $.
$}
${
syn-969 $p wff ( t = ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) $=
 f-t term-one term-one term-add term-one term-add f-u term-mul term-one term-add w-eq $.
$}
${
syn-970 $p wff ( ( t = ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) /\ ( w = ( ( t * v ) + u ) ) ) $=
 f-t f-u syn-969 f-w f-t f-v term-mul f-u term-add w-eq w-and $.
$}
${
syn-971 $p ctx ( [] ; ( ( t = ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) /\ ( w = ( ( t * v ) + u ) ) ) ) $=
 f-t f-u f-v f-w syn-970 ctx-empty ctx-cons $.
$}
${
dag-972 $p |- [] => ( ( ( t * v ) + u ) = ( ( t * v ) + u ) ) $=
 f-t f-v term-mul f-u term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-u term-add ctx-empty f-t f-v term-mul f-t f-v term-mul f-u f-u ctx-empty f-t f-v arith-78 f-u ctx-empty eq-refl eq-add-cong f-t f-v term-mul f-t f-v term-mul f-u f-u ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-973 $p term ( ( ( 1 + 1 ) + 1 ) * ( ( t * v ) + u ) ) $=
 term-one term-one term-add term-one term-add f-t f-v term-mul f-u term-add term-mul $.
$}
${
syn-974 $p term ( ( 1 + ( 1 + 1 ) ) * ( ( t * v ) + u ) ) $=
 term-one term-one term-one term-add term-add f-t f-v term-mul f-u term-add term-mul $.
$}
${
syn-975 $p term ( ( ( 1 + ( 1 + 1 ) ) * ( t * v ) ) + ( ( 1 + ( 1 + 1 ) ) * u ) ) $=
 term-one term-one term-one term-add term-add f-t f-v term-mul term-mul term-one term-one term-one term-add term-add f-u term-mul term-add $.
$}
${
dag-976 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * ( ( t * v ) + u ) ) = ( ( ( 1 + ( 1 + 1 ) ) * ( t * v ) ) + ( ( 1 + ( 1 + 1 ) ) * u ) ) ) $=
 f-t f-u f-v syn-973 f-t f-u f-v syn-974 f-t f-u f-v syn-975 ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-u term-add ctx-empty dag-6 f-t f-u f-v dag-972 eq-mul-cong term-one term-one term-one term-add term-add f-t f-v term-mul f-u ctx-empty ax-A8 eq-trans $.
$}
${
syn-977 $p term ( ( ( t * v ) * 1 ) + ( ( t * v ) * ( 1 + 1 ) ) ) $=
 f-t f-v term-mul term-one term-mul f-t f-v term-mul term-one term-one term-add term-mul term-add $.
$}
${
dag-978 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( t * v ) ) = ( ( ( t * v ) * 1 ) + ( ( t * v ) * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t f-v term-mul term-mul term-one term-one term-one term-add term-add f-t f-v term-mul term-mul f-t f-v syn-977 ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-t f-v term-mul f-t f-v term-mul ctx-empty dag-11 f-t f-v arith-78 eq-mul-cong term-one term-one term-one term-add term-add f-t f-v term-mul term-mul f-t f-v term-mul term-one term-one term-one term-add term-add term-mul f-t f-v syn-977 ctx-empty term-one term-one term-one term-add term-add f-t f-v term-mul ctx-empty ax-A5 f-t f-v term-mul term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-165 $p |- [] => ( ( ( t * v ) * 1 ) = ( t * v ) ) $=
 f-t f-v term-mul term-one term-mul f-t f-v term-mul term-one term-mul f-t f-v term-mul ctx-empty f-t f-v term-mul f-t f-v term-mul term-one term-one ctx-empty f-t f-v arith-78 term-one ctx-empty eq-refl eq-mul-cong f-t f-v term-mul ctx-empty ax-A6 eq-trans $.
$}
${
syn-979 $p term ( ( ( t * v ) * 1 ) + ( ( t * v ) * 1 ) ) $=
 f-t f-v term-mul term-one term-mul f-t f-v term-mul term-one term-mul term-add $.
$}
${
dag-980 $p |- [] => ( ( ( ( t * v ) * 1 ) + ( ( t * v ) * 1 ) ) = ( ( t * v ) + ( t * v ) ) ) $=
 f-t f-v syn-979 f-t f-v term-mul f-t f-v term-mul term-add f-t f-v term-mul f-t f-v term-mul term-add ctx-empty f-t f-v term-mul term-one term-mul f-t f-v term-mul f-t f-v term-mul term-one term-mul f-t f-v term-mul ctx-empty f-t f-v arith-165 f-t f-v arith-165 eq-add-cong f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-981 $p |- [] => ( ( ( t * v ) * ( 1 + 1 ) ) = ( ( t * v ) + ( t * v ) ) ) $=
 f-t f-v term-mul term-one term-one term-add term-mul f-t f-v syn-979 f-t f-v term-mul f-t f-v term-mul term-add ctx-empty f-t f-v term-mul term-one term-one term-add term-mul f-t f-v term-mul term-one term-one term-add term-mul f-t f-v syn-979 ctx-empty f-t f-v term-mul f-t f-v term-mul term-one term-one term-add term-one term-one term-add ctx-empty f-t f-v arith-78 arith-85 eq-mul-cong f-t f-v term-mul term-one term-one ctx-empty ax-A8 eq-trans f-t f-v dag-980 eq-trans $.
$}
${
dag-982 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) = ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul term-add f-t f-v term-mul f-t f-v term-mul term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-983 $p term ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul term-add term-add $.
$}
${
arith-168 $p |- [] => ( ( ( ( t * v ) * 1 ) + ( ( t * v ) * ( 1 + 1 ) ) ) = ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 f-t f-v syn-977 f-t f-v syn-983 f-t f-v syn-983 ctx-empty f-t f-v term-mul term-one term-mul f-t f-v term-mul f-t f-v term-mul term-one term-one term-add term-mul f-t f-v term-mul f-t f-v term-mul term-add ctx-empty f-t f-v arith-165 f-t f-v dag-981 eq-add-cong f-t f-v dag-982 eq-trans $.
$}
${
arith-169 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * ( t * v ) ) = ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 term-one term-one term-one term-add term-add f-t f-v term-mul term-mul f-t f-v syn-977 f-t f-v syn-983 ctx-empty f-t f-v dag-978 f-t f-v arith-168 eq-trans $.
$}
${
dag-984 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * u ) = ( ( u * 1 ) + ( u * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-one term-add term-add f-u term-mul term-one term-one term-one term-add term-add f-u term-mul f-u term-one term-mul f-u term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add term-one term-one term-one term-add term-add f-u f-u ctx-empty dag-11 f-u ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-add term-add f-u term-mul f-u term-one term-one term-one term-add term-add term-mul f-u term-one term-mul f-u term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add f-u ctx-empty ax-A5 f-u term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-170 $p |- [] => ( ( ( u * 1 ) + ( u * 1 ) ) = ( u + u ) ) $=
 f-u term-one term-mul f-u term-one term-mul term-add f-u f-u term-add f-u f-u term-add ctx-empty f-u term-one term-mul f-u f-u term-one term-mul f-u ctx-empty f-u arith-21 f-u arith-21 eq-add-cong f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-985 $p |- [] => ( ( u * ( 1 + 1 ) ) = ( u + u ) ) $=
 f-u term-one term-one term-add term-mul f-u term-one term-mul f-u term-one term-mul term-add f-u f-u term-add ctx-empty f-u term-one term-one term-add term-mul f-u term-one term-one term-add term-mul f-u term-one term-mul f-u term-one term-mul term-add ctx-empty f-u f-u term-one term-one term-add term-one term-one term-add ctx-empty f-u ctx-empty eq-refl arith-85 eq-mul-cong f-u term-one term-one ctx-empty ax-A8 eq-trans f-u arith-170 eq-trans $.
$}
${
dag-986 $p |- [] => ( ( ( u * 1 ) + ( u * ( 1 + 1 ) ) ) = ( u + ( u + u ) ) ) $=
 f-u term-one term-mul f-u term-one term-one term-add term-mul term-add f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty f-u term-one term-mul f-u f-u term-one term-one term-add term-mul f-u f-u term-add ctx-empty f-u arith-21 f-u dag-985 eq-add-cong f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
arith-173 $p |- [] => ( ( ( 1 + ( 1 + 1 ) ) * u ) = ( u + ( u + u ) ) ) $=
 term-one term-one term-one term-add term-add f-u term-mul f-u term-one term-mul f-u term-one term-one term-add term-mul term-add f-u f-u f-u term-add term-add ctx-empty f-u dag-984 f-u dag-986 eq-trans $.
$}
${
syn-987 $p term ( ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) + ( u + ( u + u ) ) ) $=
 f-t f-v syn-983 f-u f-u f-u term-add term-add term-add $.
$}
${
syn-988 $p term ( ( ( t * v ) + ( t * v ) ) + ( u + ( u + u ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul term-add f-u f-u f-u term-add term-add term-add $.
$}
${
syn-989 $p term ( ( t * v ) + ( ( ( t * v ) + ( t * v ) ) + ( u + ( u + u ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-988 term-add $.
$}
${
dag-990 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) + ( u + ( u + u ) ) ) = ( ( t * v ) + ( ( ( t * v ) + ( t * v ) ) + ( u + ( u + u ) ) ) ) ) $=
 f-t f-u f-v syn-987 f-t f-u f-v syn-987 f-t f-u f-v syn-989 ctx-empty f-t f-v syn-983 f-t f-v syn-983 f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty f-t f-v dag-982 f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul term-add f-u f-u f-u term-add term-add ctx-empty ax-A1 eq-trans $.
$}
${
dag-991 $p |- [] => ( ( ( ( t * v ) + ( t * v ) ) + ( u + ( u + u ) ) ) = ( ( ( t * v ) + ( t * v ) ) + ( u + ( u + u ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul term-add f-t f-v term-mul f-t f-v term-mul term-add f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul ctx-empty eq-refl eq-add-cong f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-992 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add term-add term-add $.
$}
${
dag-993 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-994 $p |- [] => ( ( ( t * v ) + ( ( ( t * v ) + ( t * v ) ) + ( u + ( u + u ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-988 f-t f-u f-v syn-992 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v syn-988 f-t f-u f-v syn-992 f-t f-u f-v syn-992 ctx-empty f-t f-u f-v syn-988 f-t f-u f-v syn-988 f-t f-u f-v syn-992 ctx-empty f-t f-u f-v dag-991 f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add ctx-empty ax-A1 eq-trans f-t f-u f-v dag-993 eq-trans eq-add-cong $.
$}
${
syn-995 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-992 term-add $.
$}
${
dag-996 $p |- [] => ( ( ( ( 1 + ( 1 + 1 ) ) * ( t * v ) ) + ( ( 1 + ( 1 + 1 ) ) * u ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-u f-v syn-975 f-t f-u f-v syn-987 f-t f-u f-v syn-995 ctx-empty term-one term-one term-one term-add term-add f-t f-v term-mul term-mul f-t f-v syn-983 term-one term-one term-one term-add term-add f-u term-mul f-u f-u f-u term-add term-add ctx-empty f-t f-v arith-169 f-u arith-173 eq-add-cong f-t f-u f-v syn-987 f-t f-u f-v syn-989 f-t f-u f-v syn-995 ctx-empty f-t f-u f-v dag-990 f-t f-u f-v dag-994 eq-trans eq-trans $.
$}
${
arith-175 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * ( ( t * v ) + u ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-u f-v syn-973 f-t f-u f-v syn-975 f-t f-u f-v syn-995 ctx-empty f-t f-u f-v dag-976 f-t f-u f-v dag-996 eq-trans $.
$}
${
dag-997 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) + ( 1 + 1 ) ) = ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-u f-v syn-995 f-t f-u f-v syn-995 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-992 f-t f-u f-v syn-992 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-993 eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-998 $p term ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) + ( 1 + 1 ) ) $=
 f-t f-u f-v syn-995 term-one term-one term-add term-add $.
$}
${
syn-999 $p term ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) + ( 1 + 1 ) ) $=
 f-t f-u f-v syn-992 term-one term-one term-add term-add $.
$}
${
syn-1000 $p term ( ( t * v ) + ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-999 term-add $.
$}
${
syn-1001 $p term ( ( ( t * v ) + ( u + ( u + u ) ) ) + ( 1 + 1 ) ) $=
 f-t f-v term-mul f-u f-u f-u term-add term-add term-add term-one term-one term-add term-add $.
$}
${
syn-1002 $p term ( ( t * v ) + ( ( ( t * v ) + ( u + ( u + u ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1001 term-add $.
$}
${
dag-1003 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) + ( 1 + 1 ) ) = ( ( t * v ) + ( ( ( t * v ) + ( u + ( u + u ) ) ) + ( 1 + 1 ) ) ) ) $=
 f-t f-u f-v syn-999 f-t f-u f-v syn-999 f-t f-u f-v syn-1002 ctx-empty f-t f-u f-v syn-992 f-t f-u f-v syn-992 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-u f-v dag-993 term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add term-add term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
dag-1004 $p |- [] => ( ( ( ( t * v ) + ( u + ( u + u ) ) ) + ( 1 + 1 ) ) = ( ( ( t * v ) + ( u + ( u + u ) ) ) + ( 1 + 1 ) ) ) $=
 f-t f-v term-mul f-u f-u f-u term-add term-add term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add term-one term-one term-add term-one term-one term-add ctx-empty f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
syn-1005 $p term ( ( t * v ) + ( ( u + ( u + u ) ) + ( 1 + 1 ) ) ) $=
 f-t f-v term-mul f-u f-u f-u term-add term-add term-one term-one term-add term-add term-add $.
$}
${
dag-1006 $p |- [] => ( ( ( u + ( u + u ) ) + ( 1 + 1 ) ) = ( ( u + ( u + u ) ) + ( 1 + 1 ) ) ) $=
 f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add term-one term-one term-add term-one term-one term-add ctx-empty f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong $.
$}
${
dag-1007 $p |- [] => ( ( ( u + u ) + ( 1 + 1 ) ) = ( u + ( u + ( 1 + 1 ) ) ) ) $=
 f-u f-u term-add term-one term-one term-add term-add f-u f-u term-add term-one term-one term-add term-add f-u f-u term-one term-one term-add term-add term-add ctx-empty f-u f-u term-add f-u f-u term-add term-one term-one term-add term-one term-one term-add ctx-empty f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong term-one term-one term-one term-one ctx-empty term-one ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong f-u f-u term-one term-one term-add ctx-empty ax-A1 eq-trans $.
$}
${
dag-1008 $p |- [] => ( ( ( u + ( u + u ) ) + ( 1 + 1 ) ) = ( u + ( u + ( u + ( 1 + 1 ) ) ) ) ) $=
 f-u f-u f-u term-add term-add term-one term-one term-add term-add f-u f-u f-u term-add term-one term-one term-add term-add term-add f-u f-u f-u term-one term-one term-add term-add term-add term-add ctx-empty f-u f-u f-u term-add term-add term-one term-one term-add term-add f-u f-u f-u term-add term-add term-one term-one term-add term-add f-u f-u f-u term-add term-one term-one term-add term-add term-add ctx-empty f-u dag-1006 f-u f-u f-u term-add term-one term-one term-add ctx-empty ax-A1 eq-trans f-u f-u f-u f-u term-add term-one term-one term-add term-add f-u f-u term-one term-one term-add term-add term-add ctx-empty f-u ctx-empty eq-refl f-u dag-1007 eq-add-cong eq-trans $.
$}
${
syn-1009 $p term ( ( t * v ) + ( u + ( u + ( u + ( 1 + 1 ) ) ) ) ) $=
 f-t f-v term-mul f-u f-u f-u term-one term-one term-add term-add term-add term-add term-add $.
$}
${
dag-1010 $p |- [] => ( ( ( ( t * v ) + ( u + ( u + u ) ) ) + ( 1 + 1 ) ) = ( ( t * v ) + ( u + ( u + ( u + ( 1 + 1 ) ) ) ) ) ) $=
 f-t f-u f-v syn-1001 f-t f-u f-v syn-1005 f-t f-u f-v syn-1009 ctx-empty f-t f-u f-v syn-1001 f-t f-u f-v syn-1001 f-t f-u f-v syn-1005 ctx-empty f-t f-u f-v dag-1004 f-t f-v term-mul f-u f-u f-u term-add term-add term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add term-one term-one term-add term-add f-u f-u f-u term-one term-one term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1008 eq-add-cong eq-trans $.
$}
${
syn-1011 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( u + ( 1 + 1 ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1009 term-add $.
$}
${
dag-1012 $p |- [] => ( ( ( t * v ) + ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) + ( 1 + 1 ) ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( u + ( 1 + 1 ) ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-999 f-t f-u f-v syn-1011 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v syn-999 f-t f-u f-v syn-1002 f-t f-u f-v syn-1011 ctx-empty f-t f-u f-v dag-1003 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1001 f-t f-u f-v syn-1009 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1010 eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-1013 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( u + ( 1 + 1 ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1011 term-add $.
$}
${
dag-1014 $p |- [] => ( ( u + ( 1 + 1 ) ) = ( ( 1 + u ) + 1 ) ) $=
 f-u term-one term-one term-add term-add f-u term-one term-add term-one term-add term-one f-u term-add term-one term-add ctx-empty f-u term-one term-add term-one term-add f-u term-one term-one term-add term-add ctx-empty f-u term-one term-one ctx-empty ax-A1 eq-sym f-u term-one term-add term-one f-u term-add term-one term-one ctx-empty f-u term-one ctx-empty ax-A2 term-one ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1015 $p |- [] => ( ( u + ( u + ( u + ( 1 + 1 ) ) ) ) = ( u + ( u + ( 1 + ( u + 1 ) ) ) ) ) $=
 f-u f-u f-u f-u term-one term-one term-add term-add term-add f-u term-one f-u term-one term-add term-add term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u term-one term-one term-add term-add term-one f-u term-one term-add term-add ctx-empty f-u ctx-empty eq-refl f-u term-one term-one term-add term-add term-one f-u term-add term-one term-add term-one f-u term-one term-add term-add ctx-empty f-u dag-1014 term-one f-u term-one ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-1016 $p term ( ( t * v ) + ( u + ( u + ( 1 + ( u + 1 ) ) ) ) ) $=
 f-t f-v term-mul f-u f-u term-one f-u term-one term-add term-add term-add term-add term-add $.
$}
${
dag-1017 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( u + ( 1 + 1 ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( u + 1 ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1009 f-t f-u f-v syn-1016 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-one term-one term-add term-add term-add term-add f-u f-u term-one f-u term-one term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1015 eq-add-cong eq-add-cong $.
$}
${
syn-1018 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( u + 1 ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1016 term-add $.
$}
${
syn-1019 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( u + 1 ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1018 term-add $.
$}
${
dag-1020 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) + ( 1 + 1 ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( u + 1 ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-998 f-t f-u f-v syn-1013 f-t f-u f-v syn-1019 ctx-empty f-t f-u f-v syn-998 f-t f-u f-v syn-1000 f-t f-u f-v syn-1013 ctx-empty f-t f-u f-v syn-998 f-t f-u f-v syn-998 f-t f-u f-v syn-1000 ctx-empty f-t f-u f-v dag-997 f-t f-v term-mul f-t f-u f-v syn-992 term-one term-one term-add ctx-empty ax-A1 eq-trans f-t f-u f-v dag-1012 eq-trans f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1011 f-t f-u f-v syn-1018 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1017 eq-add-cong eq-trans $.
$}
${
dag-1021 $p |- [] => ( ( u + ( u + ( 1 + ( u + 1 ) ) ) ) = ( u + ( u + ( 1 + ( 1 + u ) ) ) ) ) $=
 f-u f-u f-u term-one f-u term-one term-add term-add term-add f-u term-one term-one f-u term-add term-add term-add ctx-empty f-u ctx-empty eq-refl f-u f-u term-one f-u term-one term-add term-add term-one term-one f-u term-add term-add ctx-empty f-u ctx-empty eq-refl term-one term-one f-u term-one term-add term-one f-u term-add ctx-empty term-one ctx-empty eq-refl f-u term-one ctx-empty ax-A2 eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-1022 $p term ( ( t * v ) + ( u + ( u + ( 1 + ( 1 + u ) ) ) ) ) $=
 f-t f-v term-mul f-u f-u term-one term-one f-u term-add term-add term-add term-add term-add $.
$}
${
dag-1023 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( u + 1 ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( 1 + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1016 f-t f-u f-v syn-1022 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-u f-u term-one f-u term-one term-add term-add term-add term-add f-u f-u term-one term-one f-u term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1021 eq-add-cong eq-add-cong $.
$}
${
syn-1024 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( 1 + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1022 term-add $.
$}
${
syn-1025 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( 1 + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1024 term-add $.
$}
${
dag-1026 $p |- [] => ( ( u + ( 1 + ( 1 + u ) ) ) = ( ( 1 + u ) + ( 1 + u ) ) ) $=
 f-u term-one term-one f-u term-add term-add term-add f-u term-one term-add term-one f-u term-add term-add term-one f-u term-add term-one f-u term-add term-add ctx-empty f-u term-one term-add term-one f-u term-add term-add f-u term-one term-one f-u term-add term-add term-add ctx-empty f-u term-one term-one f-u term-add ctx-empty ax-A1 eq-sym f-u term-one term-add term-one f-u term-add term-one f-u term-add term-one f-u term-add ctx-empty f-u term-one ctx-empty ax-A2 term-one f-u term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1027 $p |- [] => ( ( u + ( u + ( 1 + ( 1 + u ) ) ) ) = ( u + ( 1 + ( u + ( 1 + u ) ) ) ) ) $=
 f-u f-u f-u term-one term-one f-u term-add term-add term-add term-one f-u term-one f-u term-add term-add term-add ctx-empty f-u ctx-empty eq-refl f-u term-one term-one f-u term-add term-add term-add term-one f-u term-add term-one f-u term-add term-add term-one f-u term-one f-u term-add term-add term-add ctx-empty f-u dag-1026 term-one f-u term-one f-u term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1028 $p term ( ( t * v ) + ( u + ( 1 + ( u + ( 1 + u ) ) ) ) ) $=
 f-t f-v term-mul f-u term-one f-u term-one f-u term-add term-add term-add term-add term-add $.
$}
${
dag-1029 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( u + ( u + ( 1 + ( 1 + u ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( u + ( 1 + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1022 f-t f-u f-v syn-1028 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-u f-u term-one term-one f-u term-add term-add term-add term-add f-u term-one f-u term-one f-u term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1027 eq-add-cong eq-add-cong $.
$}
${
syn-1030 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( u + ( 1 + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1028 term-add $.
$}
${
syn-1031 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( u + ( 1 + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1030 term-add $.
$}
${
dag-1032 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) + ( 1 + 1 ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( u + ( 1 + u ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-998 f-t f-u f-v syn-1025 f-t f-u f-v syn-1031 ctx-empty f-t f-u f-v syn-998 f-t f-u f-v syn-1019 f-t f-u f-v syn-1025 ctx-empty f-t f-u f-v dag-1020 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1018 f-t f-u f-v syn-1024 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1023 eq-add-cong eq-trans f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1024 f-t f-u f-v syn-1030 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1029 eq-add-cong eq-trans $.
$}
${
dag-1033 $p |- [] => ( ( u + ( 1 + u ) ) = ( ( 1 + u ) + u ) ) $=
 f-u term-one f-u term-add term-add f-u term-one term-add f-u term-add term-one f-u term-add f-u term-add ctx-empty f-u term-one term-add f-u term-add f-u term-one f-u term-add term-add ctx-empty f-u term-one f-u ctx-empty ax-A1 eq-sym f-u term-one term-add term-one f-u term-add f-u f-u ctx-empty f-u term-one ctx-empty ax-A2 f-u ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1034 $p |- [] => ( ( u + ( 1 + ( u + ( 1 + u ) ) ) ) = ( u + ( 1 + ( 1 + ( u + u ) ) ) ) ) $=
 f-u f-u term-one f-u term-one f-u term-add term-add term-add term-one term-one f-u f-u term-add term-add term-add ctx-empty f-u ctx-empty eq-refl term-one term-one f-u term-one f-u term-add term-add term-one f-u f-u term-add term-add ctx-empty term-one ctx-empty eq-refl f-u term-one f-u term-add term-add term-one f-u term-add f-u term-add term-one f-u f-u term-add term-add ctx-empty f-u dag-1033 term-one f-u f-u ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-1035 $p term ( ( t * v ) + ( u + ( 1 + ( 1 + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-u term-one term-one f-u f-u term-add term-add term-add term-add term-add $.
$}
${
dag-1036 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( u + ( 1 + u ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( 1 + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1028 f-t f-u f-v syn-1035 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-u term-one f-u term-one f-u term-add term-add term-add term-add f-u term-one term-one f-u f-u term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1034 eq-add-cong eq-add-cong $.
$}
${
syn-1037 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( 1 + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1035 term-add $.
$}
${
syn-1038 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( 1 + ( 1 + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1037 term-add $.
$}
${
dag-1039 $p |- [] => ( ( u + ( 1 + ( 1 + ( u + u ) ) ) ) = ( ( 1 + u ) + ( 1 + ( u + u ) ) ) ) $=
 f-u term-one term-one f-u f-u term-add term-add term-add term-add f-u term-one term-add term-one f-u f-u term-add term-add term-add term-one f-u term-add term-one f-u f-u term-add term-add term-add ctx-empty f-u term-one term-add term-one f-u f-u term-add term-add term-add f-u term-one term-one f-u f-u term-add term-add term-add term-add ctx-empty f-u term-one term-one f-u f-u term-add term-add ctx-empty ax-A1 eq-sym f-u term-one term-add term-one f-u term-add term-one f-u f-u term-add term-add term-one f-u f-u term-add term-add ctx-empty f-u term-one ctx-empty ax-A2 term-one f-u f-u term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1040 $p |- [] => ( ( ( t * v ) + ( u + ( 1 + ( 1 + ( u + u ) ) ) ) ) = ( ( t * v ) + ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-u term-one term-one f-u f-u term-add term-add term-add term-add term-one f-u term-one f-u f-u term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u term-one term-one f-u f-u term-add term-add term-add term-add term-one f-u term-add term-one f-u f-u term-add term-add term-add term-one f-u term-one f-u f-u term-add term-add term-add term-add ctx-empty f-u dag-1039 term-one f-u term-one f-u f-u term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1041 $p term ( ( t * v ) + ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul term-one f-u term-one f-u f-u term-add term-add term-add term-add term-add $.
$}
${
syn-1042 $p term ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1041 term-add $.
$}
${
syn-1043 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1042 term-add $.
$}
${
dag-1044 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) + ( 1 + 1 ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-998 f-t f-u f-v syn-1038 f-t f-u f-v syn-1043 ctx-empty f-t f-u f-v syn-998 f-t f-u f-v syn-1031 f-t f-u f-v syn-1038 ctx-empty f-t f-u f-v dag-1032 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1030 f-t f-u f-v syn-1037 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1036 eq-add-cong eq-trans f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1037 f-t f-u f-v syn-1042 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1035 f-t f-u f-v syn-1041 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1040 eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-1045 $p |- [] => ( ( u + ( 1 + ( u + u ) ) ) = ( ( 1 + u ) + ( u + u ) ) ) $=
 f-u term-one f-u f-u term-add term-add term-add f-u term-one term-add f-u f-u term-add term-add term-one f-u term-add f-u f-u term-add term-add ctx-empty f-u term-one term-add f-u f-u term-add term-add f-u term-one f-u f-u term-add term-add term-add ctx-empty f-u term-one f-u f-u term-add ctx-empty ax-A1 eq-sym f-u term-one term-add term-one f-u term-add f-u f-u term-add f-u f-u term-add ctx-empty f-u term-one ctx-empty ax-A2 f-u f-u term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1046 $p |- [] => ( ( 1 + ( u + ( 1 + ( u + u ) ) ) ) = ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) $=
 term-one term-one f-u term-one f-u f-u term-add term-add term-add term-one f-u f-u f-u term-add term-add term-add ctx-empty term-one ctx-empty eq-refl f-u term-one f-u f-u term-add term-add term-add term-one f-u term-add f-u f-u term-add term-add term-one f-u f-u f-u term-add term-add term-add ctx-empty f-u dag-1045 term-one f-u f-u f-u term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1047 $p term ( ( t * v ) + ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul term-one term-one f-u f-u f-u term-add term-add term-add term-add term-add $.
$}
${
dag-1048 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1041 f-t f-u f-v syn-1047 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul term-one f-u term-one f-u f-u term-add term-add term-add term-add term-one term-one f-u f-u f-u term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1046 eq-add-cong eq-add-cong $.
$}
${
syn-1049 $p term ( ( t * v ) + ( ( t * v ) + ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1047 term-add $.
$}
${
syn-1050 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1049 term-add $.
$}
${
syn-1051 $p term ( ( ( ( 1 + 1 ) + 1 ) * ( ( t * v ) + u ) ) + ( 1 + 1 ) ) $=
 f-t f-u f-v syn-973 term-one term-one term-add term-add $.
$}
${
dag-1052 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( t * v ) + u ) ) + ( 1 + 1 ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1051 f-t f-u f-v syn-998 f-t f-u f-v syn-1050 ctx-empty f-t f-u f-v syn-973 f-t f-u f-v syn-995 term-one term-one term-add term-one term-one term-add ctx-empty f-t f-u f-v arith-175 arith-85 eq-add-cong f-t f-u f-v syn-998 f-t f-u f-v syn-1043 f-t f-u f-v syn-1050 ctx-empty f-t f-u f-v dag-1044 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1042 f-t f-u f-v syn-1049 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1048 eq-add-cong eq-trans eq-trans $.
$}
${
dag-1053 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * u ) = ( ( u * 1 ) + ( u * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-add term-one term-add f-u term-mul term-one term-one term-one term-add term-add f-u term-mul f-u term-one term-mul f-u term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add f-u f-u ctx-empty dag-6 f-u ctx-empty eq-refl eq-mul-cong term-one term-one term-one term-add term-add f-u term-mul f-u term-one term-one term-one term-add term-add term-mul f-u term-one term-mul f-u term-one term-one term-add term-mul term-add ctx-empty term-one term-one term-one term-add term-add f-u ctx-empty ax-A5 f-u term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-177 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * u ) = ( u + ( u + u ) ) ) $=
 term-one term-one term-add term-one term-add f-u term-mul f-u term-one term-mul f-u term-one term-one term-add term-mul term-add f-u f-u f-u term-add term-add ctx-empty f-u dag-1053 f-u dag-986 eq-trans $.
$}
${
dag-1054 $p |- [] => ( ( ( u + ( u + u ) ) + 1 ) = ( u + ( ( u + u ) + 1 ) ) ) $=
 f-u f-u f-u term-add term-add term-one term-add f-u f-u f-u term-add term-add term-one term-add f-u f-u f-u term-add term-one term-add term-add ctx-empty f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add term-one term-one ctx-empty f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-u f-u f-u term-add term-one ctx-empty ax-A1 eq-trans $.
$}
${
dag-1055 $p |- [] => ( ( ( u + u ) + 1 ) = ( u + ( u + 1 ) ) ) $=
 f-u f-u term-add term-one term-add f-u f-u term-one term-add term-add f-u f-u term-one term-add term-add ctx-empty f-u f-u term-add term-one term-add f-u f-u term-add term-one term-add f-u f-u term-one term-add term-add ctx-empty f-u f-u term-add f-u f-u term-add term-one term-one ctx-empty f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-u f-u term-one ctx-empty ax-A1 eq-trans f-u f-u f-u term-one term-add f-u term-one term-add ctx-empty f-u ctx-empty eq-refl f-u f-u term-one term-one ctx-empty f-u ctx-empty eq-refl term-one ctx-empty eq-refl eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-1056 $p |- [] => ( ( ( u + ( u + u ) ) + 1 ) = ( u + ( u + ( 1 + u ) ) ) ) $=
 f-u f-u f-u term-add term-add term-one term-add f-u f-u f-u term-one term-add term-add term-add f-u f-u term-one f-u term-add term-add term-add ctx-empty f-u f-u f-u term-add term-add term-one term-add f-u f-u f-u term-add term-one term-add term-add f-u f-u f-u term-one term-add term-add term-add ctx-empty f-u dag-1054 f-u f-u f-u f-u term-add term-one term-add f-u f-u term-one term-add term-add ctx-empty f-u ctx-empty eq-refl f-u dag-1055 eq-add-cong eq-trans f-u f-u f-u f-u term-one term-add term-add f-u term-one f-u term-add term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u term-one term-add term-one f-u term-add ctx-empty f-u ctx-empty eq-refl f-u term-one ctx-empty ax-A2 eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-1057 $p |- [] => ( ( ( u + ( u + u ) ) + 1 ) = ( u + ( 1 + ( u + u ) ) ) ) $=
 f-u f-u f-u term-add term-add term-one term-add f-u f-u term-one f-u term-add term-add term-add f-u term-one f-u f-u term-add term-add term-add ctx-empty f-u dag-1056 f-u f-u f-u term-one f-u term-add term-add term-one f-u f-u term-add term-add ctx-empty f-u ctx-empty eq-refl f-u term-one f-u term-add term-add term-one f-u term-add f-u term-add term-one f-u f-u term-add term-add ctx-empty f-u dag-1033 term-one f-u f-u ctx-empty ax-A1 eq-trans eq-add-cong eq-trans $.
$}
${
dag-1058 $p |- [] => ( ( ( u + ( u + u ) ) + 1 ) = ( 1 + ( u + ( u + u ) ) ) ) $=
 f-u f-u f-u term-add term-add term-one term-add f-u term-one f-u f-u term-add term-add term-add term-one f-u f-u f-u term-add term-add term-add ctx-empty f-u dag-1057 f-u term-one f-u f-u term-add term-add term-add term-one f-u term-add f-u f-u term-add term-add term-one f-u f-u f-u term-add term-add term-add ctx-empty f-u dag-1045 term-one f-u f-u f-u term-add ctx-empty ax-A1 eq-trans eq-trans $.
$}
${
arith-178 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) = ( 1 + ( u + ( u + u ) ) ) ) $=
 term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-u f-u f-u term-add term-add term-one term-add term-one f-u f-u f-u term-add term-add term-add ctx-empty term-one term-one term-add term-one term-add f-u term-mul f-u f-u f-u term-add term-add term-one term-one ctx-empty f-u arith-177 term-one ctx-empty eq-refl eq-add-cong f-u dag-1058 eq-trans $.
$}
${
dag-1059 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) = ( ( ( t * v ) * 1 ) + ( ( t * v ) * ( 1 + 1 ) ) ) ) $=
 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-one term-add term-add f-t f-v term-mul term-mul f-t f-v syn-977 ctx-empty term-one term-one term-add term-one term-add term-one term-one term-one term-add term-add f-t f-v term-mul f-t f-v term-mul ctx-empty dag-6 f-t f-v arith-78 eq-mul-cong term-one term-one term-one term-add term-add f-t f-v term-mul term-mul f-t f-v term-mul term-one term-one term-one term-add term-add term-mul f-t f-v syn-977 ctx-empty term-one term-one term-one term-add term-add f-t f-v term-mul ctx-empty ax-A5 f-t f-v term-mul term-one term-one term-one term-add ctx-empty ax-A8 eq-trans eq-trans $.
$}
${
arith-179 $p |- [] => ( ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) = ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-t f-v syn-977 f-t f-v syn-983 ctx-empty f-t f-v dag-1059 f-t f-v arith-168 eq-trans $.
$}
${
dag-1060 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) $=
 term-one f-u f-u f-u term-add term-add term-add term-one f-u f-u f-u term-add term-add term-add f-t f-v syn-983 f-t f-v syn-983 ctx-empty term-one term-one f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty term-one ctx-empty eq-refl f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong f-t f-v dag-982 eq-add-cong $.
$}
${
syn-1061 $p term ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 term-one f-u f-u f-u term-add term-add term-add f-t f-v syn-983 term-add $.
$}
${
syn-1062 $p term ( ( u + ( u + u ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 f-u f-u f-u term-add term-add f-t f-v syn-983 term-add $.
$}
${
syn-1063 $p term ( 1 + ( ( u + ( u + u ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1062 term-add $.
$}
${
syn-1064 $p term ( ( u + u ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 f-u f-u term-add f-t f-v syn-983 term-add $.
$}
${
syn-1065 $p term ( u + ( ( u + u ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1064 term-add $.
$}
${
dag-1066 $p |- [] => ( ( ( u + ( u + u ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( u + ( ( u + u ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) ) $=
 f-t f-u f-v syn-1062 f-t f-u f-v syn-1062 f-t f-u f-v syn-1065 ctx-empty f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add f-t f-v syn-983 f-t f-v syn-983 ctx-empty f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong f-t f-v dag-982 eq-add-cong f-u f-u f-u term-add f-t f-v syn-983 ctx-empty ax-A1 eq-trans $.
$}
${
syn-1067 $p term ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 f-u f-t f-v syn-983 term-add $.
$}
${
syn-1068 $p term ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1067 term-add $.
$}
${
dag-1069 $p |- [] => ( ( ( u + u ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) ) $=
 f-t f-u f-v syn-1064 f-t f-u f-v syn-1068 f-t f-u f-v syn-1068 ctx-empty f-t f-u f-v syn-1064 f-t f-u f-v syn-1064 f-t f-u f-v syn-1068 ctx-empty f-u f-u term-add f-u f-u term-add f-t f-v syn-983 f-t f-v syn-983 ctx-empty f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong f-t f-v dag-982 eq-add-cong f-u f-u f-t f-v syn-983 ctx-empty ax-A1 eq-trans f-u f-u f-t f-u f-v syn-1067 f-t f-u f-v syn-1067 ctx-empty f-u ctx-empty eq-refl f-u f-u f-t f-v syn-983 f-t f-v syn-983 ctx-empty f-u ctx-empty eq-refl f-t f-v dag-982 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-1070 $p term ( u + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1068 term-add $.
$}
${
dag-1071 $p |- [] => ( ( 1 + ( ( u + ( u + u ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) = ( 1 + ( u + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) ) ) ) $=
 term-one term-one f-t f-u f-v syn-1062 f-t f-u f-v syn-1070 ctx-empty term-one ctx-empty eq-refl f-t f-u f-v syn-1062 f-t f-u f-v syn-1065 f-t f-u f-v syn-1070 ctx-empty f-t f-u f-v dag-1066 f-u f-u f-t f-u f-v syn-1064 f-t f-u f-v syn-1068 ctx-empty f-u ctx-empty eq-refl f-t f-u f-v dag-1069 eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-1072 $p term ( 1 + ( u + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1070 term-add $.
$}
${
syn-1073 $p term ( ( u + ( t * v ) ) + ( ( t * v ) + ( t * v ) ) ) $=
 f-u f-t f-v term-mul term-add f-t f-v term-mul f-t f-v term-mul term-add term-add $.
$}
${
syn-1074 $p term ( ( ( t * v ) + u ) + ( ( t * v ) + ( t * v ) ) ) $=
 f-t f-v term-mul f-u term-add f-t f-v term-mul f-t f-v term-mul term-add term-add $.
$}
${
dag-1075 $p |- [] => ( ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( ( ( t * v ) + u ) + ( ( t * v ) + ( t * v ) ) ) ) $=
 f-t f-u f-v syn-1067 f-t f-u f-v syn-1073 f-t f-u f-v syn-1074 ctx-empty f-t f-u f-v syn-1073 f-t f-u f-v syn-1067 ctx-empty f-u f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul term-add ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-t f-v term-mul term-add f-t f-v term-mul f-t f-v term-mul term-add ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-t f-v term-mul f-t f-v term-mul term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1076 $p term ( ( t * v ) + ( u + ( ( t * v ) + ( t * v ) ) ) ) $=
 f-t f-v term-mul f-u f-t f-v term-mul f-t f-v term-mul term-add term-add term-add $.
$}
${
syn-1077 $p term ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( t * v ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1076 term-add $.
$}
${
dag-1078 $p |- [] => ( ( u + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) ) ) = ( u + ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( t * v ) ) ) ) ) ) ) $=
 f-u f-u f-t f-u f-v syn-1068 f-t f-u f-v syn-1077 ctx-empty f-u ctx-empty eq-refl f-u f-u f-t f-u f-v syn-1067 f-t f-u f-v syn-1076 ctx-empty f-u ctx-empty eq-refl f-t f-u f-v syn-1067 f-t f-u f-v syn-1074 f-t f-u f-v syn-1076 ctx-empty f-t f-u f-v dag-1075 f-t f-v term-mul f-u f-t f-v term-mul f-t f-v term-mul term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-1079 $p term ( u + ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( t * v ) ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1077 term-add $.
$}
${
syn-1080 $p term ( 1 + ( u + ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( t * v ) ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1079 term-add $.
$}
${
dag-1081 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( 1 + ( u + ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( t * v ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1061 f-t f-u f-v syn-1072 f-t f-u f-v syn-1080 ctx-empty f-t f-u f-v syn-1061 f-t f-u f-v syn-1063 f-t f-u f-v syn-1072 ctx-empty f-t f-u f-v syn-1061 f-t f-u f-v syn-1061 f-t f-u f-v syn-1063 ctx-empty f-t f-u f-v dag-1060 term-one f-u f-u f-u term-add term-add f-t f-v syn-983 ctx-empty ax-A1 eq-trans f-t f-u f-v dag-1071 eq-trans term-one term-one f-t f-u f-v syn-1070 f-t f-u f-v syn-1079 ctx-empty term-one ctx-empty eq-refl f-t f-u f-v dag-1078 eq-add-cong eq-trans $.
$}
${
dag-1082 $p |- [] => ( ( u + ( ( t * v ) + ( t * v ) ) ) = ( ( ( t * v ) + u ) + ( t * v ) ) ) $=
 f-u f-t f-v term-mul f-t f-v term-mul term-add term-add f-u f-t f-v term-mul term-add f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-t f-v term-mul term-add ctx-empty f-u f-t f-v term-mul term-add f-t f-v term-mul term-add f-u f-t f-v term-mul f-t f-v term-mul term-add term-add ctx-empty f-u f-t f-v term-mul f-t f-v term-mul ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-t f-v term-mul ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-t f-v term-mul ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1083 $p |- [] => ( ( ( t * v ) + ( u + ( ( t * v ) + ( t * v ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( t * v ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-u f-t f-v term-mul f-t f-v term-mul term-add term-add f-t f-v term-mul f-u f-t f-v term-mul term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u f-t f-v term-mul f-t f-v term-mul term-add term-add f-t f-v term-mul f-u term-add f-t f-v term-mul term-add f-t f-v term-mul f-u f-t f-v term-mul term-add term-add ctx-empty f-t f-u f-v dag-1082 f-t f-v term-mul f-u f-t f-v term-mul ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1084 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( t * v ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-u f-t f-v term-mul term-add term-add term-add $.
$}
${
syn-1085 $p term ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( t * v ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1084 term-add $.
$}
${
syn-1086 $p term ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( t * v ) ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1085 term-add $.
$}
${
syn-1087 $p term ( 1 + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( t * v ) ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1086 term-add $.
$}
${
dag-1088 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( 1 + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( t * v ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1061 f-t f-u f-v syn-1080 f-t f-u f-v syn-1087 ctx-empty f-t f-u f-v dag-1081 term-one term-one f-t f-u f-v syn-1079 f-t f-u f-v syn-1086 ctx-empty term-one ctx-empty eq-refl f-u f-u f-t f-u f-v syn-1077 f-t f-u f-v syn-1085 ctx-empty f-u ctx-empty eq-refl f-u f-u f-t f-u f-v syn-1076 f-t f-u f-v syn-1084 ctx-empty f-u ctx-empty eq-refl f-t f-u f-v dag-1083 eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
dag-1089 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( u + ( t * v ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-u f-t f-v term-mul term-add term-add f-t f-v term-mul f-t f-v term-mul f-u term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u f-t f-v term-mul ctx-empty ax-A2 eq-add-cong eq-add-cong $.
$}
${
syn-1090 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-u term-add term-add term-add $.
$}
${
syn-1091 $p term ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) $=
 f-u f-t f-u f-v syn-1090 term-add $.
$}
${
syn-1092 $p term ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1091 term-add $.
$}
${
syn-1093 $p term ( 1 + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1092 term-add $.
$}
${
dag-1094 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( 1 + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1061 f-t f-u f-v syn-1087 f-t f-u f-v syn-1093 ctx-empty f-t f-u f-v dag-1088 term-one term-one f-t f-u f-v syn-1086 f-t f-u f-v syn-1092 ctx-empty term-one ctx-empty eq-refl f-u f-u f-t f-u f-v syn-1085 f-t f-u f-v syn-1091 ctx-empty f-u ctx-empty eq-refl f-u f-u f-t f-u f-v syn-1084 f-t f-u f-v syn-1090 ctx-empty f-u ctx-empty eq-refl f-t f-u f-v dag-1089 eq-add-cong eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-1095 $p term ( ( u + ( t * v ) ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) $=
 f-u f-t f-v term-mul term-add f-t f-v term-mul f-t f-v term-mul f-u term-add term-add term-add $.
$}
${
syn-1096 $p term ( ( ( t * v ) + u ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) $=
 f-t f-v term-mul f-u term-add f-t f-v term-mul f-t f-v term-mul f-u term-add term-add term-add $.
$}
${
dag-1097 $p |- [] => ( ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) = ( ( ( t * v ) + u ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) $=
 f-t f-u f-v syn-1091 f-t f-u f-v syn-1095 f-t f-u f-v syn-1096 ctx-empty f-t f-u f-v syn-1095 f-t f-u f-v syn-1091 ctx-empty f-u f-t f-v term-mul f-t f-v term-mul f-t f-v term-mul f-u term-add term-add ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-t f-v term-mul f-u term-add term-add f-t f-v term-mul f-t f-v term-mul f-u term-add term-add ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-t f-v term-mul f-t f-v term-mul f-u term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1098 $p term ( u + ( ( t * v ) + ( ( t * v ) + u ) ) ) $=
 f-u f-t f-v term-mul f-t f-v term-mul f-u term-add term-add term-add $.
$}
${
syn-1099 $p term ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1098 term-add $.
$}
${
syn-1100 $p term ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1099 term-add $.
$}
${
dag-1101 $p |- [] => ( ( 1 + ( u + ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) ) = ( 1 + ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) ) ) $=
 term-one term-one f-t f-u f-v syn-1092 f-t f-u f-v syn-1100 ctx-empty term-one ctx-empty eq-refl f-u f-u f-t f-u f-v syn-1091 f-t f-u f-v syn-1099 ctx-empty f-u ctx-empty eq-refl f-t f-u f-v syn-1091 f-t f-u f-v syn-1096 f-t f-u f-v syn-1099 ctx-empty f-t f-u f-v dag-1097 f-t f-v term-mul f-u f-t f-v term-mul f-t f-v term-mul f-u term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-1102 $p term ( 1 + ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1100 term-add $.
$}
${
syn-1103 $p term ( ( u + ( t * v ) ) + ( ( t * v ) + u ) ) $=
 f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add term-add $.
$}
${
syn-1104 $p term ( ( ( t * v ) + u ) + ( ( t * v ) + u ) ) $=
 f-t f-v term-mul f-u term-add f-t f-v term-mul f-u term-add term-add $.
$}
${
dag-1105 $p |- [] => ( ( u + ( ( t * v ) + ( ( t * v ) + u ) ) ) = ( ( ( t * v ) + u ) + ( ( t * v ) + u ) ) ) $=
 f-t f-u f-v syn-1098 f-t f-u f-v syn-1103 f-t f-u f-v syn-1104 ctx-empty f-t f-u f-v syn-1103 f-t f-u f-v syn-1098 ctx-empty f-u f-t f-v term-mul f-t f-v term-mul f-u term-add ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-u term-add ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-t f-v term-mul f-u term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1106 $p term ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) $=
 f-t f-v term-mul f-u f-t f-v term-mul f-u term-add term-add term-add $.
$}
${
syn-1107 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1106 term-add $.
$}
${
dag-1108 $p |- [] => ( ( u + ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + u ) ) ) ) ) = ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) ) ) ) $=
 f-u f-u f-t f-u f-v syn-1099 f-t f-u f-v syn-1107 ctx-empty f-u ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1098 f-t f-u f-v syn-1106 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v syn-1098 f-t f-u f-v syn-1104 f-t f-u f-v syn-1106 ctx-empty f-t f-u f-v dag-1105 f-t f-v term-mul f-u f-t f-v term-mul f-u term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-1109 $p term ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1107 term-add $.
$}
${
syn-1110 $p term ( 1 + ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1109 term-add $.
$}
${
dag-1111 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( 1 + ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1061 f-t f-u f-v syn-1102 f-t f-u f-v syn-1110 ctx-empty f-t f-u f-v syn-1061 f-t f-u f-v syn-1093 f-t f-u f-v syn-1102 ctx-empty f-t f-u f-v dag-1094 f-t f-u f-v dag-1101 eq-trans term-one term-one f-t f-u f-v syn-1100 f-t f-u f-v syn-1109 ctx-empty term-one ctx-empty eq-refl f-t f-u f-v dag-1108 eq-add-cong eq-trans $.
$}
${
dag-1112 $p |- [] => ( ( u + ( ( t * v ) + u ) ) = ( ( ( t * v ) + u ) + u ) ) $=
 f-u f-t f-v term-mul f-u term-add term-add f-u f-t f-v term-mul term-add f-u term-add f-t f-v term-mul f-u term-add f-u term-add ctx-empty f-u f-t f-v term-mul term-add f-u term-add f-u f-t f-v term-mul f-u term-add term-add ctx-empty f-u f-t f-v term-mul f-u ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-u f-u ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-u ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1113 $p |- [] => ( ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-u f-t f-v term-mul f-u term-add term-add f-t f-v term-mul f-u f-u term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u f-t f-v term-mul f-u term-add term-add f-t f-v term-mul f-u term-add f-u term-add f-t f-v term-mul f-u f-u term-add term-add ctx-empty f-t f-u f-v dag-1112 f-t f-v term-mul f-u f-u ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1114 $p term ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-u f-u term-add term-add term-add $.
$}
${
syn-1115 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1114 term-add $.
$}
${
syn-1116 $p term ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) $=
 f-u f-t f-u f-v syn-1115 term-add $.
$}
${
dag-1117 $p |- [] => ( ( 1 + ( u + ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + u ) ) ) ) ) ) = ( 1 + ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) ) ) $=
 term-one term-one f-t f-u f-v syn-1109 f-t f-u f-v syn-1116 ctx-empty term-one ctx-empty eq-refl f-u f-u f-t f-u f-v syn-1107 f-t f-u f-v syn-1115 ctx-empty f-u ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1106 f-t f-u f-v syn-1114 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1113 eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-1118 $p term ( 1 + ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1116 term-add $.
$}
${
syn-1119 $p term ( ( u + ( t * v ) ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) $=
 f-u f-t f-v term-mul term-add f-t f-u f-v syn-1114 term-add $.
$}
${
syn-1120 $p term ( ( ( t * v ) + u ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) $=
 f-t f-v term-mul f-u term-add f-t f-u f-v syn-1114 term-add $.
$}
${
dag-1121 $p |- [] => ( ( u + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) = ( ( ( t * v ) + u ) + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) $=
 f-t f-u f-v syn-1116 f-t f-u f-v syn-1119 f-t f-u f-v syn-1120 ctx-empty f-t f-u f-v syn-1119 f-t f-u f-v syn-1116 ctx-empty f-u f-t f-v term-mul f-t f-u f-v syn-1114 ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-t f-u f-v syn-1114 f-t f-u f-v syn-1114 ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-t f-u f-v syn-1114 ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1122 $p term ( u + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) $=
 f-u f-t f-u f-v syn-1114 term-add $.
$}
${
syn-1123 $p term ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1122 term-add $.
$}
${
syn-1124 $p term ( 1 + ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1123 term-add $.
$}
${
dag-1125 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( 1 + ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1061 f-t f-u f-v syn-1118 f-t f-u f-v syn-1124 ctx-empty f-t f-u f-v syn-1061 f-t f-u f-v syn-1110 f-t f-u f-v syn-1118 ctx-empty f-t f-u f-v dag-1111 f-t f-u f-v dag-1117 eq-trans term-one term-one f-t f-u f-v syn-1116 f-t f-u f-v syn-1123 ctx-empty term-one ctx-empty eq-refl f-t f-u f-v syn-1116 f-t f-u f-v syn-1120 f-t f-u f-v syn-1123 ctx-empty f-t f-u f-v dag-1121 f-t f-v term-mul f-u f-t f-u f-v syn-1114 ctx-empty ax-A1 eq-trans eq-add-cong eq-trans $.
$}
${
syn-1126 $p term ( ( u + ( t * v ) ) + ( ( t * v ) + ( u + u ) ) ) $=
 f-u f-t f-v term-mul term-add f-t f-v term-mul f-u f-u term-add term-add term-add $.
$}
${
syn-1127 $p term ( ( ( t * v ) + u ) + ( ( t * v ) + ( u + u ) ) ) $=
 f-t f-v term-mul f-u term-add f-t f-v term-mul f-u f-u term-add term-add term-add $.
$}
${
dag-1128 $p |- [] => ( ( u + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) = ( ( ( t * v ) + u ) + ( ( t * v ) + ( u + u ) ) ) ) $=
 f-t f-u f-v syn-1122 f-t f-u f-v syn-1126 f-t f-u f-v syn-1127 ctx-empty f-t f-u f-v syn-1126 f-t f-u f-v syn-1122 ctx-empty f-u f-t f-v term-mul f-t f-v term-mul f-u f-u term-add term-add ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-t f-v term-mul f-u f-u term-add term-add f-t f-v term-mul f-u f-u term-add term-add ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-t f-v term-mul f-u f-u term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1129 $p term ( ( t * v ) + ( u + ( ( t * v ) + ( u + u ) ) ) ) $=
 f-t f-v term-mul f-u f-t f-v term-mul f-u f-u term-add term-add term-add term-add $.
$}
${
dag-1130 $p |- [] => ( ( ( t * v ) + ( u + ( ( t * v ) + ( ( t * v ) + ( u + u ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1122 f-t f-u f-v syn-1129 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v syn-1122 f-t f-u f-v syn-1127 f-t f-u f-v syn-1129 ctx-empty f-t f-u f-v dag-1128 f-t f-v term-mul f-u f-t f-v term-mul f-u f-u term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1131 $p term ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1129 term-add $.
$}
${
syn-1132 $p term ( 1 + ( ( t * v ) + ( ( t * v ) + ( u + ( ( t * v ) + ( u + u ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-1131 term-add $.
$}
${
dag-1133 $p |- [] => ( ( u + ( ( t * v ) + ( u + u ) ) ) = ( ( ( t * v ) + u ) + ( u + u ) ) ) $=
 f-u f-t f-v term-mul f-u f-u term-add term-add term-add f-u f-t f-v term-mul term-add f-u f-u term-add term-add f-t f-v term-mul f-u term-add f-u f-u term-add term-add ctx-empty f-u f-t f-v term-mul term-add f-u f-u term-add term-add f-u f-t f-v term-mul f-u f-u term-add term-add term-add ctx-empty f-u f-t f-v term-mul f-u f-u term-add ctx-empty ax-A1 eq-sym f-u f-t f-v term-mul term-add f-t f-v term-mul f-u term-add f-u f-u term-add f-u f-u term-add ctx-empty f-u f-t f-v term-mul ctx-empty ax-A2 f-u f-u term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
dag-1134 $p |- [] => ( ( ( t * v ) + ( u + ( ( t * v ) + ( u + u ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-u f-t f-v term-mul f-u f-u term-add term-add term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u f-t f-v term-mul f-u f-u term-add term-add term-add f-t f-v term-mul f-u term-add f-u f-u term-add term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add ctx-empty f-t f-u f-v dag-1133 f-t f-v term-mul f-u f-u f-u term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1135 $p term ( 1 + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) $=
 term-one f-t f-u f-v syn-995 term-add $.
$}
${
dag-1136 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( 1 + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1061 f-t f-u f-v syn-1132 f-t f-u f-v syn-1135 ctx-empty f-t f-u f-v syn-1061 f-t f-u f-v syn-1124 f-t f-u f-v syn-1132 ctx-empty f-t f-u f-v dag-1125 term-one term-one f-t f-u f-v syn-1123 f-t f-u f-v syn-1131 ctx-empty term-one ctx-empty eq-refl f-t f-u f-v dag-1130 eq-add-cong eq-trans term-one term-one f-t f-u f-v syn-1131 f-t f-u f-v syn-995 ctx-empty term-one ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1129 f-t f-u f-v syn-992 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1134 eq-add-cong eq-add-cong eq-trans $.
$}
${
syn-1137 $p term ( ( 1 + ( t * v ) ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 term-one f-t f-v term-mul term-add f-t f-u f-v syn-992 term-add $.
$}
${
syn-1138 $p term ( ( ( t * v ) + 1 ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul term-one term-add f-t f-u f-v syn-992 term-add $.
$}
${
dag-1139 $p |- [] => ( ( 1 + ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) = ( ( ( t * v ) + 1 ) + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-u f-v syn-1135 f-t f-u f-v syn-1137 f-t f-u f-v syn-1138 ctx-empty f-t f-u f-v syn-1137 f-t f-u f-v syn-1135 ctx-empty term-one f-t f-v term-mul f-t f-u f-v syn-992 ctx-empty ax-A1 eq-sym term-one f-t f-v term-mul term-add f-t f-v term-mul term-one term-add f-t f-u f-v syn-992 f-t f-u f-v syn-992 ctx-empty term-one f-t f-v term-mul ctx-empty ax-A2 f-t f-u f-v syn-992 ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1140 $p term ( 1 + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 term-one f-t f-u f-v syn-992 term-add $.
$}
${
syn-1141 $p term ( ( t * v ) + ( 1 + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1140 term-add $.
$}
${
syn-1142 $p term ( ( 1 + ( t * v ) ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) $=
 term-one f-t f-v term-mul term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add term-add $.
$}
${
syn-1143 $p term ( ( ( t * v ) + 1 ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) $=
 f-t f-v term-mul term-one term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add term-add $.
$}
${
dag-1144 $p |- [] => ( ( 1 + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) = ( ( ( t * v ) + 1 ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 f-t f-u f-v syn-1140 f-t f-u f-v syn-1142 f-t f-u f-v syn-1143 ctx-empty f-t f-u f-v syn-1142 f-t f-u f-v syn-1140 ctx-empty term-one f-t f-v term-mul f-t f-v term-mul f-u f-u f-u term-add term-add term-add ctx-empty ax-A1 eq-sym term-one f-t f-v term-mul term-add f-t f-v term-mul term-one term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add f-t f-v term-mul f-u f-u f-u term-add term-add term-add ctx-empty term-one f-t f-v term-mul ctx-empty ax-A2 f-t f-v term-mul f-u f-u f-u term-add term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1145 $p term ( 1 + ( ( t * v ) + ( u + ( u + u ) ) ) ) $=
 term-one f-t f-v term-mul f-u f-u f-u term-add term-add term-add term-add $.
$}
${
syn-1146 $p term ( ( t * v ) + ( 1 + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1145 term-add $.
$}
${
dag-1147 $p |- [] => ( ( ( t * v ) + ( 1 + ( ( t * v ) + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( 1 + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1140 f-t f-u f-v syn-1146 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v syn-1140 f-t f-u f-v syn-1143 f-t f-u f-v syn-1146 ctx-empty f-t f-u f-v dag-1144 f-t f-v term-mul term-one f-t f-v term-mul f-u f-u f-u term-add term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong $.
$}
${
syn-1148 $p term ( ( t * v ) + ( ( t * v ) + ( 1 + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1146 term-add $.
$}
${
dag-1149 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + ( ( t * v ) + ( ( t * v ) + ( t * v ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( 1 + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1061 f-t f-u f-v syn-1141 f-t f-u f-v syn-1148 ctx-empty f-t f-u f-v syn-1061 f-t f-u f-v syn-1135 f-t f-u f-v syn-1141 ctx-empty f-t f-u f-v dag-1136 f-t f-u f-v syn-1135 f-t f-u f-v syn-1138 f-t f-u f-v syn-1141 ctx-empty f-t f-u f-v dag-1139 f-t f-v term-mul term-one f-t f-u f-v syn-992 ctx-empty ax-A1 eq-trans eq-trans f-t f-u f-v dag-1147 eq-trans $.
$}
${
syn-1150 $p term ( ( 1 + ( t * v ) ) + ( u + ( u + u ) ) ) $=
 term-one f-t f-v term-mul term-add f-u f-u f-u term-add term-add term-add $.
$}
${
syn-1151 $p term ( ( ( t * v ) + 1 ) + ( u + ( u + u ) ) ) $=
 f-t f-v term-mul term-one term-add f-u f-u f-u term-add term-add term-add $.
$}
${
dag-1152 $p |- [] => ( ( 1 + ( ( t * v ) + ( u + ( u + u ) ) ) ) = ( ( ( t * v ) + 1 ) + ( u + ( u + u ) ) ) ) $=
 f-t f-u f-v syn-1145 f-t f-u f-v syn-1150 f-t f-u f-v syn-1151 ctx-empty f-t f-u f-v syn-1150 f-t f-u f-v syn-1145 ctx-empty term-one f-t f-v term-mul f-u f-u f-u term-add term-add ctx-empty ax-A1 eq-sym term-one f-t f-v term-mul term-add f-t f-v term-mul term-one term-add f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty term-one f-t f-v term-mul ctx-empty ax-A2 f-u f-u f-u term-add term-add ctx-empty eq-refl eq-add-cong eq-trans $.
$}
${
syn-1153 $p term ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) $=
 f-t f-v term-mul term-one f-u f-u f-u term-add term-add term-add term-add $.
$}
${
syn-1154 $p term ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1153 term-add $.
$}
${
dag-1155 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( ( t * v ) + ( u + ( u + u ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1146 f-t f-u f-v syn-1154 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1145 f-t f-u f-v syn-1153 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v syn-1145 f-t f-u f-v syn-1151 f-t f-u f-v syn-1153 ctx-empty f-t f-u f-v dag-1152 f-t f-v term-mul term-one f-u f-u f-u term-add term-add ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
syn-1156 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1154 term-add $.
$}
${
syn-1157 $p term ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) $=
 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-add $.
$}
${
dag-1158 $p |- [] => ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1157 f-t f-u f-v syn-1061 f-t f-u f-v syn-1156 ctx-empty term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one f-u f-u f-u term-add term-add term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-t f-v syn-983 ctx-empty f-u arith-178 f-t f-v arith-179 eq-add-cong f-t f-u f-v syn-1061 f-t f-u f-v syn-1148 f-t f-u f-v syn-1156 ctx-empty f-t f-u f-v dag-1149 f-t f-u f-v dag-1155 eq-trans eq-trans $.
$}
${
dag-1159 $p |- [] => ( ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) = ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul term-one f-u f-u f-u term-add term-add term-add term-one f-u f-u f-u term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl term-one term-one f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty term-one ctx-empty eq-refl f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong eq-add-cong $.
$}
${
dag-1160 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) + 1 ) = ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) + 1 ) ) $=
 f-t f-u f-v syn-1156 f-t f-u f-v syn-1156 term-one term-one ctx-empty f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1154 f-t f-u f-v syn-1154 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1153 f-t f-u f-v syn-1153 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1159 eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong $.
$}
${
syn-1161 $p term ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) + 1 ) $=
 f-t f-u f-v syn-1156 term-one term-add $.
$}
${
syn-1162 $p term ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) + 1 ) $=
 f-t f-u f-v syn-1154 term-one term-add $.
$}
${
syn-1163 $p term ( ( t * v ) + ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) + 1 ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1162 term-add $.
$}
${
syn-1164 $p term ( ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) + 1 ) $=
 f-t f-u f-v syn-1153 term-one term-add $.
$}
${
syn-1165 $p term ( ( t * v ) + ( ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) + 1 ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1164 term-add $.
$}
${
dag-1166 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) + 1 ) = ( ( t * v ) + ( ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) + 1 ) ) ) $=
 f-t f-u f-v syn-1162 f-t f-u f-v syn-1162 f-t f-u f-v syn-1165 ctx-empty f-t f-u f-v syn-1154 f-t f-u f-v syn-1154 term-one term-one ctx-empty f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1153 f-t f-u f-v syn-1153 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1159 eq-add-cong term-one ctx-empty eq-refl eq-add-cong f-t f-v term-mul f-t f-u f-v syn-1153 term-one ctx-empty ax-A1 eq-trans $.
$}
${
syn-1167 $p term ( ( t * v ) + ( ( 1 + ( u + ( u + u ) ) ) + 1 ) ) $=
 f-t f-v term-mul term-one f-u f-u f-u term-add term-add term-add term-one term-add term-add $.
$}
${
dag-1168 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + 1 ) = ( ( 1 + ( u + ( u + u ) ) ) + 1 ) ) $=
 term-one f-u f-u f-u term-add term-add term-add term-one f-u f-u f-u term-add term-add term-add term-one term-one ctx-empty term-one term-one f-u f-u f-u term-add term-add f-u f-u f-u term-add term-add ctx-empty term-one ctx-empty eq-refl f-u f-u f-u f-u term-add f-u f-u term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u f-u ctx-empty f-u ctx-empty eq-refl f-u ctx-empty eq-refl eq-add-cong eq-add-cong eq-add-cong term-one ctx-empty eq-refl eq-add-cong $.
$}
${
dag-1169 $p |- [] => ( ( 1 + ( ( u + ( u + u ) ) + 1 ) ) = ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) $=
 term-one term-one f-u f-u f-u term-add term-add term-one term-add f-u f-u f-u term-one term-add term-add term-add ctx-empty term-one ctx-empty eq-refl f-u f-u f-u term-add term-add term-one term-add f-u f-u f-u term-add term-one term-add term-add f-u f-u f-u term-one term-add term-add term-add ctx-empty f-u dag-1054 f-u f-u f-u f-u term-add term-one term-add f-u f-u term-one term-add term-add ctx-empty f-u ctx-empty eq-refl f-u dag-1055 eq-add-cong eq-trans eq-add-cong $.
$}
${
dag-1170 $p |- [] => ( ( ( 1 + ( u + ( u + u ) ) ) + 1 ) = ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) $=
 term-one f-u f-u f-u term-add term-add term-add term-one term-add term-one f-u f-u f-u term-add term-add term-one term-add term-add term-one f-u f-u f-u term-one term-add term-add term-add term-add ctx-empty term-one f-u f-u f-u term-add term-add term-add term-one term-add term-one f-u f-u f-u term-add term-add term-add term-one term-add term-one f-u f-u f-u term-add term-add term-one term-add term-add ctx-empty f-u dag-1168 term-one f-u f-u f-u term-add term-add term-one ctx-empty ax-A1 eq-trans f-u dag-1169 eq-trans $.
$}
${
syn-1171 $p term ( ( t * v ) + ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) $=
 f-t f-v term-mul term-one f-u f-u f-u term-one term-add term-add term-add term-add term-add $.
$}
${
dag-1172 $p |- [] => ( ( ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) + 1 ) = ( ( t * v ) + ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) ) $=
 f-t f-u f-v syn-1164 f-t f-u f-v syn-1167 f-t f-u f-v syn-1171 ctx-empty f-t f-u f-v syn-1164 f-t f-u f-v syn-1164 f-t f-u f-v syn-1167 ctx-empty f-t f-u f-v syn-1153 f-t f-u f-v syn-1153 term-one term-one ctx-empty f-t f-u f-v dag-1159 term-one ctx-empty eq-refl eq-add-cong f-t f-v term-mul term-one f-u f-u f-u term-add term-add term-add term-one ctx-empty ax-A1 eq-trans f-t f-v term-mul f-t f-v term-mul term-one f-u f-u f-u term-add term-add term-add term-one term-add term-one f-u f-u f-u term-one term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1170 eq-add-cong eq-trans $.
$}
${
syn-1173 $p term ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1171 term-add $.
$}
${
dag-1174 $p |- [] => ( ( ( t * v ) + ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) + 1 ) ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1162 f-t f-u f-v syn-1173 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v syn-1162 f-t f-u f-v syn-1165 f-t f-u f-v syn-1173 ctx-empty f-t f-u f-v dag-1166 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1164 f-t f-u f-v syn-1171 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1172 eq-add-cong eq-trans eq-add-cong $.
$}
${
syn-1175 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1173 term-add $.
$}
${
dag-1176 $p |- [] => ( ( 1 + ( u + ( u + ( u + 1 ) ) ) ) = ( 1 + ( u + ( u + ( 1 + u ) ) ) ) ) $=
 term-one term-one f-u f-u f-u term-one term-add term-add term-add f-u f-u term-one f-u term-add term-add term-add ctx-empty term-one ctx-empty eq-refl f-u f-u f-u f-u term-one term-add term-add f-u term-one f-u term-add term-add ctx-empty f-u ctx-empty eq-refl f-u f-u f-u term-one term-add term-one f-u term-add ctx-empty f-u ctx-empty eq-refl f-u term-one ctx-empty ax-A2 eq-add-cong eq-add-cong eq-add-cong $.
$}
${
syn-1177 $p term ( ( t * v ) + ( 1 + ( u + ( u + ( 1 + u ) ) ) ) ) $=
 f-t f-v term-mul term-one f-u f-u term-one f-u term-add term-add term-add term-add term-add $.
$}
${
dag-1178 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( u + 1 ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( 1 + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1171 f-t f-u f-v syn-1177 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul term-one f-u f-u f-u term-one term-add term-add term-add term-add term-one f-u f-u term-one f-u term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1176 eq-add-cong eq-add-cong $.
$}
${
syn-1179 $p term ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( 1 + u ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1177 term-add $.
$}
${
syn-1180 $p term ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( 1 + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-u f-v syn-1179 term-add $.
$}
${
dag-1181 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) + 1 ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( 1 + u ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1161 f-t f-u f-v syn-1175 f-t f-u f-v syn-1180 ctx-empty f-t f-u f-v syn-1161 f-t f-u f-v syn-1163 f-t f-u f-v syn-1175 ctx-empty f-t f-u f-v syn-1161 f-t f-u f-v syn-1161 f-t f-u f-v syn-1163 ctx-empty f-t f-u f-v dag-1160 f-t f-v term-mul f-t f-u f-v syn-1154 term-one ctx-empty ax-A1 eq-trans f-t f-u f-v dag-1174 eq-trans f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1173 f-t f-u f-v syn-1179 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1178 eq-add-cong eq-trans $.
$}
${
dag-1182 $p |- [] => ( ( 1 + ( u + ( u + ( 1 + u ) ) ) ) = ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) $=
 term-one term-one f-u f-u term-one f-u term-add term-add term-add f-u term-one f-u f-u term-add term-add term-add ctx-empty term-one ctx-empty eq-refl f-u f-u f-u term-one f-u term-add term-add term-one f-u f-u term-add term-add ctx-empty f-u ctx-empty eq-refl f-u term-one f-u term-add term-add term-one f-u term-add f-u term-add term-one f-u f-u term-add term-add ctx-empty f-u dag-1033 term-one f-u f-u ctx-empty ax-A1 eq-trans eq-add-cong eq-add-cong $.
$}
${
dag-1183 $p |- [] => ( ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + ( 1 + u ) ) ) ) ) ) = ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( 1 + ( u + u ) ) ) ) ) ) ) $=
 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1177 f-t f-u f-v syn-1041 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-v term-mul f-t f-v term-mul term-one f-u f-u term-one f-u term-add term-add term-add term-add term-one f-u term-one f-u f-u term-add term-add term-add term-add ctx-empty f-t f-v term-mul ctx-empty eq-refl f-u dag-1182 eq-add-cong eq-add-cong $.
$}
${
dag-1184 $p |- [] => ( ( ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( u + ( u + u ) ) ) ) ) ) + 1 ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1161 f-t f-u f-v syn-1043 f-t f-u f-v syn-1050 ctx-empty f-t f-u f-v syn-1161 f-t f-u f-v syn-1180 f-t f-u f-v syn-1043 ctx-empty f-t f-u f-v dag-1181 f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1179 f-t f-u f-v syn-1042 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1183 eq-add-cong eq-trans f-t f-v term-mul f-t f-v term-mul f-t f-u f-v syn-1042 f-t f-u f-v syn-1049 ctx-empty f-t f-v term-mul ctx-empty eq-refl f-t f-u f-v dag-1048 eq-add-cong eq-trans $.
$}
${
syn-1185 $p term ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) $=
 f-t f-u f-v syn-1157 term-one term-add $.
$}
${
arith-181 $p |- [] => ( ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) = ( ( t * v ) + ( ( t * v ) + ( ( t * v ) + ( 1 + ( 1 + ( u + ( u + u ) ) ) ) ) ) ) ) $=
 f-t f-u f-v syn-1185 f-t f-u f-v syn-1161 f-t f-u f-v syn-1050 ctx-empty f-t f-u f-v syn-1157 f-t f-u f-v syn-1156 term-one term-one ctx-empty f-t f-u f-v dag-1158 term-one ctx-empty eq-refl eq-add-cong f-t f-u f-v dag-1184 eq-trans $.
$}
${
arith-182 $p |- [] => ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( t * v ) + u ) ) + ( 1 + 1 ) ) = ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-t f-u f-v syn-1051 f-t f-u f-v syn-1050 f-t f-u f-v syn-1185 ctx-empty f-t f-u f-v dag-1052 f-t f-u f-v syn-1185 f-t f-u f-v syn-1050 ctx-empty f-t f-u f-v arith-181 eq-sym eq-trans $.
$}
${
syn-1186 $p wff ( ( ( ( ( 1 + 1 ) + 1 ) * ( ( t * v ) + u ) ) + ( 1 + 1 ) ) = ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-t f-u f-v syn-1051 f-t f-u f-v syn-1185 w-eq $.
$}
${
$d e0 t $.
$d e0 u $.
$d e0 v $.
syn-1187 $p wff ( ( ( ( ( 1 + 1 ) + 1 ) * e0 ) + ( 1 + 1 ) ) = ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-e0 syn-957 f-t f-u f-v syn-1185 w-eq $.
$}
${
syn-1188 $p wff ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-w syn-959 f-t f-u f-v syn-1185 w-eq $.
$}
${
$d e0 t $.
$d e0 u $.
$d e0 v $.
$d e0 w $.
dag-1189 $p |- ( [] ; ( ( t = ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) /\ ( w = ( ( t * v ) + u ) ) ) ) => ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-e0 f-t f-v term-mul f-u term-add f-w f-t f-u f-v f-e0 syn-1187 f-t f-u f-v syn-1186 f-t f-u f-v f-w syn-1188 f-t f-u f-v f-w syn-971 f-w f-t f-v term-mul f-u term-add f-t f-u f-v f-w syn-971 f-t f-u syn-969 f-w f-t f-v term-mul f-u term-add w-eq f-t f-u f-v f-w syn-971 f-t f-u f-v f-w syn-970 ctx-empty nd-assume nd-and-right eq-sym f-e0 f-t f-v term-mul f-u term-add f-e0 syn-957 f-t f-u f-v syn-1185 f-t f-u f-v syn-1051 f-t f-u f-v syn-1185 f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-one term-add f-t f-u f-v syn-973 term-one term-one term-add f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-add f-e0 term-var term-one term-one term-add term-one term-add f-t f-v term-mul f-u term-add f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t f-v term-mul f-u term-add term-one term-one term-one term-one f-e0 f-t f-v term-mul f-u term-add st-one f-e0 f-t f-v term-mul f-u term-add st-one st-add-general f-e0 f-t f-v term-mul f-u term-add st-one st-add-general f-e0 f-t f-v term-mul f-u term-add st-same st-mul-general f-e0 f-t f-v term-mul f-u term-add term-one term-one term-one term-one f-e0 f-t f-v term-mul f-u term-add st-one f-e0 f-t f-v term-mul f-u term-add st-one st-add-general st-add-general f-e0 f-t f-v term-mul f-u term-add f-t f-u f-v syn-1157 term-one f-t f-u f-v syn-1157 term-one f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-add f-u term-mul term-one term-one term-one term-add term-one term-add f-u term-mul term-one f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-add f-u term-one term-one term-add term-one term-add f-u f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t f-v term-mul f-u term-add term-one term-one term-one term-one f-e0 f-t f-v term-mul f-u term-add st-one f-e0 f-t f-v term-mul f-u term-add st-one st-add-general f-e0 f-t f-v term-mul f-u term-add st-one st-add-general f-e0 f-u f-t f-v term-mul f-u term-add st-fresh st-mul-general f-e0 f-t f-v term-mul f-u term-add st-one st-add-general f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-one term-one term-add term-one term-add f-t f-v term-mul f-e0 f-t f-v term-mul f-u term-add term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t f-v term-mul f-u term-add term-one term-one term-one term-one f-e0 f-t f-v term-mul f-u term-add st-one f-e0 f-t f-v term-mul f-u term-add st-one st-add-general f-e0 f-t f-v term-mul f-u term-add st-one st-add-general f-e0 f-t f-v term-mul f-u term-add f-t f-v f-t f-v f-e0 f-t f-t f-v term-mul f-u term-add st-fresh f-e0 f-v f-t f-v term-mul f-u term-add st-fresh st-mul-general st-mul-general st-add-general f-e0 f-t f-v term-mul f-u term-add st-one st-add-general sf-eq f-e0 f-w f-e0 syn-957 f-t f-u f-v syn-1185 f-w syn-959 f-t f-u f-v syn-1185 f-e0 f-w term-one term-one term-add term-one term-add f-e0 term-var term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add f-e0 f-w term-one term-one term-add term-one term-add f-e0 term-var term-one term-one term-add term-one term-add f-w f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-w st-same st-mul-general f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general st-add-general f-e0 f-w f-t f-u f-v syn-1157 term-one f-t f-u f-v syn-1157 term-one f-e0 f-w term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-e0 f-w term-one term-one term-add term-one term-add f-u term-mul term-one term-one term-one term-add term-one term-add f-u term-mul term-one f-e0 f-w term-one term-one term-add term-one term-add f-u term-one term-one term-add term-one term-add f-u f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-u f-w st-fresh st-mul-general f-e0 f-w st-one st-add-general f-e0 f-w term-one term-one term-add term-one term-add f-t f-v term-mul term-one term-one term-add term-one term-add f-t f-v term-mul f-e0 f-w term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-w term-one term-one term-one term-one f-e0 f-w st-one f-e0 f-w st-one st-add-general f-e0 f-w st-one st-add-general f-e0 f-w f-t f-v f-t f-v f-e0 f-t f-w st-fresh f-e0 f-v f-w st-fresh st-mul-general st-mul-general st-add-general f-e0 f-w st-one st-add-general sf-eq f-t f-u f-v syn-1186 f-t f-u f-v f-w syn-971 f-t f-u f-v arith-182 nd-empty-weaken eq-replace $.
$}
${
$d e0 t $.
$d e0 v $.
syn-1190 $p term ( e0 + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) $=
 f-e0 term-var term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-add $.
$}
${
$d e0 t $.
$d e0 v $.
syn-1191 $p term ( ( e0 + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) $=
 f-t f-v f-e0 syn-1190 term-one term-add $.
$}
${
syn-1192 $p term ( t + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) $=
 f-t term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-add $.
$}
${
syn-1193 $p term ( ( t + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) $=
 f-t f-v syn-1192 term-one term-add $.
$}
${
$d e0 t $.
$d e0 v $.
$d e0 w $.
syn-1194 $p wff ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( e0 + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-w syn-959 f-t f-v f-e0 syn-1191 w-eq $.
$}
${
syn-1195 $p wff ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( t + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-w syn-959 f-t f-v syn-1193 w-eq $.
$}
${
$d e0 t $.
$d e0 u $.
$d e0 v $.
$d e0 w $.
dag-1196 $p |- ( [] ; ( ( t = ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) /\ ( w = ( ( t * v ) + u ) ) ) ) => ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( t + ( ( ( 1 + 1 ) + 1 ) * ( t * v ) ) ) + 1 ) ) $=
 f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-t f-t f-v f-w f-e0 syn-1194 f-t f-u f-v f-w syn-1188 f-t f-v f-w syn-1195 f-t f-u f-v f-w syn-971 f-t term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-t f-u f-v f-w syn-971 f-t f-u syn-969 f-w f-t f-v term-mul f-u term-add w-eq f-t f-u f-v f-w syn-971 f-t f-u f-v f-w syn-970 ctx-empty nd-assume nd-and-left eq-sym f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-w syn-959 f-t f-v f-e0 syn-1191 f-w syn-959 f-t f-u f-v syn-1185 f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-w term-one term-one term-add term-one term-add f-w f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-one term-one term-add term-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-one term-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one st-add-general f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one st-add-general f-e0 f-w term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-fresh st-mul-general f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-one term-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one st-add-general st-add-general f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-t f-v f-e0 syn-1190 term-one f-t f-u f-v syn-1157 term-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-e0 term-var term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-same f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-add f-t f-v term-mul term-one term-one term-add term-one term-add f-t f-v term-mul f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-add term-one term-one term-one term-add term-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add term-one term-one term-one term-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one st-add-general f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one st-add-general f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add f-t f-v f-t f-v f-e0 f-t term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-fresh f-e0 f-v term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-fresh st-mul-general st-mul-general st-add-general f-e0 term-one term-one term-add term-one term-add f-u term-mul term-one term-add st-one st-add-general sf-eq f-e0 f-t f-w syn-959 f-t f-v f-e0 syn-1191 f-w syn-959 f-t f-v syn-1193 f-e0 f-t term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add f-e0 f-t term-one term-one term-add term-one term-add f-w term-one term-one term-add term-one term-add f-w f-e0 f-t term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t term-one term-one term-one term-one f-e0 f-t st-one f-e0 f-t st-one st-add-general f-e0 f-t st-one st-add-general f-e0 f-w f-t st-fresh st-mul-general f-e0 f-t term-one term-one term-one term-one f-e0 f-t st-one f-e0 f-t st-one st-add-general st-add-general f-e0 f-t f-t f-v f-e0 syn-1190 term-one f-t f-v syn-1192 term-one f-e0 f-t f-e0 term-var term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-t term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-e0 f-t st-same f-e0 f-t term-one term-one term-add term-one term-add f-t f-v term-mul term-one term-one term-add term-one term-add f-t f-v term-mul f-e0 f-t term-one term-one term-add term-one term-one term-one term-add term-one f-e0 f-t term-one term-one term-one term-one f-e0 f-t st-one f-e0 f-t st-one st-add-general f-e0 f-t st-one st-add-general f-e0 f-t f-t f-v f-t f-v f-e0 f-t f-t st-fresh f-e0 f-v f-t st-fresh st-mul-general st-mul-general st-add-general f-e0 f-t st-one st-add-general sf-eq f-t f-u f-v f-w dag-1189 eq-replace $.
$}
${
$d e1 t $.
$d e1 w $.
syn-1197 $p wff ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( t + e1 ) + 1 ) ) $=
 f-w syn-959 f-t f-e1 term-var term-add term-one term-add w-eq $.
$}
${
$d e1 t $.
$d e1 u $.
$d e1 v $.
$d e1 w $.
dag-1198 $p |- ( [] ; ( ( t = ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) /\ ( w = ( ( t * v ) + u ) ) ) ) => E. e1 ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( t + e1 ) + 1 ) ) $=
 f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-t f-w f-e1 syn-1197 f-t f-v f-w syn-1195 f-t f-u f-v f-w syn-971 f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-w syn-959 f-t f-e1 term-var term-add term-one term-add f-w syn-959 f-t f-v syn-1193 f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add term-one term-one term-add term-one term-add f-w term-mul term-one term-one term-add f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-add term-one term-add f-w term-one term-one term-add term-one term-add f-w f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-add term-one term-one term-one term-add term-one f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-one term-one f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-one f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-one st-add-general f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-one st-add-general f-e1 f-w term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-fresh st-mul-general f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul term-one term-one term-one term-one f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-one f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-one st-add-general st-add-general f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-t f-e1 term-var term-add term-one f-t f-v syn-1192 term-one f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-t f-e1 term-var f-t term-one term-one term-add term-one term-add f-t f-v term-mul term-mul f-e1 f-t term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-fresh f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-same st-add-general f-e1 term-one term-one term-add term-one term-add f-t f-v term-mul term-mul st-one st-add-general sf-eq f-t f-u f-v f-w dag-1196 nd-ex-intro $.
$}
${
syn-1199 $p wff ( t < ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) ) $=
 f-t f-w syn-959 w-lt $.
$}
${
$d e1 t $.
$d e1 w $.
syn-1200 $p wff E. e1 ( ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) = ( ( t + e1 ) + 1 ) ) $=
 f-e1 f-t f-w f-e1 syn-1197 w-ex $.
$}
${
$d e1 t $.
$d e1 u $.
$d e1 v $.
$d e1 w $.
dag-1201 $p |- [] => ( ( ( t = ( ( ( ( 1 + 1 ) + 1 ) * u ) + 1 ) ) /\ ( w = ( ( t * v ) + u ) ) ) -> ( t < ( ( ( ( 1 + 1 ) + 1 ) * w ) + ( 1 + 1 ) ) ) ) $=
 f-t f-u f-v f-w syn-970 f-t f-w syn-1199 ctx-empty f-t f-w f-e1 syn-1200 f-t f-w syn-1199 f-t f-u f-v f-w syn-971 f-t f-w syn-1199 f-t f-w f-e1 syn-1200 f-t f-u f-v f-w syn-971 f-e1 f-t f-w syn-959 f-t f-u f-v f-w syn-971 ax-O7 nd-iff-right f-t f-u f-v f-w f-e1 dag-1198 nd-mp nd-imp-intro $.
$}
