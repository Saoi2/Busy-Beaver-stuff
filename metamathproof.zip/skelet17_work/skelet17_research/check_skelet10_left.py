"""Independent closed-form reconstruction and simulation of four contracts.

Formula comparison permits semiring reassociation of numerical terms, but
requires the same logical structure, ordinary Step, arbitrary-run premise
and endpoint. Metamath alone checks the proof derivations.
"""
from pathlib import Path
import json
from collections import defaultdict
from check_skelet10_scope import parse,plus,times,eq,lt,implies,both,AND,num,step,scan,sparse,table
P=Path(__file__).resolve().parent

def term(pairs):
 parts=[]
 for k,x in pairs:
  if k==0:continue
  parts.append(num(k) if x is None else times(num(k),x) if k!=1 else x)
 out=parts[0] if parts else '0'
 for x in parts[1:]:out=plus(out,x)
 return out
def lin(a=0,b=0,c=0,k=0):return term([(a,'t'),(b,'u'),(c,'v'),(k,None)])
def row(q,l,bit,r):return [num(q),l,bit,r]
x,y,d='t','u','v'
CASES={
 'left-exit-five-step':[
  row(3,lin(2),'0',lin(0,8,4,3)),row(2,x,'0',lin(0,16,8,7)),
  row(4,lin(2,0,0,1),'1',lin(0,8,4,3)),row(1,lin(4,0,0,2),'1',lin(0,4,2,1)),
  row(0,lin(8,0,0,5),'1',lin(0,2,1)),row(0,lin(16,0,0,10),d,y)],
 'left-carry-four-step':[
  row(3,lin(16,0,8,5),'0',y),row(2,lin(8,0,4,2),'1',lin(0,2,0,1)),
  row(3,lin(4,0,2,1),'0',lin(0,4,0,3)),row(2,lin(2,0,1),'1',lin(0,8,0,7)),
  row(3,x,d,lin(0,16,0,15))],
 'return-clear-four-step':[
  row(0,x,'1',lin(0,16,8,7)),row(0,lin(2),'1',lin(0,8,4,3)),
  row(0,lin(4),'1',lin(0,4,2,1)),row(0,lin(8),'1',lin(0,2,1)),row(0,lin(16),d,y)],
 'left-zero-return-to-scan':[
  row(3,lin(2),'0',lin(0,4,0,1)),row(2,x,'0',lin(0,8,0,3)),
  row(4,lin(2,0,0,1),'1',lin(0,4,0,1)),row(1,lin(4,0,0,2),'1',lin(0,2)),
  row(0,lin(8,0,0,5),'0',y)]}

def polynomial(t):
 if isinstance(t,str):return {():int(t)} if t in ('0','1') else {(t,):1}
 op,l,r=t;ll,rr=polynomial(l),polynomial(r);out=defaultdict(int)
 if op=='+':
  for p,k in [*ll.items(),*rr.items()]:out[p]+=k
 elif op=='*':
  for p,k in ll.items():
   for q,j in rr.items():out[tuple(sorted(p+q))]+=k*j
 else:raise AssertionError(op)
 return {p:k for p,k in out.items() if k}
def norm(f):
 op=f[0]
 if op in ('=','<'):return op,tuple(sorted(polynomial(f[1]).items())),tuple(sorted(polynomial(f[2]).items()))
 if op in ('A.','E.'):return op,f[1],norm(f[2])
 if op=='-.':return op,norm(f[1])
 return op,norm(f[1]),norm(f[2])
def tuple_eq(c,n):return AND([eq(a,b) for a,b in zip(c,n)])

def evaluate(t,env):
 if isinstance(t,str):return int(t) if t in ('0','1') else env[t]
 op,a,b=t;l,r=evaluate(a,env),evaluate(b,env)
 return l+r if op=='+' else l*r

def raw_step(c):
 q,l,b,r=c;nq,right,w=table[2*q+b]
 return (nq,2*l+w,r%2,r//2) if right else (nq,l//2,l%2,2*r+w)
def main():
 actual=json.loads((P/'skelet10_left_theorems.json').read_text());assert len(actual)==4
 for name,rows in CASES.items():
  given=[rows[0],*[[f'z10{name}Row{i}{s}' for s in ('Q','L','Bit','R')] for i in range(1,len(rows))]]
  canonical=AND([step(c,n) for c,n in zip(rows,rows[1:])])
  run=AND([step(c,n) for c,n in zip(given,given[1:])])
  end=tuple_eq(given[-1],rows[-1]);prem=lt('v',num(2))
  if name=='left-zero-return-to-scan':prem=sparse('u');end=both(end,scan(given[-1]))
  expected=implies(prem,both(canonical,implies(run,end)))
  label='skelet17-ladder-skelet10-'+name
  assert norm(parse(actual[label]))==norm(expected),label
 
 checked={}
 for name,rows in CASES.items():
  count=0
  for xv in range(16):
   for yv in range(16):
    for dv in ((0,) if name=='left-zero-return-to-scan' else (0,1)):
     if name=='left-zero-return-to-scan' and yv&(yv>>1):continue
     env={'t':xv,'u':yv,'v':dv};numeric=[tuple(evaluate(v,env) for v in c) for c in rows]
     assert all(raw_step(c)==n for c,n in zip(numeric,numeric[1:])),(name,env,numeric)
     if name=='left-zero-return-to-scan':
      q,l,b,r=numeric[-1];assert q==0 and b==0 and r&(r>>1)==0
     count+=1
  checked[name]={'ordinary_steps':len(rows)-1,'interpretation_cases':count,
                 'arbitrary_run_endpoint_checked_in_statement':True}
 result={'machine':'1RB0RA_0LC1RA_1RE1LD_1LC0LD_---0RB',
  'contracts':checked,'all_four_statement_reconstructions_match':True,
  'formula_comparison':'identical logical structure; semiring-normalized arithmetic terms',
  'ordinary_transition_encoding_unchanged':True,'new_induction_needed':False,
  'whole_machine_nonhalting':False,'history_totality_assumed':False,
  'scope':'statement scope and supplementary finite interpretation; derivations separately checked by Metamath'}
 (P/'skelet10_left_checks.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
