"""Independent reconstruction of the bounded greatest-index theorem."""
from pathlib import Path
import json
import check_history_tools as ht
from check_skelet10_scope import both,lt,plus,implies,parse,EX,ALL
from check_skelet10_boundaries import boundary
from check_skelet10_spread import bounded
from check_skelet10_left import norm
P=Path(__file__).resolve().parent;H,N,o=ht.H,ht.N,ht.o
inp='maximumBoundaryInput';row=['maximumBoundaryRow'+s for s in ('Q','L','Bit','R')]
iv,mv,jv=['maximumBoundary'+s for s in ('Index','Greatest','Scan')]
def pred(i):return EX(inp,H,ht.bexs(row,both(ht.at(o,i,row),boundary(inp,row))))
def nonempty(top):return EX(iv,plus(top,'1'),pred(iv))
def body(top,w):return both(pred(w),ALL(jv,plus(top,'1'),implies(pred(jv),lt(jv,plus(w,'1')))))
def maximum(top):return EX(mv,plus(top,'1'),body(top,mv))
expected=implies(nonempty(N),maximum(N))
def main():
 data=json.loads((P/'skelet10_maximum_theorems.json').read_text());label='skelet17-ladder-skelet10-boundary-index-maximum'
 assert set(data)=={label} and norm(parse(data[label]))==norm(expected) and bounded(expected)
 result={'statements_checked':1,'independent_reconstruction_matches':True,'statement_delta0':True,'maximum_not_assumed_as_an_axiom':True,'new_induction_constructions_expected':1,'induction_formula':'nonempty(t) -> maximum(t)','machine_steps_not_premises':True,'whole_machine_nonhalting':False}
 (P/'skelet10_maximum_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':main()
