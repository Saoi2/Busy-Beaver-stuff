"""Keep older proved results in the one canonical file without adding axioms.

Namespacing is textual only. All resulting proofs must pass Metamath.
"""
from pathlib import Path
import sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'bb3_metamath_extension'))
from minimize_library import parse
base=P/'idelta0_machines.mm'
def merge(file,prefix):
 s=(P/file).read_text();records,rules,variables=parse(s)
 trusted={k for k,r in rules.items() if r['kind']=='a'}
 assert len(trusted)==93
 vm={v:prefix+v for v in variables}
 lm={k:(k if k in trusted else prefix+k) for k in rules}
 def expr(xs):return ' '.join(vm.get(x,x) for x in xs)
 with base.open('a') as out:
  out.write('\n$( Preserved results from '+file+'; trusted axioms reused. $)\n')
  for r in records:
   if r['kind']=='v':out.write('$v '+expr(r['expr'])+' $.\n')
   if r['kind']=='f':out.write(lm[r['label']]+' $f '+expr(r['expr'])+' $.\n')
  out.write('${\n')
  for r in records:
   k=r['kind']
   if k in ('c','v','f','a'):continue
   if k in ('{','}'):out.write('$'+k+'\n');continue
   if k=='d':out.write('$d '+expr(r['expr'])+' $.\n');continue
   start=lm[r['label']]+' $'+k+' '+expr(r['expr'])
   if k=='p':
    proof=r['proof']
    if proof[0]=='(':
     j=proof.index(')');pp=['(',*[lm.get(x,x) for x in proof[1:j]],')',*proof[j+1:]]
    else:pp=[lm[x] for x in proof]
    out.write(start+' $=\n '+' '.join(pp)+' $.\n')
   else:out.write(start+' $.\n')
  out.write('$}\n')
 print('Preserved',file,flush=True)
for f,p in [('transitions_checked.mm','oldmachine-'),('emissions_checked.mm','oldemission-'),('gray_syntax_checked.mm','oldsyntax-')]:merge(f,p)
