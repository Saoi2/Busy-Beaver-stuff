"""Low-memory generator bootstrap; the Metamath kernel remains authoritative.

Read statement interfaces and active floating/essential hypotheses without
retaining proof records or their DV sets. New proofs must still be scoped,
kernel-verified, and audited. This does not introduce any trusted rule.
"""
from pathlib import Path
import os
import build_binary as m
P=Path(__file__).resolve().parent
path=Path(os.environ.get('IDELTA0_INPUT',P/'idelta0_machines.mm'))
b,nd=m.b,m.nd
b.lines[:]=[path.read_text()];b.rules.clear();b.metas.clear();b.floats.clear()
def tokens():
 comment=False
 with path.open() as stream:
  for line in stream:
   for token in line.split():
    if comment:
     if token=='$)':comment=False
    elif token=='$(':comment=True
    else:yield token
 assert not comment
it=iter(tokens())
def until(end):
 while True:
  token=next(it)
  if token==end:return
  yield token
active={};order=[];essential=[];scopes=[];serial=0;selected={};count=0
prefixes=('skelet17-','z10-left-instruction-contract-','z10-spread-','z10-inverse-','z10-return-','z10-right-','z10-block-','z10-clear-','z10-full-left-','z10-align-','z10-compose-','z10-maximum-')
for label in it:
 if label=='${':scopes.append((len(order),len(essential)));continue
 if label=='$}':
  nf,ne=scopes.pop()
  while len(order)>nf:active.pop(order.pop())
  del essential[ne:];continue
 if label in ('$c','$v','$d'):list(until('$.'));continue
 assert label!='$[','One standalone database is required'
 kind=next(it);assert kind in ('$f','$e','$a','$p'),(label,kind)
 if kind=='$f':
  typ,name=list(until('$.'));assert name not in active
  active[name]=(typ,label,serial);serial+=1;order.append(name);continue
 if kind=='$e':essential.append((label,tuple(until('$.'))));continue
 expr=list(until('$=') if kind=='$p' else until('$.'))
 used=set(expr)&active.keys()
 for _,e in essential:used.update(set(e)&active.keys())
 mand=sorted(used,key=lambda name:active[name][2]);hs=[e for e,_ in essential]
 b.rules[label]=(' '.join(expr),[' '.join(e) for _,e in essential],mand,hs)
 if kind=='$p':
  count+=1
  if (label.startswith(prefixes) or label=='z10-sparse-rename-bound-variables') and expr[:3]==['|-','[]','=>']:selected[label]=expr[3:]
  for token in until('$.'):pass
assert not scopes
b.metas.update({name:active[name][0] for name in order});b.floats.update({name:active[name][1] for name in order})
def expression(parts):
 cur=iter(parts)
 def take():
  token=next(cur)
  if token=='(':
   lhs=take();op=next(cur);rhs=take();assert next(cur)==')';return (op,lhs,rhs)
  if token in ('A.','E.'):return (token,take(),take())
  if token=='-.':return ('not',take())
  if token=='0':return b.Z
  if token=='1':return b.O
  if token=='[]':return b.NIL
  return (b.metas[token],token)
 out=take();assert next(cur,None) is None;return out
m.theorems.clear();m.theorems.update({name:expression(parts) for name,parts in selected.items()})
vs=[v for v,typ in b.metas.items() if typ=='var']
b.lines.append('$d '+' '.join(vs)+' $.')
b.lines.extend('$d '+v+' '+w+' $.' for v in vs for w,typ in b.metas.items() if typ!='var')
nd.cache.clear();nd.scache.clear();nd.OUTPUT_PREFIX='ladder-z10-';m.a.OUTPUT_PREFIX='ladder-z10-'
for fn in (m.a.associate,m.a.swap_at,m.a.sort_assoc,m.a.normalize):fn.cache_clear()
m.a.proof_ast.clear();olddeclare=m.declare
def declare(name,typ='var'):
 if name in b.metas:assert b.metas[name]==typ;return (typ,name)
 return olddeclare(name,typ)
m.declare=declare
for name in ('e0','e1'):declare(name)
del selected,expr,used,active,order,essential
print('Streaming resume: '+str(count)+' proved interfaces loaded; old proofs retained verbatim.',flush=True)
