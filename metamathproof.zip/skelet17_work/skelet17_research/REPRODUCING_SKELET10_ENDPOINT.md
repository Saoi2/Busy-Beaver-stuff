# Reproducing the final append stages

The authoritative proof is the single standalone idelta0_machines.mm.
It can be checked directly in Metamath with `verify proof *`. Rebuilding
Python generators is not needed to trust or use the formal result.

For development, obtain the following prefixes from the canonical file
by copying exactly the specified initial number of bytes into separate
temporary files. These positions end at complete statement/scope boundaries.

| Stage to generate | Prefix length in bytes |
|---|---:|
| General boundary progress | 933,148,619 |
| Bounded maximum | 950,836,175 |
| Global exclusion and blank endpoint | 971,146,095 |

The first prefix is the preceding verified checkpoint. Its hash is in
preceding_checkpoint_report.json. The maximum prefix hash is in
maximum_append_scope_report.json. The corrected, verified global prefix
hash is in global_scope_report.json. The generator snapshot information
in that report is historical: the final maximum was regenerated against
the project, then the actual combined and standalone files were verified.
No generator snapshot or unproved assertion is a trusted dependency.

Use these project prefixes when reproducing an extension. Metamath's
ordered floating hypotheses depend on declaration order. A proof built
against another development base may need rebasing before it can be merged.

## Progress

Use extract_streaming.py with progress_roots.json on the first prefix.
Run check_progress_base.py on that extraction to scope its DV conditions.
Set IDELTA0_INPUT to the resulting base and run extend_skelet10_progress.py.
Then run check_progress_dependencies.py, the independent statement checker
check_skelet10_progress.py, and the official kernel on the checked result.
The append-only merge utility retains the existing project and adds only
new assertions. Its optional second argument selects another destination
file for a reproduction experiment.

## Maximum

Set IDELTA0_INPUT to the second prefix and run extend_skelet10_maximum.py.
Its raw output is skelet10_maximum_project_extension_raw.mm. Run:

    python3 scope_new_extension.py RAW maximum_append.mm maximum_final_roots.json BASE
    python3 check_skelet10_maximum.py

Here RAW and BASE are the actual raw output and prefix file paths. Check
a temporary Metamath file that includes BASE followed by maximum_append.mm.
The kernel must report no errors and verify every proof. The earlier small
binary development base is not the base used for the final canonical merge.

## Global exclusion and blank start

Set IDELTA0_INPUT to the third prefix and run extend_skelet10_global.py.
Its raw output is skelet10_global_extension_raw.mm. Run:

    python3 scope_new_extension.py RAW global_append.mm global_final_roots.json BASE
    python3 check_skelet10_global.py

Verify a temporary file including BASE and global_append.mm. The scoper
retains only new proof nodes reachable from the two public endpoints,
scopes the existing distinct-variable pairs, and compresses proof labels.
It adds no axiom or inferred proof step. The official kernel checks it.

The current global scope retained 3,172 of 3,235 generated new proof nodes.
Unused intermediates were discarded. Historical complete inputs are kept
for the earlier ladder; this creates no second active mathematical library.

## Checks after an append

Run whole-file Metamath verification before refreshing reports.
refresh_streaming_report.py compares exact previous interfaces and core
signatures. audit_streaming.py decodes actual proof dependencies. Its
registry expects four new interfaces, respectively using 4, 1, 5 and 5
induction constructions. Exactly one newly appended direct induction
construction must belong to the maximum theorem. Numerical case checks
are supplementary and do not replace any kernel or statement check.

These instructions describe regeneration of the append stages. A fresh
whole-project rebuild or whole-file proof-DAG cleanup was not run for
the saved endpoint checkpoint.
